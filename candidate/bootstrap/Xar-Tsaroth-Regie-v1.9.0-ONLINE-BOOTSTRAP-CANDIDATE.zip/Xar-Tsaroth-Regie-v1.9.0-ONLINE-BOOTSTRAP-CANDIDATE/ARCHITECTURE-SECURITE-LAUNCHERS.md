# Architecture cible — Launchers MJ et Joueur

## Décision retenue

La version distribuable utilisera deux applications de bureau **Tauri 2** — `Xar Régie MJ` et `Xar Régie Joueur` — reliées au même backend **Supabase** : Auth, PostgreSQL, Realtime, Storage privé et fonctions serveur.

Le build applicatif 1.9.0 candidate reste volontairement une régie locale/LAN. Il ajoute un mini-installateur à répertoire dédié, sépare durablement programme et données, et réalise le cycle d’auto-update signé avec remplacement atomique et retour de sécurité. Il ne doit toutefois pas être publié tel quel sur Internet : la bascule vers les comptes distants et les exécutables Tauri reste un chantier distinct avant toute diffusion publique.

## Garantie réaliste

Une donnée que l’utilisateur est autorisé à afficher peut toujours être observée sur sa propre machine. La garantie réalisable et obligatoire est donc : **aucune donnée que le joueur n’est pas autorisé à voir n’est envoyée à son application**. Cacher un champ avec du CSS ou du JavaScript ne constitue jamais une protection.

## Flux choisi

```text
Launcher MJ Tauri ───── HTTPS / WSS ─────┐
                                         ├─ Supabase Auth + API/RPC autoritaire
Launcher Joueur Tauri ─ HTTPS / WSS ─────┘               │
                                                         ├─ PostgreSQL + RLS
                                                         ├─ Realtime filtré
                                                         ├─ Storage privé
                                                         └─ Fonctions serveur / secrets
```

- HTTPS et WSS uniquement, avec refus des transports non chiffrés.
- Chaque message temps réel est validé et autorisé ; une connexion ouverte ne donne aucun droit supplémentaire.
- Le serveur est l’unique autorité pour les déplacements, jets, tours, changements de scène, permissions et publications.
- Les mises à jour des launchers sont signées. La clé privée de signature reste hors du dépôt et hors des postes joueurs.

## Comptes et sessions

- Un compte par personne, avec e-mail ou identifiant et mot de passe gérés par Supabase Auth.
- Aucun mot de passe n’est enregistré par la Régie, dans un fichier `.env`, dans le navigateur, dans les logs ou dans une sauvegarde de partie.
- MFA TOTP obligatoire pour les comptes MJ, proposé aux joueurs.
- Jetons courts et renouvellement rotatif ; révocation à la déconnexion, au changement de mot de passe et depuis l’écran d’administration MJ.
- Le refresh token est conservé dans le coffre de secrets du système d’exploitation via Tauri, jamais dans `localStorage`.
- Limitation des tentatives, délai progressif, récupération de compte et journal des connexions.

## Autorisations et séparation des données

PostgreSQL applique des politiques **Row Level Security** sur toutes les tables exposées. Le principe est « refus par défaut », puis autorisations explicites selon la campagne, le rôle et la relation au personnage.

Tables séparées prévues :

- `campaigns` et `campaign_members` : propriétaire MJ et membres invités ;
- `scenes`, `scene_combats`, `initiative_entries` : état de chaque scène ;
- `characters_public` : partie partageable de la fiche ;
- `characters_owner` : partie modifiable par le joueur propriétaire et le MJ ;
- `characters_gm_secret` : secrets visibles uniquement par le MJ ;
- `tokens_public` : apparence et position autorisées ;
- `tokens_private` : PV, mana, dégâts, statistiques et notes MJ non révélés ;
- `token_templates_private` : bestiaire du MJ ;
- `rolls` : portée `public`, `owner` ou `gm` appliquée côté serveur ;
- `media_objects` : métadonnées de fichiers privés et droits d’accès.

Les rôles ou permissions ne sont jamais déduits d’un champ modifiable par le joueur. Une action vérifie à chaque requête : identité, appartenance à la campagne, rôle, propriété du personnage/token et état de la session.

## Temps réel sans fuite

- Le joueur s’abonne uniquement aux lignes qu’il peut lire selon les politiques RLS.
- Les secrets MJ vivent dans des tables distinctes auxquelles le rôle joueur n’a aucun `SELECT`.
- Les captures Discord sont produites côté serveur à partir d’un DTO public, jamais à partir du DOM MJ.
- Le déplacement d’un token passe par une fonction `move_token` qui vérifie le contrôleur, borne les coordonnées et aimante le token à la grille avant écriture.
- Les jets passent par une fonction serveur utilisant un générateur cryptographique et enregistrant l’auteur réel (`MJ` ou nom du joueur).
- Reconnexion et conflits utilisent un numéro de révision par scène et des opérations idempotentes.

## Images, musique et pièces jointes

- Buckets privés ; aucun fichier de campagne sensible n’est public par défaut.
- Téléchargement par URL signée de courte durée ou requête authentifiée.
- Vérification du type réel du fichier, taille maximale, renommage serveur et analyse antivirus avant partage.
- Les clés Discord, OVH et autres secrets d’intégration restent dans les fonctions serveur ou un coffre de secrets. Aucune `service_role`, clé webhook, clé FTP/SFTP ou mot de passe ne doit être compilé dans un launcher.
- Les références ChatGPT restent un flux assisté sans capturer cookies, mot de passe ou session ChatGPT.

## Durcissement des launchers

- Permissions Tauri minimales par fenêtre ; aucune commande système générique exposée au WebView.
- Politique CSP stricte, navigation distante interdite dans la fenêtre principale, ouverture des liens externes via le navigateur du système.
- Installateurs et mises à jour signés ; refus d’une mise à jour sans signature valide.
- Le mini-installateur Node actuel préfigure ce découpage : répertoire du programme distinct du profil de données, fiches jamais incluses dans le remplacement applicatif et retour arrière du code sans retour arrière des données.
- Cache local minimal et chiffré ; aucun secret MJ ni bestiaire privé dans le cache Joueur.
- Effacement du cache de session à la déconnexion et possibilité de révoquer un appareil.

## Tests obligatoires avant ouverture Internet

1. Tests RLS automatisés pour chaque action et chaque rôle, y compris accès horizontal à la fiche d’un autre joueur.
2. Tests prouvant que les réponses Joueur, événements Realtime et URLs médias ne contiennent aucun champ MJ.
3. Tests de falsification d’identifiants, rejeu, déplacement d’un token tiers et changement de rôle.
4. Tests de limites et validation sur chaque message WebSocket et chaque fichier.
5. Analyse de dépendances et de secrets à chaque build, puis audit externe avant la première version publique.
6. Sauvegardes chiffrées, restauration testée, rotation des clés et procédure de réponse à incident.

## Ordre de réalisation

1. Extraire le modèle de données actuel vers PostgreSQL et écrire toutes les politiques RLS.
2. Remplacer les liens contenant des tokens par Auth + invitations de campagne à durée limitée.
3. Déplacer les mutations sensibles vers des fonctions serveur autoritaires.
4. Brancher Realtime, puis vérifier les DTO publics avec des tests de non-divulgation.
5. Emballer l’interface dans les deux launchers Tauri et intégrer le coffre de secrets du système.
6. Signer les installateurs et le canal de mise à jour ; effectuer l’audit avant publication.

## Références de sécurité

- [OWASP — Authorization Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html)
- [OWASP — Authentication Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html)
- [OWASP — Password Storage Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html)
- [OWASP — WebSocket Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/WebSocket_Security_Cheat_Sheet.html)
- [Supabase — Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security)
- [Supabase — sécurisation des données et clés serveur](https://supabase.com/docs/guides/database/secure-data)
- [Supabase — fichiers privés et URLs signées](https://supabase.com/docs/guides/storage/serving/downloads)
- [Tauri 2 — signatures des mises à jour](https://v2.tauri.app/plugin/updater/)
