# Canal de mises à jour de l’application

## État de la 1.9.0 candidate

Le launcher sait désormais effectuer le cycle complet d’une mise à jour applicative : vérifier le manifeste Ed25519, télécharger le ZIP avec une taille maximale, contrôler sa taille et son SHA-256, extraire sans traversée de chemin ni lien symbolique, vérifier le `release-integrity.json` interne, conserver l’ancien programme, remplacer atomiquement l’installation puis relancer le launcher. En cas d’échec après remplacement, il restaure l’ancienne version et la relance.

Le programme et les données sont séparés. Sous Windows, le mini-installateur place l’application dans `%LOCALAPPDATA%\Programs\XarTsarothRegie` tandis que fiches, scènes, médias et configuration restent sous `%LOCALAPPDATA%\XarTsarothRegie`. Une mise à jour ou la suppression du seul dossier du programme ne touche donc pas au travail utilisateur.

Une clé publique Ed25519 dédiée est intégrée dans `application.json`. Sa clé privée n’est présente ni dans le projet, ni dans Git, ni dans le ZIP. L’adresse `updateManifestUrl` reste vide jusqu’à la création du serveur HTTPS séparé prévue au jalon suivant. Le moteur est actif et testé, mais aucun canal distant ne sera annoncé comme opérationnel avant cette connexion réelle.

Empreinte SHA-256 de la clé publique DER intégrée :

```text
41fcfae9169b04ade1ff161b1532badef3b7a6dfcb43572a789ba27514104aab
```

## Contrat du manifeste distant

Le fichier JSON publié en HTTPS doit contenir :

```json
{
  "schemaVersion": 1,
  "applicationId": "fr.xar-tsaroth.regie-du-seuil",
  "channel": "candidate",
  "version": "1.10.0",
  "publishedAt": "2026-08-17T12:00:00.000Z",
  "package": {
    "url": "https://updates.example.invalid/Xar-Tsaroth-Regie-v1.10.0-CANDIDATE.zip",
    "sha256": "empreinte-sha256-du-zip",
    "size": 123456
  },
  "signature": "signature-ed25519-en-base64"
}
```

La signature couvre la représentation canonique produite par `canonicalUpdatePayload()` dans `launcher-core.mjs`. Toute différence d’identité, de canal, de version, d’URL, de taille ou d’empreinte invalide la signature. Le launcher refuse les redirections, HTTP non chiffré, ZIP64, archives multi-volumes, chemins sortant du staging, doublons de nom, liens symboliques, formats de compression inconnus, fichiers privés et fichiers applicatifs absents ou inattendus.

## Cycle d’installation

1. Le launcher vérifie automatiquement le canal au démarrage.
2. L’utilisateur choisit explicitement **Installer la mise à jour** ou **Réparer l’installation**.
3. Le ZIP est téléchargé dans le profil privé et contrôlé avant extraction.
4. Un helper séparé ferme la Régie, extrait et vérifie la nouvelle application.
5. L’ancien dossier applicatif est renommé comme point de retour.
6. Le nouveau build prend atomiquement la place du précédent.
7. Le launcher est relancé au même endroit ; l’interface attend sa reconnexion au lieu d’afficher une page « hors contexte ».
8. En cas d’échec, le helper remet l’ancienne version en place et la relance.

Les données utilisateur ne participent jamais à cet échange. Les migrations de fiches s’exécutent ensuite depuis leur stockage privé et créent leur propre sauvegarde avant conversion.

## Mise en service du futur serveur

1. Héberger séparément, en HTTPS, un manifeste par canal et les ZIP applicatifs complets.
2. Garder la clé privée dans un coffre de publication hors dépôt et hors serveur public.
3. Produire le ZIP final, l’extraire et le retester avant publication.
4. Calculer la taille et le SHA-256 exacts du ZIP, construire le manifeste puis le signer.
5. Publier d’abord le paquet, puis le manifeste signé de façon atomique.
6. Configurer l’URL candidate, tester un passage réel vers un build de test supérieur, puis seulement préparer le canal stable.
7. Tester aussi signature falsifiée, ZIP altéré, coupure réseau, manque d’espace, restauration et conservation des fiches.

Le launcher ne fait jamais `git pull` et n’embarque aucun jeton GitHub. Le dépôt privé conserve le code et l’historique ; le serveur d’update distribue uniquement des artefacts signés.
