import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { chmod, mkdir, mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

async function waitForServer(url, child) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    if (child.exitCode !== null) throw new Error(`Le serveur FTP de test a quitté avec le code ${child.exitCode}.`);
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch {
      // Le serveur démarre encore.
    }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error("Le serveur de test OVH n’a pas démarré.");
}

const fakeCurlSource = `#!/usr/bin/env node
const fs = require("node:fs");
const path = require("node:path");
const args = process.argv.slice(2);
const root = process.env.XAR_FAKE_FTP_ROOT;
const remoteUrl = [...args].reverse().find((value) => /^(?:ftp|ftps|sftp):/.test(value));
if (!root || !remoteUrl) process.exit(2);
if (process.env.XAR_FAKE_CURL_LOG) fs.appendFileSync(process.env.XAR_FAKE_CURL_LOG, JSON.stringify(args) + "\\n");
if (remoteUrl.startsWith("sftp:") && process.env.XAR_FAKE_DISABLE_SFTP === "1") {
  process.stderr.write('curl: (1) Protocol "sftp" is disabled\\n');
  process.exit(1);
}
const parsed = new URL(remoteUrl);
const target = path.join(root, decodeURIComponent(parsed.pathname).replace(/^\\/+/, ""));
const quoteIndex = args.indexOf("--quote");
const uploadIndex = args.indexOf("--upload-file");
const listOnly = args.includes("--list-only");
function missing(code = 78) { process.stderr.write("550 Remote file not found\\n"); process.exit(code); }
function list(directory) {
  if (!fs.existsSync(directory)) missing();
  process.stdout.write(fs.readdirSync(directory).join("\\n") + "\\n");
}
if (quoteIndex >= 0) {
  const command = args[quoteIndex + 1] || "";
  const name = path.basename(command.replace(/^(?:DELE|rm)\\s+/, ""));
  const file = path.join(target, name);
  if (!fs.existsSync(file)) missing(21);
  fs.unlinkSync(file);
  if (listOnly) list(target);
  process.exit(0);
}
if (uploadIndex >= 0) {
  const chunks = [];
  process.stdin.on("data", (chunk) => chunks.push(chunk));
  process.stdin.on("end", () => {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, Buffer.concat(chunks));
  });
} else if (listOnly) {
  list(target);
} else {
  if (!fs.existsSync(target) || !fs.statSync(target).isFile()) missing();
  process.stdout.write(fs.readFileSync(target));
}
`;

const fakeSftpSource = `#!/usr/bin/env node
const fs = require("node:fs");
const path = require("node:path");
const args = process.argv.slice(2);
const root = process.env.XAR_FAKE_FTP_ROOT;
const batchIndex = args.indexOf("-b");
if (!root) process.exit(2);
const commandInput = batchIndex >= 0 && args[batchIndex + 1]
  ? fs.readFileSync(args[batchIndex + 1], "utf8")
  : fs.readFileSync(0, "utf8");
const lines = commandInput.split(/\\r?\\n/).map((line) => line.trim()).filter((line) => line && !/^(?:bye|quit|exit)$/i.test(line));
if (process.env.XAR_FAKE_SFTP_LOG) {
  fs.appendFileSync(process.env.XAR_FAKE_SFTP_LOG, JSON.stringify({ args, lines }) + "\\n");
}
if (process.env.XAR_FAKE_SFTP_CONNECTION_CLOSED === "1") {
  process.stderr.write("Connection closed\\n");
  process.exit(255);
}
function splitCommand(line) {
  const values = [];
  let current = "";
  let quoted = false;
  let escaped = false;
  for (const character of line) {
    if (escaped) {
      current += character;
      escaped = false;
    } else if (character === "\\\\") {
      escaped = true;
    } else if (character === '\"') {
      quoted = !quoted;
    } else if (/\\s/.test(character) && !quoted) {
      if (current) values.push(current);
      current = "";
    } else {
      current += character;
    }
  }
  if (current) values.push(current);
  return values;
}
function remotePath(value) {
  return path.join(root, String(value).replace(/^\\/+/, ""));
}
function missing(value) {
  process.stderr.write("Couldn't stat remote file: No such file or directory: " + value + "\\n");
  process.exit(1);
}
for (const line of lines) {
  const parts = splitCommand(line);
  const command = parts[0];
  if (command === "get") {
    const source = remotePath(parts[1]);
    if (!fs.existsSync(source)) missing(parts[1]);
    fs.mkdirSync(path.dirname(parts[2]), { recursive: true });
    fs.copyFileSync(source, parts[2]);
  } else if (command === "put") {
    const target = remotePath(parts[2]);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(parts[1], target);
  } else if (command === "rm") {
    const target = remotePath(parts[1]);
    if (!fs.existsSync(target)) missing(parts[1]);
    fs.unlinkSync(target);
  } else if (command === "ls") {
    const directory = remotePath(parts.at(-1));
    if (!fs.existsSync(directory)) missing(parts.at(-1));
    process.stdout.write(fs.readdirSync(directory).join("\\n") + "\\n");
  } else {
    process.stderr.write("Commande SFTP de test inconnue : " + line + "\\n");
    process.exit(2);
  }
}
`;

test("le nettoyage OVH replie un curl sans SFTP vers OpenSSH SFTP", async (context) => {
  const work = await mkdtemp(path.join(tmpdir(), "xar-regie-ovh-test-"));
  const fakeBin = path.join(work, "bin");
  const remoteRoot = path.join(work, "remote");
  const remoteDirectory = path.join(remoteRoot, "regie-media");
  const dataDirectory = path.join(work, "data");
  const curlLog = path.join(work, "curl.log");
  const sftpLog = path.join(work, "sftp.log");
  await Promise.all([mkdir(fakeBin), mkdir(remoteDirectory, { recursive: true }), mkdir(dataDirectory)]);
  const fakeCurl = path.join(fakeBin, "curl");
  const fakeSftp = path.join(fakeBin, "sftp");
  await Promise.all([
    writeFile(fakeCurl, fakeCurlSource),
    writeFile(fakeSftp, fakeSftpSource)
  ]);
  await Promise.all([chmod(fakeCurl, 0o755), chmod(fakeSftp, 0o755)]);

  const oldManaged = "xar-regie-v1-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.webp";
  const currentManaged = "xar-regie-v1-bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.webp";
  const legacy = "ancienne-vision-202608161545.webp";
  const manual = "portrait-manuel.webp";
  await Promise.all([
    writeFile(path.join(remoteDirectory, oldManaged), "old"),
    writeFile(path.join(remoteDirectory, currentManaged), "current"),
    writeFile(path.join(remoteDirectory, legacy), "legacy"),
    writeFile(path.join(remoteDirectory, manual), "manual"),
    writeFile(path.join(remoteDirectory, "_xar-regie-media-v1.json"), JSON.stringify({
      schemaVersion: 1,
      files: [
        { id: oldManaged, remoteName: oldManaged, originalName: "ancienne.webp", contentType: "image/webp", size: 3, buildVersion: "1.2.0", createdAt: "2026-08-15T10:00:00.000Z" },
        { id: currentManaged, remoteName: currentManaged, originalName: "courante.webp", contentType: "image/webp", size: 7, buildVersion: "1.9.0", createdAt: "2026-08-16T10:00:00.000Z" }
      ],
      legacySweepAt: null,
      lastCleanupAt: null,
      updatedAt: "2026-08-16T10:00:00.000Z"
    }))
  ]);

  const port = 44000 + Math.floor(Math.random() * 700);
  const child = spawn(process.execPath, ["server.mjs"], {
    cwd: ROOT,
    env: {
      ...process.env,
      PATH: `${fakeBin}${path.delimiter}${process.env.PATH || ""}`,
      PORT: String(port),
      XAR_DATA_DIR: dataDirectory,
      XAR_FAKE_FTP_ROOT: remoteRoot,
      XAR_FAKE_CURL_LOG: curlLog,
      XAR_FAKE_SFTP_LOG: sftpLog,
      XAR_FAKE_DISABLE_SFTP: "1",
      OVH_FTP_URL: "sftp://ftp.cluster129.hosting.ovh.net:22/~/regie-media/",
      OVH_FTP_USER: "test-user",
      OVH_FTP_PASSWORD: "secret-test"
    },
    stdio: ["ignore", "pipe", "pipe"]
  });
  const stderr = [];
  child.stderr.on("data", (chunk) => stderr.push(chunk.toString()));
  context.after(async () => {
    if (child.exitCode === null) child.kill("SIGTERM");
    if (child.exitCode === null) await new Promise((resolve) => child.once("exit", resolve));
    await rm(work, { recursive: true, force: true });
  });

  const base = `http://127.0.0.1:${port}`;
  await waitForServer(`${base}/api/health`, child);
  const foreignCleanup = await fetch(`${base}/api/ovh/cleanup`, {
    method: "POST",
    headers: { Origin: "https://example.invalid", "Content-Type": "text/plain" },
    body: JSON.stringify({ forceLegacy: true })
  });
  assert.equal(foreignCleanup.status, 403);
  assert.equal((await readFile(path.join(remoteDirectory, oldManaged), "utf8")), "old");

  const cleanupResponse = await fetch(`${base}/api/ovh/cleanup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ forceLegacy: false })
  });
  const cleanup = await cleanupResponse.json();
  assert.equal(cleanupResponse.status, 200, stderr.join(""));
  assert.equal(cleanup.cleanup.deletedManaged, 1);
  assert.equal(cleanup.cleanup.deletedLegacy, 1);
  assert.equal(cleanup.cleanup.trackedFiles, 1);

  const afterCleanup = await readdir(remoteDirectory);
  assert.equal(afterCleanup.includes(oldManaged), false);
  assert.equal(afterCleanup.includes(legacy), false);
  assert.equal(afterCleanup.includes(currentManaged), true);
  assert.equal(afterCleanup.includes(manual), true);

  const tinyImage = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADElEQVR42mNk+M8AAAICAQB7CY6aAAAAAElFTkSuQmCC";
  const uploadResponse = await fetch(`${base}/api/ovh/upload`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ imageDataUrl: tinyImage, filename: "nouvelle-vision.webp" })
  });
  const upload = await uploadResponse.json();
  assert.equal(uploadResponse.status, 200, stderr.join(""));
  assert.match(upload.filename, /^xar-regie-v1-[a-f0-9]{32}\.png$/);
  assert.ok((await readFile(path.join(remoteDirectory, upload.filename))).length > 20);

  const savedManifest = JSON.parse(await readFile(path.join(remoteDirectory, "_xar-regie-media-v1.json"), "utf8"));
  assert.equal(savedManifest.files.length, 2);
  assert.equal(savedManifest.files.every((entry) => entry.buildVersion === "1.9.0"), true);
  assert.equal((await readFile(path.join(remoteDirectory, manual), "utf8")), "manual");

  const curlCalls = (await readFile(curlLog, "utf8")).trim().split("\n").map(JSON.parse);
  assert.ok(curlCalls.some((args) => args.some((value) => value.startsWith("sftp:"))));
  assert.equal(curlCalls.some((args) => args.some((value) => value.startsWith("ftp:"))), false);

  const sftpCalls = (await readFile(sftpLog, "utf8")).trim().split("\n").map(JSON.parse);
  const sftpCommands = sftpCalls.flatMap((entry) => entry.lines);
  assert.equal(sftpCalls.some((entry) => entry.args.includes("-b")), false);
  assert.ok(sftpCommands.some((line) => line.startsWith("get ")));
  assert.ok(sftpCommands.some((line) => line.startsWith("rm ")));
  assert.ok(sftpCommands.some((line) => line.startsWith("put ")));
  assert.ok(sftpCommands.some((line) => line.startsWith("ls -1 ")));
  assert.ok(sftpCommands.some((line) => line.includes("regie-media")));
  assert.equal(sftpCommands.some((line) => line.includes("/~/")), false);
  assert.equal(JSON.stringify(sftpCalls).includes("secret-test"), false);
});

test("un refus de connexion OVH distingue la session du chemin distant", async (context) => {
  const work = await mkdtemp(path.join(tmpdir(), "xar-regie-ovh-closed-test-"));
  const fakeBin = path.join(work, "bin");
  const remoteRoot = path.join(work, "remote");
  const dataDirectory = path.join(work, "data");
  await Promise.all([mkdir(fakeBin), mkdir(remoteRoot), mkdir(dataDirectory)]);
  const fakeCurl = path.join(fakeBin, "curl");
  const fakeSftp = path.join(fakeBin, "sftp");
  await Promise.all([
    writeFile(fakeCurl, fakeCurlSource),
    writeFile(fakeSftp, fakeSftpSource)
  ]);
  await Promise.all([chmod(fakeCurl, 0o755), chmod(fakeSftp, 0o755)]);

  const port = 44700 + Math.floor(Math.random() * 200);
  const child = spawn(process.execPath, ["server.mjs"], {
    cwd: ROOT,
    env: {
      ...process.env,
      PATH: `${fakeBin}${path.delimiter}${process.env.PATH || ""}`,
      PORT: String(port),
      XAR_DATA_DIR: dataDirectory,
      XAR_FAKE_FTP_ROOT: remoteRoot,
      XAR_FAKE_DISABLE_SFTP: "1",
      XAR_FAKE_SFTP_CONNECTION_CLOSED: "1",
      OVH_FTP_URL: "sftp://ftp.cluster129.hosting.ovh.net:22/~/regie-media/",
      OVH_FTP_USER: "xartsaf-test",
      OVH_FTP_PASSWORD: "secret-test"
    },
    stdio: ["ignore", "pipe", "pipe"]
  });
  context.after(async () => {
    if (child.exitCode === null) child.kill("SIGTERM");
    if (child.exitCode === null) await new Promise((resolve) => child.once("exit", resolve));
    await rm(work, { recursive: true, force: true });
  });

  const base = `http://127.0.0.1:${port}`;
  await waitForServer(`${base}/api/health`, child);
  const response = await fetch(`${base}/api/ovh/cleanup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ forceLegacy: false })
  });
  const result = await response.json();
  assert.equal(response.status, 500);
  assert.match(result.error, /session SFTP OpenSSH/i);
  assert.match(result.error, /xartsaf-test/);
  assert.match(result.error, /port 22/i);
  assert.match(result.error, /non le chemin regie-media/i);
  assert.equal(result.error.includes("secret-test"), false);
});
