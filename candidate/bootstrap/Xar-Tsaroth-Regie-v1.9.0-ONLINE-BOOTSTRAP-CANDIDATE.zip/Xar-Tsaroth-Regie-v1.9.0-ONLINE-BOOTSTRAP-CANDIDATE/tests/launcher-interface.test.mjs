import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("les démarrages passent par le launcher applicatif et exposent les contrôles attendus", async () => {
  const [html, css, client, launcher, updater, windowsStart, unixStart, packageJson, application] = await Promise.all([
    readFile(path.join(ROOT, "launcher", "index.html"), "utf8"),
    readFile(path.join(ROOT, "launcher", "launcher.css"), "utf8"),
    readFile(path.join(ROOT, "launcher", "launcher.js"), "utf8"),
    readFile(path.join(ROOT, "launcher.mjs"), "utf8"),
    readFile(path.join(ROOT, "updater-core.mjs"), "utf8"),
    readFile(path.join(ROOT, "start-windows.bat"), "utf8"),
    readFile(path.join(ROOT, "start.sh"), "utf8"),
    readFile(path.join(ROOT, "package.json"), "utf8").then(JSON.parse),
    readFile(path.join(ROOT, "application.json"), "utf8").then(JSON.parse)
  ]);
  assert.match(html, /Entrer dans la Régie/);
  assert.match(html, /Vérifier les mises à jour/);
  assert.match(html, /Vérifier l’intégrité/);
  assert.match(html, /Retélécharger/);
  assert.match(html, /Installer la mise à jour/);
  assert.match(html, /Régie du Seuil · v\{\{APP_VERSION\}\} candidate/);
  assert.match(html, /<progress[^>]+id="launchProgress"/);
  assert.match(html, /aria-live="polite"/);
  assert.match(css, /regie-chamber\.webp/);
  assert.match(css, /prefers-reduced-motion/);
  assert.match(client, /api\/install-update/);
  assert.match(launcher, /verifyInstallation/);
  assert.match(launcher, /fetchSignedUpdateManifest/);
  assert.match(launcher, /launchUpdaterAndExit/);
  assert.match(updater, /renameSync\(root, backup\)/);
  assert.match(updater, /verifyInstallation\(root\)/);
  assert.match(windowsStart, /node installer\.mjs/);
  assert.match(unixStart, /node installer\.mjs/);
  assert.equal(packageJson.scripts.start, "node installer.mjs");
  assert.equal(packageJson.scripts["start:launcher"], "node launcher.mjs");
  assert.equal(packageJson.version, application.version);
});
