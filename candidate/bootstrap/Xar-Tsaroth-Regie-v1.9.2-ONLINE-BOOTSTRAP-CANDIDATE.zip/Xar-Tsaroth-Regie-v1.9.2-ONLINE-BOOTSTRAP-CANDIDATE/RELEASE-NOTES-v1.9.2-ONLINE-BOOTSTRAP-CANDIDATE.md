# Régie du Seuil 1.9.2 — Bootstrap candidate

## But de ce paquet

Ce bootstrap remplace le paquet 1.9.0 qui pouvait être refusé après une extraction Windows. Il installe une version 1.9.2 corrigée, puis permet de tester immédiatement l’auto-update signé vers la 1.9.3 candidate.

## Correctif Windows

- Les fichiers `desktop.ini` ajoutés par l’Explorateur sont traités comme métadonnées système inoffensives.
- Le contrôle continue de refuser tout fichier applicatif absent, modifié ou injecté.
- Si un écart réel subsiste, le message affiche le nom du fichier concerné et rappelle de décompresser entièrement l’archive.

## Statut

Ce paquet est un **bootstrap candidate** destiné à la validation du parcours d’installation et de mise à jour. La 1.8.0 reste la dernière version stable explicitement validée.
