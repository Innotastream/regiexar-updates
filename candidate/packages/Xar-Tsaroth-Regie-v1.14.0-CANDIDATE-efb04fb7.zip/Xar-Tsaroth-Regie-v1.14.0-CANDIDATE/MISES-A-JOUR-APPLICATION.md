# Canal de mises à jour de l’application

## État de la 1.14.0 candidate

La 1.14.0 part de la 1.13.2 candidate, elle-même issue de la 1.13.1 stable. Son installeur Windows exige une signature Authenticode valide, demande l’élévation administrateur, installe l’enveloppe pour tous les comptes et utilise par défaut `C:\Program Files\Xar-Tsaroth`. La page de choix entre installation personnelle et installation pour tous n’est plus affichée. Les données privées restent séparées par profil Windows et ne sont pas supprimées lors d’une désinstallation.

Le programme, le contenu applicatif actualisable et les données sont séparés. L’enveloppe Windows vit dans son dossier de programme ; le contenu applicatif actif vit sous `%LOCALAPPDATA%\XarTsarothRegie\app` ; fiches, scènes, médias, comptes et configuration restent sous `%LOCALAPPDATA%\XarTsarothRegie`. Une mise à jour remplace uniquement `app`. Les migrations de fiches travaillent sur le stockage persistant et sauvegardent l’ancien format avant conversion.

Le launcher n’exige plus de fichier `.env` ni de code joueurs global. La console locale protégée crée les comptes joueurs/MJ et valide Discord ou OVH. Les mots de passe sont des vérificateurs scrypt salés ; les secrets relisibles restent dans le coffre AES-256-GCM. Un ancien `.env.local` est migré une fois puis supprimé. Les secrets déjà enregistrés ne sont jamais renvoyés par l’API de statut ni réaffichés dans l’interface.

Le bouton **Vérifier les fichiers** compare l’installation au manifeste du build et supprime les reliquats applicatifs inattendus. Avant ce contrôle, toute donnée historique trouvée dans le dossier du programme est sauvegardée et migrée vers le profil privé. Les boutons **Exporter mes données** et **Réintégrer mes données** utilisent une archive contrôlée qui exclut comptes, vérificateurs, coffre et configuration.

L’enveloppe lance le serveur dans un processus utilitaire séparé. Pendant une mise à jour, ce processus s’arrête, un helper indépendant vérifie et remplace atomiquement le contenu applicatif, puis l’enveloppe redémarre la nouvelle version et reconnecte la fenêtre existante. Les renommages retentent les verrous temporaires `EBUSY`, `EPERM`, `EACCES` et `ENOTEMPTY`. En cas d’échec, l’ancien contenu applicatif est remis en place.

Le contrôle du paquet tolère uniquement les fichiers système inoffensifs connus que Windows peut créer lors de l’extraction, comme `desktop.ini`. Toute absence, modification ou injection applicative demeure bloquante et l’installateur affiche maintenant les chemins concernés au lieu d’un refus générique.

Les liens ChatGPT ne naviguent pas dans la fenêtre Electron : une route locale, protégée par l’origine et une liste d’autorisation stricte, demande au système de les ouvrir dans le navigateur habituel afin de conserver la session Google et l’extension Xar existantes. L’interface Electron fonctionne avec `nodeIntegration: false`, `contextIsolation: true` et le bac à sable Chromium actif.

Une clé publique Ed25519 dédiée est intégrée dans `application.json`. Sa clé privée n’est présente ni dans le projet, ni dans Git, ni dans le ZIP. Le canal candidate utilise `https://raw.githubusercontent.com/Innotastream/regiexar-updates/main/candidate/latest.json`. Ce dépôt public contient seulement les ZIP distribuables et leurs manifestes signés ; le code source reste dans `Innotastream/regiexar`, qui demeure privé.

La clé privée historique des versions 1.9.1 à 1.13.0 n’étant plus récupérable, la 1.13.1 réalise une rotation explicite. Les anciennes installations ne peuvent pas authentifier cette nouvelle paire : la 1.13.1 doit être installée manuellement une seule fois. Sa clé privée correspondante est vérifiée par GitHub Actions, conservée comme secret du dépôt source privé et sauvegardée séparément sous forme chiffrée. Aucun repli vers un manifeste non signé n’est autorisé.

Empreinte SHA-256 de la clé publique DER intégrée :

```text
3778f6c07a227603d28bf062b2a4478d30d5d1e19bfbc61da82d38fd34fafb3e
```

## Contrat du manifeste distant

Le fichier JSON publié en HTTPS doit contenir :

```json
{
  "schemaVersion": 1,
  "applicationId": "fr.xar-tsaroth.regie-du-seuil",
  "channel": "candidate",
  "version": "1.14.0",
  "publishedAt": "2026-08-17T12:00:00.000Z",
  "package": {
    "url": "https://raw.githubusercontent.com/Innotastream/regiexar-updates/main/candidate/packages/Xar-Tsaroth-Regie-v1.14.0-CANDIDATE-empreinte.zip",
    "sha256": "empreinte-sha256-du-zip",
    "size": 123456
  },
  "signature": "signature-ed25519-en-base64"
}
```

La signature couvre la représentation canonique produite par `canonicalUpdatePayload()` dans `launcher-core.mjs`. Toute différence d’identité, de canal, de version, d’URL, de taille ou d’empreinte invalide la signature. Il s’agit d’un contrôle automatique de sécurité, pas d’une validation manuelle du build. Dès qu’une version viable plus récente est publiée sur le canal configuré, elle est installable, même si plusieurs numéros de version ont été sautés. Le launcher refuse les redirections, HTTP non chiffré, ZIP64, archives multi-volumes, chemins sortant du staging, doublons de nom, liens symboliques, formats de compression inconnus, fichiers privés et fichiers applicatifs absents ou inattendus.

## Cycle d’installation

1. Le launcher vérifie automatiquement le canal au démarrage.
2. L’utilisateur choisit explicitement **Installer la mise à jour** ou **Réparer l’installation**.
3. Le ZIP est téléchargé dans le profil privé et contrôlé avant extraction. Un transfert incomplet est automatiquement retenté jusqu’à trois fois sans toucher à la version installée.
4. Un helper séparé ferme le processus local, extrait et vérifie la nouvelle application tandis que la fenêtre Windows reste ouverte.
5. L’ancien dossier applicatif est renommé comme point de retour.
6. Le nouveau build prend atomiquement la place du précédent.
7. L’enveloppe Windows redémarre le launcher mis à jour, attend la réponse de la Régie puis réutilise la même fenêtre.
8. Après contrôle, la fenêtre passe automatiquement à la version viable. En cas d’échec, le helper remet l’ancienne version en place et l’enveloppe la relance.

Les données utilisateur ne participent jamais à cet échange. Les migrations de fiches s’exécutent ensuite depuis leur stockage privé et créent leur propre sauvegarde avant conversion.

## Procédure de publication du canal

1. Héberger séparément, en HTTPS, un manifeste par canal et les ZIP applicatifs complets.
2. Garder la clé privée dans un coffre de publication hors dépôt et hors serveur public.
3. Régénérer l’intégrité puis produire le ZIP complet avec `node scripts/package-release.mjs <livraison.zip>`. Ce générateur prend uniquement les fichiers couverts par la livraison, y compris les ressources publiques de l’installeur, et exclut automatiquement `.github`, `release-publish-request.json`, les secrets et les données privées. Extraire ce ZIP et exécuter tous les tests.
4. Produire séparément le paquet rétrocompatible avec `node scripts/package-release.mjs <mise-a-jour.zip> --update-compatible`. Son manifeste d’intégrité exclut les ressources `build/` que l’updater 1.13.1 refuse, sans les retirer du ZIP complet de livraison.
5. Nommer le paquet d’auto-update avec une partie de son empreinte afin que son adresse soit immuable ; ne jamais remplacer silencieusement un fichier déjà annoncé.
6. Calculer sa taille et son SHA-256 exacts, construire le manifeste puis le signer.
7. Publier d’abord le paquet. Après signature du manifeste de prépublication, le retélécharger depuis son adresse GitHub publique et vérifier sa taille, son SHA-256, son extraction et son manifeste interne avec `node scripts/verify-signed-package.mjs <latest-signe.json>`.
8. Tant que `latest.json` annonce encore la version précédente, exécuter `node scripts/verify-update-compatibility.mjs <latest-signe.json>`. Ce contrôle télécharge la version distribuée et utilise son propre `launcher-core.mjs` pour accepter ou refuser le nouveau paquet.
9. Publier seulement après ces contrôles le manifeste `latest.json`, puis exécuter `node scripts/verify-published-update.mjs` contre le canal définitif. Le workflow de signature échoue explicitement si la demande de publication manque ; un succès avec signature sautée est interdit.
10. Toute candidate viable publiée est immédiatement proposée par l’application. La qualification **stable** reste une décision de livraison distincte et ne participe pas au mécanisme d’acceptation du launcher.
11. Tester aussi signature falsifiée, ZIP altéré, coupure réseau, manque d’espace, restauration et conservation des fiches.

Le launcher ne fait jamais `git pull` et n’embarque aucun jeton GitHub. Le dépôt privé conserve le code et l’historique ; `regiexar-updates` distribue uniquement des artefacts signés publiquement accessibles.
