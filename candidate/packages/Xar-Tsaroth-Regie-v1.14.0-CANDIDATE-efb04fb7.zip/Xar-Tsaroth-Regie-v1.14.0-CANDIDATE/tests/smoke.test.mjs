import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { AccountStore } from "../account-store.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const APPLICATION_VERSION = JSON.parse(await readFile(path.join(ROOT, "application.json"), "utf8")).version;
const GM_PASSWORD = "Mot-de-passe-MJ-test-2026!";
const PLAYER_PASSWORD = "Mot-de-passe-joueur-test-2026!";
let MJ_SESSION_TOKEN = "";
let ALICE_SESSION_TOKEN = "";
let BOB_SESSION_TOKEN = "";

function mjFetch(url, options = {}) {
  return fetch(url, {
    ...options,
    headers: { "X-Xar-Session": MJ_SESSION_TOKEN, ...(options.headers ?? {}) }
  });
}

function playerFetch(sessionToken, url, options = {}) {
  return fetch(url, {
    ...options,
    headers: { "X-Xar-Session": sessionToken, ...(options.headers ?? {}) }
  });
}

async function login(base, username, password, scope) {
  const response = await fetch(`${base}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password, scope })
  });
  const payload = await response.json();
  assert.equal(response.status, 200, payload.error);
  assert.ok(payload.sessionToken);
  return payload.sessionToken;
}

async function waitForServer(url, child) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    if (child.exitCode !== null) throw new Error(`Le serveur a quitté avec le code ${child.exitCode}.`);
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch {
      // Le port n’est pas encore prêt.
    }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error("Le serveur de test n’a pas démarré.");
}

function testState() {
  return {
    schemaVersion: 8,
    revision: 1,
    session: { name: "Test du Seuil", gmName: "MJ", phase: "Mode libre" },
    scenes: [{ id: "scene-1", name: "Scène 1", subtitle: "Test", description: "Visible" }],
    activeSceneId: "scene-1",
    activeScene: { id: "scene-1", name: "Scène 1", description: "Visible" },
    players: [
      { id: "player-a", name: "Alice", accessToken: "token-alice", _updatedAt: 1 },
      { id: "player-b", name: "Bob", accessToken: "token-bob", _updatedAt: 1 }
    ],
    characters: [
      {
        id: "character-a", ownerPlayerId: "player-a", name: "Hira", color: "#c94452", portrait: null,
        resources: { hp: 12, maxHp: 20, mana: 4, maxMana: 9 }, stats: { force: 61, instinct: 72 }, fatigue: { current: 2, max: 100 },
        conditions: [], publicNotes: "Visible", secret: { mentalResistance: 44, notes: "Secret absolu" },
        shortcuts: [{ id: "initiative-a", label: "Initiative", formula: "1d100+4", kind: "initiative", visibility: "public" }],
        _updatedAt: 1
      },
      {
        id: "character-b", ownerPlayerId: "player-b", name: "Krael", color: "#63c9ee", portrait: null,
        resources: { hp: 19, maxHp: 24, mana: 0, maxMana: 0 }, stats: {}, fatigue: { current: 0, max: 100 },
        conditions: [], publicNotes: "Autre fiche", secret: { mentalResistance: 20, notes: "Autre secret" }, shortcuts: [], _updatedAt: 1
      }
    ],
    map: {
      background: null, naturalWidth: 1600, naturalHeight: 900, zoom: 1.7, panX: 12, panY: -8, grid: true, gridSize: 120, gridOpacity: 31,
      tokens: [
        { id: "token-a", characterId: "character-a", controllerPlayerId: "player-a", followCharacter: true, name: "Hira", color: "#c94452", x: 25, y: 35, size: 74, hp: 12, maxHp: 20, mana: 4, maxMana: 9, damageDice: "2d6+4", stats: [{ id: "force", label: "Force", value: "61" }], initiative: 82, hidden: false, gmNotes: "Piège", _updatedAt: 1, _movedAt: 1 },
        { id: "token-a-custom", characterId: "character-a", controllerPlayerId: "player-a", followCharacter: false, name: "Double de Hira", color: "#ffffff", x: 30, y: 35, size: 52, hp: 99, maxHp: 99, initiative: 1, hidden: false, _updatedAt: 1, _movedAt: 1 },
        { id: "token-b", characterId: "character-b", controllerPlayerId: "player-b", followCharacter: true, name: "Krael", color: "#63c9ee", x: 70, y: 52, size: 62, hp: 19, maxHp: 24, initiative: 67, hidden: false, _updatedAt: 1, _movedAt: 1 },
        { id: "token-secret", controllerPlayerId: "player-a", name: "Ombre", x: 50, y: 50, size: 62, hidden: true, gmNotes: "Invisible", _updatedAt: 1, _movedAt: 1 },
        { id: "token-npc-private", controllerPlayerId: null, name: "Garde secret", x: 55, y: 45, size: 30, hp: 40, maxHp: 40, mana: 8, maxMana: 10, damageDice: "2d8+2", condition: "Enragé", stats: [{ id: "vigueur", label: "Vigueur", value: "70" }], notes: "Résiste au feu", gmNotes: "Fuit à 5 PV", revealDetailsToPlayers: false, hidden: false, _updatedAt: 1, _movedAt: 1 },
        { id: "token-npc-shared", controllerPlayerId: null, name: "Allié partagé", x: 60, y: 45, size: 30, hp: 18, maxHp: 24, mana: 3, maxMana: 7, damageDice: "1d8+1", condition: "Inspiré", stats: [{ id: "soin", label: "Soin", value: "65" }], notes: "Soigneur", gmNotes: "Secret MJ partagé interdit", revealDetailsToPlayers: true, hidden: false, _updatedAt: 1, _movedAt: 1 }
      ]
    },
    initiative: { order: [], currentIndex: 0, round: 1, active: false, turnsStarted: false, _updatedAt: 1 },
    tacticalSync: { paused: false, pausedAt: null, playerMovementMode: "free", publishedMap: null, publishedInitiative: null, publishedActiveScene: null },
    actionTimers: [],
    actionTimerTombstones: [],
    tokenLibrary: [{ id: "template-secret", name: "Démon archivé", gmNotes: "BestiaireSecret", hp: 99, maxHp: 99, damageDice: "4d10", size: 60 }],
    shortcuts: [{ id: "perception", label: "Perception", formula: "1d100", visibility: "public" }],
    rolls: [
      { id: "public", label: "Dégâts", formula: "1d6", total: 4, visibility: "public", revealed: true },
      { id: "gm", label: "Perception", formula: "1d100", total: 17, visibility: "gm", revealed: false },
      { id: "queued", label: "Présage", formula: "1d100", total: 66, visibility: "queued", revealed: false }
    ],
    tracks: [],
    audio: {
      masterVolume: 70, musicVolume: 72, ambienceVolume: 48, muted: false,
      music: { trackId: null, playing: false, position: 0, startedAt: null },
      ambience: { trackId: null, playing: false, position: 0, startedAt: null }
    },
    forge: { imageDataUrl: null, prompt: "", revisedPrompt: null }
  };
}

test("régie collaborative : sécurité, fiches, tokens, média et persistance", async (context) => {
  const port = 43100 + Math.floor(Math.random() * 900);
  const dataDirectory = await mkdtemp(path.join(tmpdir(), "xar-regie-test-"));
  const accounts = new AccountStore(path.join(dataDirectory, "accounts.json"));
  await accounts.create({ username: "maitre-jeu", displayName: "MJ", password: GM_PASSWORD, role: "gm" });
  await accounts.create({ id: "player-a", username: "alice", displayName: "Alice", password: PLAYER_PASSWORD, role: "player" });
  await accounts.create({ id: "player-b", username: "bob", displayName: "Bob", password: PLAYER_PASSWORD, role: "player" });
  const child = spawn(process.execPath, ["server.mjs"], {
    cwd: ROOT,
    env: { ...process.env, PORT: String(port), XAR_DATA_DIR: dataDirectory },
    stdio: ["ignore", "pipe", "pipe"]
  });
  const stderr = [];
  child.stderr.on("data", (chunk) => stderr.push(chunk.toString()));
  context.after(async () => {
    if (child.exitCode === null) child.kill("SIGTERM");
    if (child.exitCode === null) await new Promise((resolve) => child.once("exit", resolve));
    await rm(dataDirectory, { recursive: true, force: true });
  });

  const base = `http://127.0.0.1:${port}`;
  await waitForServer(`${base}/api/health`, child);
  MJ_SESSION_TOKEN = await login(base, "maitre-jeu", GM_PASSWORD, "gm");
  ALICE_SESSION_TOKEN = await login(base, "alice", PLAYER_PASSWORD, "player");
  BOB_SESSION_TOKEN = await login(base, "bob", PLAYER_PASSWORD, "player");

  const health = await fetch(`${base}/api/health`).then((response) => response.json());
  assert.equal(health.ok, true);
  assert.equal(health.accountAccessProtected, true);
  assert.equal(health.liveSync, true);
  assert.equal(health.mediaSharing, true);
  assert.equal(health.services.chatgptAssist, true);
  assert.equal(health.services.chatgptBridge, false);
  assert.equal(health.chatgptBridge.configuredConversations, 0);
  assert.equal(health.ovhMediaCleanup.automatic, true);
  assert.equal(health.ovhMediaCleanup.buildVersion, APPLICATION_VERSION);
  assert.equal(health.application.version, APPLICATION_VERSION);
  assert.equal(health.application.channel, "candidate");
  assert.equal(health.characterStorage.mode, "per-user-files");
  assert.equal(health.characterStorage.characterSchemaVersion, 2);
  assert.equal("openai" in health.services, false);
  assert.equal((await fetch(`${base}/`)).status, 200);
  assert.equal((await fetch(`${base}/api/session/full`)).status, 403);
  assert.equal((await fetch(`${base}/api/system/player-access-code`)).status, 404);

  const foreignChatGptOpen = await fetch(`${base}/api/system/open-chatgpt`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Origin: "https://evil.example" },
    body: JSON.stringify({ url: "https://chatgpt.com/" })
  });
  assert.equal(foreignChatGptOpen.status, 403);
  const invalidChatGptOpen = await mjFetch(`${base}/api/system/open-chatgpt`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url: "https://chatgpt.com.evil.example/c/faux" })
  });
  assert.equal(invalidChatGptOpen.status, 400);

  const cacheProbe = await fetch(`${base}/app.js`);
  assert.equal(cacheProbe.headers.get("cache-control"), "no-store");

  const [gmHtml, playerHtml, appModule, geometryModule, artwork, extensionManifest, extensionWorker, startUnix, ovhRegistry] = await Promise.all([
    mjFetch(`${base}/`).then((response) => response.text()),
    fetch(`${base}/player.html`).then((response) => response.text()),
    fetch(`${base}/app.js`).then((response) => response.text()),
    fetch(`${base}/map-geometry.js`).then((response) => response.text()),
    fetch(`${base}/assets/regie-chamber_1f146e88.webp`).then((response) => response.arrayBuffer()),
    readFile(path.join(ROOT, "extension-chatgpt-xar", "manifest.json"), "utf8").then(JSON.parse),
    readFile(path.join(ROOT, "extension-chatgpt-xar", "service-worker.js"), "utf8"),
    readFile(path.join(ROOT, "start.sh"), "utf8"),
    readFile(path.join(ROOT, "ovh-media-registry.mjs"), "utf8")
  ]);
  assert.match(gmHtml, /Tour précédent/);
  assert.match(gmHtml, /Zoom de la map/);
  assert.match(gmHtml, /Préparer dans ChatGPT/);
  assert.match(gmHtml, /Références personnages/);
  assert.match(gmHtml, /Bestiaire · 0/);
  assert.match(gmHtml, /Préparation secrète/);
  assert.match(gmHtml, /Mode libre/);
  assert.match(gmHtml, /Calculatrice rapide/);
  assert.match(gmHtml, /Pourcentage d’un nombre/);
  assert.match(gmHtml, /Démarrer le combat/);
  assert.match(gmHtml, /Actions & recharges/);
  assert.match(gmHtml, /Nettoyer maintenant/);
  assert.match(playerHtml, /Activer le son/);
  assert.match(playerHtml, /Mes personnages/);
  assert.match(playerHtml, /Créer une fiche/);
  assert.match(playerHtml, /Couper/);
  assert.match(playerHtml, /Ajouter au round actuel/);
  assert.match(appModule, /Keyrie: "#4da467"/);
  assert.match(appModule, /Vraska: "#a84e1b"/);
  assert.match(appModule, /name: `Scène \$\{index \+ 1\}`/);
  assert.match(appModule, /https:\/\/chatgpt\.com\//);
  assert.match(appModule, /\/api\/chatgpt-bridge\/jobs/);
  assert.match(appModule, /\/api\/system\/open-chatgpt/);
  assert.match(appModule, /\/api\/ovh\/cleanup/);
  assert.match(appModule, /switchSceneCombat/);
  assert.match(appModule, /saveTokenToLibrary/);
  assert.doesNotMatch(appModule, /\/api\/openai\/generate/);
  assert.match(geometryModule, /computeMapGeometry/);
  assert.equal(Buffer.from(artwork).subarray(8, 12).toString(), "WEBP");
  assert.equal(extensionManifest.manifest_version, 3);
  assert.deepEqual(extensionManifest.permissions, ["storage"]);
  assert.doesNotMatch(extensionWorker, /cookies\.|chrome\.cookies/);
  assert.match(startUnix, /node installer\.mjs/);
  assert.match(ovhRegistry, /xar-regie-v1-/);
  assert.doesNotMatch(`${startUnix}\n${ovhRegistry}`, /sk-[A-Za-z0-9_-]{12,}/);

  const ovhStatus = await mjFetch(`${base}/api/ovh/status`).then((response) => response.json());
  assert.equal(ovhStatus.storage.automatic, true);
  assert.equal(ovhStatus.storage.initialized, false);

  const bridgeStatus = await mjFetch(`${base}/api/chatgpt-bridge/status`).then((response) => response.json());
  assert.equal(bridgeStatus.ok, true);
  assert.ok(bridgeStatus.pairingToken.length >= 64);
  const configuredBridge = await mjFetch(`${base}/api/chatgpt-bridge/config`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ conversations: [
      { id: "characters", label: "Personnages & portraits", url: "https://chatgpt.com/c/11111111-1111-1111-1111-111111111111" },
      { id: "scenes", label: "Scènes, décors & cartes", url: "https://chatgpt.com/c/22222222-2222-2222-2222-222222222222" }
    ] })
  }).then((response) => response.json());
  assert.equal(configuredBridge.conversations.filter((entry) => entry.url).length, 2);

  const tinyReference = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADElEQVR42mNk+M8AAAICAQB7CY6aAAAAAElFTkSuQmCC";
  const queuedBridgeJob = await mjFetch(`${base}/api/chatgpt-bridge/jobs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ conversationId: "characters", prompt: "Portrait de test", attachments: [{ name: "hira.png", dataUrl: tinyReference }, { name: "krael.png", dataUrl: tinyReference }] })
  }).then((response) => response.json());
  assert.equal(queuedBridgeJob.job.status, "queued");

  const extensionHeaders = {
    Origin: "chrome-extension://xar-test-extension",
    "X-Xar-Bridge-Token": bridgeStatus.pairingToken
  };
  const offeredBridgeJobResponse = await fetch(`${base}/api/chatgpt-bridge/jobs/next?conversationUrl=${encodeURIComponent("https://chatgpt.com/c/11111111-1111-1111-1111-111111111111")}`, { headers: extensionHeaders });
  assert.equal(offeredBridgeJobResponse.headers.get("access-control-allow-origin"), "chrome-extension://xar-test-extension");
  const offeredBridgeJob = await offeredBridgeJobResponse.json();
  assert.equal(offeredBridgeJob.job.prompt, "Portrait de test");
  assert.equal(offeredBridgeJob.job.attachments[0].name, "hira.png");
  assert.equal(offeredBridgeJob.job.attachments[1].name, "krael.png");

  const preparedBridgeJob = await fetch(`${base}/api/chatgpt-bridge/jobs/${queuedBridgeJob.job.id}/status`, {
    method: "POST",
    headers: { ...extensionHeaders, "Content-Type": "application/json" },
    body: JSON.stringify({ status: "prepared" })
  });
  assert.equal(preparedBridgeJob.status, 200);

  const wrongBridgeToken = await fetch(`${base}/api/chatgpt-bridge/status`, {
    headers: { Origin: "chrome-extension://xar-test-extension", "X-Xar-Bridge-Token": "incorrect" }
  });
  assert.equal(wrongBridgeToken.status, 403);

  const importedBridgeImage = await fetch(`${base}/api/chatgpt-bridge/import?jobId=${queuedBridgeJob.job.id}&filename=resultat.png`, {
    method: "POST",
    headers: { ...extensionHeaders, "Content-Type": "image/png" },
    body: Buffer.from(tinyReference.split(",")[1], "base64")
  }).then((response) => response.json());
  assert.ok(importedBridgeImage.importId);
  const bridgeInbox = await mjFetch(`${base}/api/chatgpt-bridge/imports`).then((response) => response.json());
  assert.equal(bridgeInbox.imports.length, 1);
  const bridgeImageBytes = await mjFetch(`${base}/api/chatgpt-bridge/imports/${importedBridgeImage.importId}/content`).then((response) => response.arrayBuffer());
  assert.ok(bridgeImageBytes.byteLength > 20);
  assert.equal((await mjFetch(`${base}/api/chatgpt-bridge/imports/${importedBridgeImage.importId}`, { method: "DELETE" })).status, 200);

  const savedResponse = await mjFetch(`${base}/api/session/state`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ state: testState() })
  });
  assert.equal(savedResponse.status, 200);
  const savedPayload = await savedResponse.json();
  assert.equal(savedPayload.state.characters.length, 2);

  assert.equal((await fetch(`${base}/api/session/public`)).status, 401);

  const groupPayload = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/public`).then((response) => response.json());
  assert.equal(groupPayload.state.myPlayer.name, "Alice");
  assert.equal(groupPayload.state.tacticalLocked, false);
  assert.equal(groupPayload.state.playerMovementMode, "free");
  assert.deepEqual(groupPayload.state.actionTimers, []);
  assert.deepEqual(groupPayload.state.myCharacters.map((character) => character.id), ["character-a"]);
  assert.equal(groupPayload.state.party.length, 2);
  assert.equal(groupPayload.state.map.tokens.length, 5);
  assert.equal(groupPayload.state.map.tokens.some((token) => token.id === "token-secret"), false);
  assert.equal(groupPayload.state.map.tokens[0].controllerPlayerId, undefined);
  assert.equal(groupPayload.state.map.tokens[0].gmNotes, undefined);
  assert.equal(groupPayload.state.map.tokens.find((token) => token.id === "token-a").detailsVisible, true);
  assert.equal(groupPayload.state.map.tokens.find((token) => token.id === "token-a").mana, 4);
  const privateNpc = groupPayload.state.map.tokens.find((token) => token.id === "token-npc-private");
  assert.equal(privateNpc.detailsVisible, false);
  for (const key of ["hp", "maxHp", "mana", "maxMana", "damageDice", "condition", "stats", "notes", "gmNotes"]) assert.equal(privateNpc[key], undefined);
  const sharedNpc = groupPayload.state.map.tokens.find((token) => token.id === "token-npc-shared");
  assert.equal(sharedNpc.detailsVisible, true);
  assert.equal(sharedNpc.hp, 18);
  assert.equal(sharedNpc.damageDice, "1d8+1");
  assert.equal(sharedNpc.gmNotes, undefined);
  assert.deepEqual(groupPayload.state.initiative.order, []);
  assert.equal(groupPayload.state.initiative.currentTokenId, null);
  assert.deepEqual(groupPayload.state.rolls.map((roll) => roll.id), ["public"]);
  assert.equal(groupPayload.state.rolls[0].rollerName, "MJ");
  assert.equal("tokenLibrary" in groupPayload.state, false);
  assert.doesNotMatch(JSON.stringify(groupPayload), /token-alice|Secret absolu|Autre secret|BestiaireSecret/);

  const aliceUrl = `${base}/api/session/public`;
  const alicePayload = await playerFetch(ALICE_SESSION_TOKEN, aliceUrl).then((response) => response.json());
  assert.equal(alicePayload.state.myPlayer.name, "Alice");
  assert.deepEqual(alicePayload.state.myCharacters.map((character) => character.id), ["character-a"]);
  assert.equal(alicePayload.state.myCharacters[0].secret, undefined);
  assert.equal(alicePayload.state.map.tokens.find((token) => token.id === "token-a").controllable, true);
  assert.equal(alicePayload.state.map.tokens.find((token) => token.id === "token-a-custom").controllable, true);
  assert.equal(alicePayload.state.map.tokens.find((token) => token.id === "token-b").controllable, false);
  assert.equal(alicePayload.state.map.tokens.find((token) => token.id === "token-b").detailsVisible, false);

  const createdCharacterResponse = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/character`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: "Compagnon de test", color: "#336699" })
  });
  assert.equal(createdCharacterResponse.status, 201);
  const createdCharacter = (await createdCharacterResponse.json()).character;
  assert.equal(createdCharacter.ownerPlayerId, "player-a");
  assert.equal(createdCharacter.secret, undefined);
  const bobAfterCreation = await playerFetch(BOB_SESSION_TOKEN, `${base}/api/session/public`).then((response) => response.json());
  assert.deepEqual(bobAfterCreation.state.myCharacters.map((character) => character.id), ["character-b"]);
  assert.equal(JSON.stringify(bobAfterCreation).includes(createdCharacter.publicNotes || "__absent__"), false);

  const linkedPatch = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/character`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ characterId: createdCharacter.id, patch: { linkedTokens: [{ id: "pet-wolf", name: "Loup lié", kind: "pet", color: "#446688", size: 30 }] } })
  });
  assert.equal(linkedPatch.status, 200);
  const invokeMain = await mjFetch(`${base}/api/session/token/invoke`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ characterId: createdCharacter.id })
  });
  assert.equal(invokeMain.status, 201);
  const invokePet = await mjFetch(`${base}/api/session/token/invoke`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ characterId: createdCharacter.id, linkedTokenId: "pet-wolf" })
  });
  assert.equal(invokePet.status, 201);
  const invokedPet = (await invokePet.json()).token;
  assert.equal(invokedPet.controllerPlayerId, "player-a");
  assert.equal(invokedPet.linkedTokenId, "pet-wolf");

  const playerPing = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/ping`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ x: 33, y: 44 })
  });
  assert.equal(playerPing.status, 201);
  const groupWithPing = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/public`).then((response) => response.json());
  assert.equal(groupWithPing.state.mapPings.some((ping) => ping.x === 33 && ping.y === 44), true);

  const playerRollResponse = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/roll`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ characterId: "character-a", shortcutId: "initiative-a" })
  });
  assert.equal(playerRollResponse.status, 200);
  const playerRollPayload = await playerRollResponse.json();
  assert.equal(playerRollPayload.roll.rollerName, "Alice");
  assert.equal(playerRollPayload.roll.characterName, "Hira");
  assert.equal(playerRollPayload.roll.formula, "1d100+4");
  assert.equal(playerRollPayload.initiativeUpdated, true);
  assert.equal(playerRollPayload.discordPosted, false);
  assert.ok(playerRollPayload.roll.total >= 5 && playerRollPayload.roll.total <= 104);
  assert.equal((await fetch(`${base}/api/session/roll`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" })).status, 401);

  const initiativeState = await mjFetch(`${base}/api/session/full`).then((response) => response.json()).then((payload) => payload.state);
  assert.equal(initiativeState.initiative.active, false);
  assert.deepEqual(initiativeState.initiative.order, ["token-a"]);
  assert.equal(initiativeState.tacticalSync.playerMovementMode, "free");
  const initiativeScores = initiativeState.initiative.order
    .map((id) => initiativeState.map.tokens.find((token) => token.id === id)?.initiative)
    .filter((value) => value !== null && value !== undefined)
    .map(Number);
  assert.deepEqual(initiativeScores, [...initiativeScores].sort((left, right) => left - right));

  initiativeState.tacticalSync.playerMovementMode = "combat";
  const incoherentFreeState = await mjFetch(`${base}/api/session/state`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ state: initiativeState })
  });
  assert.equal(incoherentFreeState.status, 200);
  const preparedAlice = await playerFetch(ALICE_SESSION_TOKEN, aliceUrl).then((response) => response.json());
  assert.equal(preparedAlice.state.initiative.active, false);
  assert.equal(preparedAlice.state.initiative.currentTokenId, null);
  assert.equal(preparedAlice.state.playerMovementMode, "free");
  assert.equal(preparedAlice.state.map.tokens.find((token) => token.id === "token-a-custom").controllable, true);

  initiativeState.initiative.active = true;
  initiativeState.initiative.turnsStarted = true;
  initiativeState.initiative.currentIndex = 0;
  initiativeState.initiative.round = 1;
  initiativeState.tacticalSync = { paused: false, pausedAt: null, playerMovementMode: "combat", publishedMap: null, publishedInitiative: null, publishedActiveScene: null };
  const startedCombat = await mjFetch(`${base}/api/session/state`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ state: initiativeState })
  });
  assert.equal(startedCombat.status, 200);

  const privateTimerResponse = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/timer`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ characterId: "character-a", label: "Pas de l’ombre", cooldown: 5, visibility: "private" })
  });
  assert.equal(privateTimerResponse.status, 201);
  const privateTimer = (await privateTimerResponse.json()).timer;
  assert.equal(privateTimer.readyRound, 6);
  const groupWithoutPrivateTimer = await playerFetch(BOB_SESSION_TOKEN, `${base}/api/session/public`).then((response) => response.json());
  assert.equal(groupWithoutPrivateTimer.state.actionTimers.some((timer) => timer.id === privateTimer.id), false);
  const aliceWithPrivateTimer = await playerFetch(ALICE_SESSION_TOKEN, aliceUrl).then((response) => response.json());
  assert.equal(aliceWithPrivateTimer.state.actionTimers.find((timer) => timer.id === privateTimer.id).ownedByYou, true);
  const bobCannotReuseAliceTimer = await playerFetch(BOB_SESSION_TOKEN, `${base}/api/session/timer`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ timerId: privateTimer.id })
  });
  assert.equal(bobCannotReuseAliceTimer.status, 403);

  const legacyTokenResponse = await fetch(`${base}/api/session/public?player=player-a&token=faux&code=seuil`);
  assert.equal(legacyTokenResponse.status, 401);

  const patchCharacter = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/character`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ characterId: "character-a", patch: {
      resources: { hp: 7, mana: 6 },
      publicNotes: "Message du joueur",
      ownerPlayerId: "player-b",
      secret: { notes: "Tentative interdite" },
      shortcuts: [{ id: "initiative-a", label: "Initiative", formula: "1d20+9", kind: "initiative", visibility: "public" }]
    } })
  });
  assert.equal(patchCharacter.status, 200);
  const patchedCharacterPayload = await patchCharacter.json();
  assert.equal(patchedCharacterPayload.character.resources.hp, 7);
  assert.equal(patchedCharacterPayload.character.resources.maxHp, 20);
  assert.equal(patchedCharacterPayload.character.resources.mana, 6);
  assert.equal(patchedCharacterPayload.character.shortcuts[0].formula, "1d100+9");
  assert.equal(patchedCharacterPayload.character.secret, undefined);

  const staleMjState = testState();
  staleMjState.session.name = "Mise à jour parallèle du MJ";
  staleMjState.initiative._updatedAt = Date.now() + 1000;
  const mergedSave = await mjFetch(`${base}/api/session/state`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ state: staleMjState })
  }).then((response) => response.json());
  assert.equal(mergedSave.state.session.name, "Mise à jour parallèle du MJ");
  assert.equal(mergedSave.state.characters.find((character) => character.id === "character-a").resources.hp, 7);
  assert.equal(mergedSave.state.characters.find((character) => character.id === "character-a").publicNotes, "Message du joueur");
  assert.equal(mergedSave.state.characters.some((character) => character.id === createdCharacter.id), true);
  assert.equal(mergedSave.state.map.tokens.some((token) => token.linkedTokenId === "pet-wolf"), true);
  assert.equal(mergedSave.state.actionTimers.some((timer) => timer.id === privateTimer.id), true);

  const forbiddenCharacter = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/character`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ characterId: "character-b", patch: { publicNotes: "Intrusion" } })
  });
  assert.equal(forbiddenCharacter.status, 403);

  const moveOwnToken = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/token`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tokenId: "token-a", x: 43.125, y: 61.75 })
  });
  assert.equal(moveOwnToken.status, 200);
  const moveOtherToken = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/token`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tokenId: "token-b", x: 1, y: 1 })
  });
  assert.equal(moveOtherToken.status, 403);
  const moveHiddenToken = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/token`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tokenId: "token-secret", x: 1, y: 1 })
  });
  assert.equal(moveHiddenToken.status, 403);

  const moveSecondOwnedTokenInFreeMode = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/token`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tokenId: "token-a-custom", x: 30, y: 35 })
  });
  assert.equal(moveSecondOwnedTokenInFreeMode.status, 200);

  const beforeCombatMode = await mjFetch(`${base}/api/session/full`).then((response) => response.json()).then((payload) => payload.state);
  beforeCombatMode.tacticalSync = { paused: false, pausedAt: null, playerMovementMode: "combat", publishedMap: null, publishedInitiative: null, publishedActiveScene: null };
  beforeCombatMode.initiative = {
    ...beforeCombatMode.initiative,
    order: ["token-a", "token-a-custom", ...beforeCombatMode.initiative.order.filter((id) => !["token-a", "token-a-custom"].includes(id))],
    currentIndex: 0,
    active: true,
    _updatedAt: Number(beforeCombatMode.initiative._updatedAt || 0) + 1
  };
  const combatModeSaved = await mjFetch(`${base}/api/session/state`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ state: beforeCombatMode })
  }).then((response) => response.json());
  const aliceCombatMode = await playerFetch(ALICE_SESSION_TOKEN, aliceUrl).then((response) => response.json());
  assert.equal(aliceCombatMode.state.playerMovementMode, "combat");
  assert.equal(aliceCombatMode.state.map.tokens.find((token) => token.id === "token-a").controllable, true);
  assert.equal(aliceCombatMode.state.map.tokens.find((token) => token.id === "token-a-custom").controllable, false);
  const moveWaitingOwnedToken = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/token`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tokenId: "token-a-custom", x: 40, y: 40 })
  });
  assert.equal(moveWaitingOwnedToken.status, 423);
  const moveActiveOwnedToken = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/token`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tokenId: "token-a", x: 43.125, y: 61.75 })
  });
  assert.equal(moveActiveOwnedToken.status, 200);

  const pauseDraft = (await mjFetch(`${base}/api/session/full`).then((response) => response.json())).state;
  const publishedMap = structuredClone(pauseDraft.map);
  const publishedInitiative = structuredClone(pauseDraft.initiative);
  const publishedActiveScene = structuredClone(pauseDraft.activeScene);
  pauseDraft.map.panX = 99;
  pauseDraft.map.tokens.push({
    id: "token-secret-draft", controllerPlayerId: null, name: "Renfort en préparation", color: "#000000",
    x: 50, y: 50, size: 30, hp: 100, maxHp: 100, initiative: 3, hidden: false,
    revealDetailsToPlayers: false, gmNotes: "Ne doit jamais fuiter", _updatedAt: Date.now(), _movedAt: Date.now()
  });
  pauseDraft.tacticalSync = {
    paused: true,
    pausedAt: new Date().toISOString(),
    playerMovementMode: "combat",
    publishedMap,
    publishedInitiative,
    publishedActiveScene
  };
  const pausedSave = await mjFetch(`${base}/api/session/state`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ state: pauseDraft })
  });
  assert.equal(pausedSave.status, 200);
  const pausedGroup = await playerFetch(BOB_SESSION_TOKEN, `${base}/api/session/public`).then((response) => response.json());
  assert.equal(pausedGroup.state.tacticalLocked, true);
  assert.equal(pausedGroup.state.map.panX, publishedMap.panX);
  assert.equal(pausedGroup.state.map.tokens.some((token) => token.id === "token-secret-draft"), false);
  assert.equal("tacticalSync" in pausedGroup.state, false);
  assert.doesNotMatch(JSON.stringify(pausedGroup), /Renfort en préparation|Ne doit jamais fuiter/);
  const pausedAlice = await playerFetch(ALICE_SESSION_TOKEN, aliceUrl).then((response) => response.json());
  assert.equal(pausedAlice.state.map.tokens.find((token) => token.id === "token-a").ownedByYou, true);
  assert.equal(pausedAlice.state.map.tokens.find((token) => token.id === "token-a").controllable, false);
  const moveWhilePaused = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/token`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tokenId: "token-a", x: 10, y: 10 })
  });
  assert.equal(moveWhilePaused.status, 423);
  const initiativeWhilePaused = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/roll`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ characterId: "character-a", shortcutId: "initiative-a" })
  });
  assert.equal(initiativeWhilePaused.status, 423);
  const timerWhilePaused = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/timer`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ characterId: "character-a", label: "Interdit", cooldown: 2 })
  });
  assert.equal(timerWhilePaused.status, 423);

  const resumeDraft = (await mjFetch(`${base}/api/session/full`).then((response) => response.json())).state;
  resumeDraft.map.tokens.find((token) => token.id === "token-secret-draft").hidden = true;
  resumeDraft.tacticalSync = { paused: false, pausedAt: null, playerMovementMode: "combat", publishedMap: null, publishedInitiative: null, publishedActiveScene: null };
  const resumedSave = await mjFetch(`${base}/api/session/state`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ state: resumeDraft })
  });
  assert.equal(resumedSave.status, 200);
  const resumedGroup = await playerFetch(BOB_SESSION_TOKEN, `${base}/api/session/public`).then((response) => response.json());
  assert.equal(resumedGroup.state.tacticalLocked, false);
  assert.equal(resumedGroup.state.map.tokens.some((token) => token.id === "token-secret-draft"), false);

  const publicTimerResponse = await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/timer`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ characterId: "character-a", label: "Cri de guerre", cooldown: 2, visibility: "public" })
  });
  assert.equal(publicTimerResponse.status, 201);
  const publicTimer = (await publicTimerResponse.json()).timer;
  const groupWithPublicTimer = await playerFetch(BOB_SESSION_TOKEN, `${base}/api/session/public`).then((response) => response.json());
  assert.equal(groupWithPublicTimer.state.actionTimers.find((timer) => timer.id === publicTimer.id).ownerLabel, "Hira");
  assert.equal((await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/timer`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ timerId: publicTimer.id }) })).status, 200);
  assert.equal((await playerFetch(ALICE_SESSION_TOKEN, `${base}/api/session/timer?timerId=${encodeURIComponent(publicTimer.id)}`, { method: "DELETE" })).status, 200);
  const groupAfterTimerDelete = await playerFetch(BOB_SESSION_TOKEN, `${base}/api/session/public`).then((response) => response.json());
  assert.equal(groupAfterTimerDelete.state.actionTimers.some((timer) => timer.id === publicTimer.id), false);

  const mediaBytes = Buffer.from("ID3\u0004\u0000\u0000xar-tsaroth-test-audio");
  const mediaUpload = await mjFetch(`${base}/api/media/upload?filename=ambiance.mp3`, {
    method: "POST",
    headers: { "Content-Type": "audio/mpeg" },
    body: mediaBytes
  });
  assert.equal(mediaUpload.status, 201);
  const media = await mediaUpload.json();
  const mediaRange = await mjFetch(`${base}${media.url}`, { headers: { Range: "bytes=0-2" } });
  assert.equal(mediaRange.status, 206);
  assert.equal(Buffer.from(await mediaRange.arrayBuffer()).toString(), "ID3");
  assert.equal((await mjFetch(`${base}/api/media?mediaId=${encodeURIComponent(media.mediaId)}`, { method: "DELETE" })).status, 200);
  assert.equal((await mjFetch(`${base}${media.url}`)).status, 404);

  const fullPayload = await mjFetch(`${base}/api/session/full`).then((response) => response.json());
  const hira = fullPayload.state.characters.find((character) => character.id === "character-a");
  assert.equal(hira.ownerPlayerId, "player-a");
  assert.equal(hira.secret.notes, "Secret absolu");
  assert.equal(hira.publicNotes, "Message du joueur");
  assert.equal(hira.resources.hp, 7);
  assert.equal(hira.resources.maxHp, 20);
  assert.equal(fullPayload.state.map.tokens.find((token) => token.id === "token-a").hp, 7);
  assert.equal(fullPayload.state.map.tokens.find((token) => token.id === "token-a").mana, 6);
  assert.equal(fullPayload.state.map.tokens.find((token) => token.id === "token-a").x, 41.25);
  assert.equal(fullPayload.state.map.tokens.find((token) => token.id === "token-a").y, 60);
  assert.equal(fullPayload.state.map.tokens.find((token) => token.id === "token-a-custom").hp, 99);
  assert.equal(fullPayload.state.tokenLibrary[0].gmNotes, "BestiaireSecret");
  assert.equal(fullPayload.state.scenes[0].combat.map.tokens.find((token) => token.id === "token-a").x, 41.25);
  assert.equal(fullPayload.state.actionTimers.some((timer) => timer.id === privateTimer.id), true);
  assert.equal(fullPayload.state.actionTimerTombstones.some((entry) => entry.id === publicTimer.id), true);

  const persisted = JSON.parse(await readFile(path.join(dataDirectory, "session-state.json"), "utf8"));
  assert.equal(persisted.characters.find((character) => character.id === "character-a").resources.hp, 7);
  assert.equal(persisted.characters.find((character) => character.id === "character-a").characterSchemaVersion, 2);
  assert.equal(stderr.join(""), "");
});
