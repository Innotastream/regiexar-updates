import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { AccountStore } from "../account-store.mjs";

test("les comptes utilisent un vérificateur et la révocation invalide les sessions", async () => {
  const root = mkdtempSync(path.join(tmpdir(), "xar-accounts-"));
  try {
    const store = new AccountStore(path.join(root, "accounts.json"));
    const created = await store.create({ username: "Aino.MJ", displayName: "Aino", password: "UnMotDePasseSolide!", role: "gm" });
    assert.equal(created.role, "gm");
    assert.equal(readFileSync(path.join(root, "accounts.json"), "utf8").includes("UnMotDePasseSolide!"), false);
    assert.equal(await store.authenticate("aino.mj", "mauvais-mot-de-passe", { requiredRole: "gm" }), null);
    const authenticated = await store.authenticate("AINO.MJ", "UnMotDePasseSolide!", { requiredRole: "gm" });
    assert.equal(authenticated.id, created.id);
    assert.ok(store.resolveSession(authenticated.id, authenticated.authRevision));
    await store.update(created.id, { revoked: true });
    assert.equal(store.resolveSession(authenticated.id, authenticated.authRevision), null);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test("le registre récupère sa copie précédente après une écriture interrompue", async () => {
  const root = mkdtempSync(path.join(tmpdir(), "xar-accounts-recovery-"));
  try {
    const filePath = path.join(root, "accounts.json");
    const store = new AccountStore(filePath);
    const created = await store.create({ username: "secours", password: "MotDePasseSecours!", role: "player" });
    await store.update(created.id, { role: "gm" });
    writeFileSync(filePath, "{registre interrompu", { mode: 0o600 });
    const recovered = store.list().find((account) => account.id === created.id);
    assert.ok(recovered);
    assert.equal(recovered.role, "player");
    assert.equal(JSON.parse(readFileSync(filePath, "utf8")).accounts.length, 1);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test("un compte joueur peut être promu MJ et lié à un ancien identifiant", async () => {
  const root = mkdtempSync(path.join(tmpdir(), "xar-accounts-"));
  try {
    const store = new AccountStore(path.join(root, "accounts.json"));
    const created = await store.create({ id: "player-existing-01", username: "joueur", password: "MotDePasseJoueur!", role: "player" });
    assert.equal(created.id, "player-existing-01");
    assert.equal(await store.authenticate("joueur", "MotDePasseJoueur!", { requiredRole: "gm" }), null);
    await store.update(created.id, { role: "gm" });
    assert.equal((await store.authenticate("joueur", "MotDePasseJoueur!", { requiredRole: "gm" })).role, "gm");
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});
