import { copyFileSync, existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
import path from "node:path";
import { createPasswordVerifier, verifyPassword } from "./access-control.mjs";

export const ACCOUNT_SCHEMA_VERSION = 1;
export const ACCOUNT_ROLES = Object.freeze(["player", "gm"]);

function cleanText(value, maximum, label) {
  const text = String(value ?? "").trim();
  if (!text || text.length > maximum || /[\0\r\n]/.test(text)) throw new Error(`${label} invalide.`);
  return text;
}

export function normalizeUsername(value) {
  const username = cleanText(value, 64, "Identifiant");
  if (!/^[\p{L}\p{N}][\p{L}\p{N}._-]{2,63}$/u.test(username)) {
    throw new Error("L’identifiant doit contenir 3 à 64 lettres, chiffres, points, tirets ou tirets bas.");
  }
  return username.normalize("NFKC").toLocaleLowerCase("fr");
}

function validId(value) {
  const id = String(value ?? "").trim();
  return /^[a-zA-Z0-9_-]{8,128}$/.test(id) ? id : null;
}

function publicAccount(account) {
  return {
    id: account.id,
    username: account.username,
    displayName: account.displayName,
    role: account.role,
    revoked: Boolean(account.revokedAt),
    revokedAt: account.revokedAt ?? null,
    createdAt: account.createdAt,
    updatedAt: account.updatedAt
  };
}

function safeEnvelope(value) {
  if (!value || typeof value !== "object" || !Array.isArray(value.accounts)) throw new Error("Registre de comptes invalide.");
  const accounts = value.accounts;
  if (!accounts.every((account) => (
    validId(account?.id)
    && typeof account?.username === "string"
    && typeof account?.usernameKey === "string"
    && ACCOUNT_ROLES.includes(account?.role)
    && typeof account?.passwordVerifier === "string"
  ))) throw new Error("Registre de comptes invalide.");
  return { schemaVersion: ACCOUNT_SCHEMA_VERSION, accounts };
}

export class AccountStore {
  constructor(filePath) {
    this.filePath = path.resolve(filePath);
  }

  read() {
    const candidates = [this.filePath, `${this.filePath}.previous`];
    for (const candidate of candidates) {
      if (!existsSync(candidate)) continue;
      try {
        const envelope = safeEnvelope(JSON.parse(readFileSync(candidate, "utf8")));
        if (candidate !== this.filePath) {
          const recovery = `${this.filePath}.${process.pid}.recovery`;
          copyFileSync(candidate, recovery);
          rmSync(this.filePath, { force: true });
          renameSync(recovery, this.filePath);
        }
        return envelope;
      }
      catch {}
    }
    if (!candidates.some(existsSync)) return { schemaVersion: ACCOUNT_SCHEMA_VERSION, accounts: [] };
    throw new Error("Le registre des comptes et sa copie de sécurité sont illisibles.");
  }

  write(envelope) {
    mkdirSync(path.dirname(this.filePath), { recursive: true, mode: 0o700 });
    const temporary = `${this.filePath}.${process.pid}.${randomBytes(4).toString("hex")}.partial`;
    const previous = `${this.filePath}.previous`;
    writeFileSync(temporary, `${JSON.stringify(safeEnvelope(envelope), null, 2)}\n`, { mode: 0o600 });
    if (existsSync(this.filePath)) {
      rmSync(previous, { force: true });
      renameSync(this.filePath, previous);
    }
    try {
      renameSync(temporary, this.filePath);
    } catch (error) {
      if (!existsSync(this.filePath) && existsSync(previous)) renameSync(previous, this.filePath);
      rmSync(temporary, { force: true });
      throw error;
    }
  }

  list() {
    return this.read().accounts.map(publicAccount).sort((left, right) => left.username.localeCompare(right.username, "fr"));
  }

  async create({ username, displayName, password, role = "player", id = null }) {
    const envelope = this.read();
    const usernameText = cleanText(username, 64, "Identifiant");
    const usernameKey = normalizeUsername(usernameText);
    if (envelope.accounts.some((account) => account.usernameKey === usernameKey)) throw new Error("Cet identifiant existe déjà.");
    if (!ACCOUNT_ROLES.includes(role)) throw new Error("Niveau d’accès invalide.");
    const accountId = validId(id) ?? `usr_${randomBytes(12).toString("base64url")}`;
    if (envelope.accounts.some((account) => account.id === accountId)) throw new Error("Cette identité de joueur est déjà liée à un compte.");
    const now = new Date().toISOString();
    const account = {
      id: accountId,
      username: usernameText,
      usernameKey,
      displayName: cleanText(displayName || usernameText, 96, "Nom affiché"),
      role,
      passwordVerifier: await createPasswordVerifier(password),
      authRevision: 1,
      revokedAt: null,
      createdAt: now,
      updatedAt: now
    };
    envelope.accounts.push(account);
    this.write(envelope);
    return publicAccount(account);
  }

  async authenticate(username, password, { requiredRole = null } = {}) {
    let usernameKey;
    try { usernameKey = normalizeUsername(username); }
    catch { return null; }
    const account = this.read().accounts.find((candidate) => candidate.usernameKey === usernameKey);
    if (!account || account.revokedAt || (requiredRole && account.role !== requiredRole)) return null;
    if (!await verifyPassword(password, account.passwordVerifier)) return null;
    return { ...publicAccount(account), authRevision: Number(account.authRevision || 1) };
  }

  resolveSession(id, authRevision) {
    const account = this.read().accounts.find((candidate) => candidate.id === id);
    if (!account || account.revokedAt || Number(account.authRevision || 1) !== Number(authRevision)) return null;
    return { ...publicAccount(account), authRevision: Number(account.authRevision || 1) };
  }

  async update(id, changes = {}) {
    const envelope = this.read();
    const account = envelope.accounts.find((candidate) => candidate.id === id);
    if (!account) throw new Error("Compte introuvable.");
    if (changes.role !== undefined) {
      if (!ACCOUNT_ROLES.includes(changes.role)) throw new Error("Niveau d’accès invalide.");
      account.role = changes.role;
    }
    if (changes.displayName !== undefined) account.displayName = cleanText(changes.displayName, 96, "Nom affiché");
    if (changes.password) account.passwordVerifier = await createPasswordVerifier(changes.password);
    if (changes.revoked !== undefined) account.revokedAt = changes.revoked ? new Date().toISOString() : null;
    account.authRevision = Number(account.authRevision || 1) + 1;
    account.updatedAt = new Date().toISOString();
    this.write(envelope);
    return publicAccount(account);
  }
}
