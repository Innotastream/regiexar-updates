import http from "node:http";
import {
  createReadStream,
  existsSync,
  mkdirSync,
  readFileSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync
} from "node:fs";
import { chmod, mkdtemp, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { normalizeChatGptExternalUrl, openSystemBrowser } from "./desktop-shell.mjs";
import { randomBytes, randomInt as cryptoRandomInt, randomUUID, timingSafeEqual } from "node:crypto";
import { UserCharacterStorage } from "./character-storage.mjs";
import { AccountStore } from "./account-store.mjs";
import { AttemptLimiter } from "./access-control.mjs";
import { importCharacterDocx } from "./docx-character-import.mjs";
import { createCharacterSheet, migrateCharacterSheet, normalizeLinkedTokens } from "./public/character-schema.js";
import { snapMapPercentPoint } from "./public/map-geometry.js";
import { sanitizeInitiativeOrder, sortInitiativeTokenIds } from "./public/initiative-state.js";
import {
  OVH_MANIFEST_FILENAME,
  appendManagedFile,
  cleanupPlan,
  emptyOvhManifest,
  isLegacyRegieRemoteName,
  isManagedRemoteName,
  managedRemoteName,
  normalizeOvhManifest
} from "./ovh-media-registry.mjs";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(ROOT, "public");
const APPLICATION_RELEASE = readJson(path.join(ROOT, "application.json")) ?? {};
const APP_VERSION = String(APPLICATION_RELEASE.version || readJson(path.join(ROOT, "package.json"))?.version || "dev");
const MAX_JSON_BODY_BYTES = 50 * 1024 * 1024;
const MAX_MEDIA_BODY_BYTES = 300 * 1024 * 1024;
const MAX_OVH_TEXT_BYTES = 5 * 1024 * 1024;

const DATA_DIR = process.env.XAR_DATA_DIR
  ? path.resolve(ROOT, process.env.XAR_DATA_DIR)
  : path.join(ROOT, "data");
const SESSION_FILE = path.join(DATA_DIR, "session-state.json");
const MEDIA_DIR = path.join(DATA_DIR, "media");
const CHATGPT_BRIDGE_FILE = path.join(DATA_DIR, "chatgpt-bridge.json");
const CHATGPT_BRIDGE_IMPORT_DIR = path.join(DATA_DIR, "chatgpt-bridge-imports");
const ACCOUNTS_FILE = path.join(DATA_DIR, "accounts.json");
mkdirSync(DATA_DIR, { recursive: true });
mkdirSync(MEDIA_DIR, { recursive: true });
mkdirSync(CHATGPT_BRIDGE_IMPORT_DIR, { recursive: true });

const userCharacterStorage = new UserCharacterStorage(DATA_DIR, { applicationVersion: APP_VERSION });
const accountStore = new AccountStore(ACCOUNTS_FILE);
const authenticatedSessions = new Map();
const authenticationLimiter = new AttemptLimiter({ maximumAttempts: 8, windowMs: 15 * 60 * 1000, lockMs: 60 * 1000 });
const SESSION_MAX_AGE_SECONDS = 12 * 60 * 60;
let sessionState = readJson(SESSION_FILE) ?? null;
const sessionBeforeCharacterMigration = sessionState ? JSON.stringify(sessionState.characters ?? []) : null;
const sessionBeforeAccessMigration = sessionState ? JSON.stringify(sessionState.players ?? []) : null;
sessionState = stripLegacyAccessTokens(migrateSessionCharacterSchemas(sessionState));
const sessionCharacterSchemaChanged = Boolean(sessionState && sessionBeforeCharacterMigration !== JSON.stringify(sessionState.characters ?? []));
const sessionAccessSchemaChanged = Boolean(sessionState && sessionBeforeAccessMigration !== JSON.stringify(sessionState.players ?? []));
const characterHydration = userCharacterStorage.hydrateSession(sessionState);
sessionState = characterHydration.state;
if (sessionState && (sessionCharacterSchemaChanged || sessionAccessSchemaChanged || characterHydration.changed)) {
  const temporary = `${SESSION_FILE}.migration.tmp`;
  writeFileSync(temporary, `${JSON.stringify(sessionState, null, 2)}\n`, { mode: 0o600 });
  renameSync(temporary, SESSION_FILE);
}
let revision = Number(sessionState?.revision ?? 0);
const eventClients = new Set();
const bridgeJobs = [];
const bridgeImports = [];
let bridgeLastSeenAt = 0;
let ovhOperationChain = Promise.resolve();
const ovhOpenSshHosts = new Set();
let ovhRuntimeStatus = {
  buildVersion: APP_VERSION,
  automatic: true,
  initialized: false,
  trackedFiles: 0,
  lastCleanupAt: null,
  lastDeletedCount: 0,
  warnings: []
};

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".mp3": "audio/mpeg",
  ".ogg": "audio/ogg",
  ".oga": "audio/ogg",
  ".wav": "audio/wav",
  ".m4a": "audio/mp4",
  ".aac": "audio/aac",
  ".flac": "audio/flac"
};

function readJson(filePath) {
  try {
    return JSON.parse(readFileSync(filePath, "utf8"));
  } catch {
    return null;
  }
}

function defaultBridgeConfig() {
  return {
    pairingToken: `${randomUUID().replaceAll("-", "")}${randomUUID().replaceAll("-", "")}`,
    conversations: [
      { id: "characters", label: "Personnages & portraits", url: "" },
      { id: "scenes", label: "Scènes, décors & cartes", url: "" }
    ]
  };
}

function normalizedChatGptConversationUrl(value) {
  try {
    const parsed = new URL(String(value ?? "").trim());
    if (parsed.protocol !== "https:" || parsed.hostname !== "chatgpt.com") return "";
    const match = parsed.pathname.match(/(?:^|\/)c\/[a-zA-Z0-9_-]+/);
    if (!match) return "";
    const end = (match.index ?? 0) + match[0].length;
    return `https://chatgpt.com${parsed.pathname.slice(0, end)}`;
  } catch {
    return "";
  }
}

function normalizeBridgeConfig(candidate) {
  const fallback = defaultBridgeConfig();
  const byId = new Map((candidate?.conversations ?? []).map((entry) => [entry.id, entry]));
  return {
    pairingToken: String(candidate?.pairingToken || fallback.pairingToken),
    conversations: fallback.conversations.map((entry) => {
      const saved = byId.get(entry.id) ?? {};
      return {
        id: entry.id,
        label: String(saved.label || entry.label).slice(0, 80),
        url: normalizedChatGptConversationUrl(saved.url)
      };
    })
  };
}

let bridgeConfig = normalizeBridgeConfig(readJson(CHATGPT_BRIDGE_FILE));

function saveBridgeConfig() {
  const temporary = `${CHATGPT_BRIDGE_FILE}.tmp`;
  writeFileSync(temporary, JSON.stringify(bridgeConfig, null, 2), { mode: 0o600 });
  renameSync(temporary, CHATGPT_BRIDGE_FILE);
}

saveBridgeConfig();

function entityStamp(entity, field = "_updatedAt") {
  const value = Number(entity?.[field] ?? 0);
  return Number.isFinite(value) ? value : 0;
}

function migrateSessionCharacterSchemas(candidate) {
  if (!candidate || typeof candidate !== "object" || !Array.isArray(candidate.characters)) return candidate;
  return {
    ...candidate,
    characters: candidate.characters.map((character) => migrateCharacterSheet(character, {
      ownerPlayerId: character?.ownerPlayerId ?? null
    }).character)
  };
}

function stripLegacyAccessTokens(candidate) {
  if (!candidate || typeof candidate !== "object" || !Array.isArray(candidate.players)) return candidate;
  return {
    ...candidate,
    players: candidate.players.map((player) => {
      const { accessToken: _legacyAccessToken, ...safePlayer } = player && typeof player === "object" ? player : {};
      return safePlayer;
    })
  };
}

function mergeCollaborativeState(incoming, current) {
  if (!current || !incoming || typeof incoming !== "object") return incoming;
  const merged = { ...incoming };
  const sceneChanged = String(incoming.activeSceneId || "") !== String(current.activeSceneId || "");
  const incomingIsStale = Number(incoming.revision ?? 0) < Number(current.revision ?? 0);
  const mergeTombstones = (nextItems, currentItems) => {
    const byId = new Map();
    for (const entry of [...(currentItems ?? []), ...(nextItems ?? [])]) {
      if (!entry?.id) continue;
      const previous = byId.get(entry.id);
      if (!previous || Date.parse(entry.deletedAt || 0) >= Date.parse(previous.deletedAt || 0)) byId.set(entry.id, entry);
    }
    return [...byId.values()].slice(-2000);
  };
  const mergeEntities = (nextItems, currentItems, tombstones = []) => {
    const currentById = new Map((currentItems ?? []).map((item) => [item.id, item]));
    const mergedItems = (nextItems ?? []).map((item) => {
      const serverItem = currentById.get(item.id);
      return serverItem && entityStamp(serverItem) > entityStamp(item) ? serverItem : item;
    });
    const knownIds = new Set(mergedItems.map((item) => item.id));
    for (const item of currentItems ?? []) if (!knownIds.has(item.id)) mergedItems.push(item);
    const deleted = new Map(tombstones.map((entry) => [entry.id, Date.parse(entry.deletedAt || 0)]));
    return mergedItems.filter((item) => (deleted.get(item.id) ?? 0) < entityStamp(item));
  };
  const mergeTokens = (nextTokens, currentTokens) => {
    const currentById = new Map((currentTokens ?? []).map((token) => [token.id, token]));
    const mergedTokens = (nextTokens ?? []).map((token) => {
      const serverToken = currentById.get(token.id);
      if (!serverToken) return token;
      let result = entityStamp(serverToken) > entityStamp(token) ? serverToken : token;
      if (entityStamp(serverToken, "_movedAt") > entityStamp(token, "_movedAt")) {
        result = { ...result, x: serverToken.x, y: serverToken.y, _movedAt: serverToken._movedAt };
      }
      return result;
    });
    if (incomingIsStale) {
      const knownIds = new Set(mergedTokens.map((token) => token.id));
      for (const token of currentTokens ?? []) if (!knownIds.has(token.id)) mergedTokens.push(token);
    }
    return mergedTokens;
  };
  merged.playerTombstones = mergeTombstones(incoming.playerTombstones, current.playerTombstones);
  merged.characterTombstones = mergeTombstones(incoming.characterTombstones, current.characterTombstones);
  if (Array.isArray(incoming.players)) merged.players = mergeEntities(incoming.players, current.players, merged.playerTombstones);
  if (Array.isArray(incoming.characters)) merged.characters = mergeEntities(incoming.characters, current.characters, merged.characterTombstones);
  const currentTargetScene = sceneChanged
    ? (current.scenes ?? []).find((scene) => scene.id === incoming.activeSceneId)
    : null;
  const comparisonMap = currentTargetScene?.combat?.map ?? current.map;
  if (incoming.map && typeof incoming.map === "object") {
    merged.map = {
      ...incoming.map,
      tokens: mergeTokens(incoming.map.tokens, comparisonMap?.tokens)
    };
  }
  if (Array.isArray(incoming.scenes)) {
    const currentScenes = new Map((current.scenes ?? []).map((scene) => [scene.id, scene]));
    merged.scenes = incoming.scenes.map((scene) => {
      const serverScene = currentScenes.get(scene.id);
      if (!serverScene?.combat?.map || !scene.combat?.map) return scene;
      return {
        ...scene,
        combat: {
          ...scene.combat,
          map: {
            ...scene.combat.map,
            tokens: mergeTokens(scene.combat.map.tokens, serverScene.combat.map.tokens)
          },
          initiative: entityStamp(serverScene.combat.initiative) > entityStamp(scene.combat.initiative)
            ? serverScene.combat.initiative
            : scene.combat.initiative
        }
      };
    });
  }
  if (Array.isArray(incoming.rolls)) {
    const byId = new Map(incoming.rolls.map((roll) => [roll.id, roll]));
    for (const roll of current.rolls ?? []) if (!byId.has(roll.id)) byId.set(roll.id, roll);
    merged.rolls = [...byId.values()]
      .sort((left, right) => Date.parse(right.createdAt || 0) - Date.parse(left.createdAt || 0))
      .slice(0, 100);
  }
  if (Array.isArray(incoming.actionTimers) || Array.isArray(current.actionTimers)) {
    const tombstones = new Map();
    for (const entry of [...(current.actionTimerTombstones ?? []), ...(incoming.actionTimerTombstones ?? [])]) {
      if (!entry?.id) continue;
      const previous = tombstones.get(entry.id);
      if (!previous || Date.parse(entry.deletedAt || 0) >= Date.parse(previous.deletedAt || 0)) tombstones.set(entry.id, entry);
    }
    const timers = new Map();
    for (const timer of [...(current.actionTimers ?? []), ...(incoming.actionTimers ?? [])]) {
      if (!timer?.id || tombstones.has(timer.id)) continue;
      const previous = timers.get(timer.id);
      if (!previous || Date.parse(timer.updatedAt || timer.createdAt || 0) >= Date.parse(previous.updatedAt || previous.createdAt || 0)) timers.set(timer.id, timer);
    }
    merged.actionTimers = [...timers.values()].slice(0, 300);
    merged.actionTimerTombstones = [...tombstones.values()]
      .sort((left, right) => Date.parse(left.deletedAt || 0) - Date.parse(right.deletedAt || 0))
      .slice(-1000);
  }
  const comparisonInitiative = currentTargetScene?.combat?.initiative ?? current.initiative;
  if (entityStamp(comparisonInitiative) > entityStamp(incoming.initiative)) merged.initiative = comparisonInitiative;
  return merged;
}

function syncActiveSceneCombatSnapshot(targetState) {
  const scene = (targetState?.scenes ?? []).find((entry) => entry.id === targetState.activeSceneId);
  if (!scene || !targetState.map || !targetState.initiative) return;
  scene.combat = {
    map: structuredClone(targetState.map),
    initiative: structuredClone(targetState.initiative)
  };
}

function saveSession(nextState, { merge = false } = {}) {
  const prepared = stripLegacyAccessTokens(migrateSessionCharacterSchemas(merge ? mergeCollaborativeState(nextState, sessionState) : nextState));
  syncActiveSceneCombatSnapshot(prepared);
  revision = Math.max(revision + 1, Number(prepared?.revision ?? 0) + 1);
  sessionState = { ...prepared, revision, updatedAt: new Date().toISOString() };
  const temporary = `${SESSION_FILE}.tmp`;
  writeFileSync(temporary, `${JSON.stringify(sessionState, null, 2)}\n`, { mode: 0o600 });
  renameSync(temporary, SESSION_FILE);
  userCharacterStorage.persistSession(sessionState);
  broadcastRevision();
  return sessionState;
}

function ensureSessionPlayer(account) {
  if (!sessionState || (sessionState.players ?? []).some((player) => player.id === account.id)) return false;
  sessionState.players ??= [];
  sessionState.players.push({ id: account.id, name: account.displayName, _updatedAt: Date.now() });
  saveSession(sessionState);
  return true;
}

function broadcastRevision() {
  const payload = `event: revision\ndata: ${JSON.stringify({ revision })}\n\n`;
  for (const client of [...eventClients]) {
    try { client.write(payload); } catch { eventClients.delete(client); }
  }
}

function isLoopback(req) {
  const address = req.socket.remoteAddress ?? "";
  return address === "127.0.0.1" || address === "::1" || address === "::ffff:127.0.0.1";
}

function sessionTokenFromRequest(req) {
  const header = String(req.headers["x-xar-session"] || "").trim();
  if (header) return header;
  const cookies = String(req.headers.cookie || "").split(";");
  for (const cookie of cookies) {
    const separator = cookie.indexOf("=");
    if (separator < 1 || cookie.slice(0, separator).trim() !== "xar_session") continue;
    try { return decodeURIComponent(cookie.slice(separator + 1).trim()); }
    catch { return ""; }
  }
  return "";
}

function authenticatedAccount(req) {
  const token = sessionTokenFromRequest(req);
  const session = authenticatedSessions.get(token);
  if (!token || !session || session.expiresAt <= Date.now()) {
    if (token) authenticatedSessions.delete(token);
    return null;
  }
  const account = accountStore.resolveSession(session.accountId, session.authRevision);
  if (!account) {
    authenticatedSessions.delete(token);
    return null;
  }
  session.expiresAt = Date.now() + SESSION_MAX_AGE_SECONDS * 1000;
  return account;
}

function allowPlayer(req) {
  return Boolean(authenticatedAccount(req));
}

function safeEqual(left, right) {
  const leftBuffer = Buffer.from(String(left ?? ""));
  const rightBuffer = Buffer.from(String(right ?? ""));
  return leftBuffer.length === rightBuffer.length && leftBuffer.length > 0 && timingSafeEqual(leftBuffer, rightBuffer);
}

function isMjRequest(req) {
  return authenticatedAccount(req)?.role === "gm";
}

function requestOrigin(req) {
  return String(req.headers.origin ?? "");
}

function bridgeCorsHeaders(req) {
  const origin = requestOrigin(req);
  if (!origin.startsWith("chrome-extension://")) return {};
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Headers": "Content-Type, X-Xar-Bridge-Token",
    "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
    Vary: "Origin"
  };
}

function bridgeAuthorized(req, reqUrl) {
  if (isMjRequest(req, reqUrl)) return true;
  return isLoopback(req) && safeEqual(req.headers["x-xar-bridge-token"], bridgeConfig.pairingToken);
}

function bridgeStatus({ includeToken = false } = {}) {
  const connected = bridgeLastSeenAt > 0 && Date.now() - bridgeLastSeenAt < 15000;
  return {
    connected,
    lastSeenAt: bridgeLastSeenAt || null,
    conversations: bridgeConfig.conversations,
    queuedJobs: bridgeJobs.filter((job) => ["queued", "offered", "prepared", "sent"].includes(job.status)).length,
    pendingImports: bridgeImports.length,
    ...(includeToken ? { pairingToken: bridgeConfig.pairingToken } : {})
  };
}

function pruneBridgeQueues() {
  const cutoff = Date.now() - 6 * 60 * 60 * 1000;
  for (let index = bridgeJobs.length - 1; index >= 0; index -= 1) {
    if (bridgeJobs[index].createdAt < cutoff) bridgeJobs.splice(index, 1);
  }
  for (let index = bridgeImports.length - 1; index >= 0; index -= 1) {
    if (bridgeImports[index].createdAt >= cutoff) continue;
    const stale = bridgeImports.splice(index, 1)[0];
    if (stale?.filePath && existsSync(stale.filePath)) rmSync(stale.filePath, { force: true });
  }
}

function cleanBridgeAttachment(entry, index) {
  const parsed = parseDataUrl(entry?.dataUrl);
  if (!parsed.mimeType.startsWith("image/")) throw new Error("Les références du pont doivent être des images.");
  if (parsed.bytes.length > 15 * 1024 * 1024) throw new Error("Une référence dépasse 15 Mo.");
  return {
    name: safeFilename(entry?.name, `reference-${index + 1}.webp`),
    mimeType: parsed.mimeType,
    dataUrl: String(entry.dataUrl)
  };
}

function bridgeImageExtension(contentType) {
  if (contentType === "image/png") return ".png";
  if (contentType === "image/jpeg") return ".jpg";
  if (contentType === "image/webp") return ".webp";
  if (contentType === "image/gif") return ".gif";
  return ".img";
}

function authenticatedPlayer(req) {
  const account = authenticatedAccount(req);
  if (account && sessionState) ensureSessionPlayer(account);
  return account ? { id: account.id, name: account.displayName, role: account.role } : null;
}

function sendJson(res, status, payload, extraHeaders = {}) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    ...extraHeaders
  });
  res.end(body);
}

function sendError(res, status, message, details) {
  sendJson(res, status, { ok: false, error: message, ...(details ? { details } : {}) });
}

function sessionCookie(token, maximumAge = SESSION_MAX_AGE_SECONDS) {
  return `xar_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maximumAge}`;
}

function createAuthenticatedSession(account) {
  const token = randomBytes(32).toString("base64url");
  authenticatedSessions.set(token, {
    accountId: account.id,
    authRevision: account.authRevision,
    expiresAt: Date.now() + SESSION_MAX_AGE_SECONDS * 1000
  });
  return token;
}

function sendBridgeJson(req, res, status, payload) {
  sendJson(res, status, payload, bridgeCorsHeaders(req));
}

function sendBridgeError(req, res, status, message) {
  sendBridgeJson(req, res, status, { ok: false, error: message });
}

async function readRawBody(req, maximum) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maximum) throw new Error(`La requête dépasse ${Math.round(maximum / 1024 / 1024)} Mo.`);
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function readBody(req, maximum = MAX_JSON_BODY_BYTES) {
  const bytes = await readRawBody(req, maximum);
  return bytes.length ? JSON.parse(bytes.toString("utf8")) : {};
}

function parseDataUrl(dataUrl) {
  const match = /^data:([^;,]+);base64,(.+)$/s.exec(String(dataUrl ?? ""));
  if (!match) throw new Error("Image encodée invalide.");
  return { mimeType: match[1], bytes: Buffer.from(match[2], "base64") };
}

function safeFilename(value, fallback = "xar-tsaroth.webp") {
  const cleaned = String(value ?? "")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 120);
  return cleaned || fallback;
}

const ownerCharacterKeys = new Set([
  "name", "surname", "givenName", "race", "age", "className", "advancedClass", "profession",
  "previousProfession", "pronouns", "portrait", "color", "resources", "stats", "fatigue", "morale",
  "armor", "speed", "initiativeBonus", "conditions", "publicNotes", "armorText", "weaponText", "passives",
  "skills", "specialSkills", "languages", "inventory", "personalAdvantageStock", "shortcuts", "linkedTokens"
]);

function stripPrivateCharacter(character) {
  const visible = {
    id: character?.id,
    ownerPlayerId: character?.ownerPlayerId,
    characterSchema: character?.characterSchema,
    characterSchemaVersion: character?.characterSchemaVersion,
    _updatedAt: character?._updatedAt
  };
  for (const key of ownerCharacterKeys) {
    if (Object.prototype.hasOwnProperty.call(character ?? {}, key)) visible[key] = character[key];
  }
  return visible;
}

function characterSummary(character) {
  return {
    id: character.id,
    name: character.name,
    portrait: character.portrait,
    color: character.color
  };
}

function publicState(fullState, identity) {
  if (!fullState) return null;
  const tacticalPaused = fullState.tacticalSync?.paused === true;
  const tacticalMap = tacticalPaused && fullState.tacticalSync?.publishedMap
    ? fullState.tacticalSync.publishedMap
    : fullState.map;
  const tacticalInitiative = tacticalPaused && fullState.tacticalSync?.publishedInitiative
    ? fullState.tacticalSync.publishedInitiative
    : fullState.initiative;
  const combatActive = tacticalInitiative?.active === true;
  const playerMovementMode = combatActive ? "combat" : "free";
  const tacticalActiveScene = tacticalPaused
    ? (fullState.tacticalSync?.publishedActiveScene ?? null)
    : fullState.activeScene;
  const fullOrder = tacticalInitiative?.order ?? [];
  const activeTokenId = combatActive
    ? fullOrder[Number(tacticalInitiative?.currentIndex ?? 0)] ?? null
    : null;
  const visibleTokens = (tacticalMap?.tokens ?? [])
    .filter((token) => !token.hidden)
    .map((token) => {
      const ownedByYou = Boolean(identity && token.controllerPlayerId === identity.id);
      const detailsVisible = ownedByYou || token.revealDetailsToPlayers === true;
      const visible = {
        id: token.id,
        characterId: token.characterId,
        name: token.name,
        image: token.image,
        color: token.color,
        x: token.x,
        y: token.y,
        size: token.size,
        initiative: token.initiative,
        detailsVisible,
        ownedByYou,
        controllable: Boolean(ownedByYou && !tacticalPaused && (playerMovementMode === "free" || token.id === activeTokenId))
      };
      if (detailsVisible) Object.assign(visible, {
        hp: token.hp,
        maxHp: token.maxHp,
        mana: token.mana,
        maxMana: token.maxMana,
        damageDice: token.damageDice,
        armor: token.armor,
        speed: token.speed,
        stats: token.stats,
        initiativeBonus: token.initiativeBonus,
        condition: token.condition,
        notes: token.notes
      });
      return visible;
    });
  const visibleTokenIds = new Set(visibleTokens.map((token) => token.id));
  const visibleOrder = fullOrder.filter((tokenId) => visibleTokenIds.has(tokenId));
  const visibleCurrentIndex = visibleOrder.indexOf(activeTokenId);
  const visibleRolls = (fullState.rolls ?? [])
    .filter((roll) => roll.visibility === "public" || roll.revealed)
    .map((roll) => ({ ...roll, rollerName: roll.rollerName || "MJ", rollerRole: roll.rollerRole || "gm" }));
  const characters = fullState.characters ?? [];
  const visibleSceneId = tacticalPaused ? (tacticalActiveScene?.id ?? null) : (fullState.activeSceneId ?? tacticalActiveScene?.id ?? null);
  const visibleActionTimers = (fullState.actionTimers ?? [])
    .filter((timer) => timer.sceneId === visibleSceneId && (timer.visibility === "public" || (identity && timer.ownerPlayerId === identity.id)))
    .map((timer) => ({
      id: timer.id,
      label: timer.label,
      cooldown: timer.cooldown,
      usedRound: timer.usedRound,
      readyRound: timer.readyRound,
      ownerLabel: timer.ownerLabel,
      visibility: timer.visibility,
      ownedByYou: Boolean(identity && timer.ownerPlayerId === identity.id)
    }));
  return {
    schemaVersion: fullState.schemaVersion,
    revision: fullState.revision,
    updatedAt: fullState.updatedAt,
    session: fullState.session,
    party: characters.map(characterSummary),
    myPlayer: identity ? { id: identity.id, name: identity.name || "Joueur", role: identity.role } : null,
    myCharacters: identity
      ? characters.filter((character) => character.ownerPlayerId === identity.id).map(stripPrivateCharacter)
      : [],
    tacticalLocked: tacticalPaused,
    playerMovementMode,
    map: { ...(tacticalMap ?? {}), tokens: visibleTokens },
    initiative: {
      ...(tacticalInitiative ?? {}),
      active: combatActive,
      order: visibleOrder,
      currentIndex: visibleCurrentIndex >= 0 ? visibleCurrentIndex : 0,
      currentTokenId: visibleCurrentIndex >= 0 ? activeTokenId : null
    },
    activeScene: tacticalActiveScene ? {
      id: tacticalActiveScene.id,
      name: tacticalActiveScene.name,
      subtitle: tacticalActiveScene.subtitle,
      description: tacticalActiveScene.description,
      accent: tacticalActiveScene.accent
    } : null,
    rolls: visibleRolls.slice(0, 30),
    actionTimers: visibleActionTimers,
    mapPings: (fullState.mapPings ?? [])
      .filter((ping) => ping.sceneId === visibleSceneId && Number(ping.expiresAt || 0) > Date.now())
      .map((ping) => ({ id: ping.id, x: ping.x, y: ping.y, author: ping.author, color: ping.color, expiresAt: ping.expiresAt })),
    tracks: (fullState.tracks ?? []).map((track) => ({
      id: track.id,
      mediaId: track.mediaId,
      url: track.url,
      name: track.name,
      originalName: track.originalName,
      channel: track.channel,
      type: track.type,
      size: track.size
    })),
    audio: fullState.audio ?? null
  };
}

function cleanObject(value) {
  if (Array.isArray(value)) return value.slice(0, 300).map(cleanObject);
  if (value && typeof value === "object") {
    const result = {};
    for (const [key, child] of Object.entries(value)) {
      if (["__proto__", "constructor", "prototype"].includes(key)) continue;
      result[key] = cleanObject(child);
    }
    return result;
  }
  if (typeof value === "string") return value.slice(0, 50000);
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  if (typeof value === "boolean" || value === null) return value;
  return "";
}

function characterPatch(bodyPatch, isGm) {
  const result = {};
  const permitted = isGm ? new Set([...ownerCharacterKeys, "ownerPlayerId", "secret"]) : ownerCharacterKeys;
  for (const [key, value] of Object.entries(bodyPatch ?? {})) {
    if (!permitted.has(key)) continue;
    if (key === "portrait") result[key] = value ? String(value).slice(0, 2_000_000) : null;
    else if (key === "linkedTokens") result[key] = normalizeLinkedTokens(value);
    else result[key] = cleanObject(value);
  }
  return result;
}

function characterTokenStats(character) {
  const labels = { force: "Force", dexterity: "Dextérité", agility: "Agilité", spiritSocial: "Esprit / Social", intelligence: "Intelligence", instinct: "Instinct" };
  return Object.entries(character.stats ?? {}).map(([key, value]) => ({ id: `character-stat-${key}`, label: labels[key] || key, value: String(value ?? "") }));
}

function createSessionToken(character, linkedToken = null) {
  const index = sessionState.map?.tokens?.length ?? 0;
  const point = snapMapPercentPoint(42 + (index % 4) * 6, 48 + (index % 3) * 7, sessionState.map ?? {});
  return {
    id: `token-${randomUUID()}`,
    libraryTemplateId: null,
    characterId: character.id,
    linkedTokenId: linkedToken?.id ?? null,
    controllerPlayerId: character.ownerPlayerId,
    followCharacter: !linkedToken,
    name: linkedToken?.name || character.name || "Personnage",
    image: linkedToken?.image || character.portrait || null,
    color: linkedToken?.color || character.color || "#8d72cb",
    x: point.x,
    y: point.y,
    size: Number(linkedToken?.size || 30),
    hp: linkedToken ? 0 : Number(character.resources?.hp ?? 0),
    maxHp: linkedToken ? 0 : Number(character.resources?.maxHp ?? 0),
    initiative: null,
    mana: linkedToken ? 0 : Number(character.resources?.mana ?? 0),
    maxMana: linkedToken ? 0 : Number(character.resources?.maxMana ?? 0),
    damageDice: "",
    armor: linkedToken ? 0 : Number(character.armor ?? 0),
    speed: linkedToken ? 0 : Number(character.speed ?? 0),
    stats: linkedToken ? [] : characterTokenStats(character),
    initiativeBonus: linkedToken ? 0 : Number(character.initiativeBonus ?? 0),
    condition: "",
    hidden: false,
    revealDetailsToPlayers: false,
    notes: "",
    gmNotes: "",
    _updatedAt: Date.now(),
    _movedAt: Date.now()
  };
}

function enforceD100Shortcuts(character) {
  if (!Array.isArray(character.shortcuts)) return;
  character.shortcuts = character.shortcuts.map((shortcut) => {
    const next = { ...shortcut };
    const damageDice = next.kind === "damage" || /d[eé]g[aâ]ts?|dommages?|damage/i.test(String(next.label ?? ""));
    if (next.kind === "initiative" || !damageDice) {
      const formula = String(next.formula || "1d100").replaceAll(" ", "");
      next.formula = /(?:\d*)d\d+/i.test(formula)
        ? formula.replace(/(?:\d*)d\d+/i, "1d100")
        : `1d100${formula ? `${/^[+\-]/.test(formula) ? "" : "+"}${formula}` : ""}`;
    }
    return next;
  });
}

function usesDamageDice(label = "") {
  return /d[eé]g[aâ]ts?|dommages?|damage/i.test(String(label));
}

function d100Formula(formula = "1d100") {
  const clean = String(formula || "1d100").replaceAll(" ", "").slice(0, 100);
  return /(?:\d*)d\d+/i.test(clean)
    ? clean.replace(/(?:\d*)d\d+/i, "1d100")
    : `1d100${clean ? `${/^[+\-]/.test(clean) ? "" : "+"}${clean}` : ""}`;
}

function rollFormula(formula) {
  const normalized = String(formula || "").toLowerCase().replaceAll(" ", "").slice(0, 100);
  if (!normalized || !/^[+\-]?((\d*)d\d+|\d+)([+\-]((\d*)d\d+|\d+))*$/.test(normalized)) {
    throw new Error("Formule invalide. Exemple : 1d100+10 ou 2d6+4.");
  }
  const terms = normalized.match(/[+\-]?[^+\-]+/g) || [];
  let total = 0;
  const parts = [];
  for (const term of terms) {
    const sign = term.startsWith("-") ? -1 : 1;
    const clean = term.replace(/^[+\-]/, "");
    if (clean.includes("d")) {
      const [countText, sidesText] = clean.split("d");
      const count = Number(countText || 1);
      const sides = Number(sidesText);
      if (count < 1 || count > 100 || sides < 2 || sides > 1000) throw new Error("Dés hors limites (maximum 100 dés de 1000 faces).");
      const results = Array.from({ length: count }, () => cryptoRandomInt(1, sides + 1));
      total += results.reduce((sum, value) => sum + value, 0) * sign;
      parts.push(`${sign < 0 ? "−" : parts.length ? "+" : ""}[${results.join(", ")}]`);
    } else {
      const value = Number(clean) * sign;
      total += value;
      parts.push(`${value >= 0 && parts.length ? "+" : ""}${value}`);
    }
  }
  return { total, breakdown: parts.join(" ") };
}

function safeDiscordLabel(value) {
  return String(value || "Jet").replace(/([*_`~|\\])/g, "\\$1").slice(0, 180);
}

function discordRollContent(roll) {
  return `🎲 **${safeDiscordLabel(roll.rollerName)} · ${safeDiscordLabel(roll.characterName ? `${roll.characterName} · ${roll.label}` : roll.label)}** — \`${roll.formula}\`\nRésultat : **${roll.total}** · ${roll.breakdown}`;
}

function syncCharacterTokens(character) {
  const collections = [sessionState?.map?.tokens ?? []];
  for (const scene of sessionState?.scenes ?? []) {
    if (scene.id === sessionState.activeSceneId || !Array.isArray(scene.combat?.map?.tokens)) continue;
    collections.push(scene.combat.map.tokens);
  }
  for (const tokens of collections) {
    for (const token of tokens) {
      if (token.characterId !== character.id) continue;
      if (token.linkedTokenId) {
        const linked = normalizeLinkedTokens(character.linkedTokens).find((entry) => entry.id === token.linkedTokenId);
        if (!linked) continue;
        token.name = linked.name;
        token.color = linked.color;
        token.image = linked.image;
        token.size = linked.size;
        token.controllerPlayerId = character.ownerPlayerId;
        token._updatedAt = character._updatedAt;
        continue;
      }
      if (token.followCharacter === false) continue;
      token.name = character.name || token.name;
      token.color = character.color || token.color;
      token.image = character.portrait || token.image;
      token.hp = Number(character.resources?.hp ?? token.hp ?? 0);
      token.maxHp = Number(character.resources?.maxHp ?? token.maxHp ?? 0);
      token.mana = Number(character.resources?.mana ?? token.mana ?? 0);
      token.maxMana = Number(character.resources?.maxMana ?? token.maxMana ?? 0);
      token.armor = Number(character.armor ?? token.armor ?? 0);
      token.speed = Number(character.speed ?? token.speed ?? 0);
      const statLabels = {
        force: "Force", dexterity: "Dextérité", agility: "Agilité", spiritSocial: "Esprit / Social",
        intelligence: "Intelligence", instinct: "Instinct / Perception"
      };
      token.stats = Object.entries(character.stats ?? {}).map(([key, value]) => ({ id: `character-stat-${key}`, label: statLabels[key] || key, value: String(value ?? "") }));
      token.initiativeBonus = Number(character.initiativeBonus ?? token.initiativeBonus ?? 0);
      token._updatedAt = character._updatedAt;
    }
  }
}

function webhookForTarget(target) {
  if (target === "dice") return process.env.DISCORD_DICE_WEBHOOK_URL?.trim();
  if (target === "journal") return process.env.DISCORD_JOURNAL_WEBHOOK_URL?.trim();
  return process.env.DISCORD_IMAGE_WEBHOOK_URL?.trim();
}

async function postToDiscord(body) {
  const webhook = webhookForTarget(body.target);
  if (!webhook) throw new Error(`Le webhook Discord « ${body.target || "images"} » n’est pas configuré.`);
  const content = String(body.content ?? "").slice(0, 1900);
  let response;
  if (body.imageDataUrl) {
    const image = parseDataUrl(body.imageDataUrl);
    const form = new FormData();
    form.append("payload_json", JSON.stringify({ content, allowed_mentions: { parse: [] } }));
    form.append("files[0]", new Blob([image.bytes], { type: image.mimeType }), safeFilename(body.filename));
    response = await fetch(`${webhook}${webhook.includes("?") ? "&" : "?"}wait=true`, { method: "POST", body: form });
  } else {
    response = await fetch(`${webhook}${webhook.includes("?") ? "&" : "?"}wait=true`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content, allowed_mentions: { parse: [] } })
    });
  }
  const text = await response.text();
  if (!response.ok) throw new Error(`Discord a refusé l’envoi (${response.status}) : ${text.slice(0, 300)}`);
  return { message: text ? JSON.parse(text) : null };
}

function ovhConnectionConfig() {
  const baseUrl = process.env.OVH_FTP_URL?.trim();
  const username = process.env.OVH_FTP_USER?.trim();
  const password = process.env.OVH_FTP_PASSWORD ?? "";
  if (!baseUrl || !username || !password) throw new Error("Les paramètres OVH ne sont pas configurés dans l’administration du launcher.");
  const parsed = new URL(baseUrl);
  if (!["ftp:", "ftps:", "sftp:"].includes(parsed.protocol)) throw new Error("OVH_FTP_URL doit utiliser ftp, ftps ou sftp.");
  const remoteSegments = parsed.pathname.split("/").filter(Boolean);
  const remoteLeaf = remoteSegments.at(-1)?.toLowerCase();
  if (!remoteSegments.length || remoteSegments.some((entry) => entry.toLowerCase() === "www")) {
    throw new Error("OVH_FTP_URL doit viser un dossier média dédié, jamais la racine FTP ni le dossier www.");
  }
  if (/[\r\n]/.test(`${username}${password}`)) throw new Error("Les identifiants OVH contiennent un caractère interdit.");
  const connection = {
    baseUrl: baseUrl.replace(/\/+$/, ""),
    username,
    password,
    parsed,
    remoteLeaf,
    curlOptions: parsed.protocol === "ftp:" ? ["--ssl-reqd"] : [],
    transport: parsed.protocol === "sftp:" && ovhOpenSshHosts.has(parsed.hostname)
      ? "openssh-sftp"
      : (parsed.protocol === "ftp:" ? "ftpes" : parsed.protocol.replace(":", ""))
  };
  return connection;
}

function curlHasDisabledSftp(error) {
  return /protocol\s+["']?sftp["']?\s+(?:is\s+)?(?:disabled|not supported)|unsupported protocol[^\n]*sftp/i.test(String(error?.message || ""));
}

function queueOvhOperation(task) {
  const operation = ovhOperationChain.then(task, task);
  ovhOperationChain = operation.catch(() => {});
  return operation;
}

async function withOvhConnection(callback) {
  const config = ovhConnectionConfig();
  const temporaryDirectory = await mkdtemp(path.join(tmpdir(), "xar-regie-ovh-"));
  const netrc = path.join(temporaryDirectory, "credentials.netrc");
  await writeFile(netrc, `machine ${config.parsed.hostname}\nlogin ${config.username}\npassword ${config.password}\n`, { mode: 0o600 });
  try {
    return await callback({ ...config, netrc, temporaryDirectory });
  } finally {
    rmSync(temporaryDirectory, { recursive: true, force: true });
  }
}

function runOvhCurlOnce(connection, argumentsList, input = null, { allowMissing = false } = {}) {
  return new Promise((resolve, reject) => {
    const common = [
      "--silent", "--show-error", "--connect-timeout", "12", "--max-time", "180",
      ...(connection.curlOptions ?? []),
      "--netrc-file", connection.netrc
    ];
    const testScript = process.env.NODE_ENV === "test" ? process.env.XAR_TEST_OVH_CURL_SCRIPT : "";
    const command = testScript ? process.execPath : "curl";
    const prefix = testScript ? [path.resolve(testScript)] : [];
    const child = spawn(command, [...prefix, ...common, ...argumentsList], { stdio: ["pipe", "pipe", "pipe"] });
    const output = [];
    let outputSize = 0;
    let errorText = "";
    child.stdout.on("data", (chunk) => {
      outputSize += chunk.length;
      if (outputSize <= MAX_OVH_TEXT_BYTES) output.push(chunk);
      else child.kill("SIGTERM");
    });
    child.stderr.on("data", (chunk) => { errorText += chunk.toString(); });
    child.on("error", reject);
    child.on("close", (code) => {
      if (outputSize > MAX_OVH_TEXT_BYTES) return reject(new Error("La réponse FTP dépasse la limite de sécurité."));
      if (code === 0) return resolve({ bytes: Buffer.concat(output), missing: false });
      const missing = [21, 22, 78, 79].includes(code) && /(?:550|not found|no such file|does not exist|remote file)/i.test(errorText);
      if (allowMissing && missing) return resolve({ bytes: Buffer.alloc(0), missing: true });
      const detail = errorText.trim().replace(/\s+/g, " ").slice(0, 420);
      const error = new Error(detail || `Le transfert FTP a échoué avec le code ${code}.`);
      error.curlCode = code;
      return reject(error);
    });
    child.stdin.end(input ?? undefined);
  });
}

const runOvhCurl = runOvhCurlOnce;

function runCapturedProcess(command, argumentsList, { env = process.env, input = null } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, argumentsList, { env, stdio: ["pipe", "pipe", "pipe"], windowsHide: true });
    const output = [];
    let outputSize = 0;
    let errorText = "";
    child.stdout.on("data", (chunk) => {
      outputSize += chunk.length;
      if (outputSize <= MAX_OVH_TEXT_BYTES) output.push(chunk);
      else child.kill("SIGTERM");
    });
    child.stderr.on("data", (chunk) => { errorText += chunk.toString(); });
    child.on("error", (error) => reject(new Error(`Impossible de lancer ${path.basename(command)} : ${error.message}`)));
    child.on("close", (code) => {
      if (outputSize > MAX_OVH_TEXT_BYTES) return reject(new Error("La réponse SFTP dépasse la limite de sécurité."));
      resolve({ code: Number(code ?? 1), bytes: Buffer.concat(output), errorText });
    });
    child.stdin.end(input ?? undefined);
  });
}

function windowsPowerShellExecutable() {
  const root = process.env.SystemRoot || process.env.WINDIR;
  const bundled = root ? path.join(root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe") : "";
  return bundled && existsSync(bundled) ? bundled : "powershell.exe";
}

function openSshSftpExecutable() {
  const testScript = process.env.NODE_ENV === "test" ? process.env.XAR_TEST_OVH_SFTP_SCRIPT : "";
  if (testScript) return { command: process.execPath, prefix: [path.resolve(testScript)] };
  if (process.platform !== "win32") return { command: "sftp", prefix: [] };
  const root = process.env.SystemRoot || process.env.WINDIR;
  const bundled = root ? path.join(root, "System32", "OpenSSH", "sftp.exe") : "";
  return { command: bundled && existsSync(bundled) ? bundled : "sftp.exe", prefix: [] };
}

async function ensureSftpAskpass(connection) {
  if (connection.askpassPath) return connection.askpassPath;
  if (process.platform !== "win32") {
    const askpassPath = path.join(connection.temporaryDirectory, "askpass.sh");
    await writeFile(askpassPath, "#!/bin/sh\nprintf '%s\\n' \"$XAR_OVH_SFTP_PASSWORD\"\n", { mode: 0o700 });
    await chmod(askpassPath, 0o700);
    connection.askpassPath = askpassPath;
    return askpassPath;
  }

  const sourcePath = path.join(connection.temporaryDirectory, "XarAskPass.cs");
  const compilerPath = path.join(connection.temporaryDirectory, "compile-askpass.ps1");
  const askpassPath = path.join(connection.temporaryDirectory, "xar-askpass.exe");
  const source = [
    "using System;",
    "using System.Text;",
    "public static class XarAskPass {",
    "  public static int Main(string[] args) {",
    "    Console.OutputEncoding = new UTF8Encoding(false);",
    "    Console.WriteLine(Environment.GetEnvironmentVariable(\"XAR_OVH_SFTP_PASSWORD\") ?? \"\");",
    "    return 0;",
    "  }",
    "}"
  ].join("\n");
  const compiler = [
    "param([string]$SourcePath, [string]$OutputPath)",
    "$code = [System.IO.File]::ReadAllText($SourcePath)",
    "Add-Type -TypeDefinition $code -Language CSharp -OutputAssembly $OutputPath -OutputType ConsoleApplication -ErrorAction Stop"
  ].join("\r\n");
  await Promise.all([
    writeFile(sourcePath, source, { mode: 0o600 }),
    writeFile(compilerPath, compiler, { mode: 0o600 })
  ]);
  const result = await runCapturedProcess(windowsPowerShellExecutable(), [
    "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
    "-File", compilerPath, sourcePath, askpassPath
  ]);
  if (result.code !== 0 || !existsSync(askpassPath)) {
    const detail = result.errorText.trim().replace(/\s+/g, " ").slice(0, 420);
    throw new Error(detail || "Windows n’a pas pu préparer l’authentification SFTP sécurisée.");
  }
  connection.askpassPath = askpassPath;
  return askpassPath;
}

function sftpQuoted(value) {
  const clean = String(value ?? "");
  if (!clean || /[\r\n\0]/.test(clean)) throw new Error("Un chemin SFTP contient un caractère interdit.");
  return `"${clean.replace(/(["\\])/g, "\\$1")}"`;
}

function sftpRemoteDirectory(connection) {
  const urlPath = decodeURIComponent(connection.parsed.pathname).replace(/\/+$/, "") || "/";
  // Dans une URL SFTP curl, /~/ désigne le dossier personnel de l’utilisateur.
  // Le client OpenSSH démarre déjà dans ce dossier : il lui faut donc un chemin relatif.
  if (urlPath === "/~") return ".";
  if (urlPath.startsWith("/~/")) return urlPath.slice(3) || ".";
  return urlPath;
}

function sftpRemotePath(connection, remoteName = "") {
  const directory = sftpRemoteDirectory(connection);
  if (directory === ".") return remoteName || ".";
  return remoteName ? `${directory}/${remoteName}`.replace(/\/{2,}/g, "/") : directory;
}

function sftpLocalPath(value) {
  return process.platform === "win32" ? String(value).replaceAll("\\", "/") : String(value);
}

function actionableSftpFailure(connection, detail) {
  const host = connection.parsed.hostname;
  const port = Number(connection.parsed.port || 22);
  if (/connection (?:closed|reset)|closed by remote host|kex_exchange_identification/i.test(detail)) {
    return `OVH a fermé la session SFTP OpenSSH à ${host}:${port} avant l’accès au dossier. Vérifiez le port 22, l’activation SFTP et le mot de passe de l’utilisateur « ${connection.username} ». Si les mêmes valeurs fonctionnent dans FileZilla, la cause est une incompatibilité du client OpenSSH et non le chemin regie-media.`;
  }
  if (/permission denied|authentication failed|no supported authentication methods/i.test(detail)) {
    return `OVH a refusé l’identification SFTP de l’utilisateur « ${connection.username} ». Vérifiez que le SFTP est activé pour cet utilisateur puis réinitialisez au besoin son mot de passe FTP/SFTP dans l’espace client OVHcloud.`;
  }
  if (/could not resolve hostname|name or service not known|temporary failure in name resolution/i.test(detail)) {
    return `Le nom du serveur SFTP « ${host} » est introuvable depuis cet ordinateur. Vérifiez l’adresse « Serveur FTP et SFTP » indiquée par OVHcloud et la connexion Internet.`;
  }
  if (/connection refused|connection timed out|operation timed out|network is unreachable/i.test(detail)) {
    return `Le serveur SFTP ${host}:${port} est inaccessible depuis cet ordinateur. Vérifiez le port 22, le pare-feu et l’état du service OVHcloud.`;
  }
  return detail;
}

async function runOvhSftpBatch(connection, commands, { allowMissing = false } = {}) {
  const askpassPath = await ensureSftpAskpass(connection);
  const port = Number(connection.parsed.port || 22);
  const executable = openSshSftpExecutable();
  const result = await runCapturedProcess(executable.command, [...executable.prefix,
    "-q", "-P", String(port),
    "-oBatchMode=no",
    "-oPreferredAuthentications=password,keyboard-interactive",
    "-oNumberOfPasswordPrompts=1",
    "-oStrictHostKeyChecking=accept-new",
    "-oConnectTimeout=12",
    "-oLogLevel=ERROR",
    `${connection.username}@${connection.parsed.hostname}`
  ], {
    env: {
      ...process.env,
      DISPLAY: process.env.DISPLAY || "xar-regie:0",
      SSH_ASKPASS: askpassPath,
      SSH_ASKPASS_REQUIRE: "force",
      XAR_OVH_SFTP_PASSWORD: connection.password
    },
    input: `${commands.join("\n")}\nbye\n`
  });
  const errorDetail = result.errorText.trim().replace(/\s+/g, " ").slice(0, 520);
  const detail = `${result.errorText}\n${result.bytes.toString("utf8")}`.trim().replace(/\s+/g, " ").slice(0, 520);
  const missing = /no such file|not found|couldn'?t stat|cannot stat/i.test(errorDetail);
  if (allowMissing && missing) return { bytes: Buffer.alloc(0), missing: true };
  const commandFailed = /couldn'?t|cannot|permission denied|remote (?:open|readdir|delete).*failed|\bfailure\b|invalid command|not connected/i.test(errorDetail);
  if (result.code === 0 && !commandFailed) return { bytes: result.bytes, missing: false };
  throw new Error(actionableSftpFailure(connection, detail) || `Le client SFTP sécurisé a échoué avec le code ${result.code}.`);
}

async function withOpenSshSftpFallback(connection, curlOperation, sftpOperation) {
  if (connection.transport === "openssh-sftp") return sftpOperation();
  try {
    return await curlOperation();
  } catch (error) {
    if (connection.parsed.protocol !== "sftp:" || !curlHasDisabledSftp(error)) throw error;
    connection.transport = "openssh-sftp";
    try {
      const result = await sftpOperation();
      ovhOpenSshHosts.add(connection.parsed.hostname);
      return result;
    } catch (sftpError) {
      connection.transport = "sftp";
      throw new Error(`Le curl de cet ordinateur ne prend pas SFTP en charge et le client OpenSSH SFTP n’a pas pu se connecter : ${sftpError.message}`);
    }
  }
}

function ovhRemoteUrl(connection, remoteName) {
  return `${connection.baseUrl}/${encodeURIComponent(remoteName)}`;
}

async function readOvhRemoteText(connection, remoteName) {
  return withOpenSshSftpFallback(
    connection,
    async () => {
      const result = await runOvhCurl(connection, ["--fail", ovhRemoteUrl(connection, remoteName)], null, { allowMissing: true });
      return result.missing ? null : result.bytes.toString("utf8");
    },
    async () => {
      const localPath = path.join(connection.temporaryDirectory, `read-${randomUUID()}.bin`);
      const result = await runOvhSftpBatch(connection, [
        `get ${sftpQuoted(sftpRemotePath(connection, remoteName))} ${sftpQuoted(sftpLocalPath(localPath))}`
      ], { allowMissing: true });
      return result.missing ? null : (await readFile(localPath)).toString("utf8");
    }
  );
}

async function uploadOvhRemoteBytes(connection, remoteName, bytes) {
  return withOpenSshSftpFallback(
    connection,
    async () => {
      const createDirectories = connection.parsed.protocol === "sftp:" ? [] : ["--ftp-create-dirs"];
      await runOvhCurl(connection, ["--fail", ...createDirectories, "--upload-file", "-", ovhRemoteUrl(connection, remoteName)], bytes);
    },
    async () => {
      const localPath = path.join(connection.temporaryDirectory, `upload-${randomUUID()}.bin`);
      await writeFile(localPath, bytes, { mode: 0o600 });
      await runOvhSftpBatch(connection, [
        `put ${sftpQuoted(sftpLocalPath(localPath))} ${sftpQuoted(sftpRemotePath(connection, remoteName))}`
      ]);
    }
  );
}

async function deleteOvhRemoteFile(connection, remoteName) {
  if (!isManagedRemoteName(remoteName) && !isLegacyRegieRemoteName(remoteName)) {
    throw new Error("La protection FTP a refusé la suppression d’un fichier non géré.");
  }
  return withOpenSshSftpFallback(
    connection,
    () => {
      const command = connection.parsed.protocol === "sftp:" ? `rm ${remoteName}` : `DELE ${remoteName}`;
      return runOvhCurl(connection, ["--fail", "--quote", command, "--list-only", `${connection.baseUrl}/`], null, { allowMissing: true });
    },
    () => runOvhSftpBatch(connection, [`rm ${sftpQuoted(sftpRemotePath(connection, remoteName))}`], { allowMissing: true })
  );
}

async function listOvhRemoteFiles(connection) {
  return withOpenSshSftpFallback(
    connection,
    async () => {
      const result = await runOvhCurl(connection, ["--fail", "--list-only", `${connection.baseUrl}/`]);
      return result.bytes.toString("utf8").split(/\r?\n/).map((entry) => entry.trim()).filter(Boolean);
    },
    async () => {
      const result = await runOvhSftpBatch(connection, [`ls -1 ${sftpQuoted(sftpRemotePath(connection))}`]);
      return result.bytes.toString("utf8").split(/\r?\n/)
        .map((entry) => entry.trim())
        .filter((entry) => entry && !/^sftp>\s*/i.test(entry))
        .map((entry) => path.posix.basename(entry.replaceAll("\\", "/")))
        .filter(Boolean);
    }
  );
}

async function readOvhManifest(connection) {
  const raw = await readOvhRemoteText(connection, OVH_MANIFEST_FILENAME);
  if (raw === null) return emptyOvhManifest();
  try {
    return normalizeOvhManifest(JSON.parse(raw));
  } catch (error) {
    throw new Error(`Le registre distant Xar Régie ne peut pas être lu : ${error.message}`);
  }
}

async function writeOvhManifest(connection, manifest) {
  const normalized = normalizeOvhManifest(manifest);
  normalized.updatedAt = new Date().toISOString();
  await uploadOvhRemoteBytes(connection, OVH_MANIFEST_FILENAME, Buffer.from(`${JSON.stringify(normalized, null, 2)}\n`, "utf8"));
  return normalized;
}

async function performOvhCleanup(connection, { forceLegacy = false } = {}) {
  const manifest = await readOvhManifest(connection);
  const plan = cleanupPlan(manifest, APP_VERSION);
  const failedManaged = [];
  const warnings = [];
  let deletedManaged = 0;
  let deletedLegacy = 0;

  for (const entry of plan.obsolete) {
    try {
      await deleteOvhRemoteFile(connection, entry.remoteName);
      deletedManaged += 1;
    } catch (error) {
      failedManaged.push(entry);
      warnings.push(`${entry.originalName || entry.remoteName} : ${error.message}`);
    }
  }

  manifest.files = [...plan.retained, ...failedManaged];
  if (forceLegacy || manifest.legacySweepBuildVersion !== APP_VERSION) {
    try {
      const legacyNames = [...new Set((await listOvhRemoteFiles(connection)).filter(isLegacyRegieRemoteName))];
      let legacyFailed = false;
      for (const remoteName of legacyNames) {
        try {
          await deleteOvhRemoteFile(connection, remoteName);
          deletedLegacy += 1;
        } catch (error) {
          legacyFailed = true;
          warnings.push(`${remoteName} : ${error.message}`);
        }
      }
      if (!legacyFailed) {
        manifest.legacySweepAt = new Date().toISOString();
        manifest.legacySweepBuildVersion = APP_VERSION;
      }
    } catch (error) {
      warnings.push(`Inventaire des anciens médias : ${error.message}`);
    }
  }

  manifest.lastCleanupAt = new Date().toISOString();
  const savedManifest = await writeOvhManifest(connection, manifest);
  ovhRuntimeStatus = {
    buildVersion: APP_VERSION,
    automatic: true,
    initialized: true,
    trackedFiles: savedManifest.files.length,
    lastCleanupAt: savedManifest.lastCleanupAt,
    lastDeletedCount: deletedManaged + deletedLegacy,
    warnings
  };
  return {
    manifest: savedManifest,
    summary: {
      buildVersion: APP_VERSION,
      deletedManaged,
      deletedLegacy,
      deletedCount: deletedManaged + deletedLegacy,
      trackedFiles: savedManifest.files.length,
      lastCleanupAt: savedManifest.lastCleanupAt,
      warnings
    }
  };
}

async function cleanupOvhMedia({ forceLegacy = false } = {}) {
  return queueOvhOperation(() => withOvhConnection(async (connection) => {
    const result = await performOvhCleanup(connection, { forceLegacy });
    return result.summary;
  }));
}

async function uploadToOvh(body) {
  return queueOvhOperation(() => withOvhConnection(async (connection) => {
    const image = parseDataUrl(body.imageDataUrl);
    const originalFilename = safeFilename(body.filename);
    const cleanup = await performOvhCleanup(connection);
    const remoteName = managedRemoteName(originalFilename, image.mimeType);
    const createdAt = new Date().toISOString();
    await uploadOvhRemoteBytes(connection, remoteName, image.bytes);
    let manifest;
    try {
      manifest = appendManagedFile(cleanup.manifest, {
        id: remoteName,
        remoteName,
        originalName: originalFilename,
        contentType: image.mimeType,
        size: image.bytes.length,
        buildVersion: APP_VERSION,
        createdAt,
        keepAcrossBuilds: false
      });
      manifest = await writeOvhManifest(connection, manifest);
    } catch (error) {
      await deleteOvhRemoteFile(connection, remoteName).catch(() => {});
      throw error;
    }
    ovhRuntimeStatus = {
      ...ovhRuntimeStatus,
      initialized: true,
      trackedFiles: manifest.files.length,
      warnings: cleanup.summary.warnings
    };
    const publicBase = process.env.OVH_PUBLIC_BASE_URL?.trim();
    return {
      filename: remoteName,
      originalFilename,
      publicUrl: publicBase ? `${publicBase.replace(/\/+$/, "")}/${encodeURIComponent(remoteName)}` : null,
      cleanup: cleanup.summary,
      storage: ovhRuntimeStatus
    };
  }));
}

function mediaExtension(filename, contentType) {
  const requested = path.extname(filename).toLowerCase();
  if (mimeTypes[requested]?.startsWith("audio/")) return requested;
  return Object.entries(mimeTypes).find(([, type]) => type === contentType && type.startsWith("audio/"))?.[0] ?? ".mp3";
}

async function uploadMedia(req, res, url) {
  if (!isMjRequest(req, url)) return sendError(res, 403, "L’import audio est réservé à la session MJ authentifiée.");
  const filename = safeFilename(url.searchParams.get("filename"), "piste.mp3");
  const contentType = String(req.headers["content-type"] ?? "audio/mpeg").split(";")[0];
  if (!contentType.startsWith("audio/")) return sendError(res, 415, "Le fichier doit être un média audio.");
  const bytes = await readRawBody(req, MAX_MEDIA_BODY_BYTES);
  if (!bytes.length) return sendError(res, 400, "Le fichier audio est vide.");
  const mediaId = `${randomUUID()}${mediaExtension(filename, contentType)}`;
  writeFileSync(path.join(MEDIA_DIR, mediaId), bytes, { mode: 0o600 });
  return sendJson(res, 201, { ok: true, mediaId, url: `/media/${mediaId}`, contentType, size: bytes.length });
}

function deleteMedia(req, res, url) {
  if (!isMjRequest(req, url)) return sendError(res, 403, "La suppression audio est réservée à la session MJ authentifiée.");
  const mediaId = path.basename(String(url.searchParams.get("mediaId") ?? ""));
  if (!mediaId) return sendError(res, 400, "Média non indiqué.");
  const filePath = path.join(MEDIA_DIR, mediaId);
  if (existsSync(filePath)) rmSync(filePath, { force: true });
  return sendJson(res, 200, { ok: true });
}

function staticFilePath(requestPath) {
  const decoded = decodeURIComponent(requestPath);
  const relative = decoded === "/" ? "index.html" : decoded.replace(/^\/+/, "");
  const normalized = path.normalize(relative).replace(/^(\.\.(\/|\\|$))+/, "");
  const resolved = path.join(PUBLIC_DIR, normalized);
  return resolved.startsWith(PUBLIC_DIR) ? resolved : null;
}

function serveMedia(req, res, url) {
  if (!isMjRequest(req, url) && !allowPlayer(req)) return sendError(res, 403, "Accès au média refusé.");
  const mediaId = path.basename(decodeURIComponent(url.pathname.replace(/^\/media\//, "")));
  const filePath = path.join(MEDIA_DIR, mediaId);
  if (!mediaId || !existsSync(filePath) || !statSync(filePath).isFile()) {
    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    return res.end("Média introuvable");
  }
  const size = statSync(filePath).size;
  const type = mimeTypes[path.extname(filePath).toLowerCase()] ?? "application/octet-stream";
  const range = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range ?? ""));
  if (range) {
    const start = range[1] ? Number(range[1]) : 0;
    const end = range[2] ? Math.min(Number(range[2]), size - 1) : size - 1;
    if (!Number.isFinite(start) || !Number.isFinite(end) || start > end || start >= size) {
      res.writeHead(416, { "Content-Range": `bytes */${size}` });
      return res.end();
    }
    res.writeHead(206, {
      "Content-Type": type,
      "Content-Length": end - start + 1,
      "Content-Range": `bytes ${start}-${end}/${size}`,
      "Accept-Ranges": "bytes",
      "Cache-Control": "private, max-age=3600",
      "X-Content-Type-Options": "nosniff"
    });
    return createReadStream(filePath, { start, end }).pipe(res);
  }
  res.writeHead(200, {
    "Content-Type": type,
    "Content-Length": size,
    "Accept-Ranges": "bytes",
    "Cache-Control": "private, max-age=3600",
    "X-Content-Type-Options": "nosniff"
  });
  return createReadStream(filePath).pipe(res);
}

function openEventStream(req, res, url) {
  if (!isMjRequest(req, url) && !allowPlayer(req)) return sendError(res, 403, "Accès à la synchronisation refusé.");
  res.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-store",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no"
  });
  res.write(`event: revision\ndata: ${JSON.stringify({ revision })}\n\n`);
  eventClients.add(res);
  const heartbeat = setInterval(() => {
    try { res.write(": direct\n\n"); } catch { clearInterval(heartbeat); }
  }, 20000);
  req.on("close", () => {
    clearInterval(heartbeat);
    eventClients.delete(res);
  });
}

async function handleChatGptBridge(req, res, url) {
  const corsHeaders = bridgeCorsHeaders(req);
  if (req.method === "OPTIONS") {
    res.writeHead(204, corsHeaders);
    return res.end();
  }
  if (!bridgeAuthorized(req, url)) return sendBridgeError(req, res, 403, "Pont ChatGPT non appairé.");
  const managerRequest = isMjRequest(req, url);
  pruneBridgeQueues();

  if (req.method === "GET" && url.pathname === "/api/chatgpt-bridge/status") {
    if (!managerRequest) bridgeLastSeenAt = Date.now();
    return sendBridgeJson(req, res, 200, { ok: true, ...bridgeStatus({ includeToken: managerRequest }) });
  }

  if (req.method === "POST" && url.pathname === "/api/chatgpt-bridge/config") {
    if (!managerRequest) return sendBridgeError(req, res, 403, "La configuration du pont est réservée à la Régie locale.");
    const body = await readBody(req);
    const incoming = new Map((body.conversations ?? []).map((entry) => [entry.id, entry]));
    bridgeConfig = {
      ...bridgeConfig,
      conversations: bridgeConfig.conversations.map((current) => {
        const next = incoming.get(current.id) ?? current;
        const rawUrl = String(next.url ?? "").trim();
        const normalizedUrl = rawUrl ? normalizedChatGptConversationUrl(rawUrl) : "";
        if (rawUrl && !normalizedUrl) throw new Error(`L’adresse « ${current.label} » doit être une conversation ChatGPT contenant /c/.`);
        return {
          id: current.id,
          label: String(next.label || current.label).slice(0, 80),
          url: normalizedUrl
        };
      })
    };
    saveBridgeConfig();
    return sendBridgeJson(req, res, 200, { ok: true, ...bridgeStatus({ includeToken: true }) });
  }

  if (req.method === "POST" && url.pathname === "/api/chatgpt-bridge/rotate-token") {
    if (!managerRequest) return sendBridgeError(req, res, 403, "La rotation du code est réservée à la Régie locale.");
    bridgeConfig.pairingToken = `${randomUUID().replaceAll("-", "")}${randomUUID().replaceAll("-", "")}`;
    bridgeLastSeenAt = 0;
    saveBridgeConfig();
    return sendBridgeJson(req, res, 200, { ok: true, ...bridgeStatus({ includeToken: true }) });
  }

  if (req.method === "POST" && url.pathname === "/api/chatgpt-bridge/jobs") {
    if (!managerRequest) return sendBridgeError(req, res, 403, "Seule la Régie locale peut préparer une demande.");
    const body = await readBody(req);
    const conversation = bridgeConfig.conversations.find((entry) => entry.id === body.conversationId);
    if (!conversation) return sendBridgeError(req, res, 400, "Conversation cible inconnue.");
    if (!conversation.url) return sendBridgeError(req, res, 409, `Configurez d’abord « ${conversation.label} ».`);
    const prompt = String(body.prompt ?? "").trim().slice(0, 50000);
    if (!prompt) return sendBridgeError(req, res, 400, "Le prompt est vide.");
    if (!Array.isArray(body.attachments)) body.attachments = [];
    if (body.attachments.length > 8) return sendBridgeError(req, res, 413, "Le pont accepte au maximum huit références par demande.");
    const attachments = body.attachments.map(cleanBridgeAttachment);
    const approximateTotal = attachments.reduce((total, entry) => total + entry.dataUrl.length, 0);
    if (approximateTotal > 55 * 1024 * 1024) return sendBridgeError(req, res, 413, "Les références dépassent la taille totale autorisée.");
    const job = {
      id: randomUUID(),
      conversationId: conversation.id,
      conversationUrl: conversation.url,
      prompt,
      attachments,
      status: "queued",
      createdAt: Date.now(),
      offeredAt: null,
      updatedAt: Date.now()
    };
    bridgeJobs.push(job);
    return sendBridgeJson(req, res, 201, { ok: true, job: { id: job.id, status: job.status, conversationUrl: job.conversationUrl } });
  }

  if (req.method === "GET" && url.pathname === "/api/chatgpt-bridge/jobs/next") {
    if (managerRequest) return sendBridgeError(req, res, 403, "Cette route est réservée à l’extension appairée.");
    bridgeLastSeenAt = Date.now();
    const currentConversation = normalizedChatGptConversationUrl(url.searchParams.get("conversationUrl"));
    const job = bridgeJobs.find((entry) => ["queued", "offered"].includes(entry.status) && entry.conversationUrl === currentConversation);
    if (!job) return sendBridgeJson(req, res, 200, { ok: true, job: null, ...bridgeStatus() });
    job.status = "offered";
    job.offeredAt = Date.now();
    job.updatedAt = Date.now();
    return sendBridgeJson(req, res, 200, {
      ok: true,
      job: {
        id: job.id,
        conversationId: job.conversationId,
        prompt: job.prompt,
        attachments: job.attachments,
        createdAt: job.createdAt
      }
    });
  }

  const jobStatusMatch = url.pathname.match(/^\/api\/chatgpt-bridge\/jobs\/([a-f0-9-]+)\/status$/i);
  if (req.method === "POST" && jobStatusMatch) {
    if (managerRequest) return sendBridgeError(req, res, 403, "Cette route est réservée à l’extension appairée.");
    bridgeLastSeenAt = Date.now();
    const job = bridgeJobs.find((entry) => entry.id === jobStatusMatch[1]);
    if (!job) return sendBridgeError(req, res, 404, "Demande du pont introuvable.");
    const body = await readBody(req, 128 * 1024);
    const status = String(body.status ?? "");
    if (!["offered", "prepared", "sent", "cancelled", "failed"].includes(status)) {
      return sendBridgeError(req, res, 400, "État de demande invalide.");
    }
    job.status = status;
    job.updatedAt = Date.now();
    job.message = String(body.message ?? "").slice(0, 500);
    return sendBridgeJson(req, res, 200, { ok: true, job: { id: job.id, status: job.status } });
  }

  if (req.method === "POST" && url.pathname === "/api/chatgpt-bridge/import") {
    if (managerRequest) return sendBridgeError(req, res, 403, "Cette route est réservée à l’extension appairée.");
    bridgeLastSeenAt = Date.now();
    const contentType = String(req.headers["content-type"] ?? "").split(";")[0].toLowerCase();
    if (!contentType.startsWith("image/")) return sendBridgeError(req, res, 415, "Le résultat importé doit être une image.");
    const bytes = await readRawBody(req, 40 * 1024 * 1024);
    if (!bytes.length) return sendBridgeError(req, res, 400, "L’image importée est vide.");
    const importId = randomUUID();
    const requestedName = safeFilename(url.searchParams.get("filename"), `chatgpt-${Date.now()}${bridgeImageExtension(contentType)}`);
    const filename = path.extname(requestedName) ? requestedName : `${requestedName}${bridgeImageExtension(contentType)}`;
    const filePath = path.join(CHATGPT_BRIDGE_IMPORT_DIR, `${importId}${bridgeImageExtension(contentType)}`);
    writeFileSync(filePath, bytes, { mode: 0o600 });
    const job = bridgeJobs.find((entry) => entry.id === url.searchParams.get("jobId"));
    if (job) {
      job.status = "imported";
      job.updatedAt = Date.now();
    }
    bridgeImports.push({ id: importId, jobId: job?.id ?? null, filename, contentType, size: bytes.length, filePath, createdAt: Date.now() });
    return sendBridgeJson(req, res, 201, { ok: true, importId, filename, size: bytes.length });
  }

  if (req.method === "GET" && url.pathname === "/api/chatgpt-bridge/imports") {
    if (!managerRequest) return sendBridgeError(req, res, 403, "La boîte d’arrivée est réservée à la Régie locale.");
    return sendBridgeJson(req, res, 200, {
      ok: true,
      imports: bridgeImports.map(({ filePath: _filePath, ...entry }) => entry)
    });
  }

  const importContentMatch = url.pathname.match(/^\/api\/chatgpt-bridge\/imports\/([a-f0-9-]+)\/content$/i);
  if (req.method === "GET" && importContentMatch) {
    if (!managerRequest) return sendBridgeError(req, res, 403, "L’image est réservée à la Régie locale.");
    const entry = bridgeImports.find((item) => item.id === importContentMatch[1]);
    if (!entry || !existsSync(entry.filePath)) return sendBridgeError(req, res, 404, "Image importée introuvable.");
    res.writeHead(200, {
      "Content-Type": entry.contentType,
      "Content-Length": entry.size,
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff"
    });
    return createReadStream(entry.filePath).pipe(res);
  }

  const importDeleteMatch = url.pathname.match(/^\/api\/chatgpt-bridge\/imports\/([a-f0-9-]+)$/i);
  if (req.method === "DELETE" && importDeleteMatch) {
    if (!managerRequest) return sendBridgeError(req, res, 403, "La boîte d’arrivée est réservée à la Régie locale.");
    const index = bridgeImports.findIndex((item) => item.id === importDeleteMatch[1]);
    if (index < 0) return sendBridgeError(req, res, 404, "Image importée introuvable.");
    const entry = bridgeImports.splice(index, 1)[0];
    if (existsSync(entry.filePath)) rmSync(entry.filePath, { force: true });
    const job = bridgeJobs.find((item) => item.id === entry.jobId);
    if (job) {
      job.status = "completed";
      job.updatedAt = Date.now();
    }
    return sendBridgeJson(req, res, 200, { ok: true });
  }

  return sendBridgeError(req, res, 404, "Route du pont ChatGPT inconnue.");
}

async function handleApi(req, res, url) {
  if (url.pathname.startsWith("/api/chatgpt-bridge/")) return handleChatGptBridge(req, res, url);
  if (req.method === "POST" && url.pathname === "/api/auth/login") {
    try { authenticationLimiter.assertAvailable(); }
    catch (error) { return sendError(res, 429, error.message); }
    const body = await readBody(req, 16 * 1024);
    const scope = body.scope === "gm" ? "gm" : "player";
    const account = await accountStore.authenticate(body.username, body.password);
    if (!account || (scope === "gm" && account.role !== "gm")) {
      authenticationLimiter.recordFailure();
      return sendError(res, 403, "Identifiant ou mot de passe incorrect.");
    }
    authenticationLimiter.recordSuccess();
    if (scope === "player") ensureSessionPlayer(account);
    const sessionToken = createAuthenticatedSession(account);
    return sendJson(res, 200, { ok: true, account, sessionToken, expiresInSeconds: SESSION_MAX_AGE_SECONDS }, {
      "Set-Cookie": sessionCookie(sessionToken)
    });
  }
  if (req.method === "POST" && url.pathname === "/api/auth/logout") {
    const token = sessionTokenFromRequest(req);
    if (token) authenticatedSessions.delete(token);
    return sendJson(res, 200, { ok: true }, { "Set-Cookie": sessionCookie("", 0) });
  }
  if (req.method === "GET" && url.pathname === "/api/auth/me") {
    const account = authenticatedAccount(req);
    if (!account) return sendError(res, 401, "Connexion requise.");
    return sendJson(res, 200, { ok: true, account });
  }
  if (req.method === "POST" && url.pathname === "/api/system/open-chatgpt") {
    if (!isMjRequest(req, url)) return sendError(res, 403, "L’ouverture de ChatGPT est réservée à la session MJ authentifiée.");
    const body = await readBody(req, 16 * 1024);
    const externalUrl = normalizeChatGptExternalUrl(body.url);
    if (!externalUrl) return sendError(res, 400, "Seules la page d’accueil et les conversations de chatgpt.com peuvent être ouvertes.");
    openSystemBrowser(externalUrl, { onError: () => {} });
    return sendJson(res, 200, { ok: true, openedInSystemBrowser: true });
  }
  if (req.method === "GET" && url.pathname === "/api/health") {
    return sendJson(res, 200, {
      ok: true,
      services: {
        chatgptAssist: true,
        chatgptBridge: bridgeLastSeenAt > 0 && Date.now() - bridgeLastSeenAt < 15000,
        discordImages: Boolean(process.env.DISCORD_IMAGE_WEBHOOK_URL?.trim()),
        discordDice: Boolean(process.env.DISCORD_DICE_WEBHOOK_URL?.trim()),
        discordJournal: Boolean(process.env.DISCORD_JOURNAL_WEBHOOK_URL?.trim()),
        ovh: Boolean(process.env.OVH_FTP_URL?.trim() && process.env.OVH_FTP_USER?.trim() && process.env.OVH_FTP_PASSWORD)
      },
      liveSync: true,
      mediaSharing: true,
      chatgptBridge: { configuredConversations: bridgeConfig.conversations.filter((entry) => entry.url).length },
      ovhMediaCleanup: { ...ovhRuntimeStatus },
      application: {
        id: String(APPLICATION_RELEASE.applicationId || "fr.xar-tsaroth.regie-du-seuil"),
        version: APP_VERSION,
        channel: String(APPLICATION_RELEASE.channel || "development"),
        launcherUrl: String(process.env.XAR_LAUNCHER_ORIGIN || "http://127.0.0.1:4169")
      },
      characterStorage: userCharacterStorage.publicStatus(),
      sessionRevision: revision,
      accountAccessProtected: true
    });
  }
  if (req.method === "GET" && url.pathname === "/api/session/events") return openEventStream(req, res, url);
  if (req.method === "GET" && url.pathname === "/api/session/public") {
    const identity = authenticatedPlayer(req);
    if (!identity) return sendError(res, 401, "Connexion joueur requise.");
    return sendJson(res, 200, { ok: true, state: publicState(sessionState, identity) });
  }
  if (req.method === "GET" && url.pathname === "/api/session/full") {
    if (!isMjRequest(req, url)) return sendError(res, 403, "La fiche MJ complète exige une session MJ authentifiée.");
    return sendJson(res, 200, { ok: true, state: sessionState });
  }
  if (req.method === "POST" && url.pathname === "/api/session/state") {
    if (!isMjRequest(req, url)) return sendError(res, 403, "Seule la session MJ authentifiée peut modifier la session complète.");
    const body = await readBody(req);
    if (!body?.state || typeof body.state !== "object") return sendError(res, 400, "État de session invalide.");
    const saved = saveSession(body.state, { merge: true });
    return sendJson(res, 200, { ok: true, revision: saved.revision, state: saved });
  }
  if (req.method === "POST" && url.pathname === "/api/session/character/import-docx") {
    const identity = authenticatedPlayer(req);
    if (!identity) return sendError(res, 401, "Connexion joueur requise.");
    const filename = safeFilename(req.headers["x-xar-filename"], "fiche.docx");
    if (path.extname(filename).toLowerCase() !== ".docx") return sendError(res, 415, "Sélectionnez un fichier Word .docx.");
    const bytes = await readRawBody(req, 25 * 1024 * 1024);
    if (!bytes.length) return sendError(res, 400, "Le fichier Word est vide.");
    const temporaryDirectory = await mkdtemp(path.join(tmpdir(), "xar-word-upload-"));
    try {
      const temporaryFile = path.join(temporaryDirectory, filename);
      await writeFile(temporaryFile, bytes, { mode: 0o600 });
      const imported = await importCharacterDocx(temporaryFile, { ownerPlayerId: identity.id, filename });
      return sendJson(res, 200, {
        ok: true,
        draft: stripPrivateCharacter(imported.character),
        source: imported.source,
        warnings: imported.warnings
      });
    } finally {
      rmSync(temporaryDirectory, { recursive: true, force: true });
    }
  }
  if (req.method === "POST" && url.pathname === "/api/session/character") {
    if (!sessionState) return sendError(res, 409, "Aucune session MJ n’est encore ouverte.");
    const identity = authenticatedPlayer(req);
    if (!identity) return sendError(res, 401, "Connexion joueur requise.");
    const body = await readBody(req, 8 * 1024 * 1024);
    const requestedId = String(body?.draft?.id || "");
    const recoveredId = /^character-[a-zA-Z0-9_-]{8,150}$/.test(requestedId) ? requestedId : `character-${randomUUID()}`;
    const existing = (sessionState.characters ?? []).find((entry) => entry.id === recoveredId);
    if (existing) return sendJson(res, 200, { ok: true, revision, character: stripPrivateCharacter(existing), alreadyPresent: true });
    const character = createCharacterSheet({
      id: recoveredId,
      ownerPlayerId: identity.id,
      name: String(body?.draft?.name || body.name || "Nouveau personnage").trim().slice(0, 120),
      color: String(body?.draft?.color || body.color || "#8d72cb")
    });
    if (body?.draft && typeof body.draft === "object") {
      const recoveredPatch = characterPatch(body.draft, false);
      for (const nestedKey of ["resources", "stats", "fatigue"]) {
        if (!recoveredPatch[nestedKey] || typeof recoveredPatch[nestedKey] !== "object") continue;
        character[nestedKey] = { ...character[nestedKey], ...recoveredPatch[nestedKey] };
        delete recoveredPatch[nestedKey];
      }
      Object.assign(character, recoveredPatch, { id: recoveredId, ownerPlayerId: identity.id, _updatedAt: Date.now() });
      character.linkedTokens = normalizeLinkedTokens(character.linkedTokens);
      enforceD100Shortcuts(character);
    }
    sessionState.characters ??= [];
    sessionState.characters.push(character);
    const saved = saveSession(sessionState);
    return sendJson(res, 201, { ok: true, revision: saved.revision, character: stripPrivateCharacter(character) });
  }
  if (req.method === "PATCH" && url.pathname === "/api/session/character") {
    const isGm = isMjRequest(req, url);
    if (!sessionState) return sendError(res, 409, "Aucune session MJ n’est encore ouverte.");
    const body = await readBody(req);
    const character = (sessionState.characters ?? []).find((entry) => entry.id === body.characterId);
    if (!character) return sendError(res, 404, "Personnage introuvable.");
    const identity = authenticatedPlayer(req);
    if (!isGm && (!identity || character.ownerPlayerId !== identity.id)) {
      return sendError(res, 403, "Cette fiche appartient à un autre joueur.");
    }
    const permittedPatch = characterPatch(body.patch, isGm);
    const initiativeBonusChanged = Object.prototype.hasOwnProperty.call(permittedPatch, "initiativeBonus");
    for (const nestedKey of ["resources", "stats", "fatigue", "secret"]) {
      if (!permittedPatch[nestedKey] || typeof permittedPatch[nestedKey] !== "object") continue;
      character[nestedKey] = { ...(character[nestedKey] ?? {}), ...permittedPatch[nestedKey] };
      delete permittedPatch[nestedKey];
    }
    Object.assign(character, permittedPatch);
    character.linkedTokens = normalizeLinkedTokens(character.linkedTokens);
    enforceD100Shortcuts(character);
    if (initiativeBonusChanged) {
      const bonus = Number(character.initiativeBonus || 0);
      for (const shortcut of character.shortcuts ?? []) {
        if (shortcut.kind === "initiative") shortcut.formula = `1d100${bonus >= 0 ? "+" : ""}${bonus}`;
      }
    }
    character._updatedAt = Date.now();
    syncCharacterTokens(character);
    const saved = saveSession(sessionState);
    return sendJson(res, 200, { ok: true, revision: saved.revision, character: isGm ? character : stripPrivateCharacter(character) });
  }
  if (req.method === "POST" && url.pathname === "/api/session/token/invoke") {
    if (!isMjRequest(req, url)) return sendError(res, 403, "L’invocation depuis une fiche est réservée à la session MJ authentifiée.");
    if (!sessionState) return sendError(res, 409, "Aucune session MJ n’est encore ouverte.");
    const body = await readBody(req, 64 * 1024);
    const character = (sessionState.characters ?? []).find((entry) => entry.id === body.characterId);
    if (!character) return sendError(res, 404, "Personnage introuvable.");
    const linkedTokenId = String(body.linkedTokenId || "");
    const linkedToken = linkedTokenId ? normalizeLinkedTokens(character.linkedTokens).find((entry) => entry.id === linkedTokenId) : null;
    if (linkedTokenId && !linkedToken) return sendError(res, 404, "Token lié introuvable sur cette fiche.");
    sessionState.map ??= { tokens: [] };
    sessionState.map.tokens ??= [];
    const existing = sessionState.map.tokens.find((token) => token.characterId === character.id && String(token.linkedTokenId || "") === linkedTokenId);
    if (existing) return sendJson(res, 200, { ok: true, revision, token: existing, alreadyPresent: true });
    const token = createSessionToken(character, linkedToken);
    sessionState.map.tokens.push(token);
    const saved = saveSession(sessionState);
    return sendJson(res, 201, { ok: true, revision: saved.revision, token, alreadyPresent: false });
  }
  if (req.method === "POST" && url.pathname === "/api/session/ping") {
    const isGm = isMjRequest(req, url);
    if (!sessionState) return sendError(res, 409, "Aucune session MJ n’est encore ouverte.");
    const identity = authenticatedPlayer(req);
    if (!identity) return sendError(res, 401, "Connexion requise pour signaler la carte.");
    const body = await readBody(req, 16 * 1024);
    const x = Number(body.x);
    const y = Number(body.y);
    if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || x > 100 || y < 0 || y > 100) return sendError(res, 400, "Position de signal invalide.");
    const character = identity ? (sessionState.characters ?? []).find((entry) => entry.ownerPlayerId === identity.id) : null;
    const now = Date.now();
    const ping = {
      id: `ping-${randomUUID()}`,
      sceneId: sessionState.activeSceneId || sessionState.activeScene?.id || null,
      x,
      y,
      author: isGm ? "MJ" : String(identity.name || identity.playerName || character?.name || "Joueur").slice(0, 80),
      color: isGm ? "#ffd782" : String(character?.color || "#8d72cb"),
      createdAt: now,
      expiresAt: now + 4_500
    };
    sessionState.mapPings = [...(sessionState.mapPings ?? []).filter((entry) => Number(entry.expiresAt || 0) > now), ping].slice(-20);
    const saved = saveSession(sessionState);
    return sendJson(res, 201, { ok: true, revision: saved.revision, ping });
  }
  if (req.method === "POST" && url.pathname === "/api/session/roll") {
    if (!sessionState) return sendError(res, 409, "Aucune session MJ n’est encore ouverte.");
    const identity = authenticatedPlayer(req);
    if (!identity) return sendError(res, 401, "Connexion joueur requise pour lancer un jet.");
    const body = await readBody(req, 256 * 1024);
    const character = (sessionState.characters ?? []).find((entry) => entry.id === body.characterId && entry.ownerPlayerId === identity.id);
    if (!character) return sendError(res, 403, "Ce personnage n’appartient pas à ce joueur.");
    const shortcut = (character.shortcuts ?? []).find((entry) => entry.id === body.shortcutId);
    if (!shortcut) return sendError(res, 404, "Raccourci de jet introuvable.");
    if (shortcut.kind === "initiative" && sessionState.tacticalSync?.paused === true) {
      return sendError(res, 423, "La table est en préparation secrète. L’initiative sera disponible à la reprise.");
    }
    const formula = shortcut.kind === "damage" || usesDamageDice(shortcut.label)
      ? String(shortcut.formula || "1d100").replaceAll(" ", "").slice(0, 100)
      : d100Formula(shortcut.formula);
    let result;
    try { result = rollFormula(formula); }
    catch (error) { return sendError(res, 400, error.message); }
    const now = Date.now();
    const roll = {
      id: randomUUID(),
      label: String(shortcut.label || "Jet").slice(0, 120),
      characterName: String(character.name || "Personnage").slice(0, 120),
      formula,
      total: result.total,
      breakdown: result.breakdown,
      visibility: "public",
      revealed: true,
      rollerName: String(identity.name || identity.playerName || "Joueur").slice(0, 120),
      rollerRole: "player",
      createdAt: new Date(now).toISOString()
    };
    let initiativeUpdated = false;
    if (shortcut.kind === "initiative") {
      const token = (sessionState.map?.tokens ?? []).find((entry) => entry.characterId === character.id && entry.controllerPlayerId === identity.id && !entry.hidden);
      if (token) {
        token.initiative = result.total;
        token._updatedAt = now;
        sessionState.initiative ??= { order: [], currentIndex: 0, round: 1, active: false, turnsStarted: false };
        const preserveCurrentTurn = sessionState.initiative.active === true;
        const previousActiveTokenId = preserveCurrentTurn
          ? sessionState.initiative.order?.[Number(sessionState.initiative.currentIndex ?? 0)] ?? null
          : null;
        const mapTokens = sessionState.map?.tokens ?? [];
        const preparedOrder = sanitizeInitiativeOrder(sessionState.initiative.order, mapTokens);
        if (!preparedOrder.includes(token.id)) preparedOrder.push(token.id);
        sessionState.initiative.order = sortInitiativeTokenIds(preparedOrder, mapTokens);
        sessionState.initiative.currentIndex = previousActiveTokenId
          ? Math.max(0, sessionState.initiative.order.indexOf(previousActiveTokenId))
          : 0;
        sessionState.initiative.active = preserveCurrentTurn;
        sessionState.initiative.turnsStarted = preserveCurrentTurn;
        sessionState.initiative._updatedAt = now;
        sessionState.tacticalSync ??= {};
        sessionState.tacticalSync.playerMovementMode = preserveCurrentTurn ? "combat" : "free";
        initiativeUpdated = true;
      }
    }
    sessionState.rolls = [roll, ...(sessionState.rolls ?? []).filter((entry) => entry.id !== roll.id)].slice(0, 100);
    const saved = saveSession(sessionState);
    let discordPosted = false;
    let discordError = "";
    if (webhookForTarget("dice")) {
      try {
        await postToDiscord({ target: "dice", content: discordRollContent(roll) });
        discordPosted = true;
      } catch (error) { discordError = error.message; }
    }
    return sendJson(res, 200, { ok: true, revision: saved.revision, roll, initiativeUpdated, discordPosted, discordError });
  }
  if (req.method === "PATCH" && url.pathname === "/api/session/token") {
    const isGm = isMjRequest(req, url);
    if (!sessionState) return sendError(res, 409, "Aucune session MJ n’est encore ouverte.");
    const body = await readBody(req);
    if (!isGm && sessionState.tacticalSync?.paused === true) {
      return sendError(res, 423, "La table est temporairement verrouillée pendant la préparation du MJ.");
    }
    const token = (sessionState.map?.tokens ?? []).find((entry) => entry.id === body.tokenId);
    if (!token) return sendError(res, 404, "Token introuvable.");
    const identity = authenticatedPlayer(req);
    if (!isGm && (!identity || token.controllerPlayerId !== identity.id || token.hidden)) {
      return sendError(res, 403, "Vous ne pouvez pas déplacer ce token.");
    }
    if (!isGm && sessionState.initiative?.active === true) {
      const order = sessionState.initiative?.order ?? [];
      const activeTokenId = order[Number(sessionState.initiative?.currentIndex ?? 0)] ?? null;
      if (token.id !== activeTokenId) return sendError(res, 423, "Ce token pourra être déplacé pendant son tour de jeu.");
    }
    const point = snapMapPercentPoint(body.x ?? token.x, body.y ?? token.y, sessionState.map ?? {});
    token.x = point.x;
    token.y = point.y;
    token._movedAt = Date.now();
    const saved = saveSession(sessionState);
    return sendJson(res, 200, { ok: true, revision: saved.revision, token: { id: token.id, x: token.x, y: token.y } });
  }
  if (req.method === "POST" && url.pathname === "/api/session/timer") {
    if (!sessionState) return sendError(res, 409, "Aucune session MJ n’est encore ouverte.");
    const identity = authenticatedPlayer(req);
    if (!identity) return sendError(res, 401, "Connexion joueur requise pour créer un minuteur.");
    if (sessionState.tacticalSync?.paused === true) return sendError(res, 423, "Les minuteurs sont verrouillés pendant la préparation secrète du MJ.");
    if (sessionState.initiative?.active !== true) return sendError(res, 409, "Commencez un combat avant d’ajouter une recharge.");
    const body = await readBody(req, 256 * 1024);
    const character = (sessionState.characters ?? []).find((entry) => entry.id === body.characterId && entry.ownerPlayerId === identity.id);
    if (!character) return sendError(res, 403, "Ce personnage ne vous appartient pas.");
    const label = String(body.label || "").trim().slice(0, 120);
    if (!label) return sendError(res, 400, "Donnez un nom à l’action.");
    const cooldown = Math.min(999, Math.max(1, Math.trunc(Number(body.cooldown) || 1)));
    sessionState.actionTimers ??= [];
    if (sessionState.actionTimers.length >= 300) return sendError(res, 409, "La session contient déjà trop de minuteurs.");
    const usedRound = Math.max(1, Number(sessionState.initiative?.round) || 1);
    const timer = {
      id: randomUUID(),
      sceneId: sessionState.activeSceneId || null,
      label,
      cooldown,
      usedRound,
      readyRound: usedRound + cooldown,
      ownerPlayerId: identity.id,
      characterId: character.id,
      ownerLabel: String(character.name || identity.name || "Joueur").slice(0, 120),
      visibility: body.visibility === "public" ? "public" : "private",
      createdByRole: "player",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    sessionState.actionTimers.unshift(timer);
    const saved = saveSession(sessionState);
    return sendJson(res, 201, { ok: true, revision: saved.revision, timer: { ...timer, ownerPlayerId: undefined, characterId: undefined, ownedByYou: true } });
  }
  if (req.method === "PATCH" && url.pathname === "/api/session/timer") {
    if (!sessionState) return sendError(res, 409, "Aucune session MJ n’est encore ouverte.");
    const identity = authenticatedPlayer(req);
    if (!identity) return sendError(res, 401, "Connexion joueur requise.");
    if (sessionState.tacticalSync?.paused === true) return sendError(res, 423, "Les minuteurs sont verrouillés pendant la préparation secrète du MJ.");
    if (sessionState.initiative?.active !== true) return sendError(res, 409, "Aucun combat n’est en cours.");
    const body = await readBody(req, 256 * 1024);
    const timer = (sessionState.actionTimers ?? []).find((entry) => entry.id === body.timerId && entry.ownerPlayerId === identity.id && entry.sceneId === sessionState.activeSceneId);
    if (!timer) return sendError(res, 403, "Ce minuteur ne vous appartient pas.");
    const usedRound = Math.max(1, Number(sessionState.initiative?.round) || 1);
    timer.usedRound = usedRound;
    timer.readyRound = usedRound + Math.max(1, Number(timer.cooldown) || 1);
    timer.updatedAt = new Date().toISOString();
    const saved = saveSession(sessionState);
    return sendJson(res, 200, { ok: true, revision: saved.revision });
  }
  if (req.method === "DELETE" && url.pathname === "/api/session/timer") {
    if (!sessionState) return sendError(res, 409, "Aucune session MJ n’est encore ouverte.");
    const identity = authenticatedPlayer(req);
    if (!identity) return sendError(res, 401, "Connexion joueur requise.");
    const timerId = url.searchParams.get("timerId");
    const timer = (sessionState.actionTimers ?? []).find((entry) => entry.id === timerId);
    if (!timer || timer.ownerPlayerId !== identity.id) return sendError(res, 403, "Ce minuteur ne vous appartient pas.");
    sessionState.actionTimers = sessionState.actionTimers.filter((entry) => entry.id !== timerId);
    sessionState.actionTimerTombstones ??= [];
    sessionState.actionTimerTombstones.push({ id: timerId, deletedAt: new Date().toISOString() });
    sessionState.actionTimerTombstones = sessionState.actionTimerTombstones.slice(-1000);
    const saved = saveSession(sessionState);
    return sendJson(res, 200, { ok: true, revision: saved.revision });
  }
  if (req.method === "POST" && url.pathname === "/api/media/upload") return uploadMedia(req, res, url);
  if (req.method === "DELETE" && url.pathname === "/api/media") return deleteMedia(req, res, url);
  if (req.method === "POST" && url.pathname === "/api/discord/post") {
    if (!isMjRequest(req, url)) return sendError(res, 403, "L’envoi Discord est réservé à la session MJ authentifiée.");
    return sendJson(res, 200, { ok: true, ...(await postToDiscord(await readBody(req))) });
  }
  if (req.method === "POST" && url.pathname === "/api/ovh/upload") {
    if (!isMjRequest(req, url)) return sendError(res, 403, "L’envoi OVH est réservé à la session MJ authentifiée.");
    return sendJson(res, 200, { ok: true, ...(await uploadToOvh(await readBody(req))) });
  }
  if (req.method === "GET" && url.pathname === "/api/ovh/status") {
    if (!isMjRequest(req, url)) return sendError(res, 403, "L’état OVH est réservé à la session MJ authentifiée.");
    return sendJson(res, 200, { ok: true, storage: ovhRuntimeStatus });
  }
  if (req.method === "POST" && url.pathname === "/api/ovh/cleanup") {
    if (!isMjRequest(req, url)) return sendError(res, 403, "Le nettoyage OVH est réservé à la session MJ authentifiée.");
    const body = await readBody(req);
    return sendJson(res, 200, { ok: true, cleanup: await cleanupOvhMedia({ forceLegacy: Boolean(body.forceLegacy) }), storage: ovhRuntimeStatus });
  }
  return sendError(res, 404, "Route API inconnue.");
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
  try {
    if (url.pathname.startsWith("/api/")) return await handleApi(req, res, url);
    if (url.pathname.startsWith("/media/")) return serveMedia(req, res, url);
    const filePath = staticFilePath(url.pathname);
    if (!filePath || !existsSync(filePath) || !statSync(filePath).isFile()) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("Introuvable");
    }
    const extension = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      "Content-Type": mimeTypes[extension] ?? "application/octet-stream",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer"
    });
    createReadStream(filePath).pipe(res);
  } catch (error) {
    console.error(error);
    if (!res.headersSent) sendError(res, 500, error instanceof Error ? error.message : "Erreur interne.");
    else res.end();
  }
});

const port = Number(process.env.PORT || 4173);
server.listen(port, "0.0.0.0", () => console.log(`Régie du Seuil ouverte sur http://localhost:${port}`));

function shutdown() {
  for (const client of eventClients) client.end();
  server.close(() => process.exit(0));
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
