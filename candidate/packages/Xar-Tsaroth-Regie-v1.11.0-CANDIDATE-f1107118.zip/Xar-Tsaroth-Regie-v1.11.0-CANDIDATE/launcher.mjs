import http from "node:http";
import {
  chmodSync,
  copyFileSync,
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync
} from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomBytes } from "node:crypto";
import { spawn } from "node:child_process";
import {
  compareApplicationVersions,
  downloadVerifiedPackage,
  fetchSignedUpdateManifest,
  loadApplicationRelease,
  verifyInstallation
} from "./launcher-core.mjs";
import {
  PENDING_UPDATE_SCHEMA_VERSION,
  UPDATE_STATUS_FILENAME,
  readUpdateStatus
} from "./updater-core.mjs";
import { defaultPrivateRoot } from "./installation-paths.mjs";
import { openDedicatedWindow, resolveApplicationBrowser } from "./desktop-shell.mjs";
import {
  generatePlayerAccessCode,
  mergeConfigurationInput,
  parseEnvironmentText,
  publicConfigurationStatus,
  serializeEnvironment
} from "./configuration-core.mjs";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const LAUNCHER_ASSET_DIR = path.join(ROOT, "launcher");
const release = loadApplicationRelease(ROOT);
const csrfToken = randomBytes(32).toString("hex");
const appPort = Number(process.env.PORT || 4173);
const launcherPort = Number(process.env.XAR_LAUNCHER_PORT || 4169);
const launcherOrigin = `http://127.0.0.1:${launcherPort}`;
const appUrl = `http://127.0.0.1:${appPort}`;
let applicationProcess = null;
let launcherServer = null;
let latestSignedManifest = null;
let updateOperation = null;
let shutdownStarted = false;
let privateEnvironment = {};
let runtimeEnvironment = { ...process.env };

const launcherState = {
  application: { running: false, ready: false, url: appUrl, error: null },
  configuration: {
    ready: false,
    needsSetup: true,
    issues: [{ field: "configuration", message: "La configuration initiale doit être terminée." }]
  },
  shell: {
    available: false,
    engine: null,
    launcher: { dedicated: false, mode: "pending", engine: null, message: "Fenêtre en préparation." },
    application: { dedicated: false, mode: "pending", engine: null, message: "La table n’est pas encore ouverte." }
  },
  integrity: verifyInstallation(ROOT),
  update: { configured: false, checking: false, state: "not-checked", message: "Vérification en attente.", availableVersion: null },
  downloadedPackage: null,
  operation: null,
  lastUpdate: null
};

const privateRoot = defaultPrivateRoot();
const dataDirectory = path.join(privateRoot, "data");
const privateEnvironmentFile = path.join(privateRoot, ".env.local");
const downloadsDirectory = path.join(privateRoot, "downloads");
const updatesDirectory = path.join(privateRoot, "updates");
const updateStatusPath = path.join(updatesDirectory, UPDATE_STATUS_FILENAME);
launcherState.lastUpdate = readUpdateStatus(updateStatusPath);
const applicationBrowser = resolveApplicationBrowser();
launcherState.shell.available = Boolean(applicationBrowser);
launcherState.shell.engine = applicationBrowser?.engine ?? null;

function previousBuildDirectories() {
  const parent = path.dirname(ROOT);
  try {
    return readdirSync(parent, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && /^(?:xar-regie-mj|xar-tsaroth-regie)-v\d/i.test(entry.name))
      .map((entry) => path.join(parent, entry.name))
      .filter((directory) => directory !== ROOT)
      .sort((left, right) => statSync(right).mtimeMs - statSync(left).mtimeMs);
  } catch {
    return [];
  }
}

function preparePrivateStorage() {
  mkdirSync(privateRoot, { recursive: true, mode: 0o700 });
  mkdirSync(dataDirectory, { recursive: true, mode: 0o700 });
  mkdirSync(downloadsDirectory, { recursive: true, mode: 0o700 });
  mkdirSync(updatesDirectory, { recursive: true, mode: 0o700 });

  const packagedEnvironmentFile = path.join(ROOT, ".env.local");
  if (existsSync(packagedEnvironmentFile) && !existsSync(privateEnvironmentFile)) {
    copyFileSync(packagedEnvironmentFile, privateEnvironmentFile);
  } else if (!existsSync(privateEnvironmentFile)) {
    const previousEnvironment = previousBuildDirectories()
      .map((directory) => path.join(directory, ".env.local"))
      .find(existsSync);
    if (previousEnvironment) copyFileSync(previousEnvironment, privateEnvironmentFile);
  }
  try { if (existsSync(privateEnvironmentFile)) chmodSync(privateEnvironmentFile, 0o600); } catch {}

  const currentSessionFile = path.join(dataDirectory, "session-state.json");
  if (!existsSync(currentSessionFile)) {
    const legacyDataDirectory = [path.join(ROOT, "data"), ...previousBuildDirectories().map((directory) => path.join(directory, "data"))]
      .find((directory) => existsSync(path.join(directory, "session-state.json")));
    if (legacyDataDirectory) cpSync(legacyDataDirectory, dataDirectory, { recursive: true, force: false, errorOnExist: false });
  }
}

function readEnvironmentFile(filePath) {
  if (!existsSync(filePath)) return {};
  return parseEnvironmentText(readFileSync(filePath, "utf8"));
}

function refreshRuntimeEnvironment() {
  privateEnvironment = readEnvironmentFile(privateEnvironmentFile);
  runtimeEnvironment = { ...privateEnvironment, ...process.env };
  launcherState.configuration = publicConfigurationStatus(privateEnvironment, {
    fileExists: existsSync(privateEnvironmentFile)
  });
  return runtimeEnvironment;
}

function savePrivateConfiguration(input) {
  const next = mergeConfigurationInput(input, privateEnvironment);
  const temporary = `${privateEnvironmentFile}.${process.pid}.partial`;
  writeFileSync(temporary, serializeEnvironment(next), { mode: 0o600 });
  rmSync(privateEnvironmentFile, { force: true });
  renameSync(temporary, privateEnvironmentFile);
  try { chmodSync(privateEnvironmentFile, 0o600); } catch {}
  refreshRuntimeEnvironment();
  return launcherState.configuration;
}

function updateManifestUrl(environment) {
  return String(environment.XAR_UPDATE_MANIFEST_URL || release.updateManifestUrl || "").trim();
}

function publicStatus() {
  return {
    ok: true,
    release: {
      applicationId: release.applicationId,
      displayName: release.displayName,
      version: release.version,
      channel: release.channel
    },
    application: { ...launcherState.application },
    configuration: structuredClone(launcherState.configuration),
    shell: {
      available: launcherState.shell.available,
      engine: launcherState.shell.engine,
      launcher: { ...launcherState.shell.launcher },
      application: { ...launcherState.shell.application }
    },
    integrity: { ...launcherState.integrity },
    update: { ...launcherState.update },
    downloadedPackage: launcherState.downloadedPackage,
    operation: launcherState.operation ? { ...launcherState.operation } : null,
    lastUpdate: launcherState.lastUpdate ? { ...launcherState.lastUpdate } : null
  };
}

function sendJson(response, status, payload) {
  const body = JSON.stringify(payload);
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer"
  });
  response.end(body);
}

function loopbackRequest(request) {
  const address = request.socket.remoteAddress || "";
  return address === "127.0.0.1" || address === "::1" || address === "::ffff:127.0.0.1";
}

function authorizedMutation(request) {
  return loopbackRequest(request)
    && request.headers.origin === launcherOrigin
    && request.headers["x-xar-launcher-token"] === csrfToken;
}

async function readJsonBody(request, maximumBytes = 32 * 1024) {
  let received = 0;
  const chunks = [];
  for await (const chunk of request) {
    received += chunk.length;
    if (received > maximumBytes) throw new Error("Les informations envoyées sont trop volumineuses.");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new Error("Les informations envoyées sont invalides.");
  }
}

async function waitForApplication() {
  for (let attempt = 0; attempt < 120; attempt += 1) {
    if (!applicationProcess || applicationProcess.exitCode !== null) return false;
    try {
      const response = await fetch(`${appUrl}/api/health`, { signal: AbortSignal.timeout(500) });
      if (response.ok) return true;
    } catch {
      // Le serveur finit son démarrage.
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  return false;
}

async function startApplication(environment) {
  if (applicationProcess && applicationProcess.exitCode === null) return;
  if (!launcherState.configuration.ready) {
    launcherState.application = {
      running: false,
      ready: false,
      url: appUrl,
      error: null,
      blockedByConfiguration: true
    };
    return;
  }
  launcherState.application = { running: true, ready: false, url: appUrl, error: null };
  applicationProcess = spawn(process.execPath, [path.join(ROOT, "server.mjs")], {
    cwd: ROOT,
    env: {
      ...environment,
      ...process.env,
      PORT: String(appPort),
      XAR_DATA_DIR: dataDirectory,
      XAR_LAUNCHER_ORIGIN: launcherOrigin
    },
    stdio: "inherit"
  });
  applicationProcess.once("error", (error) => {
    launcherState.application = { running: false, ready: false, url: appUrl, error: `Démarrage impossible : ${error.message}` };
  });
  applicationProcess.once("exit", (code, signal) => {
    launcherState.application = {
      running: false,
      ready: false,
      url: appUrl,
      error: code === 0 || signal === "SIGTERM" ? null : `La Régie s’est arrêtée (code ${code ?? signal}).`
    };
  });
  launcherState.application.ready = await waitForApplication();
  if (!launcherState.application.ready) launcherState.application.error = "La Régie n’a pas répondu dans le délai prévu.";
}

async function stopApplication() {
  const processToStop = applicationProcess;
  if (!processToStop || processToStop.exitCode !== null) return;
  processToStop.kill("SIGTERM");
  for (let attempt = 0; attempt < 80 && processToStop.exitCode === null; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  if (processToStop.exitCode === null) processToStop.kill("SIGKILL");
}

function openApplicationShell(kind, url) {
  const result = openDedicatedWindow(url, {
    onError: (error) => {
      launcherState.shell[kind] = {
        dedicated: false,
        mode: "browser-fallback",
        engine: "Navigateur par défaut",
        message: `La fenêtre dédiée n’a pas répondu (${error.message}). Le navigateur par défaut a pris le relais.`
      };
    }
  });
  launcherState.shell[kind] = result;
  return result;
}

async function checkForUpdates(environment) {
  const manifestUrl = updateManifestUrl(environment);
  if (!manifestUrl) {
    launcherState.update = {
      configured: false,
      checking: false,
      state: "not-configured",
      message: "Canal signé non configuré : aucun téléchargement distant n’est autorisé.",
      availableVersion: null
    };
    return launcherState.update;
  }
  if (!release.updatePublicKey) {
    launcherState.update = {
      configured: false,
      checking: false,
      state: "trust-missing",
      message: "Le canal existe, mais aucune clé publique de signature n’est intégrée au build.",
      availableVersion: null
    };
    return launcherState.update;
  }
  launcherState.update = { ...launcherState.update, configured: true, checking: true, state: "checking", message: "Vérification du canal signé…" };
  try {
    latestSignedManifest = await fetchSignedUpdateManifest(manifestUrl, {
      applicationId: release.applicationId,
      publicKey: release.updatePublicKey,
      channel: release.channel
    });
    const comparison = compareApplicationVersions(release.version, latestSignedManifest.version);
    launcherState.update = {
      configured: true,
      checking: false,
      state: comparison < 0 ? "available" : comparison === 0 ? "current" : "ahead",
      message: comparison < 0
        ? `La version ${latestSignedManifest.version} est disponible.`
        : comparison === 0
          ? "La version installée est à jour."
          : "Cette version installée est plus récente que le canal configuré.",
      availableVersion: comparison < 0 ? latestSignedManifest.version : null
    };
  } catch (error) {
    latestSignedManifest = null;
    launcherState.update = {
      configured: true,
      checking: false,
      state: "error",
      message: String(error?.message || "Vérification des mises à jour impossible."),
      availableVersion: null
    };
  }
  return launcherState.update;
}

async function downloadLatestSignedPackage(environment, { operation = "download" } = {}) {
  if (!latestSignedManifest) await checkForUpdates(environment);
  if (!latestSignedManifest) throw new Error("Aucun paquet signé n’est disponible.");
  const safeChannel = String(latestSignedManifest.channel || "release").replace(/[^a-z0-9_-]+/gi, "-");
  const filename = `Xar-Tsaroth-Regie-v${latestSignedManifest.version}-${safeChannel}.zip`;
  const destination = path.join(downloadsDirectory, filename);
  launcherState.operation = {
    kind: operation,
    state: "downloading",
    progress: 0,
    message: `Téléchargement sécurisé de la version ${latestSignedManifest.version}…`
  };
  const downloaded = await downloadVerifiedPackage(latestSignedManifest.package, destination, fetch, {
    onProgress: ({ percent }) => {
      launcherState.operation = {
        kind: operation,
        state: "downloading",
        progress: percent,
        message: `Téléchargement signé · ${percent} %`
      };
    }
  });
  launcherState.downloadedPackage = { version: latestSignedManifest.version, filename, size: downloaded.size };
  launcherState.operation = {
    kind: operation,
    state: "verified",
    progress: 100,
    message: "Paquet reçu : taille, empreinte et signature confirmées."
  };
  return { ...launcherState.downloadedPackage, path: downloaded.path };
}

function writePendingUpdate(downloaded, { allowSameVersion = false } = {}) {
  const pendingPath = path.join(updatesDirectory, "pending-update.json");
  const temporary = `${pendingPath}.${process.pid}.partial`;
  const instruction = {
    schemaVersion: PENDING_UPDATE_SCHEMA_VERSION,
    createdAt: new Date().toISOString(),
    packagePath: downloaded.path,
    manifest: latestSignedManifest,
    allowSameVersion
  };
  writeFileSync(temporary, `${JSON.stringify(instruction, null, 2)}\n`, { mode: 0o600 });
  rmSync(pendingPath, { force: true });
  renameSync(temporary, pendingPath);
  try { chmodSync(pendingPath, 0o600); } catch {}
  return pendingPath;
}

async function prepareSelfUpdate(environment, { allowSameVersion = false, reason = "update" } = {}) {
  if (!latestSignedManifest) await checkForUpdates(environment);
  if (!latestSignedManifest) throw new Error("Aucune mise à jour signée n’est disponible.");
  const comparison = compareApplicationVersions(release.version, latestSignedManifest.version);
  if (comparison > 0 || (comparison === 0 && !allowSameVersion)) {
    throw new Error(comparison === 0 ? "Cette version est déjà installée et intacte." : "Le canal proposé est plus ancien que cette installation.");
  }
  const downloaded = await downloadLatestSignedPackage(environment, { operation: reason });
  const pendingPath = writePendingUpdate(downloaded, { allowSameVersion });
  launcherState.operation = {
    kind: reason,
    state: "restarting",
    progress: 100,
    message: "Paquet validé. La Régie va redémarrer et achever l’installation."
  };
  return pendingPath;
}

function launchUpdaterAndExit(pendingPath) {
  const updater = spawn(process.execPath, [path.join(ROOT, "updater.mjs"), pendingPath, String(process.pid)], {
    cwd: privateRoot,
    env: { ...process.env, XAR_PRIVATE_ROOT: privateRoot },
    detached: true,
    stdio: "ignore",
    windowsHide: true
  });
  updater.unref();
  if (applicationProcess && applicationProcess.exitCode === null) applicationProcess.kill("SIGTERM");
  const forceExit = setTimeout(() => process.exit(0), 4_000);
  forceExit.unref();
  if (launcherServer) launcherServer.close(() => process.exit(0));
  else process.exit(0);
}

function shutdownLauncher() {
  if (shutdownStarted) return;
  shutdownStarted = true;
  if (applicationProcess && applicationProcess.exitCode === null) applicationProcess.kill("SIGTERM");
  const forceExit = setTimeout(() => process.exit(0), 4_000);
  forceExit.unref();
  if (launcherServer) launcherServer.close(() => process.exit(0));
  else process.exit(0);
}

function serveAsset(response, filename, contentType) {
  const filePath = path.join(LAUNCHER_ASSET_DIR, filename);
  let body = readFileSync(filePath);
  if (filename === "index.html") {
    body = Buffer.from(body.toString("utf8")
      .replaceAll("{{CSRF_TOKEN}}", csrfToken)
      .replaceAll("{{APP_VERSION}}", release.version));
  }
  response.writeHead(200, {
    "Content-Type": contentType,
    "Content-Length": body.length,
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer"
  });
  response.end(body);
}

async function handleLauncherRequest(request, response) {
  if (!loopbackRequest(request)) return sendJson(response, 403, { ok: false, error: "Launcher réservé à cette machine." });
  const url = new URL(request.url || "/", launcherOrigin);
  if (request.method === "GET" && url.pathname === "/") return serveAsset(response, "index.html", "text/html; charset=utf-8");
  if (request.method === "GET" && url.pathname === "/launcher.css") return serveAsset(response, "launcher.css", "text/css; charset=utf-8");
  if (request.method === "GET" && url.pathname === "/launcher.js") return serveAsset(response, "launcher.js", "text/javascript; charset=utf-8");
  if (request.method === "GET" && url.pathname === "/regie-chamber.webp") return serveAsset(response, "regie-chamber.webp", "image/webp");
  if (request.method === "GET" && url.pathname === "/xar-tsaroth-title.png") return serveAsset(response, "xar-tsaroth-title.png", "image/png");
  if (request.method === "GET" && url.pathname === "/xar-icon.png") return serveAsset(response, "xar-icon.png", "image/png");
  if (request.method === "GET" && url.pathname === "/api/status") return sendJson(response, 200, publicStatus());
  if (request.method !== "POST" || !authorizedMutation(request)) return sendJson(response, 403, { ok: false, error: "Commande locale refusée." });

  try {
    if (url.pathname === "/api/shutdown") {
      sendJson(response, 200, { ok: true, message: "Arrêt local de la Régie demandé." });
      setTimeout(shutdownLauncher, 60).unref();
      return;
    }
    if (url.pathname === "/api/configuration/generate-code") {
      return sendJson(response, 200, { ok: true, playerAccessCode: generatePlayerAccessCode() });
    }
    if (url.pathname === "/api/configuration") {
      const body = await readJsonBody(request);
      savePrivateConfiguration(body);
      await stopApplication();
      launcherState.application = { running: false, ready: false, url: appUrl, error: null };
      if (launcherState.integrity.ok) await startApplication(runtimeEnvironment);
      return sendJson(response, 200, publicStatus());
    }
    if (url.pathname === "/api/open") {
      if (!launcherState.configuration.ready) throw new Error("Terminez d’abord la configuration guidée.");
      if (!launcherState.application.ready) await startApplication(runtimeEnvironment);
      if (!launcherState.application.ready) throw new Error(launcherState.application.error || "La Régie n’est pas prête.");
      launcherState.shell.application = {
        dedicated: true,
        mode: "same-window",
        engine: process.env.XAR_DESKTOP_HOST === "1" ? "Application Windows" : applicationBrowser?.engine ?? "Fenêtre actuelle",
        message: "La Régie va remplacer cet écran dans la même fenêtre."
      };
      return sendJson(response, 200, publicStatus());
    }
    if (url.pathname === "/api/check-update") {
      await checkForUpdates(runtimeEnvironment);
      return sendJson(response, 200, publicStatus());
    }
    if (url.pathname === "/api/verify-integrity") {
      launcherState.integrity = verifyInstallation(ROOT);
      return sendJson(response, 200, publicStatus());
    }
    if (url.pathname === "/api/redownload") {
      if (updateOperation) throw new Error("Un téléchargement est déjà en cours.");
      updateOperation = downloadLatestSignedPackage(runtimeEnvironment, { operation: "redownload" });
      try {
        const downloadedPackage = await updateOperation;
        return sendJson(response, 200, { ...publicStatus(), downloadedPackage: { version: downloadedPackage.version, filename: downloadedPackage.filename, size: downloadedPackage.size } });
      } finally {
        updateOperation = null;
      }
    }
    if (url.pathname === "/api/install-update") {
      if (updateOperation) throw new Error("Une opération de mise à jour est déjà en cours.");
      const repair = !launcherState.integrity.ok;
      updateOperation = prepareSelfUpdate(runtimeEnvironment, { allowSameVersion: repair, reason: repair ? "repair" : "update" });
      try {
        const pendingPath = await updateOperation;
        sendJson(response, 200, publicStatus());
        setTimeout(() => launchUpdaterAndExit(pendingPath), 900).unref();
        return;
      } finally {
        updateOperation = null;
      }
    }
    return sendJson(response, 404, { ok: false, error: "Commande inconnue." });
  } catch (error) {
    if (["/api/redownload", "/api/install-update"].includes(url.pathname)) {
      launcherState.operation = {
        kind: url.pathname === "/api/install-update" ? "update" : "redownload",
        state: "error",
        progress: 0,
        message: String(error?.message || "Opération de mise à jour impossible.")
      };
    }
    return sendJson(response, 409, {
      ok: false,
      error: String(error?.message || "Commande impossible."),
      issues: Array.isArray(error?.issues) ? error.issues : undefined,
      status: publicStatus()
    });
  }
}

export async function runLauncher({ openBrowser = true } = {}) {
  preparePrivateStorage();
  refreshRuntimeEnvironment();
  if (launcherState.integrity.ok && launcherState.configuration.ready) {
    await startApplication(runtimeEnvironment);
  } else if (!launcherState.configuration.ready) {
    launcherState.application = {
      running: false,
      ready: false,
      url: appUrl,
      error: null,
      blockedByConfiguration: true
    };
  } else {
    launcherState.application = {
      running: false,
      ready: false,
      url: appUrl,
      error: "Démarrage bloqué : l’intégrité du build doit être restaurée."
    };
  }
  const server = http.createServer((request, response) => {
    handleLauncherRequest(request, response).catch((error) => sendJson(response, 500, { ok: false, error: String(error?.message || error) }));
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(launcherPort, "127.0.0.1", resolve);
  });
  launcherServer = server;
  checkForUpdates(runtimeEnvironment).catch(() => {});
  if (openBrowser) openApplicationShell("launcher", launcherOrigin);
  process.once("SIGINT", shutdownLauncher);
  process.once("SIGTERM", shutdownLauncher);
  return { server, origin: launcherOrigin, appUrl };
}

if (path.resolve(process.argv[1] || "") === fileURLToPath(import.meta.url)) {
  runLauncher().catch((error) => {
    console.error(`Launcher impossible : ${error.message}`);
    if (applicationProcess && applicationProcess.exitCode === null) applicationProcess.kill("SIGTERM");
    process.exitCode = 1;
  });
}
