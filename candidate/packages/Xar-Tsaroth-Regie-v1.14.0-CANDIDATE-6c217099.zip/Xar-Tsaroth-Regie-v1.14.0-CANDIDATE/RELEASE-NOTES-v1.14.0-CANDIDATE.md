# Régie du Seuil 1.14.0 — Candidate comptes et données

Cette candidate part de la 1.13.2 candidate et conserve la 1.13.1 stable comme référence de sécurité. Elle ne devient stable qu’après validation explicite.

## Accès par comptes

- Les URL personnelles, jetons de joueur, code global et mot de passe MJ quotidien sont remplacés par un identifiant et un mot de passe propres à chaque personne.
- Les comptes possèdent un niveau Joueur ou Maître de jeu. L’administration locale protégée peut les créer, les révoquer, les restaurer, les promouvoir ou les rétrograder.
- Un compte peut être rattaché à l’identité d’un ancien joueur pour retrouver ses fiches existantes.
- Les mots de passe ne sont jamais chiffrés de façon réversible ni enregistrés en clair : seuls des vérificateurs scrypt salés sont conservés.
- Les sessions sont aléatoires, éphémères et contrôlées côté serveur. Révocation, changement de rôle ou changement de mot de passe invalident les sessions précédentes.
- Le registre des comptes conserve une copie précédente et la restaure automatiquement si une écriture a été interrompue par un crash.

## Interface Joueur

- La vue Joueur est séparée en deux pages : **Carte & outils** et **Fiches de personnages**.
- La carte regroupe la calculatrice tactique et les raccourcis rapides des personnages du compte.
- La page Fiches permet de créer autant de personnages que nécessaire sans exposer les fiches des autres comptes.
- Un fichier Word `.docx` peut préremplir une nouvelle fiche à partir de libellés français reconnus. Le document est limité avant et après décompression et les champs restent modifiables après import.
- Les anciens fichiers `.doc` doivent d’abord être enregistrés au format `.docx`.

## Conservation et maintenance

- **Vérifier les fichiers** supprime les reliquats applicatifs absents du manifeste du build, sans toucher au profil privé.
- Un ancien dossier `data` trouvé dans le programme est sauvegardé, fusionné vers le profil persistant puis retiré de l’installation.
- `.env.local` n’est plus nécessaire. Une configuration historique est migrée une seule fois vers `configuration.json` et le coffre chiffré, puis le fichier historique est supprimé.
- **Exporter mes données** crée une archive `.xarbackup` contenant fiches, scènes, médias et stockage local joueur.
- **Réintégrer mes données** vérifie les chemins, tailles et empreintes, conserve une sauvegarde des fichiers remplacés, restaure les données puis redémarre la Régie.
- Comptes, vérificateurs, mots de passe, configuration, coffre et jetons du pont ChatGPT sont volontairement exclus des sauvegardes transportables.

## Installation et mises à jour

- L’installation Windows reste commune à tous les utilisateurs sous `C:\Program Files\Xar-Tsaroth`.
- Le numéro applicatif passe à `1.14.0`, l’API de l’enveloppe Electron à `3` et le schéma de session à `10`.
- Le canal reste `candidate`. La publication distante exige toujours un paquet complet retesté, un manifeste Ed25519 valide et une signature Authenticode valide pour l’installeur Windows.
