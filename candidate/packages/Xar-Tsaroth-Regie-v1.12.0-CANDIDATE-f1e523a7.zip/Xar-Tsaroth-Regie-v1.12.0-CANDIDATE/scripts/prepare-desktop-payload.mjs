import { copyFileSync, mkdirSync, rmSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  INTEGRITY_MANIFEST_FILENAME,
  listReleaseFiles,
  verifyInstallation
} from "../launcher-core.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const destinationRoot = path.join(root, "desktop-payload");
const integrity = verifyInstallation(root);
if (!integrity.ok) throw new Error("Le build source doit être intact avant de préparer l’installeur Windows.");

rmSync(destinationRoot, { recursive: true, force: true });
mkdirSync(destinationRoot, { recursive: true, mode: 0o755 });
for (const relativePath of [...listReleaseFiles(root), INTEGRITY_MANIFEST_FILENAME]) {
  const source = path.join(root, ...relativePath.split("/"));
  const destination = path.join(destinationRoot, ...relativePath.split("/"));
  mkdirSync(path.dirname(destination), { recursive: true, mode: 0o755 });
  copyFileSync(source, destination);
}
console.log(`Paquet applicatif Windows préparé : ${integrity.checkedFiles} fichiers contrôlés.`);

