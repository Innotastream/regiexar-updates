#!/usr/bin/env sh
set -eu
XAR_APP_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$XAR_APP_DIR"

if ! command -v node >/dev/null 2>&1; then
  echo "Le lanceur technique macOS/Linux requiert Node.js 20 ou plus récent."
  echo "Sous Windows, utilisez l’installeur Xar-Tsaroth-Regie-Setup fourni."
  exit 1
fi

XAR_NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]")"
if [ "$XAR_NODE_MAJOR" -lt 20 ]; then
  echo "Votre version de Node.js est trop ancienne. Installez Node.js 20 LTS ou plus récent."
  exit 1
fi

exec node installer.mjs
