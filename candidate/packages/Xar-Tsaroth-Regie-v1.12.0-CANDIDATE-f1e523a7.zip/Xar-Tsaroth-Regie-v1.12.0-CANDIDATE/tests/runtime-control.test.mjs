import test from "node:test";
import assert from "node:assert/strict";
import {
  extractLauncherToken,
  parseStoppedProcessIds,
  requestLauncherShutdown,
  stopLegacyWindowsRuntime,
  windowsRuntimeStopScript
} from "../runtime-control.mjs";

const TOKEN = "a".repeat(64);

test("le jeton local du launcher est extrait uniquement dans son format strict", () => {
  assert.equal(extractLauncherToken(`<html data-launcher-token="${TOKEN}">`), TOKEN);
  assert.equal(extractLauncherToken('<html data-launcher-token="trop-court">'), null);
  assert.equal(extractLauncherToken(`<script>${TOKEN}</script>`), null);
});

test("l’arrêt gracieux réutilise exactement l’origine et le jeton CSRF du launcher", async () => {
  const calls = [];
  const origin = "http://127.0.0.1:4169";
  const fetchImpl = async (url, options = {}) => {
    calls.push({ url, options });
    if (calls.length === 1) return { ok: true, text: async () => `<html data-launcher-token="${TOKEN}">` };
    return { ok: true };
  };

  assert.equal(await requestLauncherShutdown({ origin, fetchImpl }), true);
  assert.equal(calls.length, 2);
  assert.equal(calls[0].url, `${origin}/`);
  assert.equal(calls[1].url, `${origin}/api/shutdown`);
  assert.equal(calls[1].options.method, "POST");
  assert.equal(calls[1].options.headers.Origin, origin);
  assert.equal(calls[1].options.headers["X-Xar-Launcher-Token"], TOKEN);
});

test("l’arrêt Windows cible seulement launcher.mjs et server.mjs dans l’installation exacte", () => {
  const installationRoot = "C:\\Users\\Xar\\AppData\\Local\\Programs\\XarTsarothRegie";
  const script = windowsRuntimeStopScript(installationRoot);
  assert.match(script, /Get-CimInstance Win32_Process/);
  assert.match(script, /\\launcher\.mjs/);
  assert.match(script, /\\server\.mjs/);
  assert.doesNotMatch(script, /updater\.mjs/i);
  assert.doesNotMatch(script, /Stop-Process\s+-Name/i);

  let invocation = null;
  const stopped = stopLegacyWindowsRuntime({
    installationRoot,
    platform: "win32",
    spawnSyncImpl(command, args, options) {
      invocation = { command, args, options };
      return { status: 0, stdout: "XAR_STOPPED:4100\r\nXAR_STOPPED:4101\r\n", stderr: "" };
    }
  });
  assert.deepEqual(stopped, [4100, 4101]);
  assert.equal(invocation.command, "powershell.exe");
  assert.ok(invocation.args.includes("-EncodedCommand"));
  assert.doesNotMatch(invocation.args.join(" "), /XarTsarothRegie/i);
  const encoded = invocation.args.at(-1);
  assert.equal(Buffer.from(encoded, "base64").toString("utf16le"), script);
});

test("le relevé des processus arrêtés ignore les sorties étrangères ou invalides", () => {
  assert.deepEqual(parseStoppedProcessIds("bruit\nXAR_STOPPED:42\nXAR_STOPPED:0\nXAR_STOPPED:abc\n"), [42]);
});
