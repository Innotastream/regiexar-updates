import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { downloadVerifiedPackage } from "../launcher-core.mjs";

function packageInfo(bytes) {
  return {
    url: "https://updates.example.test/application.zip",
    size: bytes.length,
    sha256: createHash("sha256").update(bytes).digest("hex")
  };
}

test("un téléchargement incomplet est retenté puis remplacé uniquement après contrôle", async (context) => {
  const root = await mkdtemp(path.join(tmpdir(), "xar-download-retry-"));
  context.after(() => rm(root, { recursive: true, force: true }));
  const destination = path.join(root, "application.zip");
  const bytes = Buffer.from("paquet applicatif complet et contrôlé");
  const requests = [];
  const fetchImplementation = async (url, options) => {
    requests.push({ url, options });
    if (requests.length === 1) {
      return new Response(Buffer.from("incomplet"), { headers: { "content-length": "9" } });
    }
    return new Response(bytes, { headers: { "content-length": String(bytes.length) } });
  };

  const result = await downloadVerifiedPackage(packageInfo(bytes), destination, fetchImplementation);
  assert.equal(result.attempts, 2);
  assert.equal(requests.length, 2);
  assert.match(requests[1].url, /xar_retry=/);
  assert.equal(requests[0].options.headers["Accept-Encoding"], "identity");
  assert.deepEqual(await readFile(destination), bytes);
});

test("trois paquets incomplets laissent l’installation intacte avec un message clair", async (context) => {
  const root = await mkdtemp(path.join(tmpdir(), "xar-download-refused-"));
  context.after(() => rm(root, { recursive: true, force: true }));
  const destination = path.join(root, "application.zip");
  const bytes = Buffer.from("contenu attendu");
  let attempts = 0;
  const fetchImplementation = async () => {
    attempts += 1;
    return new Response(Buffer.from("non"), { headers: { "content-length": "3" } });
  };

  await assert.rejects(
    () => downloadVerifiedPackage(packageInfo(bytes), destination, fetchImplementation),
    /application actuelle est restée intacte/i
  );
  assert.equal(attempts, 3);
  assert.equal(existsSync(destination), false);
});
