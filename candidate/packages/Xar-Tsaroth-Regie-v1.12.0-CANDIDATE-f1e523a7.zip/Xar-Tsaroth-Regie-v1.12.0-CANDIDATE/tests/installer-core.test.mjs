import test from "node:test";
import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { installApplication, renameWithRetry } from "../installer-core.mjs";
import { defaultInstallationRoot, defaultPrivateRoot } from "../installation-paths.mjs";
import { writeIntegrityManifest } from "../launcher-core.mjs";

async function sampleBuild(root, version) {
  await mkdir(root, { recursive: true });
  await writeFile(path.join(root, "application.json"), `${JSON.stringify({
    applicationId: "fr.xar.test",
    displayName: "Xar Test",
    version,
    channel: "candidate",
    updatePublicKey: "test-public-key"
  }, null, 2)}\n`);
  await writeFile(path.join(root, "launcher.mjs"), `export const version = "${version}";\n`);
  writeIntegrityManifest(root);
}

test("le programme et les données utilisent des répertoires distincts", () => {
  const environment = { LOCALAPPDATA: "C:\\Users\\Xar\\AppData\\Local", APPDATA: "C:\\Users\\Xar\\AppData\\Roaming" };
  const dataRoot = defaultPrivateRoot(environment, "win32", "C:\\Users\\Xar");
  const applicationRoot = defaultInstallationRoot(environment, "win32", "C:\\Users\\Xar");
  assert.notEqual(dataRoot, applicationRoot);
  assert.match(applicationRoot.replaceAll("\\", "/"), /Programs\/XarTsarothRegie$/);
  assert.match(dataRoot.replaceAll("\\", "/"), /XarTsarothRegie$/);
});

test("réinstaller ou mettre à jour le programme conserve les fiches et la configuration privées", async (context) => {
  const sandbox = await mkdtemp(path.join(tmpdir(), "xar-installer-"));
  context.after(() => rm(sandbox, { recursive: true, force: true }));
  const sourceOne = path.join(sandbox, "source-1.8.0");
  const sourceTwo = path.join(sandbox, "source-1.9.0");
  const installationRoot = path.join(sandbox, "programs", "XarTsarothRegie");
  const privateRoot = path.join(sandbox, "profile", "XarTsarothRegie");
  await sampleBuild(sourceOne, "1.8.0");
  await writeFile(path.join(sourceOne, ".env.local"), "PRIVATE_VALUE=preserved\n");
  await mkdir(path.join(sourceOne, "data", "users", "person-one"), { recursive: true });
  await writeFile(path.join(sourceOne, "data", "session-state.json"), "{\"legacy\":true}\n");
  await writeFile(path.join(sourceOne, "data", "users", "person-one", "characters.json"), "{\"characters\":[{\"id\":\"hero\"}]}\n");

  const first = installApplication({ sourceRoot: sourceOne, installationRoot, privateRoot });
  assert.equal(first.installed, true);
  assert.equal(JSON.parse(await readFile(path.join(installationRoot, "application.json"), "utf8")).version, "1.8.0");
  assert.equal(await readFile(path.join(privateRoot, ".env.local"), "utf8"), "PRIVATE_VALUE=preserved\n");
  assert.match(await readFile(path.join(privateRoot, "data", "users", "person-one", "characters.json"), "utf8"), /hero/);

  await sampleBuild(sourceTwo, "1.9.0");
  const second = installApplication({ sourceRoot: sourceTwo, installationRoot, privateRoot });
  assert.equal(second.installed, true);
  assert.equal(JSON.parse(await readFile(path.join(installationRoot, "application.json"), "utf8")).version, "1.9.0");
  assert.match(await readFile(path.join(privateRoot, "data", "users", "person-one", "characters.json"), "utf8"), /hero/);
  assert.equal(await readFile(path.join(privateRoot, ".env.local"), "utf8"), "PRIVATE_VALUE=preserved\n");

  assert.throws(
    () => installApplication({ sourceRoot: sourceOne, installationRoot, privateRoot }),
    /retour arrière refusé/
  );
  assert.equal(JSON.parse(await readFile(path.join(installationRoot, "application.json"), "utf8")).version, "1.9.0");
});

test("un refus d’intégrité indique le fichier exact à corriger", async (context) => {
  const sandbox = await mkdtemp(path.join(tmpdir(), "xar-installer-diagnostic-"));
  context.after(() => rm(sandbox, { recursive: true, force: true }));
  const source = path.join(sandbox, "source");
  await sampleBuild(source, "1.9.3");
  await rm(path.join(source, "launcher.mjs"));

  assert.throws(
    () => installApplication({
      sourceRoot: source,
      installationRoot: path.join(sandbox, "program"),
      privateRoot: path.join(sandbox, "profile")
    }),
    /fichiers manquants : launcher\.mjs/
  );
});

test("un renommage Windows verrouillé est retenté avant de réussir", () => {
  const waits = [];
  let calls = 0;
  renameWithRetry("source", "destination", {
    attempts: 4,
    delayMs: 10,
    sleep: (duration) => waits.push(duration),
    renameFile: () => {
      calls += 1;
      if (calls < 3) throw Object.assign(new Error("busy"), { code: "EBUSY" });
    }
  });
  assert.equal(calls, 3);
  assert.deepEqual(waits, [10, 20]);
});

test("une erreur de renommage non liée à un verrou n’est jamais masquée", () => {
  let waits = 0;
  assert.throws(
    () => renameWithRetry("source", "destination", {
      sleep: () => { waits += 1; },
      renameFile: () => { throw Object.assign(new Error("introuvable"), { code: "ENOENT" }); }
    }),
    /introuvable/
  );
  assert.equal(waits, 0);
});

test("un verrou Windows persistant produit un diagnostic actionnable sans menacer les données", () => {
  assert.throws(
    () => renameWithRetry("source", "destination", {
      attempts: 2,
      delayMs: 0,
      sleep: () => {},
      renameFile: () => { throw Object.assign(new Error("locked"), { code: "EPERM" }); }
    }),
    /fiches et scènes restent en sécurité/
  );
});
