import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  generatePlayerAccessCode,
  mergeConfigurationInput,
  parseEnvironmentText,
  publicConfigurationStatus,
  serializeEnvironment,
  validateConfiguration
} from "../configuration-core.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("une première ouverture sans configuration déclenche l’assistant", () => {
  const status = publicConfigurationStatus({}, { fileExists: false });
  assert.equal(status.ready, false);
  assert.equal(status.needsSetup, true);
  assert.ok(status.issues.some((issue) => issue.field === "configuration"));
  assert.ok(status.issues.some((issue) => issue.field === "playerAccessCode"));
});

test("les services facultatifs peuvent rester désactivés avec un code joueurs valide", () => {
  const result = validateConfiguration({ PLAYER_ACCESS_CODE: "table-privee-2026" });
  assert.equal(result.valid, true);
});

test("l’assistant refuse un faux webhook et une cible OVH dangereuse", () => {
  const result = validateConfiguration({
    PLAYER_ACCESS_CODE: "table-privee-2026",
    DISCORD_IMAGE_WEBHOOK_URL: "https://discord.example/api/webhooks/1/token",
    OVH_FTP_URL: "sftp://ftp.example.test/www",
    OVH_FTP_USER: "mj",
    OVH_FTP_PASSWORD: "secret"
  });
  assert.equal(result.valid, false);
  assert.ok(result.issues.some((issue) => issue.field === "discord.images"));
  assert.ok(result.issues.some((issue) => issue.field === "ovh.url"));
});

test("un secret existant reste intact quand le champ masqué est laissé vide", () => {
  const current = {
    PLAYER_ACCESS_CODE: "ancien-code",
    DISCORD_IMAGE_WEBHOOK_URL: "https://discord.com/api/webhooks/1/token",
    OVH_FTP_URL: "sftp://ftp.example.test/~/regie-media/",
    OVH_FTP_USER: "mj",
    OVH_FTP_PASSWORD: "mot-de-passe"
  };
  const merged = mergeConfigurationInput({
    playerAccessCode: "",
    discord: { images: { enabled: true, value: "" }, dice: { enabled: false }, journal: { enabled: false } },
    ovh: { enabled: true, url: "", user: "", password: "", publicBaseUrl: "" }
  }, current);
  assert.equal(merged.PLAYER_ACCESS_CODE, current.PLAYER_ACCESS_CODE);
  assert.equal(merged.DISCORD_IMAGE_WEBHOOK_URL, current.DISCORD_IMAGE_WEBHOOK_URL);
  assert.equal(merged.OVH_FTP_PASSWORD, current.OVH_FTP_PASSWORD);
});

test("la sérialisation privée conserve les caractères spéciaux sans afficher les secrets", () => {
  const values = {
    PORT: "4173",
    PLAYER_ACCESS_CODE: "table privée #1",
    OVH_FTP_PASSWORD: "p@ss=word# avec espace"
  };
  assert.deepEqual(parseEnvironmentText(serializeEnvironment(values)), values);
  const status = publicConfigurationStatus(values);
  assert.equal(status.playerAccessCodeConfigured, true);
  assert.equal("playerAccessCode" in status, false);
  assert.equal("password" in status.ovh, false);
});

test("le générateur produit un code joueurs suffisamment robuste", () => {
  const left = generatePlayerAccessCode();
  const right = generatePlayerAccessCode();
  assert.match(left, /^XT-[A-Za-z0-9_-]{12}$/);
  assert.notEqual(left, right);
});

test("le launcher bloque le premier démarrage puis enregistre la configuration sans exposer le code", { timeout: 30_000 }, async (context) => {
  const privateRoot = await mkdtemp(path.join(tmpdir(), "xar-guided-setup-"));
  const launcherPort = 46_000 + Math.floor(Math.random() * 1_000);
  const applicationPort = launcherPort + 1_500;
  const launcherOrigin = `http://127.0.0.1:${launcherPort}`;
  const accessCode = "XT-test-guide-2026";
  const child = spawn(process.execPath, [path.join(ROOT, "launcher.mjs")], {
    cwd: ROOT,
    env: {
      ...process.env,
      XAR_PRIVATE_ROOT: privateRoot,
      XAR_LAUNCHER_PORT: String(launcherPort),
      PORT: String(applicationPort),
      XAR_UPDATE_MANIFEST_URL: "https://127.0.0.1:9/latest.json"
    },
    stdio: "ignore"
  });
  context.after(async () => {
    try { child.kill("SIGTERM"); } catch {}
    await rm(privateRoot, { recursive: true, force: true });
  });

  let html = "";
  for (let attempt = 0; attempt < 100; attempt += 1) {
    try {
      const response = await fetch(launcherOrigin, { signal: AbortSignal.timeout(300) });
      if (response.ok) {
        html = await response.text();
        break;
      }
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 80));
  }
  assert.ok(html, "le launcher doit répondre");
  const csrfToken = html.match(/data-launcher-token="([a-f0-9]{64})"/)?.[1];
  assert.ok(csrfToken);

  const initial = await fetch(`${launcherOrigin}/api/status`).then((response) => response.json());
  assert.equal(initial.configuration.needsSetup, true);
  assert.equal(initial.application.ready, false);
  assert.equal(initial.application.blockedByConfiguration, true);

  const configuredResponse = await fetch(`${launcherOrigin}/api/configuration`, {
    method: "POST",
    headers: {
      Origin: launcherOrigin,
      "Content-Type": "application/json",
      "X-Xar-Launcher-Token": csrfToken
    },
    body: JSON.stringify({
      playerAccessCode: accessCode,
      discord: {
        images: { enabled: false, value: "" },
        dice: { enabled: false, value: "" },
        journal: { enabled: false, value: "" }
      },
      ovh: { enabled: false, url: "", user: "", password: "", publicBaseUrl: "" }
    })
  });
  const configured = await configuredResponse.json();
  assert.equal(configuredResponse.status, 200);
  assert.equal(configured.configuration.ready, true);
  assert.equal(configured.application.ready, true);
  assert.doesNotMatch(JSON.stringify(configured), new RegExp(accessCode));
  assert.match(await readFile(path.join(privateRoot, ".env.local"), "utf8"), new RegExp(accessCode));

  await fetch(`${launcherOrigin}/api/shutdown`, {
    method: "POST",
    headers: { Origin: launcherOrigin, "X-Xar-Launcher-Token": csrfToken }
  }).catch(() => {});
});
