const token = document.documentElement.dataset.launcherToken;
const initialVersion = document.documentElement.dataset.appVersion;
const $ = (selector) => document.querySelector(selector);
const restartSessionKey = "xar-regie-expected-update";
const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)");
let latestStatus = null;
let restartExpectedVersion = sessionStorage.getItem(restartSessionKey) || "";
let restartCompleted = false;
let configurationPresented = false;
let navigatingToApplication = false;

function initializeCinematicEffects() {
  if (!reducedMotion.matches && matchMedia("(pointer: fine)").matches) {
    let framePending = false;
    let nextX = 0;
    let nextY = 0;
    addEventListener("pointermove", (event) => {
      nextX = ((event.clientX / innerWidth) - .5) * 18;
      nextY = ((event.clientY / innerHeight) - .5) * 14;
      if (framePending) return;
      framePending = true;
      requestAnimationFrame(() => {
        document.documentElement.style.setProperty("--parallax-x", `${nextX.toFixed(2)}px`);
        document.documentElement.style.setProperty("--parallax-y", `${nextY.toFixed(2)}px`);
        framePending = false;
      });
    }, { passive: true });
  }

  if (reducedMotion.matches) return;
  const canvas = $("#arcaneCanvas");
  const context = canvas.getContext("2d");
  if (!context) return;
  const particles = [];
  let width = innerWidth;
  let height = innerHeight;
  let pixelRatio = 1;

  function resetParticle(particle, initial = false) {
    particle.x = Math.random() * width;
    particle.y = initial ? Math.random() * height : height + Math.random() * 40;
    particle.radius = .35 + Math.random() * 1.25;
    particle.vx = (Math.random() - .5) * .18;
    particle.vy = -.12 - Math.random() * .48;
    particle.alpha = .16 + Math.random() * .53;
    particle.pulse = Math.random() * Math.PI * 2;
    particle.violet = Math.random() > .72;
  }

  function resize() {
    width = innerWidth;
    height = innerHeight;
    pixelRatio = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.round(width * pixelRatio);
    canvas.height = Math.round(height * pixelRatio);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
  }

  resize();
  for (let index = 0; index < Math.min(76, Math.max(38, Math.round(width / 21))); index += 1) {
    const particle = {};
    resetParticle(particle, true);
    particles.push(particle);
  }
  addEventListener("resize", resize, { passive: true });

  function paint(time) {
    context.clearRect(0, 0, width, height);
    context.globalCompositeOperation = "lighter";
    for (const particle of particles) {
      particle.x += particle.vx;
      particle.y += particle.vy;
      particle.pulse += .018;
      if (particle.y < -15 || particle.x < -20 || particle.x > width + 20) resetParticle(particle);
      const flicker = .62 + Math.sin(particle.pulse + time * .001) * .38;
      const color = particle.violet ? "193, 126, 222" : "255, 170, 72";
      context.beginPath();
      context.fillStyle = `rgba(${color}, ${particle.alpha * flicker})`;
      context.shadowColor = `rgba(${color}, .72)`;
      context.shadowBlur = particle.radius * 7;
      context.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
      context.fill();
    }
    context.shadowBlur = 0;
    context.globalCompositeOperation = "source-over";
    requestAnimationFrame(paint);
  }
  requestAnimationFrame(paint);
}

function initializeBrandForge() {
  const forge = $("#logoForge");
  const canvas = $("#brandForgeCanvas");
  const context = canvas.getContext("2d");
  if (!forge || !context || reducedMotion.matches) {
    forge?.classList.add("settled");
    return;
  }

  const compact = matchMedia("(max-width: 720px)").matches;
  const particleCount = compact ? 520 : 980;
  const particles = [];
  let width = 1;
  let height = 1;
  let pixelRatio = 1;

  function resize() {
    const bounds = canvas.getBoundingClientRect();
    width = Math.max(1, bounds.width);
    height = Math.max(1, bounds.height);
    pixelRatio = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.round(width * pixelRatio);
    canvas.height = Math.round(height * pixelRatio);
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
  }

  resize();
  for (let index = 0; index < particleCount; index += 1) {
    const angle = Math.random() * Math.PI * 2;
    const radius = .32 + Math.random() * .62;
    particles.push({
      startX: .5 + Math.cos(angle) * radius,
      startY: .5 + Math.sin(angle) * radius * .72,
      targetX: .1 + Math.random() * .8,
      targetY: .39 + (Math.random() - .5) * .25,
      delay: Math.random() * .9,
      size: .35 + Math.random() * 1.35,
      driftX: (Math.random() - .5) * .24,
      driftY: (Math.random() - .5) * .2,
      violet: Math.random() > .66,
      filament: index % 23 === 0
    });
  }

  const startedAt = performance.now();
  requestAnimationFrame(() => forge.classList.add("forging"));
  addEventListener("resize", resize, { passive: true });

  function paint(now) {
    const elapsed = (now - startedAt) / 1000;
    context.clearRect(0, 0, width, height);
    context.globalCompositeOperation = "lighter";

    for (const particle of particles) {
      const age = elapsed - particle.delay;
      if (age < 0 || age > 3.7) continue;
      let x;
      let y;
      let alpha;
      if (age < 1.12) {
        const progress = 1 - Math.pow(1 - age / 1.12, 3);
        x = particle.startX + (particle.targetX - particle.startX) * progress;
        y = particle.startY + (particle.targetY - particle.startY) * progress;
        alpha = Math.sin(Math.min(1, age / 1.12) * Math.PI) * .78;
        if (particle.filament && progress > .18) {
          context.beginPath();
          context.moveTo(particle.startX * width, particle.startY * height);
          context.lineTo(x * width, y * height);
          context.strokeStyle = particle.violet ? `rgba(202,136,232,${alpha * .18})` : `rgba(255,202,116,${alpha * .15})`;
          context.lineWidth = .45;
          context.stroke();
        }
      } else {
        const burst = age - 1.12;
        x = particle.targetX + particle.driftX * burst;
        y = particle.targetY + particle.driftY * burst;
        alpha = Math.max(0, .88 - burst / 2.7);
      }
      const color = particle.violet ? "204, 132, 236" : "255, 190, 91";
      context.beginPath();
      context.fillStyle = `rgba(${color},${alpha})`;
      context.shadowColor = `rgba(${color},${Math.min(1, alpha + .18)})`;
      context.shadowBlur = particle.size * 5.5;
      context.arc(x * width, y * height, particle.size, 0, Math.PI * 2);
      context.fill();
    }

    context.shadowBlur = 0;
    context.globalCompositeOperation = "source-over";
    if (elapsed < 4.8) {
      requestAnimationFrame(paint);
    } else {
      context.clearRect(0, 0, width, height);
      forge.classList.add("settled");
    }
  }
  requestAnimationFrame(paint);
}

function setCard(cardId, tone, titleId, title, detailId, detail) {
  const card = $(cardId);
  card.classList.remove("good", "warning", "bad");
  if (tone) card.classList.add(tone);
  $(titleId).textContent = title;
  $(detailId).textContent = detail;
}

function setStage(selector, state) {
  const stage = $(selector);
  stage.classList.remove("complete", "current", "error");
  if (state) stage.classList.add(state);
}

function setProgress(value, detail) {
  const progress = Math.max(0, Math.min(100, Math.round(value)));
  $("#launchProgress").value = progress;
  $("#launchProgress").textContent = `${progress} %`;
  $("#progressValue").value = `${progress} %`;
  $("#progressValue").textContent = `${progress} %`;
  $("#progressDetail").textContent = detail;
}

function showTransition({ title, detail, kicker = "Veuillez patienter" }) {
  $("#restartKicker").textContent = kicker;
  $("#restartTitle").textContent = title;
  $("#restartDetail").textContent = detail;
  $("#restartOverlay").hidden = false;
  $("#launcherMain").setAttribute("aria-hidden", "true");
}

function hideTransition() {
  $("#restartOverlay").hidden = true;
  $("#launcherMain").removeAttribute("aria-hidden");
}

function transitionToApplication(url) {
  if (navigatingToApplication || !url) return;
  navigatingToApplication = true;
  showTransition({
    kicker: "Ouverture de la Régie",
    title: "Votre table est prête",
    detail: "Le launcher laisse maintenant place à la Régie dans cette même fenêtre."
  });
  setTimeout(() => location.assign(url), reducedMotion.matches ? 80 : 650);
}

function updateConfigurationHints(configuration) {
  const discord = configuration?.discord ?? {};
  const ovh = configuration?.ovh ?? {};
  $("#playerCodeHint").textContent = configuration?.playerAccessCodeConfigured
    ? "Un code est déjà enregistré. Laissez ce champ vide pour le conserver."
    : "Au moins 8 caractères. Vous pouvez générer automatiquement un code sécurisé.";
  for (const [name, label] of [["images", "Images"], ["dice", "Dice"], ["journal", "Journal"]]) {
    const hint = $(`#discord${label}Hint`);
    hint.textContent = discord[name]?.configured
      ? "Un webhook est déjà enregistré. Laissez ce champ vide pour le conserver."
      : "Collez ici l’adresse complète du webhook Discord.";
  }
  $("#ovhPasswordHint").textContent = ovh.passwordConfigured
    ? "Un mot de passe est déjà enregistré. Laissez ce champ vide pour le conserver."
    : "Le mot de passe reste uniquement sur cet ordinateur.";
}

function renderConfigurationIssues(issues = []) {
  const container = $("#configurationIssues");
  container.replaceChildren();
  if (!issues.length) {
    container.hidden = true;
    return;
  }
  const title = document.createElement("strong");
  title.textContent = "Vérifiez les informations suivantes :";
  const list = document.createElement("ul");
  for (const issue of issues) {
    const item = document.createElement("li");
    item.textContent = issue.message;
    list.append(item);
  }
  container.append(title, list);
  container.hidden = false;
}

async function openConfiguration({ force = false } = {}) {
  const configuration = latestStatus?.configuration ?? {};
  configurationPresented = true;
  $("#playerAccessCode").value = "";
  const discordEnabled = Object.values(configuration.discord ?? {}).some((entry) => entry?.configured);
  $("#discordEnabled").checked = discordEnabled;
  $("#discordFields").hidden = !discordEnabled;
  $("#discordImages").value = "";
  $("#discordDice").value = "";
  $("#discordJournal").value = "";
  $("#ovhEnabled").checked = Boolean(configuration.ovh?.configured || configuration.ovh?.url);
  $("#ovhFields").hidden = !$("#ovhEnabled").checked;
  $("#ovhUrl").value = configuration.ovh?.url || "";
  $("#ovhUser").value = configuration.ovh?.user || "";
  $("#ovhPassword").value = "";
  $("#ovhPublicBaseUrl").value = configuration.ovh?.publicBaseUrl || "";
  updateConfigurationHints(configuration);
  renderConfigurationIssues(configuration.issues ?? []);
  $("#closeConfiguration").hidden = force || !configuration.ready;
  $("#configurationOverlay").hidden = false;
  document.body.classList.add("dialog-open");
  if (!configuration.playerAccessCodeConfigured) {
    try {
      const payload = await request("/api/configuration/generate-code");
      $("#playerAccessCode").value = payload.playerAccessCode;
    } catch {
      // Le champ reste éditable manuellement.
    }
  }
  $("#playerAccessCode").focus();
}

function closeConfiguration() {
  if (!latestStatus?.configuration?.ready) return;
  $("#configurationOverlay").hidden = true;
  document.body.classList.remove("dialog-open");
  $("#openConfiguration").focus();
}

function render(status) {
  latestStatus = status;
  const configuration = status.configuration ?? { ready: true, needsSetup: false, issues: [] };
  const application = status.application;
  const integrity = status.integrity;
  const update = status.update;
  const operation = status.operation;
  const operationBusy = ["downloading", "restarting"].includes(operation?.state);

  setCard(
    "#configurationCard",
    configuration.ready ? "good" : "warning",
    "#configurationStatus",
    configuration.ready ? "Réglages prêts" : "Configuration nécessaire",
    "#configurationDetail",
    configuration.ready
      ? "Le code joueurs et les services choisis sont configurés."
      : "Suivez l’assistant avant le premier démarrage."
  );

  setCard(
    "#applicationCard",
    application.ready ? "good" : application.error ? "bad" : "warning",
    "#applicationStatus",
    application.ready ? "Régie prête" : application.error ? "Démarrage interrompu" : configuration.ready ? "Démarrage en cours" : "En attente des réglages",
    "#applicationDetail",
    application.error || (application.ready
      ? "L’application locale répond et peut être ouverte."
      : configuration.ready ? "La Régie termine son démarrage." : "La Régie démarrera après l’enregistrement de la configuration.")
  );

  const integrityIssueCount = (integrity.missing?.length || 0)
    + (integrity.modified?.length || 0)
    + (integrity.unexpected?.length || 0)
    + (integrity.invalidEntries?.length || 0);
  setCard(
    "#integrityCard",
    integrity.ok ? "good" : "bad",
    "#integrityStatus",
    integrity.ok ? "Fichiers intacts" : "Réparation nécessaire",
    "#integrityDetail",
    integrity.ok
      ? `${integrity.checkedFiles} fichiers applicatifs ont été vérifiés.`
      : integrity.reason === "manifest-missing"
        ? "La liste de contrôle des fichiers est absente."
        : `${integrityIssueCount} fichier(s) doivent être restaurés.`
  );

  const updateTone = update.state === "available" || update.state === "trust-missing" || update.state === "not-configured"
    ? "warning"
    : update.state === "error" ? "bad"
      : update.state === "current" || update.state === "ahead" ? "good" : "";
  const updateTitle = update.state === "available" ? `Version ${update.availableVersion} disponible`
    : update.state === "current" ? "Application à jour"
      : update.state === "checking" ? "Recherche en cours"
        : update.state === "error" ? "Vérification impossible"
          : update.state === "trust-missing" ? "Vérification de sécurité indisponible"
            : update.state === "ahead" ? "Version plus récente installée"
              : "Mises à jour non configurées";
  setCard("#updateCard", updateTone, "#updateStatus", updateTitle, "#updateDetail", update.message);

  setStage("#stageApplication", application.ready ? "complete" : application.error ? "error" : "current");
  setStage("#stageIntegrity", integrity.ok ? "complete" : "error");
  setStage(
    "#stageUpdate",
    update.state === "checking" || update.state === "not-checked" ? "current"
      : update.state === "error" || update.state === "trust-missing" ? "error"
        : update.state === "available" || update.state === "not-configured" ? "current" : "complete"
  );

  if (operation?.state === "downloading") {
    setProgress(operation.progress, operation.message);
  } else if (operation?.state === "restarting") {
    setProgress(100, operation.message);
    showTransition({
      title: "Installation de la mise à jour",
      detail: "La nouvelle version est installée puis contrôlée. La Régie reviendra automatiquement dans cette fenêtre."
    });
  } else {
    const configurationProgress = configuration.ready ? 12 : 3;
    const appProgress = application.ready ? 30 : application.error ? 10 : configuration.ready ? 18 : 5;
    const integrityProgress = integrity.ok || integrityIssueCount > 0 || integrity.reason ? 30 : 12;
    const updateResolved = !["not-checked", "checking"].includes(update.state);
    const updateProgress = updateResolved ? 28 : update.state === "checking" ? 14 : 4;
    const detail = !configuration.ready ? "Terminez la configuration guidée pour démarrer la Régie."
      : application.error ? application.error
        : !integrity.ok ? "Les fichiers doivent être réparés avant utilisation."
          : update.state === "available" ? `La version ${update.availableVersion} est prête à être installée.`
            : application.ready ? "Tout est prêt. Vous pouvez ouvrir la Régie."
              : "Démarrage de l’application locale…";
    setProgress(configurationProgress + appProgress + integrityProgress + updateProgress, detail);
  }

  const global = $("#globalStatus");
  global.classList.remove("good", "bad");
  let globalMessage = "Préparation en cours…";
  if (!configuration.ready) {
    globalMessage = "Configuration requise avant le premier démarrage";
  } else if (application.error || !integrity.ok) {
    global.classList.add("bad");
    globalMessage = application.error ? "Le démarrage a été interrompu" : "Les fichiers doivent être réparés";
  } else if (operationBusy) {
    globalMessage = operation?.message || "Mise à jour en cours…";
  } else if (update.state === "available") {
    globalMessage = `Mise à jour ${update.availableVersion} disponible`;
  } else if (application.ready) {
    global.classList.add("good");
    globalMessage = "La Régie est prête";
  }
  $("#globalStatusText").textContent = globalMessage;

  const repairAvailable = !integrity.ok && update.configured && ["available", "current"].includes(update.state);
  const updateAvailable = update.state === "available";
  const installButton = $("#installUpdate");
  installButton.hidden = !(repairAvailable || updateAvailable);
  installButton.disabled = operationBusy;
  if (repairAvailable) {
    $("#installUpdateLabel").textContent = "Réparer l’installation";
    $("#installUpdateDetail").textContent = "Restaurer automatiquement les fichiers endommagés";
  } else if (updateAvailable) {
    $("#installUpdateLabel").textContent = `Installer la version ${update.availableVersion}`;
    $("#installUpdateDetail").textContent = "Vos données et la version précédente seront conservées";
  }

  $("#openApplication").disabled = !configuration.ready || !application.ready || !integrity.ok || operationBusy;
  $("#checkUpdate").disabled = operationBusy || update.state === "checking";
  $("#verifyIntegrity").disabled = operationBusy;
  $("#openConfiguration").disabled = operationBusy;
  $("#launcherMain").setAttribute("aria-busy", String(operationBusy));

  if (operation?.message && operationBusy) $("#operationMessage").textContent = operation.message;
  if (status.lastUpdate?.state === "installed" && status.lastUpdate.version === status.release.version) {
    $("#operationMessage").textContent = `Version ${status.lastUpdate.version} installée et vérifiée. La version précédente a été conservée.`;
  } else if (status.lastUpdate?.state === "error") {
    $("#operationMessage").textContent = status.lastUpdate.message;
  }

  if (!configuration.ready && !configurationPresented) openConfiguration({ force: true });

  if (restartExpectedVersion && status.release.version === restartExpectedVersion && status.lastUpdate?.state === "installed" && application.ready) {
    showTransition({
      kicker: "Mise à jour terminée",
      title: `Version ${restartExpectedVersion} prête`,
      detail: "La nouvelle version a été contrôlée. Ouverture de la Régie dans cette fenêtre."
    });
    if (!restartCompleted) {
      restartCompleted = true;
      sessionStorage.removeItem(restartSessionKey);
      setTimeout(() => transitionToApplication(application.url), 450);
    }
  } else if (restartExpectedVersion && status.lastUpdate?.state === "error") {
    restartExpectedVersion = "";
    sessionStorage.removeItem(restartSessionKey);
    hideTransition();
  }
}

async function request(path, { operation = "", body = undefined } = {}) {
  if (operation) $("#operationMessage").textContent = operation;
  const headers = { "X-Xar-Launcher-Token": token };
  if (body !== undefined) headers["Content-Type"] = "application/json";
  const response = await fetch(path, {
    method: "POST",
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const payload = await response.json();
  if (!response.ok || !payload.ok) {
    const error = new Error(payload.error || "Commande impossible.");
    error.status = payload.status;
    error.issues = payload.issues || payload.status?.configuration?.issues || [];
    throw error;
  }
  if (payload.release) render(payload);
  return payload;
}

async function refresh() {
  try {
    const response = await fetch("/api/status", { cache: "no-store" });
    if (!response.ok) throw new Error(`statut ${response.status}`);
    render(await response.json());
  } catch (error) {
    if (restartExpectedVersion || latestStatus?.operation?.state === "restarting") {
      showTransition({
        title: "Installation de la mise à jour",
        detail: "L’application redémarre. Cette fenêtre se reconnectera automatiquement."
      });
    } else {
      $("#operationMessage").textContent = `Le launcher ne répond plus : ${error.message}`;
    }
  }
}

$("#discordEnabled").addEventListener("change", (event) => {
  $("#discordFields").hidden = !event.currentTarget.checked;
});
$("#ovhEnabled").addEventListener("change", (event) => {
  $("#ovhFields").hidden = !event.currentTarget.checked;
});
$("#openConfiguration").addEventListener("click", () => openConfiguration());
$("#closeConfiguration").addEventListener("click", closeConfiguration);
$("#configurationOverlay").addEventListener("click", (event) => {
  if (event.target === event.currentTarget) closeConfiguration();
});
addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !$("#configurationOverlay").hidden) closeConfiguration();
});

$("#generatePlayerCode").addEventListener("click", async () => {
  try {
    const payload = await request("/api/configuration/generate-code");
    $("#playerAccessCode").value = payload.playerAccessCode;
    $("#playerAccessCode").focus();
  } catch (error) {
    renderConfigurationIssues([{ message: error.message }]);
  }
});

$("#configurationForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const saveButton = $("#saveConfiguration");
  saveButton.disabled = true;
  renderConfigurationIssues([]);
  const body = {
    playerAccessCode: $("#playerAccessCode").value,
    discord: {
      images: { enabled: $("#discordEnabled").checked, value: $("#discordImages").value },
      dice: { enabled: $("#discordEnabled").checked, value: $("#discordDice").value },
      journal: { enabled: $("#discordEnabled").checked, value: $("#discordJournal").value }
    },
    ovh: {
      enabled: $("#ovhEnabled").checked,
      url: $("#ovhUrl").value,
      user: $("#ovhUser").value,
      password: $("#ovhPassword").value,
      publicBaseUrl: $("#ovhPublicBaseUrl").value
    }
  };
  try {
    const payload = await request("/api/configuration", {
      operation: "Enregistrement de la configuration et démarrage de la Régie…",
      body
    });
    $("#configurationOverlay").hidden = true;
    document.body.classList.remove("dialog-open");
    $("#operationMessage").textContent = "Configuration enregistrée. La Régie est prête.";
    transitionToApplication(payload.application.url);
  } catch (error) {
    if (error.status) render(error.status);
    renderConfigurationIssues(error.issues?.length ? error.issues : [{ message: error.message }]);
  } finally {
    saveButton.disabled = false;
  }
});

$("#openApplication").addEventListener("click", async () => {
  try {
    const payload = await request("/api/open", { operation: "Ouverture de la Régie…" });
    transitionToApplication(payload.application.url);
  } catch (error) {
    $("#operationMessage").textContent = error.message;
  }
});

$("#checkUpdate").addEventListener("click", async () => {
  try {
    await request("/api/check-update", { operation: "Recherche de la dernière version…" });
    $("#operationMessage").textContent = "Vérification des mises à jour terminée.";
  } catch (error) {
    $("#operationMessage").textContent = error.message;
  }
});

$("#verifyIntegrity").addEventListener("click", async () => {
  try {
    const payload = await request("/api/verify-integrity", { operation: "Vérification des fichiers applicatifs…" });
    $("#operationMessage").textContent = payload.integrity.ok
      ? "Tous les fichiers applicatifs sont intacts."
      : payload.update.configured
        ? "Certains fichiers doivent être restaurés. Utilisez « Réparer l’installation »."
        : "Certains fichiers doivent être restaurés, mais le service de mise à jour n’est pas disponible.";
  } catch (error) {
    $("#operationMessage").textContent = error.message;
  }
});

$("#installUpdate").addEventListener("click", async () => {
  const expectedVersion = latestStatus?.update?.availableVersion || latestStatus?.release?.version || initialVersion;
  restartExpectedVersion = expectedVersion;
  sessionStorage.setItem(restartSessionKey, expectedVersion);
  try {
    await request("/api/install-update", { operation: "Téléchargement et vérification de la mise à jour…" });
    showTransition({
      title: "Installation de la mise à jour",
      detail: "La nouvelle version est installée puis contrôlée. La Régie reviendra automatiquement dans cette fenêtre."
    });
  } catch (error) {
    restartExpectedVersion = "";
    sessionStorage.removeItem(restartSessionKey);
    hideTransition();
    $("#operationMessage").textContent = error.message;
  }
});

initializeCinematicEffects();
initializeBrandForge();
if (restartExpectedVersion) {
  showTransition({
    title: "Redémarrage de l’application",
    detail: "La mise à jour est en cours. Cette fenêtre se reconnectera automatiquement."
  });
}
refresh();
setInterval(refresh, 1_500);
