# Régie du Seuil 1.10.1 — Candidate

## Correctif d’installation Windows

- Le mini-installateur arrête désormais l’ancienne Régie avant de remplacer son dossier applicatif. Une 1.10.1 répond par une commande locale protégée par l’origine et le jeton CSRF du launcher.
- La transition depuis la 1.10.0 dispose d’un secours Windows ciblé : seuls `launcher.mjs` et `server.mjs` exécutés depuis `%LOCALAPPDATA%\Programs\XarTsarothRegie` peuvent être arrêtés. Aucun autre programme Node et aucun updater en cours ne sont concernés.
- Les renommages atomiques de l’installateur et de l’auto-updater retentent les verrous transitoires de Windows avant d’afficher un diagnostic clair.
- Le répertoire de données `%LOCALAPPDATA%\XarTsarothRegie` n’est ni renommé, ni supprimé, ni inclus dans le paquet. Fiches, scènes, médias et configuration restent donc inchangés.

## Continuité fonctionnelle

- Le launcher MMO, les fenêtres Edge/Chrome dédiées, l’ouverture de ChatGPT dans le navigateur habituel et le canal de mise à jour signé sont conservés.
- Le build complet passe 58 tests automatisés avant emballage ; le ZIP livré doit encore être extrait et retesté dans un dossier neuf.

## Statut

Cette version reste **candidate** jusqu’à validation explicite de l’utilisateur. La 1.8.0 reste la dernière version stable et sa référence de sécurité demeure intacte.
