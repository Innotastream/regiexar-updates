import path from "node:path";
import { fileURLToPath } from "node:url";
import { applyPendingUpdate } from "./updater-core.mjs";

const installationRoot = path.dirname(fileURLToPath(import.meta.url));
const pendingPath = process.argv[2] ? path.resolve(process.argv[2]) : "";
const parentPid = Number(process.argv[3] || 0);

if (!pendingPath) {
  console.error("Instruction de mise à jour absente.");
  process.exitCode = 1;
} else {
  applyPendingUpdate({
    pendingPath,
    installationRoot,
    parentPid,
    relaunch: process.env.XAR_DESKTOP_HOST !== "1"
  })
    .catch((error) => {
      console.error(`Mise à jour impossible : ${error.message}`);
      process.exitCode = 1;
    });
}
