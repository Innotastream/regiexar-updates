import {
  existsSync,
  mkdirSync,
  readFileSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync
} from "node:fs";
import { spawn } from "node:child_process";
import path from "node:path";
import {
  extractZipArchive,
  loadApplicationRelease,
  locateExtractedApplicationRoot,
  sha256File,
  validateExtractedUpdate,
  verifyInstallation,
  verifySignedUpdateManifest
} from "./launcher-core.mjs";
import { renameWithRetry } from "./installer-core.mjs";

export const PENDING_UPDATE_SCHEMA_VERSION = 1;
export const UPDATE_STATUS_FILENAME = "update-status.json";

function safeStatusPayload(status) {
  return {
    schemaVersion: 1,
    state: String(status.state || "unknown"),
    version: status.version ? String(status.version) : null,
    message: String(status.message || ""),
    backupName: status.backupName ? String(status.backupName) : null,
    updatedAt: new Date().toISOString()
  };
}

export function writeUpdateStatus(statusPath, status) {
  const destination = path.resolve(statusPath);
  mkdirSync(path.dirname(destination), { recursive: true, mode: 0o700 });
  const temporary = `${destination}.${process.pid}.partial`;
  writeFileSync(temporary, `${JSON.stringify(safeStatusPayload(status), null, 2)}\n`, { mode: 0o600 });
  rmSync(destination, { force: true });
  renameSync(temporary, destination);
}

export function readUpdateStatus(statusPath) {
  try {
    const parsed = JSON.parse(readFileSync(path.resolve(statusPath), "utf8"));
    return safeStatusPayload(parsed);
  } catch {
    return null;
  }
}

function processStillRunning(pid) {
  if (!Number.isSafeInteger(pid) || pid < 1) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === "EPERM";
  }
}

export async function waitForProcessExit(pid, { timeoutMs = 45_000, intervalMs = 125 } = {}) {
  const startedAt = Date.now();
  while (processStillRunning(pid)) {
    if (Date.now() - startedAt > timeoutMs) throw new Error("L’ancienne version ne s’est pas arrêtée à temps.");
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
}

function assertSafeInstallationRoot(rootDirectory) {
  const root = path.resolve(rootDirectory);
  const parent = path.dirname(root);
  if (root === parent || !path.basename(root) || !existsSync(path.join(root, "application.json"))) {
    throw new Error("Dossier d’installation refusé.");
  }
  return root;
}

function verifyDownloadedPackage(packagePath, packageInfo) {
  const archive = path.resolve(packagePath);
  if (!existsSync(archive) || !statSync(archive).isFile()) throw new Error("Paquet de mise à jour introuvable.");
  if (statSync(archive).size !== Number(packageInfo.size)) throw new Error("La taille du paquet téléchargé a changé.");
  if (sha256File(archive) !== String(packageInfo.sha256).toLowerCase()) throw new Error("L’empreinte du paquet téléchargé a changé.");
  return archive;
}

function uniqueSiblingPath(parent, basename, suffix) {
  return path.join(parent, `.${basename}.${suffix}-${Date.now()}-${process.pid}`);
}

function relaunchApplication(installationRoot) {
  const launcherPath = path.join(installationRoot, "launcher.mjs");
  if (!existsSync(launcherPath)) throw new Error("Le nouveau launcher est absent après installation.");
  const child = spawn(process.execPath, [launcherPath], {
    cwd: installationRoot,
    env: { ...process.env, XAR_UPDATE_JUST_INSTALLED: "1" },
    detached: true,
    stdio: "ignore",
    windowsHide: true
  });
  child.unref();
}

export async function applyPendingUpdate({
  pendingPath,
  installationRoot,
  parentPid = null,
  relaunch = true
}) {
  const root = assertSafeInstallationRoot(installationRoot);
  const pendingFile = path.resolve(pendingPath);
  const statusPath = path.join(path.dirname(pendingFile), UPDATE_STATUS_FILENAME);
  const pending = JSON.parse(readFileSync(pendingFile, "utf8"));
  if (Number(pending.schemaVersion) !== PENDING_UPDATE_SCHEMA_VERSION) throw new Error("Instruction de mise à jour inconnue.");

  const currentRelease = loadApplicationRelease(root);
  const signedManifest = verifySignedUpdateManifest(pending.manifest, {
    applicationId: currentRelease.applicationId,
    publicKey: currentRelease.updatePublicKey,
    channel: currentRelease.channel
  });
  const packagePath = verifyDownloadedPackage(pending.packagePath, signedManifest.package);
  const parent = path.dirname(root);
  const basename = path.basename(root);
  const staging = uniqueSiblingPath(parent, basename, "update-stage");
  const backup = uniqueSiblingPath(parent, basename, `backup-v${currentRelease.version}`);
  let activeMoved = false;
  let replacementInstalled = false;

  try {
    writeUpdateStatus(statusPath, {
      state: "extracting",
      version: signedManifest.version,
      message: "Extraction et contrôle de la mise à jour signée…"
    });
    await extractZipArchive(packagePath, staging);
    const extractedRoot = locateExtractedApplicationRoot(staging);
    validateExtractedUpdate(extractedRoot, signedManifest, currentRelease, { allowSameVersion: Boolean(pending.allowSameVersion) });

    if (parentPid) await waitForProcessExit(Number(parentPid));
    writeUpdateStatus(statusPath, {
      state: "installing",
      version: signedManifest.version,
      message: "Installation atomique et création du point de retour…"
    });
    renameWithRetry(root, backup);
    activeMoved = true;
    renameWithRetry(extractedRoot, root);
    replacementInstalled = true;
    rmSync(staging, { recursive: true, force: true });

    const installedRelease = loadApplicationRelease(root);
    const installedIntegrity = verifyInstallation(root);
    if (installedRelease.version !== signedManifest.version || !installedIntegrity.ok) {
      throw new Error("Le contrôle final de la nouvelle installation a échoué.");
    }

    writeUpdateStatus(statusPath, {
      state: "installed",
      version: installedRelease.version,
      message: `Mise à jour ${installedRelease.version} installée et contrôlée.`,
      backupName: path.basename(backup)
    });
    rmSync(pendingFile, { force: true });
    if (relaunch) relaunchApplication(root);
    return { version: installedRelease.version, backupPath: backup, statusPath };
  } catch (error) {
    try {
      if (replacementInstalled && existsSync(root)) rmSync(root, { recursive: true, force: true });
      if (activeMoved && existsSync(backup) && !existsSync(root)) renameWithRetry(backup, root);
    } catch (rollbackError) {
      error.message = `${error.message} Retour à l’ancienne version impossible : ${rollbackError.message}`;
    }
    rmSync(staging, { recursive: true, force: true });
    writeUpdateStatus(statusPath, {
      state: "error",
      version: signedManifest.version,
      message: `Mise à jour annulée : ${error.message}`
    });
    if (relaunch && existsSync(path.join(root, "launcher.mjs"))) {
      try { relaunchApplication(root); } catch {}
    }
    throw error;
  }
}
