# Régie du Seuil 1.11.0 — Candidate

## Application Windows

- Un véritable installeur Windows place la Régie comme un programme classique, avec raccourcis du Bureau et du menu Démarrer.
- Electron, Chromium et le moteur Node nécessaire sont embarqués : l’utilisateur n’installe plus Node.js et la Régie ne dépend plus du mode application d’Edge ou Chrome.
- Le launcher et la table utilisent la même fenêtre. **Ouvrir la Régie** produit une transition interne au lieu d’ouvrir un autre onglet ou une autre fenêtre.
- ChatGPT reste volontairement ouvert dans le navigateur habituel afin de conserver la connexion Google et l’extension Xar.

## Premier démarrage guidé

- En l’absence de configuration valide, le serveur de jeu attend pendant que le launcher affiche un assistant graphique.
- Le code d’accès joueurs peut être généré automatiquement et est ajouté aux liens par la Régie sans nouvelle saisie manuelle.
- Discord et OVH sont clairement facultatifs. Les adresses sont validées avant enregistrement et les cibles OVH dangereuses restent refusées.
- Les mots de passe et webhooks restent dans le profil privé, ne sont jamais réaffichés et ne sont jamais intégrés aux builds.

## Launcher retravaillé

- Tous les sons, ambiances audio et contrôles SFX ont été retirés.
- Les libellés techniques ou cryptiques ont été remplacés par des états et actions directs.
- Le panneau sans fonction « Architecture du portail » devient une liste des nouveautés de la version.
- Le titre officiel Xar Tsaroth est repris et forgé visuellement avec particules, filaments, frappe verticale et double onde. La version reste indiquée discrètement en bas.

## Mise à jour et conservation

- L’enveloppe Windows reste installée tandis que les ZIP applicatifs complets, signés et versionnés remplacent uniquement le contenu actif.
- Après une mise à jour, l’enveloppe redémarre le nouveau processus, attend son contrôle puis recharge la version viable dans la fenêtre existante.
- Les fiches, scènes, médias et réglages privés restent sous `%LOCALAPPDATA%\XarTsarothRegie`, hors du programme et hors du canal de mise à jour.
- Une désinstallation ne demande pas l’effacement de ce profil ; les versions futures peuvent migrer les fiches avec une sauvegarde préalable.

## Statut

Cette version reste **candidate** jusqu’à validation visuelle et fonctionnelle explicite de l’utilisateur. La 1.8.0 reste la dernière version stable et sa référence de sécurité demeure intacte.

