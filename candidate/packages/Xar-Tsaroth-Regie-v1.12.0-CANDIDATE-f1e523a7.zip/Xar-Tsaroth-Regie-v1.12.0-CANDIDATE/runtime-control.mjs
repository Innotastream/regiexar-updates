import { spawnSync } from "node:child_process";
import path from "node:path";

const DEFAULT_LAUNCHER_PORT = 4169;

function launcherOrigin(environment = process.env) {
  const port = Number(environment.XAR_LAUNCHER_PORT || DEFAULT_LAUNCHER_PORT);
  return `http://127.0.0.1:${Number.isSafeInteger(port) && port > 0 ? port : DEFAULT_LAUNCHER_PORT}`;
}

function timeoutSignal(timeoutMs) {
  return typeof AbortSignal?.timeout === "function" ? AbortSignal.timeout(timeoutMs) : undefined;
}

export function extractLauncherToken(html) {
  const match = String(html || "").match(/\bdata-launcher-token\s*=\s*["']([a-f0-9]{64})["']/i);
  return match ? match[1].toLowerCase() : null;
}

export async function requestLauncherShutdown({
  origin = launcherOrigin(),
  fetchImpl = globalThis.fetch,
  timeoutMs = 1_500
} = {}) {
  if (typeof fetchImpl !== "function") return false;
  try {
    const page = await fetchImpl(`${origin}/`, {
      redirect: "error",
      signal: timeoutSignal(timeoutMs)
    });
    if (!page.ok) return false;
    const token = extractLauncherToken(await page.text());
    if (!token) return false;
    const response = await fetchImpl(`${origin}/api/shutdown`, {
      method: "POST",
      redirect: "error",
      headers: {
        Origin: origin,
        "X-Xar-Launcher-Token": token
      },
      signal: timeoutSignal(timeoutMs)
    });
    return response.ok;
  } catch {
    return false;
  }
}

export async function waitForLauncherStop({
  origin = launcherOrigin(),
  fetchImpl = globalThis.fetch,
  timeoutMs = 4_000,
  intervalMs = 100
} = {}) {
  if (typeof fetchImpl !== "function") return true;
  const startedAt = Date.now();
  while (Date.now() - startedAt < timeoutMs) {
    try {
      await fetchImpl(`${origin}/api/status`, {
        redirect: "error",
        signal: timeoutSignal(Math.min(500, intervalMs * 4))
      });
    } catch {
      return true;
    }
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
  }
  return false;
}

function powershellLiteral(value) {
  return `'${String(value).replaceAll("'", "''")}'`;
}

export function windowsRuntimeStopScript(installationRoot) {
  const target = path.win32.resolve(installationRoot).replace(/[\\/]+$/, "").toLowerCase();
  return [
    "$ErrorActionPreference = 'Stop'",
    `$target = ${powershellLiteral(target)}`,
    "$launcher = $target + '\\launcher.mjs'",
    "$server = $target + '\\server.mjs'",
    "Get-CimInstance Win32_Process -Filter \"Name = 'node.exe'\" | ForEach-Object {",
    "  $command = [string]$_.CommandLine",
    "  if (-not [string]::IsNullOrWhiteSpace($command)) {",
    "    $normalized = $command.Replace('/', '\\').ToLowerInvariant()",
    "    $runtimePattern = '(?:^|[\\s\"''])(?:' + [regex]::Escape($launcher) + '|' + [regex]::Escape($server) + ')(?:$|[\\s\"''])'",
    "    if ($normalized -match $runtimePattern) {",
    "      Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop",
    "      Write-Output ('XAR_STOPPED:' + $_.ProcessId)",
    "    }",
    "  }",
    "}"
  ].join("\r\n");
}

export function parseStoppedProcessIds(output) {
  return [...String(output || "").matchAll(/(?:^|\r?\n)XAR_STOPPED:(\d+)(?=\r?\n|$)/g)]
    .map((match) => Number(match[1]))
    .filter((pid) => Number.isSafeInteger(pid) && pid > 0);
}

export function stopLegacyWindowsRuntime({
  installationRoot,
  platform = process.platform,
  spawnSyncImpl = spawnSync
} = {}) {
  if (platform !== "win32" || !installationRoot) return [];
  const encodedCommand = Buffer.from(windowsRuntimeStopScript(installationRoot), "utf16le").toString("base64");
  const args = ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encodedCommand];
  let result = spawnSyncImpl("powershell.exe", args, {
    encoding: "utf8",
    timeout: 12_000,
    windowsHide: true
  });
  if (result?.error?.code === "ENOENT") {
    result = spawnSyncImpl("pwsh.exe", args, {
      encoding: "utf8",
      timeout: 12_000,
      windowsHide: true
    });
  }
  return parseStoppedProcessIds(result?.stdout);
}

export async function stopInstalledRuntime({
  installationRoot,
  platform = process.platform,
  origin = launcherOrigin(),
  fetchImpl = globalThis.fetch,
  spawnSyncImpl = spawnSync
} = {}) {
  const graceful = await requestLauncherShutdown({ origin, fetchImpl });
  if (graceful) await waitForLauncherStop({ origin, fetchImpl });
  const stoppedProcessIds = stopLegacyWindowsRuntime({ installationRoot, platform, spawnSyncImpl });
  if (stoppedProcessIds.length) await new Promise((resolve) => setTimeout(resolve, 250));
  return { graceful, stoppedProcessIds };
}
