# Régie du Seuil 1.12.0 — Candidate

## Nouveau socle Windows

- L’entrée utilisateur est désormais `Xar-Tsaroth-Regie-Setup-1.12.0.exe`, puis le raccourci **Xar Tsaroth - Régie du Seuil** créé par Windows.
- Aucun lanceur `.bat` n’est livré pour Windows. L’application installée possède son propre exécutable, une fenêtre dédiée sans barre d’adresse et une icône Xar Tsaroth multirésolution entièrement redessinée.
- Chromium et le moteur Node nécessaires sont embarqués. La version installée ne dépend ni d’Edge, ni de Chrome, ni d’une installation séparée de Node.js.

## Mises à jour sans validation manuelle

- Toute version viable plus récente publiée sur le canal de l’application est immédiatement installable, même lors d’un saut de plusieurs versions.
- La qualification **stable** reste une décision de livraison distincte ; elle ne bloque jamais l’acceptation technique d’une mise à jour par le launcher.
- Un téléchargement incomplet est retenté trois fois avec contournement du cache. En cas d’échec, la version installée reste intacte et le message affiché indique clairement qu’aucun fichier n’a été remplacé.
- Chaque paquet public reçoit une adresse immuable dérivée de son empreinte. Le manifeste du canal n’est publié qu’après un vrai retéléchargement depuis GitHub, contrôle de taille, SHA-256, extraction et vérification de tous les fichiers.

## Conservation et sécurité

- Les fiches, scènes, médias et réglages restent dans `%LOCALAPPDATA%\XarTsarothRegie`, séparément de l’exécutable et du contenu applicatif remplaçable.
- La configuration graphique continue de gérer le code joueurs, Discord et OVH sans édition manuelle de `.env.local`.
- Les signatures cryptographiques empêchent l’installation d’un paquet falsifié ; elles ne demandent aucune action ni approbation humaine.

## Statut

Cette livraison reste **candidate** jusqu’à validation visuelle et fonctionnelle explicite. La v1.8.0 demeure la dernière version stable de référence et reste intacte.
