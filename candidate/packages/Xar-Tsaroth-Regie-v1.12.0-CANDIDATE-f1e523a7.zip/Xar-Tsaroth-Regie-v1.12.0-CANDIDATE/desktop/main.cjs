const { app, BrowserWindow, Menu, session, shell, utilityProcess } = require("electron");
const { existsSync, mkdirSync, readFileSync } = require("node:fs");
const http = require("node:http");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

const launcherOrigin = "http://127.0.0.1:4169";
const applicationOrigin = "http://127.0.0.1:4173";
const localAppData = process.env.LOCALAPPDATA || process.env.APPDATA || app.getPath("appData");
const privateRoot = path.join(localAppData, "XarTsarothRegie");
const applicationRoot = path.join(privateRoot, "app");
const desktopProfile = path.join(privateRoot, "desktop");
const bundledPayload = path.join(process.resourcesPath, "payload");
const updateInstruction = path.join(privateRoot, "updates", "pending-update.json");
const updateStatus = path.join(privateRoot, "updates", "update-status.json");
let mainWindow = null;
let runtimeProcess = null;
let quitting = false;
let recoveryRunning = false;

mkdirSync(desktopProfile, { recursive: true });
app.setPath("userData", desktopProfile);

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function readJson(filePath) {
  try { return JSON.parse(readFileSync(filePath, "utf8")); }
  catch { return null; }
}

function requestResponds(url, timeoutMs = 700) {
  return new Promise((resolve) => {
    const request = http.get(url, { timeout: timeoutMs }, (response) => {
      response.resume();
      resolve(response.statusCode >= 200 && response.statusCode < 500);
    });
    request.on("timeout", () => request.destroy());
    request.on("error", () => resolve(false));
  });
}

async function waitForLauncher(maximumAttempts = 180) {
  for (let attempt = 0; attempt < maximumAttempts; attempt += 1) {
    if (await requestResponds(`${launcherOrigin}/api/status`)) return true;
    await delay(200);
  }
  return false;
}

async function payloadTools() {
  const launcherCore = await import(pathToFileURL(path.join(bundledPayload, "launcher-core.mjs")).href);
  const installerCore = await import(pathToFileURL(path.join(bundledPayload, "installer-core.mjs")).href);
  return { ...launcherCore, ...installerCore };
}

async function ensureApplicationPayload() {
  if (!existsSync(path.join(bundledPayload, "release-integrity.json"))) {
    throw new Error("Les fichiers intégrés à l’installeur sont incomplets.");
  }
  const tools = await payloadTools();
  const bundledIntegrity = tools.verifyInstallation(bundledPayload);
  if (!bundledIntegrity.ok) throw new Error("Les fichiers intégrés à l’installeur n’ont pas réussi leur contrôle.");
  const bundledRelease = tools.loadApplicationRelease(bundledPayload);

  if (existsSync(path.join(applicationRoot, "application.json"))) {
    const installedRelease = tools.loadApplicationRelease(applicationRoot);
    const installedIntegrity = tools.verifyInstallation(applicationRoot);
    const comparison = tools.compareApplicationVersions(installedRelease.version, bundledRelease.version);
    if (comparison > 0 && installedIntegrity.ok) return installedRelease;
    if (comparison > 0 && !installedIntegrity.ok) {
      throw new Error(`La version ${installedRelease.version}, plus récente que l’installeur, est endommagée. Utilisez la réparation depuis cette version ou un installeur plus récent.`);
    }
    if (comparison === 0 && installedIntegrity.ok) return installedRelease;
  }

  const installed = tools.installApplication({
    sourceRoot: bundledPayload,
    installationRoot: applicationRoot,
    privateRoot
  });
  return installed.release;
}

async function stopOldLocalRuntimes() {
  if (process.platform !== "win32") return;
  const runtimeControl = await import(pathToFileURL(path.join(bundledPayload, "runtime-control.mjs")).href);
  const legacyRoot = path.join(localAppData, "Programs", "XarTsarothRegie");
  for (const installationRoot of [legacyRoot, applicationRoot]) {
    try { await runtimeControl.stopInstalledRuntime({ installationRoot }); }
    catch { /* Un ancien processus absent ou déjà arrêté ne bloque pas le démarrage. */ }
  }
}

function startRuntime() {
  if (quitting || runtimeProcess) return;
  const entry = path.join(applicationRoot, "desktop", "runtime.cjs");
  if (!existsSync(entry)) throw new Error("Le moteur local de la Régie est absent.");
  runtimeProcess = utilityProcess.fork(entry, [], {
    serviceName: "Xar Tsaroth - Régie locale",
    stdio: "inherit",
    env: {
      ...process.env,
      XAR_DESKTOP_HOST: "1",
      XAR_INSTALL_ROOT: applicationRoot,
      XAR_PRIVATE_ROOT: privateRoot,
      XAR_LAUNCHER_PORT: "4169",
      PORT: "4173"
    }
  });
  runtimeProcess.once("exit", () => {
    runtimeProcess = null;
    if (!quitting) recoverRuntime().catch(showFatalError);
  });
}

async function recoverRuntime() {
  if (recoveryRunning || quitting) return;
  recoveryRunning = true;
  try {
    await delay(1_500);
    const tools = await payloadTools();
    for (let attempt = 0; attempt < 180 && !quitting; attempt += 1) {
      const pending = existsSync(updateInstruction);
      const lastStatus = readJson(updateStatus);
      if (pending && lastStatus?.state !== "error") {
        await delay(500);
        continue;
      }
      if (tools.verifyInstallation(applicationRoot).ok) {
        startRuntime();
        if (await waitForLauncher()) return;
      }
      await delay(500);
    }
    throw new Error("La Régie n’a pas réussi à redémarrer après la mise à jour.");
  } finally {
    recoveryRunning = false;
  }
}

function trustedLocalUrl(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === "http:"
      && parsed.hostname === "127.0.0.1"
      && new Set(["4169", "4173"]).has(parsed.port);
  } catch {
    return false;
  }
}

function allowedExternalUrl(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === "https:" && parsed.hostname === "chatgpt.com";
  } catch {
    return false;
  }
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1560,
    height: 980,
    minWidth: 1040,
    minHeight: 690,
    show: false,
    backgroundColor: "#09040f",
    autoHideMenuBar: true,
    title: "Xar Tsaroth - Régie du Seuil",
    icon: path.join(__dirname, "icon.png"),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      spellcheck: false
    }
  });
  Menu.setApplicationMenu(null);
  mainWindow.loadFile(path.join(__dirname, "loading.html"));
  mainWindow.once("ready-to-show", () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (trustedLocalUrl(url) || allowedExternalUrl(url)) shell.openExternal(url);
    return { action: "deny" };
  });
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (trustedLocalUrl(url) || url.startsWith("file:")) return;
    event.preventDefault();
    if (allowedExternalUrl(url)) shell.openExternal(url);
  });
  mainWindow.webContents.on("will-redirect", (event, url) => {
    if (trustedLocalUrl(url)) return;
    event.preventDefault();
  });
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

async function showLoadingMessage(message, isError = false) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const encoded = JSON.stringify({ message, isError });
  await mainWindow.webContents.executeJavaScript(`globalThis.renderDesktopStatus(${encoded})`).catch(() => {});
}

async function showFatalError(error) {
  await showLoadingMessage(`Démarrage impossible : ${error.message}`, true);
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.show();
}

async function boot() {
  createMainWindow();
  await showLoadingMessage("Vérification de l’installation…");
  await stopOldLocalRuntimes();
  const release = await ensureApplicationPayload();
  await showLoadingMessage(`Préparation de la version ${release.version}…`);
  startRuntime();
  if (!await waitForLauncher()) throw new Error("Le launcher local ne répond pas.");
  await mainWindow.loadURL(launcherOrigin);
  mainWindow.show();
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (!mainWindow) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  });
  app.whenReady().then(() => {
    app.setAppUserModelId("fr.xar-tsaroth.regie-du-seuil.desktop");
    const allowedPermissions = new Set(["clipboard-read", "clipboard-sanitized-write"]);
    session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
      callback(trustedLocalUrl(webContents.getURL()) && allowedPermissions.has(permission));
    });
    session.defaultSession.setPermissionCheckHandler((webContents, permission) => {
      return trustedLocalUrl(webContents.getURL()) && allowedPermissions.has(permission);
    });
    boot().catch(showFatalError);
  });
}

app.on("before-quit", () => {
  quitting = true;
  try { runtimeProcess?.kill(); } catch {}
  runtimeProcess = null;
});
app.on("window-all-closed", () => app.quit());
