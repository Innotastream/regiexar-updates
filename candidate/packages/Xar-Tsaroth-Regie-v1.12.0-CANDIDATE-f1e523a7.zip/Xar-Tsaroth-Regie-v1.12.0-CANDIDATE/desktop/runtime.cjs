const path = require("node:path");
const { pathToFileURL } = require("node:url");

const applicationRoot = path.resolve(__dirname, "..");
process.env.ELECTRON_RUN_AS_NODE = "1";
process.env.XAR_DESKTOP_HOST = "1";
process.env.XAR_INSTALL_ROOT = process.env.XAR_INSTALL_ROOT || applicationRoot;
process.env.XAR_LAUNCHER_PORT = process.env.XAR_LAUNCHER_PORT || "4169";
process.env.PORT = process.env.PORT || "4173";

(async () => {
  const { runLauncher } = await import(pathToFileURL(path.join(applicationRoot, "launcher.mjs")).href);
  await runLauncher({ openBrowser: false });
})().catch((error) => {
  console.error(`Régie locale impossible : ${error.message}`);
  process.exitCode = 1;
});

