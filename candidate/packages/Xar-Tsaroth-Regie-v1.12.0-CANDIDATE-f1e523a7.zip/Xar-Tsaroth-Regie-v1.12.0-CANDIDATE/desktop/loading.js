globalThis.renderDesktopStatus = ({ message, isError }) => {
  const status = document.querySelector("#desktopStatus");
  status.textContent = String(message || "Démarrage de l’application…");
  status.classList.toggle("error", Boolean(isError));
};

