import test from "node:test";
import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

async function source(relativePath) {
  return readFile(path.join(ROOT, relativePath), "utf8");
}

async function optionalSource(relativePath) {
  try {
    return await source(relativePath);
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    throw error;
  }
}

test("le launcher sépare clairement les accès MJ et joueur, protège l’administration et reste silencieux", async () => {
  const [html, css, client, launcher, environmentExample] = await Promise.all([
    source("launcher/index.html"),
    source("launcher/launcher.css"),
    source("launcher/launcher.js"),
    source("launcher.mjs"),
    source(".env.example")
  ]);
  assert.match(html, /Entrer comme MJ/);
  assert.match(html, /Entrer comme joueur/);
  assert.match(html, /Vérifier les mises à jour/);
  assert.match(html, /Vérifier les fichiers/);
  assert.match(html, /Notes de mise à jour/);
  assert.match(html, /Console de la Régie/);
  assert.match(html, /Enregistrer les réglages/);
  assert.match(html, /Mot de passe MJ du jour/);
  assert.match(html, /Mot de passe d’administration/);
  assert.match(html, /Code d’accès joueurs/);
  assert.match(html, /Stockage OVH/);
  assert.match(html, /id="ovhEnabled"[^>]*checked/);
  assert.match(html, /Discord/);
  assert.match(html, /Régie du Seuil · version \{\{APP_VERSION\}\} · mises à jour actives/);
  assert.match(html, /<progress[^>]+id="launchProgress"/);
  assert.match(html, /id="arcaneCanvas"/);
  assert.doesNotMatch(html, /Architecture du portail|État du royaume|Ouverture des sceaux|>01<|>02<|>03</i);
  assert.doesNotMatch(html, /class="hero-intro"/);
  assert.doesNotMatch(html, /soundToggle|SFX|ambiance/i);
  assert.doesNotMatch(client, /AudioContext|webkitAudioContext|createOscillator/);
  assert.match(client, /api\/configuration/);
  assert.match(client, /api\/open-mj/);
  assert.match(client, /api\/open-player/);
  assert.match(client, /xarDesktop\?\.navigate/);
  assert.match(client, /transitionToApplication/);
  assert.match(client, /payload\.mjUrl/);
  assert.match(launcher, /mergeConfigurationInput/);
  assert.match(launcher, /serializeEnvironment/);
  assert.match(launcher, /blockedByConfiguration/);
  assert.match(launcher, /readSecretVault/);
  assert.match(launcher, /verifyPassword/);
  assert.match(launcher, /XAR_MJ_SESSION_TOKEN/);
  assert.doesNotMatch(launcher, /openApplicationShell\("application"/);
  assert.match(environmentExample, /assistant graphique/);
  assert.match(environmentExample, /aucun utilisateur ne doit avoir à modifier ce fichier à la main/);
  assert.match(css, /prefers-reduced-motion/);
  assert.match(html, /aria-live="polite"/);
});

test("le titre officiel Xar Tsaroth est forgé visuellement sans moteur audio", async () => {
  const [html, css, client, titleAsset] = await Promise.all([
    source("launcher/index.html"),
    source("launcher/launcher.css"),
    source("launcher/launcher.js"),
    stat(path.join(ROOT, "launcher", "xar-tsaroth-title.png"))
  ]);
  assert.match(html, /xar-tsaroth-title\.png/);
  assert.match(html, /id="brandForgeCanvas"/);
  assert.match(html, /forge-strike/);
  assert.match(html, /wave-one/);
  assert.match(html, /wave-two/);
  assert.match(css, /forged-title-reveal/);
  assert.match(css, /forge-filaments-reveal/);
  assert.match(css, /forge-strike/);
  assert.match(css, /forge-wave/);
  assert.match(client, /compact \? 520 : 980/);
  assert.match(client, /initializeBrandForge/);
  assert.ok(titleAsset.size > 100_000);
});

test("l’application Windows possède une icône multirésolution dédiée", async () => {
  const [ico, desktopIcon, launcherIcon, iconSource] = await Promise.all([
    readFile(path.join(ROOT, "build", "icon.ico")).catch((error) => error?.code === "ENOENT" ? null : Promise.reject(error)),
    stat(path.join(ROOT, "desktop", "icon.png")),
    stat(path.join(ROOT, "launcher", "xar-icon.png")),
    optionalSource("build/app-icon.svg")
  ]);
  assert.ok(desktopIcon.size > 100_000);
  assert.ok(launcherIcon.size > 40_000);
  if (ico !== null && iconSource !== null) {
    assert.deepEqual([...ico.subarray(0, 4)], [0, 0, 1, 0]);
    assert.ok(ico.length > 100_000);
    assert.match(iconSource, /Xar Tsaroth — Régie du Seuil/);
    assert.match(iconSource, /id="gold"/);
  }
});

test("l’installeur Windows fournit une seule fenêtre sécurisée, un coffre système et un moteur autonome", async () => {
  const [desktopMain, desktopPreload, desktopRuntime, loading, packageJson, workflow, updater, launcher, installer, installerCore, runtimeControl, windowsStart, unixStart, application] = await Promise.all([
    source("desktop/main.cjs"),
    source("desktop/preload.cjs"),
    source("desktop/runtime.cjs"),
    source("desktop/loading.html"),
    source("package.json").then(JSON.parse),
    optionalSource(".github/workflows/build-windows-installer.yml"),
    source("updater.mjs"),
    source("launcher.mjs"),
    source("installer.mjs"),
    source("installer-core.mjs"),
    source("runtime-control.mjs"),
    optionalSource("start-windows.bat"),
    source("start.sh"),
    source("application.json").then(JSON.parse)
  ]);
  assert.match(desktopMain, /new BrowserWindow/);
  assert.match(desktopMain, /requestSingleInstanceLock/);
  assert.match(desktopMain, /utilityProcess\.fork/);
  assert.match(desktopMain, /contextIsolation: true/);
  assert.match(desktopMain, /nodeIntegration: false/);
  assert.match(desktopMain, /sandbox: true/);
  assert.match(desktopMain, /safeStorage\.encryptString/);
  assert.match(desktopMain, /XAR_SECRET_VAULT_KEY/);
  assert.match(desktopMain, /xar:player-sheets:save/);
  assert.match(desktopPreload, /contextBridge\.exposeInMainWorld/);
  assert.match(desktopMain, /setWindowOpenHandler/);
  assert.match(desktopMain, /XarTsarothRegie/);
  assert.match(desktopMain, /applicationRoot = path\.join\(privateRoot, "app"\)/);
  assert.match(desktopRuntime, /ELECTRON_RUN_AS_NODE/);
  assert.match(desktopRuntime, /runLauncher\(\{ openBrowser: false \}\)/);
  assert.match(loading, /Xar Tsaroth/);
  assert.match(updater, /XAR_DESKTOP_HOST !== "1"/);
  assert.match(launcher, /verifyInstallation/);
  assert.match(launcher, /fetchSignedUpdateManifest/);
  assert.match(launcher, /launchUpdaterAndExit/);
  assert.match(launcher, /\/api\/shutdown/);
  assert.match(installer, /stopInstalledRuntime/);
  assert.match(installerCore, /renameWithRetry/);
  assert.match(runtimeControl, /Get-CimInstance Win32_Process/);
  assert.equal(windowsStart, null);
  assert.match(unixStart, /node installer\.mjs/);
  assert.equal(packageJson.main, "desktop/main.cjs");
  assert.equal(packageJson.devDependencies.electron, "43.2.0");
  assert.equal(packageJson.devDependencies["electron-builder"], "26.15.7");
  assert.equal(packageJson.build.nsis.oneClick, false);
  assert.equal(packageJson.build.nsis.deleteAppDataOnUninstall, false);
  assert.equal(packageJson.build.win.executableName, "Xar Tsaroth - Regie du Seuil");
  assert.match(packageJson.build.win.artifactName, /Xar-Tsaroth-Regie-Setup/);
  if (workflow !== null) {
    assert.match(workflow, /windows-latest/);
    assert.match(workflow, /desktop:build:windows/);
    assert.match(workflow, /actions\/upload-artifact@v4/);
  }
  assert.equal(packageJson.version, application.version);
  assert.equal(application.version, "1.13.1");
  assert.match(application.updatePublicKey, /Y1kWBBN0aAByYzoaG6dEnoSSG0cGabibeJfXCYQ81Rw=/);
  assert.equal(application.desktopShellApiVersion, 2);
});

test("la Régie retrouve les mises à jour et le code joueurs sans saisie manuelle", async () => {
  const [appHtml, appClient, server] = await Promise.all([
    source("public/index.html"),
    source("public/app.js"),
    source("server.mjs")
  ]);
  assert.match(appHtml, /id="openUpdateCenter"/);
  assert.match(appClient, /openUpdateCenter/);
  assert.match(appClient, /launcherUrl/);
  assert.match(appClient, /managerPlayerAccessCode/);
  assert.doesNotMatch(appClient, /Code global de la vue joueurs à inclure dans le lien/);
  assert.match(server, /\/api\/system\/player-access-code/);
  assert.match(server, /isMjRequest/);
  assert.match(appClient, /X-Xar-Mj-Session/);
  assert.match(server, /XAR_LAUNCHER_ORIGIN/);
  assert.match(appClient, /api\/system\/open-chatgpt/);
});
