import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import {
  AttemptLimiter,
  createPasswordVerifier,
  localDateKey,
  validDailyPasswordRecord,
  verifyPassword
} from "../access-control.mjs";
import {
  readSecretVault,
  splitSecretEnvironment,
  writeSecretVault
} from "../secret-vault.mjs";
import { normalizePlayerConnectionUrl } from "../player-connection.mjs";

test("les mots de passe utilisent un vérificateur scrypt salé irréversible", async () => {
  const password = "Exemple-solide-2026!";
  const left = await createPasswordVerifier(password);
  const right = await createPasswordVerifier(password);
  assert.match(left, /^scrypt\$32768\$8\$1\$/);
  assert.notEqual(left, right);
  assert.equal(left.includes(password), false);
  assert.equal(await verifyPassword(password, left), true);
  assert.equal(await verifyPassword("Mot-de-passe-incorrect", left), false);
  assert.equal(validDailyPasswordRecord({ date: localDateKey(), verifier: left }), true);
});

test("les tentatives répétées déclenchent un verrou temporaire", () => {
  const limiter = new AttemptLimiter({ maximumAttempts: 2, lockMs: 1000 });
  limiter.recordFailure(100);
  limiter.recordFailure(200);
  assert.throws(() => limiter.assertAvailable(300), /Trop de tentatives/);
  assert.doesNotThrow(() => limiter.assertAvailable(1300));
});

test("le coffre AES-256-GCM ne laisse aucun secret lisible sur disque", async (context) => {
  const directory = await mkdtemp(path.join(tmpdir(), "xar-vault-test-"));
  context.after(() => rm(directory, { recursive: true, force: true }));
  const filePath = path.join(directory, "secrets.vault");
  const key = Buffer.alloc(32, 19);
  const secrets = {
    PLAYER_ACCESS_CODE: "code-joueur-exemple",
    OVH_FTP_PASSWORD: "mot-de-passe-ovh-exemple",
    DISCORD_IMAGE_WEBHOOK_URL: "https://discord.com/api/webhooks/1/exemple"
  };
  writeSecretVault(filePath, secrets, key);
  const bytes = await readFile(filePath, "utf8");
  for (const value of Object.values(secrets)) assert.equal(bytes.includes(value), false);
  assert.deepEqual(readSecretVault(filePath, key), secrets);
  assert.throws(() => readSecretVault(filePath, Buffer.alloc(32, 20)));
  assert.deepEqual(splitSecretEnvironment({ PORT: "4173", ...secrets }), { publicValues: { PORT: "4173" }, secrets });
});

test("un lien joueur doit être personnel et utiliser HTTPS ou le réseau local", () => {
  const local = normalizePlayerConnectionUrl("http://192.168.1.44:4173/player.html?player=a&token=b&code=c#fragment");
  assert.equal(new URL(local).hash, "");
  assert.equal(normalizePlayerConnectionUrl("https://table.example/player.html?player=a&token=b&code=c"), "https://table.example/player.html?player=a&token=b&code=c");
  assert.throws(() => normalizePlayerConnectionUrl("http://table.example/player.html?player=a&token=b&code=c"), /HTTPS/);
  assert.throws(() => normalizePlayerConnectionUrl("https://table.example/player.html?player=a"), /incomplet/);
  assert.throws(() => normalizePlayerConnectionUrl("https://table.example/player.html?player=a&token=b&code=c&mj=interdit"), /non autorisé/);
});
