import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const source = (relativePath) => readFile(path.join(ROOT, relativePath), "utf8");

test("la vue joueur reste centrée sur la carte de combat et ses personnages", async () => {
  const [html, client, styles] = await Promise.all([source("public/player.html"), source("public/player.js"), source("public/styles.css")]);
  assert.match(html, /id="playerBattlefield"/);
  assert.match(html, /id="myCharacterPanel"/);
  assert.match(html, /id="createPlayerCharacter"/);
  assert.match(html, /id="playerPartyList"/);
  assert.match(html, /id="mutePlayerMusic"/);
  assert.match(html, /id="mutePlayerAmbience"/);
  assert.match(html, /id="playerPingLayer"/);
  assert.doesNotMatch(html, /Administration|Configuration OVH|Webhook|Zone secrète MJ/);
  assert.match(client, /PlayerSheetStorage/);
  assert.match(client, /api\/session\/character/);
  assert.match(client, /api\/session\/ping/);
  assert.match(client, /linkedTokens/);
  assert.match(styles, /map-ping-wave/);
  assert.match(styles, /player-party-card/);
});

test("les contrôles serveur couvrent création de fiche, invocation, ping et déplacement", async () => {
  const server = await source("server.mjs");
  assert.match(server, /POST" && url\.pathname === "\/api\/session\/character"/);
  assert.match(server, /POST" && url\.pathname === "\/api\/session\/token\/invoke"/);
  assert.match(server, /L’invocation depuis une fiche est réservée à la session MJ authentifiée/);
  assert.match(server, /isMjRequest\(req, url\)/);
  assert.match(server, /POST" && url\.pathname === "\/api\/session\/ping"/);
  assert.match(server, /token\.controllerPlayerId !== identity\.id/);
  assert.match(server, /character\.ownerPlayerId !== identity\.id/);
});

test("le stockage joueur natif est hors du build, atomique et sans jeton d’accès", async () => {
  const [desktop, preload, localStore] = await Promise.all([source("desktop/main.cjs"), source("desktop/preload.cjs"), source("public/player-sheet-storage.js")]);
  assert.match(desktop, /player-data/);
  assert.match(desktop, /characters\.previous\.json/);
  assert.match(desktop, /renameSync\(temporary, context\.filePath\)/);
  assert.match(desktop, /"accessToken" in character/);
  assert.match(preload, /savePlayerSheet/);
  assert.match(localStore, /indexedDB/);
  assert.match(localStore, /navigator\?\.storage\?\.persist/);
});
