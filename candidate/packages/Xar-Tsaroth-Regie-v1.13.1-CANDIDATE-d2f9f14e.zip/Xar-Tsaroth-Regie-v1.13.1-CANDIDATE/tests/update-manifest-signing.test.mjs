import test from "node:test";
import assert from "node:assert/strict";
import { generateKeyPairSync } from "node:crypto";
import {
  signingKeyMatchesPublicKey,
  signUpdateManifest
} from "../scripts/sign-update-manifest.mjs";

function releaseFor(publicKey) {
  return {
    applicationId: "fr.xar.test",
    channel: "candidate",
    updatePublicKey: publicKey.export({ type: "spki", format: "pem" })
  };
}

function unsignedManifest() {
  return {
    schemaVersion: 1,
    applicationId: "fr.xar.test",
    channel: "candidate",
    version: "1.13.1",
    publishedAt: "2026-08-18T02:00:00.000Z",
    package: {
      url: "https://updates.example.test/Xar-Tsaroth-Regie-v1.13.1.zip",
      sha256: "d".repeat(64),
      size: 123456
    }
  };
}

test("le manifeste de publication est signé puis revérifié avec la clé du build", () => {
  const { publicKey, privateKey } = generateKeyPairSync("ed25519");
  const privatePem = privateKey.export({ type: "pkcs8", format: "pem" });
  assert.equal(signingKeyMatchesPublicKey(privatePem, releaseFor(publicKey).updatePublicKey), true);
  const signed = signUpdateManifest(unsignedManifest(), privatePem, releaseFor(publicKey));
  assert.match(signed.signature, /^[A-Za-z0-9+/]+={0,2}$/);
  assert.equal(signed.version, "1.13.1");
});

test("une mauvaise clé privée ne peut jamais signer le canal", () => {
  const trusted = generateKeyPairSync("ed25519");
  const foreign = generateKeyPairSync("ed25519");
  const foreignPem = foreign.privateKey.export({ type: "pkcs8", format: "pem" });
  assert.equal(signingKeyMatchesPublicKey(foreignPem, releaseFor(trusted.publicKey).updatePublicKey), false);
  assert.throws(
    () => signUpdateManifest(unsignedManifest(), foreignPem, releaseFor(trusted.publicKey)),
    /ne correspond pas/
  );
});
