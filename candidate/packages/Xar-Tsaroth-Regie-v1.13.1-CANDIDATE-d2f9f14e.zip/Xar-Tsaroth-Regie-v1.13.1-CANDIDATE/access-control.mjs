import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

const scrypt = promisify(scryptCallback);
const VERIFIER_PREFIX = "scrypt";
const SCRYPT_PARAMETERS = Object.freeze({ N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
const ADMIN_PASSWORD_VERIFIER = "scrypt$32768$8$1$hD4kzfZlB5IlUTs6Aub7gw$iknrPPuuadJTK2sS0NvYqYk2JCVS_ixUIwE16-w1OXLWdximcTNUWaL_ribTDE9kEACGQvhv26wRyeRVVrwc6w";

function passwordText(value) {
  const text = String(value ?? "");
  if (text.length < 10 || text.length > 256 || /[\0\r\n]/.test(text)) {
    throw new Error("Le mot de passe doit contenir entre 10 et 256 caractères.");
  }
  return text;
}

export function localDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export async function createPasswordVerifier(password, { salt = randomBytes(16) } = {}) {
  const text = passwordText(password);
  const saltBuffer = Buffer.isBuffer(salt) ? salt : Buffer.from(salt);
  const derived = await scrypt(text, saltBuffer, 64, SCRYPT_PARAMETERS);
  return [
    VERIFIER_PREFIX,
    SCRYPT_PARAMETERS.N,
    SCRYPT_PARAMETERS.r,
    SCRYPT_PARAMETERS.p,
    saltBuffer.toString("base64url"),
    Buffer.from(derived).toString("base64url")
  ].join("$");
}

export async function verifyPassword(password, verifier) {
  const parts = String(verifier ?? "").split("$");
  if (parts.length !== 6 || parts[0] !== VERIFIER_PREFIX) return false;
  const [N, r, p] = parts.slice(1, 4).map(Number);
  if (N !== SCRYPT_PARAMETERS.N || r !== SCRYPT_PARAMETERS.r || p !== SCRYPT_PARAMETERS.p) return false;
  let salt;
  let expected;
  try {
    salt = Buffer.from(parts[4], "base64url");
    expected = Buffer.from(parts[5], "base64url");
  } catch {
    return false;
  }
  if (salt.length < 16 || expected.length !== 64) return false;
  let text;
  try { text = passwordText(password); }
  catch { return false; }
  const actual = Buffer.from(await scrypt(text, salt, expected.length, SCRYPT_PARAMETERS));
  return timingSafeEqual(actual, expected);
}

export function adminPasswordVerifier() {
  return ADMIN_PASSWORD_VERIFIER;
}

export function validDailyPasswordRecord(record, date = new Date()) {
  return Boolean(record?.date === localDateKey(date) && typeof record?.verifier === "string" && record.verifier.startsWith(`${VERIFIER_PREFIX}$`));
}

export class AttemptLimiter {
  constructor({ maximumAttempts = 5, windowMs = 15 * 60 * 1000, lockMs = 60 * 1000 } = {}) {
    this.maximumAttempts = maximumAttempts;
    this.windowMs = windowMs;
    this.lockMs = lockMs;
    this.attempts = [];
    this.lockedUntil = 0;
  }

  assertAvailable(now = Date.now()) {
    if (now < this.lockedUntil) {
      const seconds = Math.max(1, Math.ceil((this.lockedUntil - now) / 1000));
      const error = new Error(`Trop de tentatives. Réessayez dans ${seconds} seconde${seconds > 1 ? "s" : ""}.`);
      error.code = "RATE_LIMITED";
      throw error;
    }
  }

  recordFailure(now = Date.now()) {
    this.attempts = this.attempts.filter((timestamp) => now - timestamp <= this.windowMs);
    this.attempts.push(now);
    if (this.attempts.length >= this.maximumAttempts) {
      this.lockedUntil = now + this.lockMs;
      this.attempts = [];
    }
  }

  recordSuccess() {
    this.attempts = [];
    this.lockedUntil = 0;
  }
}
