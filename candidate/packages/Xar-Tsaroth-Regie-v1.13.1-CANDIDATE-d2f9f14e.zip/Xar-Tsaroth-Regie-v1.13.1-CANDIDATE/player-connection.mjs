function privateIpv4(hostname) {
  const parts = hostname.split(".").map(Number);
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  return parts[0] === 10
    || parts[0] === 127
    || (parts[0] === 169 && parts[1] === 254)
    || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31)
    || (parts[0] === 192 && parts[1] === 168);
}

function privateHost(hostname) {
  const host = String(hostname ?? "").toLowerCase();
  return host === "localhost"
    || host === "::1"
    || host.endsWith(".local")
    || privateIpv4(host)
    || /^(?:fc|fd|fe8|fe9|fea|feb)[0-9a-f:]+$/i.test(host);
}

export function normalizePlayerConnectionUrl(value) {
  const raw = String(value ?? "").trim();
  if (!raw || raw.length > 4096) throw new Error("Le lien joueur est absent ou trop long.");
  let parsed;
  try { parsed = new URL(raw); }
  catch { throw new Error("Le lien joueur n’est pas une adresse valide."); }
  if (parsed.username || parsed.password) throw new Error("Le lien joueur ne doit pas contenir d’identifiants dans l’adresse.");
  if (parsed.protocol !== "https:" && !(parsed.protocol === "http:" && privateHost(parsed.hostname))) {
    throw new Error("Le lien joueur doit utiliser HTTPS, ou HTTP sur le réseau local.");
  }
  if (!parsed.pathname.endsWith("/player.html")) throw new Error("Ce lien n’ouvre pas la vue joueur de la Régie.");
  const allowedParameters = new Set(["player", "token", "code"]);
  for (const name of parsed.searchParams.keys()) {
    if (!allowedParameters.has(name)) throw new Error("Le lien joueur contient un paramètre non autorisé.");
  }
  for (const name of ["player", "token", "code"]) {
    const entry = parsed.searchParams.get(name) || "";
    if (entry.length < 1 || entry.length > 512 || /[\0\r\n]/.test(entry)) throw new Error("Le lien personnel est incomplet.");
  }
  parsed.hash = "";
  return parsed.href;
}
