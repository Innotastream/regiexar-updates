# Canal de mises à jour de l’application

## État de la 1.13.1 candidate

La 1.13.1 poursuit le socle Windows installé avec `Xar-Tsaroth-Regie-Setup-1.13.1.exe`. Elle embarque Chromium et le moteur Node nécessaire, sépare les entrées MJ et Joueur dans la même fenêtre et ne dépend pas d’une installation locale de Node.js, Edge, Chrome ou d’un script `.bat`. L’installeur NSIS crée un véritable exécutable avec l’icône Xar Tsaroth, ainsi que les raccourcis habituels, et ne supprime pas les données utilisateur lors d’une désinstallation.

Le programme, le contenu applicatif actualisable et les données sont séparés. L’enveloppe Windows vit dans son dossier de programme ; le contenu applicatif actif vit sous `%LOCALAPPDATA%\XarTsarothRegie\app` ; les fiches, scènes, médias et la configuration restent sous `%LOCALAPPDATA%\XarTsarothRegie\data` et `%LOCALAPPDATA%\XarTsarothRegie\.env.local`. Une mise à jour remplace uniquement `app`. Les migrations de fiches travaillent sur le stockage persistant et sauvegardent l’ancien format avant conversion.

Si la configuration privée est absente ou invalide, le serveur de jeu ne démarre pas. Le launcher affiche d’abord un assistant local qui génère le code joueurs, valide les webhooks Discord et encadre la cible OVH. Les webhooks, mots de passe et codes déjà enregistrés ne sont jamais renvoyés par l’API de statut ni réaffichés dans l’interface.

L’enveloppe lance le serveur dans un processus utilitaire séparé. Pendant une mise à jour, ce processus s’arrête, un helper indépendant vérifie et remplace atomiquement le contenu applicatif, puis l’enveloppe redémarre la nouvelle version et reconnecte la fenêtre existante. Les renommages retentent les verrous temporaires `EBUSY`, `EPERM`, `EACCES` et `ENOTEMPTY`. En cas d’échec, l’ancien contenu applicatif est remis en place.

Le contrôle du paquet tolère uniquement les fichiers système inoffensifs connus que Windows peut créer lors de l’extraction, comme `desktop.ini`. Toute absence, modification ou injection applicative demeure bloquante et l’installateur affiche maintenant les chemins concernés au lieu d’un refus générique.

Les liens ChatGPT ne naviguent pas dans la fenêtre Electron : une route locale, protégée par l’origine et une liste d’autorisation stricte, demande au système de les ouvrir dans le navigateur habituel afin de conserver la session Google et l’extension Xar existantes. L’interface Electron fonctionne avec `nodeIntegration: false`, `contextIsolation: true` et le bac à sable Chromium actif.

Une clé publique Ed25519 dédiée est intégrée dans `application.json`. Sa clé privée n’est présente ni dans le projet, ni dans Git, ni dans le ZIP. Le canal candidate utilise `https://raw.githubusercontent.com/Innotastream/regiexar-updates/main/candidate/latest.json`. Ce dépôt public contient seulement les ZIP distribuables et leurs manifestes signés ; le code source reste dans `Innotastream/regiexar`, qui demeure privé.

La clé privée historique des versions 1.9.1 à 1.13.0 n’étant plus récupérable, la 1.13.1 réalise une rotation explicite. Les anciennes installations ne peuvent pas authentifier cette nouvelle paire : la 1.13.1 doit être installée manuellement une seule fois. Sa clé privée correspondante est vérifiée par GitHub Actions, conservée comme secret du dépôt source privé et sauvegardée séparément sous forme chiffrée. Aucun repli vers un manifeste non signé n’est autorisé.

Empreinte SHA-256 de la clé publique DER intégrée :

```text
3778f6c07a227603d28bf062b2a4478d30d5d1e19bfbc61da82d38fd34fafb3e
```

## Contrat du manifeste distant

Le fichier JSON publié en HTTPS doit contenir :

```json
{
  "schemaVersion": 1,
  "applicationId": "fr.xar-tsaroth.regie-du-seuil",
  "channel": "candidate",
  "version": "1.13.1",
  "publishedAt": "2026-08-17T12:00:00.000Z",
  "package": {
    "url": "https://raw.githubusercontent.com/Innotastream/regiexar-updates/main/candidate/packages/Xar-Tsaroth-Regie-v1.13.1-CANDIDATE-empreinte.zip",
    "sha256": "empreinte-sha256-du-zip",
    "size": 123456
  },
  "signature": "signature-ed25519-en-base64"
}
```

La signature couvre la représentation canonique produite par `canonicalUpdatePayload()` dans `launcher-core.mjs`. Toute différence d’identité, de canal, de version, d’URL, de taille ou d’empreinte invalide la signature. Il s’agit d’un contrôle automatique de sécurité, pas d’une validation manuelle du build. Dès qu’une version viable plus récente est publiée sur le canal configuré, elle est installable, même si plusieurs numéros de version ont été sautés. Le launcher refuse les redirections, HTTP non chiffré, ZIP64, archives multi-volumes, chemins sortant du staging, doublons de nom, liens symboliques, formats de compression inconnus, fichiers privés et fichiers applicatifs absents ou inattendus.

## Cycle d’installation

1. Le launcher vérifie automatiquement le canal au démarrage.
2. L’utilisateur choisit explicitement **Installer la mise à jour** ou **Réparer l’installation**.
3. Le ZIP est téléchargé dans le profil privé et contrôlé avant extraction. Un transfert incomplet est automatiquement retenté jusqu’à trois fois sans toucher à la version installée.
4. Un helper séparé ferme le processus local, extrait et vérifie la nouvelle application tandis que la fenêtre Windows reste ouverte.
5. L’ancien dossier applicatif est renommé comme point de retour.
6. Le nouveau build prend atomiquement la place du précédent.
7. L’enveloppe Windows redémarre le launcher mis à jour, attend la réponse de la Régie puis réutilise la même fenêtre.
8. Après contrôle, la fenêtre passe automatiquement à la version viable. En cas d’échec, le helper remet l’ancienne version en place et l’enveloppe la relance.

Les données utilisateur ne participent jamais à cet échange. Les migrations de fiches s’exécutent ensuite depuis leur stockage privé et créent leur propre sauvegarde avant conversion.

## Procédure de publication du canal

1. Héberger séparément, en HTTPS, un manifeste par canal et les ZIP applicatifs complets.
2. Garder la clé privée dans un coffre de publication hors dépôt et hors serveur public.
3. Produire le ZIP final, l’extraire et le retester avant publication.
4. Nommer le paquet avec une partie de son empreinte afin que son adresse soit immuable ; ne jamais remplacer silencieusement un fichier déjà annoncé.
5. Calculer la taille et le SHA-256 exacts du ZIP, construire le manifeste puis le signer.
6. Publier d’abord le paquet. Le retélécharger ensuite depuis son adresse GitHub publique et vérifier sa taille, son SHA-256, son extraction et son manifeste interne avec `node scripts/verify-published-update.mjs <adresse-du-manifeste-de-prépublication>`.
7. Publier seulement après ce contrôle le manifeste `latest.json`, puis exécuter à nouveau `node scripts/verify-published-update.mjs` contre le canal définitif. Un paquet distant tronqué ne doit jamais devenir la version annoncée.
8. Toute candidate viable publiée est immédiatement proposée par l’application. La qualification **stable** reste une décision de livraison distincte et ne participe pas au mécanisme d’acceptation du launcher.
9. Tester aussi signature falsifiée, ZIP altéré, coupure réseau, manque d’espace, restauration et conservation des fiches.

Le launcher ne fait jamais `git pull` et n’embarque aucun jeton GitHub. Le dépôt privé conserve le code et l’historique ; `regiexar-updates` distribue uniquement des artefacts signés publiquement accessibles.
