import { createPrivateKey, createPublicKey, sign, timingSafeEqual } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  canonicalUpdatePayload,
  loadApplicationRelease,
  verifySignedUpdateManifest
} from "../launcher-core.mjs";

function publicKeyDer(key) {
  return createPublicKey(key).export({ type: "spki", format: "der" });
}

export function signingKeyMatchesPublicKey(privateKeyPem, publicKeyPem) {
  const privateKey = createPrivateKey(privateKeyPem);
  const derived = publicKeyDer(privateKey);
  const expected = publicKeyDer(publicKeyPem);
  return derived.length === expected.length && timingSafeEqual(derived, expected);
}

export function signUpdateManifest(unsignedManifest, privateKeyPem, release) {
  if (!signingKeyMatchesPublicKey(privateKeyPem, release.updatePublicKey)) {
    throw new Error("La clé privée de publication ne correspond pas à la clé publique du build.");
  }

  const manifest = {
    schemaVersion: unsignedManifest.schemaVersion,
    applicationId: unsignedManifest.applicationId,
    channel: unsignedManifest.channel,
    version: unsignedManifest.version,
    publishedAt: unsignedManifest.publishedAt,
    package: {
      url: unsignedManifest.package?.url,
      sha256: unsignedManifest.package?.sha256,
      size: unsignedManifest.package?.size
    }
  };
  const privateKey = createPrivateKey(privateKeyPem);
  manifest.signature = sign(null, Buffer.from(canonicalUpdatePayload(manifest)), privateKey).toString("base64");

  return verifySignedUpdateManifest(manifest, {
    applicationId: release.applicationId,
    publicKey: release.updatePublicKey,
    channel: release.channel
  });
}

function isCommandLineEntry() {
  return process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
}

if (isCommandLineEntry()) {
  const [unsignedPath, privateKeyPath, outputPath, projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..")] = process.argv.slice(2);
  if (!unsignedPath || !privateKeyPath || !outputPath) {
    throw new Error("Usage : node scripts/sign-update-manifest.mjs <manifeste-non-signe.json> <cle-privee.pem> <latest.json> [dossier-projet]");
  }
  const release = loadApplicationRelease(projectRoot);
  const unsignedManifest = JSON.parse(readFileSync(unsignedPath, "utf8"));
  const privateKeyPem = readFileSync(privateKeyPath, "utf8");
  const signedManifest = signUpdateManifest(unsignedManifest, privateKeyPem, release);
  writeFileSync(outputPath, `${JSON.stringify(signedManifest, null, 2)}\n`, { mode: 0o644 });
  console.log(`Manifeste ${signedManifest.channel} ${signedManifest.version} signé et vérifié.`);
}
