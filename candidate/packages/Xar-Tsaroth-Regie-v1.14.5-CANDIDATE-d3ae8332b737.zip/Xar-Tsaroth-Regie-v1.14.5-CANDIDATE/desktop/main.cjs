const { app, BrowserWindow, Menu, dialog, ipcMain, safeStorage, session, shell, utilityProcess } = require("electron");
const { chmodSync, copyFileSync, existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } = require("node:fs");
const { createHash, randomBytes } = require("node:crypto");
const http = require("node:http");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

const launcherOrigin = "http://127.0.0.1:4169";
const applicationOrigin = "http://127.0.0.1:4173";
const localAppData = process.env.LOCALAPPDATA || process.env.APPDATA || app.getPath("appData");
const privateRoot = path.join(localAppData, "XarTsarothRegie");
const applicationRoot = path.join(privateRoot, "app");
const desktopProfile = path.join(privateRoot, "desktop");
const bundledPayload = path.join(process.resourcesPath, "payload");
const updateInstruction = path.join(privateRoot, "updates", "pending-update.json");
const updateStatus = path.join(privateRoot, "updates", "update-status.json");
const vaultDirectory = path.join(privateRoot, "secrets");
const protectedVaultKeyFile = path.join(vaultDirectory, "desktop-key.bin");
const playerDataRoot = path.join(privateRoot, "player-data");
let mainWindow = null;
let runtimeProcess = null;
let quitting = false;
let recoveryRunning = false;
let maintenanceRunning = false;
let vaultKey = null;
let allowedPlayerOrigin = "";

mkdirSync(desktopProfile, { recursive: true });
mkdirSync(vaultDirectory, { recursive: true });
mkdirSync(playerDataRoot, { recursive: true });
app.setPath("userData", desktopProfile);

function ensureVaultKey() {
  if (!safeStorage.isEncryptionAvailable()) throw new Error("Le coffre sécurisé de Windows n’est pas disponible.");
  if (existsSync(protectedVaultKeyFile)) {
    const decoded = Buffer.from(safeStorage.decryptString(readFileSync(protectedVaultKeyFile)), "base64");
    if (decoded.length !== 32) throw new Error("La clé du coffre local est invalide.");
    vaultKey = decoded;
    return;
  }
  vaultKey = randomBytes(32);
  const temporary = `${protectedVaultKeyFile}.${process.pid}.partial`;
  writeFileSync(temporary, safeStorage.encryptString(vaultKey.toString("base64")), { mode: 0o600 });
  rmSync(protectedVaultKeyFile, { force: true });
  renameSync(temporary, protectedVaultKeyFile);
  try { chmodSync(protectedVaultKeyFile, 0o600); } catch {}
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function readJson(filePath) {
  try { return JSON.parse(readFileSync(filePath, "utf8")); }
  catch { return null; }
}

function requestResponds(url, timeoutMs = 700) {
  return new Promise((resolve) => {
    const request = http.get(url, { timeout: timeoutMs }, (response) => {
      response.resume();
      resolve(response.statusCode >= 200 && response.statusCode < 500);
    });
    request.on("timeout", () => request.destroy());
    request.on("error", () => resolve(false));
  });
}

async function waitForLauncher(maximumAttempts = 180) {
  for (let attempt = 0; attempt < maximumAttempts; attempt += 1) {
    if (await requestResponds(`${launcherOrigin}/api/status`)) return true;
    await delay(200);
  }
  return false;
}

async function payloadTools() {
  const launcherCore = await import(pathToFileURL(path.join(bundledPayload, "launcher-core.mjs")).href);
  const installerCore = await import(pathToFileURL(path.join(bundledPayload, "installer-core.mjs")).href);
  return { ...launcherCore, ...installerCore };
}

async function userDataTools() {
  return import(pathToFileURL(path.join(applicationRoot, "user-data-backup.mjs")).href);
}

function assertLauncherSender(event) {
  const senderUrl = event.senderFrame?.url || event.sender.getURL();
  if (!senderUrl.startsWith(`${launcherOrigin}/`)) throw new Error("Commande réservée au launcher local.");
}

async function stopRuntimeForMaintenance() {
  maintenanceRunning = true;
  const active = runtimeProcess;
  if (!active) return;
  try { active.kill(); } catch {}
  for (let attempt = 0; attempt < 100 && runtimeProcess; attempt += 1) await delay(50);
  if (runtimeProcess) throw new Error("Le moteur local n’a pas pu être arrêté avant la restauration.");
}

async function ensureApplicationPayload() {
  if (!existsSync(path.join(bundledPayload, "release-integrity.json"))) {
    throw new Error("Les fichiers intégrés à l’installeur sont incomplets.");
  }
  const tools = await payloadTools();
  const bundledIntegrity = tools.verifyInstallation(bundledPayload);
  if (!bundledIntegrity.ok) throw new Error("Les fichiers intégrés à l’installeur n’ont pas réussi leur contrôle.");
  const bundledRelease = tools.loadApplicationRelease(bundledPayload);

  if (existsSync(path.join(applicationRoot, "application.json"))) {
    const installedRelease = tools.loadApplicationRelease(applicationRoot);
    const installedIntegrity = tools.verifyInstallation(applicationRoot);
    const comparison = tools.compareApplicationVersions(installedRelease.version, bundledRelease.version);
    if (comparison > 0 && installedIntegrity.ok) return installedRelease;
    if (comparison > 0 && !installedIntegrity.ok) {
      throw new Error(`La version ${installedRelease.version}, plus récente que l’installeur, est endommagée. Utilisez la réparation depuis cette version ou un installeur plus récent.`);
    }
    if (comparison === 0 && installedIntegrity.ok) return installedRelease;
  }

  const installed = tools.installApplication({
    sourceRoot: bundledPayload,
    installationRoot: applicationRoot,
    privateRoot
  });
  return installed.release;
}

async function stopOldLocalRuntimes() {
  if (process.platform !== "win32") return;
  const runtimeControl = await import(pathToFileURL(path.join(bundledPayload, "runtime-control.mjs")).href);
  const legacyRoot = path.join(localAppData, "Programs", "XarTsarothRegie");
  for (const installationRoot of [legacyRoot, applicationRoot]) {
    try { await runtimeControl.stopInstalledRuntime({ installationRoot }); }
    catch { /* Un ancien processus absent ou déjà arrêté ne bloque pas le démarrage. */ }
  }
}

function startRuntime() {
  if (quitting || runtimeProcess) return;
  const entry = path.join(applicationRoot, "desktop", "runtime.cjs");
  if (!existsSync(entry)) throw new Error("Le moteur local de la Régie est absent.");
  runtimeProcess = utilityProcess.fork(entry, [], {
    serviceName: "Xar Tsaroth - Régie locale",
    stdio: "inherit",
    env: {
      ...process.env,
      XAR_DESKTOP_HOST: "1",
      XAR_INSTALL_ROOT: applicationRoot,
      XAR_PRIVATE_ROOT: privateRoot,
      XAR_SECRET_VAULT_KEY: vaultKey.toString("base64"),
      XAR_LAUNCHER_PORT: "4169",
      PORT: "4173"
    }
  });
  runtimeProcess.once("exit", () => {
    runtimeProcess = null;
    if (!quitting && !maintenanceRunning) recoverRuntime().catch(showFatalError);
  });
}

async function recoverRuntime() {
  if (recoveryRunning || quitting) return;
  recoveryRunning = true;
  try {
    await delay(1_500);
    const tools = await payloadTools();
    for (let attempt = 0; attempt < 180 && !quitting; attempt += 1) {
      const pending = existsSync(updateInstruction);
      const lastStatus = readJson(updateStatus);
      if (pending && lastStatus?.state !== "error") {
        await delay(500);
        continue;
      }
      if (tools.verifyInstallation(applicationRoot).ok) {
        startRuntime();
        if (await waitForLauncher()) return;
      }
      await delay(500);
    }
    throw new Error("La Régie n’a pas réussi à redémarrer après la mise à jour.");
  } finally {
    recoveryRunning = false;
  }
}

function trustedLocalUrl(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === "http:"
      && parsed.hostname === "127.0.0.1"
      && new Set(["4169", "4173"]).has(parsed.port);
  } catch {
    return false;
  }
}

function privatePlayerHost(hostname) {
  const host = String(hostname || "").toLowerCase();
  if (host === "localhost" || host === "::1" || host.endsWith(".local")) return true;
  const parts = host.split(".").map(Number);
  return parts.length === 4 && parts.every((part) => Number.isInteger(part) && part >= 0 && part <= 255) && (
    parts[0] === 10 || parts[0] === 127 || (parts[0] === 169 && parts[1] === 254)
    || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) || (parts[0] === 192 && parts[1] === 168)
  );
}

function normalizedPlayerUrl(rawUrl) {
  const parsed = new URL(String(rawUrl || ""));
  if (parsed.username || parsed.password) throw new Error("Adresse joueur refusée.");
  if (parsed.protocol !== "https:" && !(parsed.protocol === "http:" && privatePlayerHost(parsed.hostname))) throw new Error("Connexion joueur non sécurisée.");
  if (parsed.search || parsed.hash) throw new Error("L’adresse joueur ne doit contenir aucun paramètre.");
  if (parsed.pathname === "/" || parsed.pathname === "") parsed.pathname = "/player.html";
  if (!parsed.pathname.endsWith("/player.html")) throw new Error("Adresse joueur refusée.");
  parsed.hash = "";
  return parsed.href;
}

function trustedPlayerUrl(rawUrl) {
  if (!allowedPlayerOrigin) return false;
  try {
    const parsed = new URL(rawUrl);
    return parsed.origin === allowedPlayerOrigin && parsed.pathname.endsWith("/player.html");
  } catch {
    return false;
  }
}

function trustedApplicationUrl(rawUrl) {
  return trustedLocalUrl(rawUrl) || trustedPlayerUrl(rawUrl);
}

function playerStorageContext(event, namespace) {
  const senderUrl = event.senderFrame?.url || event.sender.getURL();
  if (!trustedPlayerUrl(senderUrl)) throw new Error("Stockage joueur refusé.");
  const parsed = new URL(senderUrl);
  const prefix = `${parsed.origin}:`;
  const playerId = namespace.startsWith(prefix) ? namespace.slice(prefix.length) : "";
  if (!/^[a-zA-Z0-9_-]{8,128}$/.test(playerId)) throw new Error("Identité de stockage joueur invalide.");
  const digest = createHash("sha256").update(namespace).digest("hex").slice(0, 40);
  const directory = path.join(playerDataRoot, digest);
  return { playerId, directory, filePath: path.join(directory, "characters.json") };
}

function readPlayerSheetEnvelope(filePath) {
  try {
    const envelope = JSON.parse(readFileSync(filePath, "utf8"));
    return envelope?.schemaVersion === 1 && Array.isArray(envelope.records) ? envelope : { schemaVersion: 1, records: [] };
  } catch {
    return { schemaVersion: 1, records: [] };
  }
}

function writePlayerSheetEnvelope(context, envelope) {
  mkdirSync(context.directory, { recursive: true, mode: 0o700 });
  const temporary = `${context.filePath}.${process.pid}.partial`;
  writeFileSync(temporary, `${JSON.stringify(envelope, null, 2)}\n`, { mode: 0o600 });
  if (existsSync(context.filePath)) copyFileSync(context.filePath, path.join(context.directory, "characters.previous.json"));
  rmSync(context.filePath, { force: true });
  renameSync(temporary, context.filePath);
  try { chmodSync(context.filePath, 0o600); } catch {}
}

function allowedExternalUrl(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === "https:" && parsed.hostname === "chatgpt.com";
  } catch {
    return false;
  }
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1560,
    height: 980,
    minWidth: 1040,
    minHeight: 690,
    show: false,
    backgroundColor: "#09040f",
    autoHideMenuBar: true,
    title: "Xar Tsaroth - Régie du Seuil",
    icon: path.join(__dirname, "icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      spellcheck: false
    }
  });
  Menu.setApplicationMenu(null);
  mainWindow.loadFile(path.join(__dirname, "loading.html"));
  mainWindow.once("ready-to-show", () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (trustedLocalUrl(url) || allowedExternalUrl(url)) shell.openExternal(url);
    return { action: "deny" };
  });
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (trustedApplicationUrl(url) || url.startsWith("file:")) return;
    event.preventDefault();
    if (allowedExternalUrl(url)) shell.openExternal(url);
  });
  mainWindow.webContents.on("will-redirect", (event, url) => {
    if (trustedApplicationUrl(url)) return;
    event.preventDefault();
  });
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

async function showLoadingMessage(message, isError = false) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const encoded = JSON.stringify({ message, isError });
  await mainWindow.webContents.executeJavaScript(`globalThis.renderDesktopStatus(${encoded})`).catch(() => {});
}

async function showFatalError(error) {
  await showLoadingMessage(`Démarrage impossible : ${error.message}`, true);
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.show();
}

async function boot() {
  createMainWindow();
  await showLoadingMessage("Vérification de l’installation…");
  ensureVaultKey();
  await stopOldLocalRuntimes();
  const release = await ensureApplicationPayload();
  await showLoadingMessage(`Préparation de la version ${release.version}…`);
  startRuntime();
  if (!await waitForLauncher()) throw new Error("Le launcher local ne répond pas.");
  await mainWindow.loadURL(launcherOrigin);
  mainWindow.show();
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (!mainWindow) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  });
  app.whenReady().then(() => {
    app.setAppUserModelId("fr.xar-tsaroth.regie-du-seuil.desktop");
    const allowedPermissions = new Set(["clipboard-read", "clipboard-sanitized-write"]);
    session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
      callback(trustedApplicationUrl(webContents.getURL()) && allowedPermissions.has(permission));
    });
    session.defaultSession.setPermissionCheckHandler((webContents, permission) => {
      return trustedApplicationUrl(webContents.getURL()) && allowedPermissions.has(permission);
    });
    boot().catch(showFatalError);
  });
}

app.on("before-quit", () => {
  quitting = true;
  try { runtimeProcess?.kill(); } catch {}
  runtimeProcess = null;
});

ipcMain.handle("xar:navigate", async (event, payload) => {
  if (!mainWindow || mainWindow.isDestroyed()) throw new Error("Fenêtre indisponible.");
  const senderUrl = event.senderFrame?.url || event.sender.getURL();
  if (!senderUrl.startsWith(`${launcherOrigin}/`)) throw new Error("Navigation réservée au launcher.");
  if (payload?.mode === "mj") {
    const target = new URL(String(payload.url || ""));
    if (target.origin !== applicationOrigin) throw new Error("Adresse MJ refusée.");
    allowedPlayerOrigin = "";
    await mainWindow.loadURL(target.href);
    return true;
  }
  if (payload?.mode === "player") {
    const target = normalizedPlayerUrl(payload.url);
    allowedPlayerOrigin = new URL(target).origin;
    await mainWindow.loadURL(target);
    return true;
  }
  throw new Error("Mode d’ouverture inconnu.");
});

ipcMain.handle("xar:user-data:export", async (event) => {
  assertLauncherSender(event);
  const release = readJson(path.join(applicationRoot, "application.json"));
  const selected = await dialog.showSaveDialog(mainWindow, {
    title: "Exporter mes données Xar Tsaroth",
    defaultPath: path.join(app.getPath("documents"), `Xar-Tsaroth-donnees-v${release?.version || "actuelle"}.xarbackup`),
    filters: [{ name: "Sauvegarde Xar Tsaroth", extensions: ["xarbackup"] }]
  });
  if (selected.canceled || !selected.filePath) return { canceled: true };
  const tools = await userDataTools();
  return {
    canceled: false,
    ...tools.createUserDataBackup({
      privateRoot,
      destinationPath: selected.filePath,
      applicationId: release.applicationId,
      applicationVersion: release.version
    })
  };
});

ipcMain.handle("xar:user-data:import", async (event) => {
  assertLauncherSender(event);
  const selected = await dialog.showOpenDialog(mainWindow, {
    title: "Réintégrer une sauvegarde Xar Tsaroth",
    properties: ["openFile"],
    filters: [{ name: "Sauvegarde Xar Tsaroth", extensions: ["xarbackup"] }]
  });
  if (selected.canceled || !selected.filePaths[0]) return { canceled: true };
  const release = readJson(path.join(applicationRoot, "application.json"));
  await stopRuntimeForMaintenance();
  try {
    const tools = await userDataTools();
    const result = tools.importUserDataBackup({ privateRoot, archivePath: selected.filePaths[0], applicationId: release.applicationId });
    return { canceled: false, ...result };
  } finally {
    maintenanceRunning = false;
    startRuntime();
    if (!await waitForLauncher()) throw new Error("Les données ont été restaurées, mais le launcher n’a pas redémarré.");
    await mainWindow.loadURL(launcherOrigin);
  }
});

ipcMain.handle("xar:player-sheets:load", (event, payload) => {
  const context = playerStorageContext(event, String(payload?.namespace || ""));
  return readPlayerSheetEnvelope(context.filePath).records;
});

ipcMain.handle("xar:player-sheets:save", (event, payload) => {
  const context = playerStorageContext(event, String(payload?.namespace || ""));
  const serialized = JSON.stringify(payload?.character ?? null);
  if (Buffer.byteLength(serialized) > 8 * 1024 * 1024) throw new Error("Cette fiche dépasse la taille locale autorisée.");
  const character = JSON.parse(serialized);
  if (!character?.id || character.ownerPlayerId !== context.playerId || "accessToken" in character || "token" in character) throw new Error("Fiche joueur invalide.");
  const envelope = readPlayerSheetEnvelope(context.filePath);
  const record = { key: `${payload.namespace}:${character.id}`, character, pending: Boolean(payload.pending), savedAt: Date.now() };
  envelope.records = [...envelope.records.filter((entry) => entry?.character?.id !== character.id), record];
  envelope.updatedAt = new Date().toISOString();
  writePlayerSheetEnvelope(context, envelope);
  return true;
});
app.on("window-all-closed", () => app.quit());
