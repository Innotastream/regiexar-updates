const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("xarDesktop", Object.freeze({
  navigate: (mode, url) => ipcRenderer.invoke("xar:navigate", { mode, url }),
  exportUserData: () => ipcRenderer.invoke("xar:user-data:export"),
  importUserData: () => ipcRenderer.invoke("xar:user-data:import"),
  loadPlayerSheets: (namespace) => ipcRenderer.invoke("xar:player-sheets:load", { namespace }),
  savePlayerSheet: (namespace, character, pending) => ipcRenderer.invoke("xar:player-sheets:save", { namespace, character, pending })
}));
