# Régie du Seuil 1.14.5 — Accès MJ et stockage OVH

- L’entrée MJ ne demande plus deux fois le mot de passe : la première authentification établit directement le cookie de session sécurisé avant l’ouverture de l’application.
- Le jeton de session n’est plus transmis au JavaScript du launcher ni à la passerelle Electron.
- Les boutons de la Forge expliquent que l’option OVH stocke une copie distante de l’image sans publier sur le site public.
- La configuration OVH est optionnelle et désactivée par défaut lors du premier réglage.
- Aucun compte, mot de passe, vérificateur, donnée utilisateur, coffre, webhook ou secret n’est inclus dans les paquets.
