const token = document.documentElement.dataset.launcherToken;
const initialVersion = document.documentElement.dataset.appVersion;
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const restartSessionKey = "xar-regie-expected-update";
const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)");
const CINEMATIC_SETTLE_MS = 5_000;
const ARCANE_FRAME_INTERVAL_MS = 1_000 / 12;
const FORGE_FRAME_INTERVAL_MS = 1_000 / 30;
const cinematicStartedAt = performance.now();
let latestStatus = null;
let restartExpectedVersion = sessionStorage.getItem(restartSessionKey) || "";
let restartCompleted = false;
let navigatingToApplication = false;
let adminSession = "";
let latestAccounts = [];

function initializeMotionBudget() {
  const root = document.documentElement;
  const synchronize = () => {
    root.classList.toggle("effects-paused", document.hidden);
    if (performance.now() - cinematicStartedAt >= CINEMATIC_SETTLE_MS) root.classList.add("effects-settled");
  };
  document.addEventListener("visibilitychange", synchronize, { passive: true });
  setTimeout(() => root.classList.add("effects-settled"), CINEMATIC_SETTLE_MS);
  synchronize();
}

function initializeCinematicEffects() {
  if (!reducedMotion.matches && matchMedia("(pointer: fine)").matches) {
    let framePending = false;
    let nextX = 0;
    let nextY = 0;
    addEventListener("pointermove", (event) => {
      nextX = ((event.clientX / innerWidth) - .5) * 18;
      nextY = ((event.clientY / innerHeight) - .5) * 14;
      if (framePending) return;
      framePending = true;
      requestAnimationFrame(() => {
        document.documentElement.style.setProperty("--parallax-x", `${nextX.toFixed(2)}px`);
        document.documentElement.style.setProperty("--parallax-y", `${nextY.toFixed(2)}px`);
        framePending = false;
      });
    }, { passive: true });
  }

  if (reducedMotion.matches) return;
  const canvas = $("#arcaneCanvas");
  const context = canvas.getContext("2d");
  if (!context) return;
  const particles = [];
  let width = innerWidth;
  let height = innerHeight;
  let pixelRatio = 1;
  let animationFrame = 0;
  let lastPaintedAt = Number.NEGATIVE_INFINITY;

  function resetParticle(particle, initial = false) {
    particle.x = Math.random() * width;
    particle.y = initial ? Math.random() * height : height + Math.random() * 40;
    particle.radius = .35 + Math.random() * 1.25;
    particle.vx = (Math.random() - .5) * .18;
    particle.vy = -.12 - Math.random() * .48;
    particle.alpha = .16 + Math.random() * .53;
    particle.pulse = Math.random() * Math.PI * 2;
    particle.violet = Math.random() > .72;
  }

  function resize() {
    width = innerWidth;
    height = innerHeight;
    pixelRatio = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.round(width * pixelRatio);
    canvas.height = Math.round(height * pixelRatio);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
  }

  resize();
  for (let index = 0; index < Math.min(76, Math.max(38, Math.round(width / 21))); index += 1) {
    const particle = {};
    resetParticle(particle, true);
    particles.push(particle);
  }
  addEventListener("resize", resize, { passive: true });

  function queuePaint() {
    if (!animationFrame && !document.hidden && !document.documentElement.classList.contains("effects-settled")) {
      animationFrame = requestAnimationFrame(paint);
    }
  }

  function paint(time) {
    animationFrame = 0;
    if (document.hidden || document.documentElement.classList.contains("effects-settled")) return;
    if (time - lastPaintedAt < ARCANE_FRAME_INTERVAL_MS) {
      queuePaint();
      return;
    }
    lastPaintedAt = time;
    context.clearRect(0, 0, width, height);
    context.globalCompositeOperation = "lighter";
    for (const particle of particles) {
      particle.x += particle.vx;
      particle.y += particle.vy;
      particle.pulse += .018;
      if (particle.y < -15 || particle.x < -20 || particle.x > width + 20) resetParticle(particle);
      const flicker = .62 + Math.sin(particle.pulse + time * .001) * .38;
      const color = particle.violet ? "193, 126, 222" : "255, 170, 72";
      context.beginPath();
      context.fillStyle = `rgba(${color}, ${particle.alpha * flicker})`;
      context.shadowColor = `rgba(${color}, .72)`;
      context.shadowBlur = particle.radius * 7;
      context.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
      context.fill();
    }
    context.shadowBlur = 0;
    context.globalCompositeOperation = "source-over";
    queuePaint();
  }
  document.addEventListener("visibilitychange", () => {
    if (document.hidden && animationFrame) {
      cancelAnimationFrame(animationFrame);
      animationFrame = 0;
    } else {
      queuePaint();
    }
  }, { passive: true });
  queuePaint();
}

function initializeBrandForge() {
  const forge = $("#logoForge");
  const canvas = $("#brandForgeCanvas");
  const context = canvas.getContext("2d");
  if (!forge || !context || reducedMotion.matches) {
    forge?.classList.add("settled");
    return;
  }

  const compact = matchMedia("(max-width: 720px)").matches;
  const particleCount = compact ? 520 : 980;
  const particles = [];
  let width = 1;
  let height = 1;
  let pixelRatio = 1;
  let animationFrame = 0;
  let lastPaintedAt = Number.NEGATIVE_INFINITY;

  function resize() {
    const bounds = canvas.getBoundingClientRect();
    width = Math.max(1, bounds.width);
    height = Math.max(1, bounds.height);
    pixelRatio = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.round(width * pixelRatio);
    canvas.height = Math.round(height * pixelRatio);
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
  }

  resize();
  for (let index = 0; index < particleCount; index += 1) {
    const angle = Math.random() * Math.PI * 2;
    const radius = .32 + Math.random() * .62;
    particles.push({
      startX: .5 + Math.cos(angle) * radius,
      startY: .5 + Math.sin(angle) * radius * .72,
      targetX: .1 + Math.random() * .8,
      targetY: .39 + (Math.random() - .5) * .25,
      delay: Math.random() * .9,
      size: .35 + Math.random() * 1.35,
      driftX: (Math.random() - .5) * .24,
      driftY: (Math.random() - .5) * .2,
      violet: Math.random() > .66,
      filament: index % 23 === 0
    });
  }

  const startedAt = performance.now();
  requestAnimationFrame(() => forge.classList.add("forging"));
  addEventListener("resize", resize, { passive: true });

  function queuePaint() {
    if (!animationFrame && !document.hidden && !forge.classList.contains("settled")) {
      animationFrame = requestAnimationFrame(paint);
    }
  }

  function paint(now) {
    animationFrame = 0;
    const elapsed = (now - startedAt) / 1000;
    if (document.hidden) return;
    if (elapsed >= 4.8) {
      context.clearRect(0, 0, width, height);
      forge.classList.add("settled");
      return;
    }
    if (now - lastPaintedAt < FORGE_FRAME_INTERVAL_MS) {
      queuePaint();
      return;
    }
    lastPaintedAt = now;
    context.clearRect(0, 0, width, height);
    context.globalCompositeOperation = "lighter";

    for (const particle of particles) {
      const age = elapsed - particle.delay;
      if (age < 0 || age > 3.7) continue;
      let x;
      let y;
      let alpha;
      if (age < 1.12) {
        const progress = 1 - Math.pow(1 - age / 1.12, 3);
        x = particle.startX + (particle.targetX - particle.startX) * progress;
        y = particle.startY + (particle.targetY - particle.startY) * progress;
        alpha = Math.sin(Math.min(1, age / 1.12) * Math.PI) * .78;
        if (particle.filament && progress > .18) {
          context.beginPath();
          context.moveTo(particle.startX * width, particle.startY * height);
          context.lineTo(x * width, y * height);
          context.strokeStyle = particle.violet ? `rgba(202,136,232,${alpha * .18})` : `rgba(255,202,116,${alpha * .15})`;
          context.lineWidth = .45;
          context.stroke();
        }
      } else {
        const burst = age - 1.12;
        x = particle.targetX + particle.driftX * burst;
        y = particle.targetY + particle.driftY * burst;
        alpha = Math.max(0, .88 - burst / 2.7);
      }
      const color = particle.violet ? "204, 132, 236" : "255, 190, 91";
      context.beginPath();
      context.fillStyle = `rgba(${color},${alpha})`;
      context.shadowColor = `rgba(${color},${Math.min(1, alpha + .18)})`;
      context.shadowBlur = particle.size * 5.5;
      context.arc(x * width, y * height, particle.size, 0, Math.PI * 2);
      context.fill();
    }

    context.shadowBlur = 0;
    context.globalCompositeOperation = "source-over";
    queuePaint();
  }
  document.addEventListener("visibilitychange", () => {
    if (document.hidden && animationFrame) {
      cancelAnimationFrame(animationFrame);
      animationFrame = 0;
      return;
    }
    if ((performance.now() - startedAt) / 1000 >= 4.8) {
      context.clearRect(0, 0, width, height);
      forge.classList.add("settled");
      return;
    }
    queuePaint();
  }, { passive: true });
  queuePaint();
}

function setCard(cardId, tone, titleId, title, detailId, detail) {
  const card = $(cardId);
  card.classList.remove("good", "warning", "bad");
  if (tone) card.classList.add(tone);
  $(titleId).textContent = title;
  $(detailId).textContent = detail;
}

function setStage(selector, state) {
  const stage = $(selector);
  stage.classList.remove("complete", "current", "error");
  if (state) stage.classList.add(state);
}

function setProgress(value, detail) {
  const progress = Math.max(0, Math.min(100, Math.round(value)));
  $("#launchProgress").value = progress;
  $("#launchProgress").textContent = `${progress} %`;
  $("#progressValue").value = `${progress} %`;
  $("#progressValue").textContent = `${progress} %`;
  $("#progressDetail").textContent = detail;
}

function showTransition({ title, detail, kicker = "Veuillez patienter" }) {
  $("#restartKicker").textContent = kicker;
  $("#restartTitle").textContent = title;
  $("#restartDetail").textContent = detail;
  $("#restartOverlay").hidden = false;
  $("#launcherMain").setAttribute("aria-hidden", "true");
}

function hideTransition() {
  $("#restartOverlay").hidden = true;
  $("#launcherMain").removeAttribute("aria-hidden");
}

function transitionToApplication(url, mode) {
  if (navigatingToApplication || !url) return;
  navigatingToApplication = true;
  showTransition({
    kicker: "Ouverture de la Régie",
    title: "Votre table est prête",
    detail: "Le launcher laisse maintenant place à la Régie dans cette même fenêtre."
  });
  setTimeout(async () => {
    try {
      if (globalThis.xarDesktop?.navigate) await globalThis.xarDesktop.navigate(mode, url);
      else location.assign(url);
    } catch (error) {
      navigatingToApplication = false;
      hideTransition();
      $("#operationMessage").textContent = error.message;
    }
  }, reducedMotion.matches ? 80 : 650);
}

function updateConfigurationHints(configuration) {
  const discord = configuration?.discord ?? {};
  const ovh = configuration?.ovh ?? {};
  for (const [name, label] of [["images", "Images"], ["dice", "Dice"], ["journal", "Journal"]]) {
    const hint = $(`#discord${label}Hint`);
    hint.textContent = discord[name]?.configured
      ? "Un webhook est déjà enregistré. Laissez ce champ vide pour le conserver."
      : "Collez ici l’adresse complète du webhook Discord.";
  }
  $("#ovhPasswordHint").textContent = ovh.passwordConfigured
    ? "Un mot de passe est déjà enregistré. Laissez ce champ vide pour le conserver."
    : "Le mot de passe reste uniquement sur cet ordinateur.";
}

function renderAccounts(accounts = []) {
  latestAccounts = accounts;
  const container = $("#accountList");
  container.replaceChildren();
  if (!accounts.length) {
    const empty = document.createElement("p");
    empty.className = "account-empty";
    empty.textContent = "Aucun compte. Créez au moins un compte MJ avant d’ouvrir la Régie.";
    container.append(empty);
    return;
  }
  for (const account of accounts) {
    const row = document.createElement("article");
    row.className = `account-row${account.revoked ? " revoked" : ""}`;
    const identity = document.createElement("div");
    const name = document.createElement("strong");
    name.textContent = account.displayName;
    const detail = document.createElement("small");
    detail.textContent = `${account.username} · ${account.role === "gm" ? "Maître de jeu" : "Joueur"}${account.revoked ? " · révoqué" : ""}`;
    identity.append(name, detail);
    const actions = document.createElement("div");
    actions.className = "account-actions";
    const role = document.createElement("button");
    role.type = "button";
    role.dataset.accountAction = "role";
    role.dataset.accountId = account.id;
    role.dataset.nextRole = account.role === "gm" ? "player" : "gm";
    role.textContent = account.role === "gm" ? "Rétrograder joueur" : "Promouvoir MJ";
    const revoked = document.createElement("button");
    revoked.type = "button";
    revoked.dataset.accountAction = "revoked";
    revoked.dataset.accountId = account.id;
    revoked.dataset.nextRevoked = String(!account.revoked);
    revoked.textContent = account.revoked ? "Réactiver" : "Révoquer";
    const password = document.createElement("button");
    password.type = "button";
    password.dataset.accountAction = "password";
    password.dataset.accountId = account.id;
    password.textContent = "Changer le mot de passe";
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "danger";
    remove.dataset.accountAction = "delete";
    remove.dataset.accountId = account.id;
    remove.textContent = "Supprimer le compte";
    actions.append(role, revoked, password, remove);
    row.append(identity, actions);
    container.append(row);
  }
}

function renderProfiles(profiles = []) {
  const container = $("#profileList");
  container.replaceChildren();
  if (!profiles.length) {
    const empty = document.createElement("p");
    empty.className = "account-empty";
    empty.textContent = "Aucune fiche sauvegardée.";
    container.append(empty);
    return;
  }
  for (const profile of profiles) {
    const group = document.createElement("article");
    group.className = "profile-group";
    const header = document.createElement("div");
    header.className = "profile-group-header";
    const identity = document.createElement("span");
    const name = document.createElement("strong");
    name.textContent = profile.ownerName;
    const account = document.createElement("small");
    account.textContent = profile.accountUsername ? `${profile.accountUsername} · ${profile.characters.length} fiche(s)` : `${profile.characters.length} fiche(s) · compte non rattaché`;
    identity.append(name, account);
    header.append(identity);
    const characters = document.createElement("div");
    characters.className = "profile-character-list";
    for (const character of profile.characters) {
      const row = document.createElement("div");
      row.className = "profile-character-row";
      const label = document.createElement("span");
      label.textContent = character.name;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.dataset.profileAction = "delete-character";
      remove.dataset.ownerPlayerId = profile.ownerPlayerId;
      remove.dataset.characterId = character.id;
      remove.dataset.characterName = character.name;
      remove.textContent = "Supprimer la fiche";
      row.append(label, remove);
      characters.append(row);
    }
    group.append(header, characters);
    container.append(group);
  }
}

async function loadAccounts() {
  const payload = await request("/api/accounts/list", { admin: true });
  renderAccounts(payload.accounts);
  renderProfiles(payload.profiles);
  const select = $("#accountLegacyPlayer");
  const selected = select.value;
  select.replaceChildren(new Option("Nouvelle identité", ""));
  const usedIds = new Set(payload.accounts.map((account) => account.id));
  for (const player of payload.legacyPlayers ?? []) {
    if (!usedIds.has(player.id)) select.append(new Option(player.name, player.id));
  }
  select.value = selected;
  return payload.accounts;
}

function renderConfigurationIssues(issues = []) {
  const container = $("#configurationIssues");
  container.replaceChildren();
  if (!issues.length) {
    container.hidden = true;
    return;
  }
  const title = document.createElement("strong");
  title.textContent = "Vérifiez les informations suivantes :";
  const list = document.createElement("ul");
  for (const issue of issues) {
    const item = document.createElement("li");
    item.textContent = issue.message;
    list.append(item);
  }
  container.append(title, list);
  container.hidden = false;
}

async function openConfiguration() {
  const configuration = latestStatus?.configuration ?? {};
  const discordEnabled = Object.values(configuration.discord ?? {}).some((entry) => entry?.configured);
  $("#discordEnabled").checked = discordEnabled;
  $("#discordFields").hidden = !discordEnabled;
  $("#discordImages").value = "";
  $("#discordDice").value = "";
  $("#discordJournal").value = "";
  $("#ovhEnabled").checked = Boolean(configuration.ovh?.enabled);
  $("#ovhFields").hidden = !$("#ovhEnabled").checked;
  $("#ovhUrl").value = configuration.ovh?.url || "";
  $("#ovhUser").value = configuration.ovh?.user || "";
  $("#ovhPassword").value = "";
  $("#ovhPublicBaseUrl").value = configuration.ovh?.publicBaseUrl || "";
  updateConfigurationHints(configuration);
  renderConfigurationIssues(configuration.issues ?? []);
  $("#closeConfiguration").hidden = false;
  $("#configurationOverlay").hidden = false;
  document.body.classList.add("dialog-open");
  await loadAccounts();
  $("#accountUsername").focus();
}

function closeConfiguration() {
  $("#configurationOverlay").hidden = true;
  document.body.classList.remove("dialog-open");
  $("#openAdministration").focus();
}

function showOverlay(id, focusSelector) {
  $(`#${id}`).hidden = false;
  document.body.classList.add("dialog-open");
  requestAnimationFrame(() => $(focusSelector)?.focus());
}

function closeOverlay(id) {
  $(`#${id}`).hidden = true;
  if ($$(".configuration-overlay:not([hidden])").length === 0) document.body.classList.remove("dialog-open");
}

function showIssues(selector, messages) {
  const container = $(selector);
  const entries = (Array.isArray(messages) ? messages : [messages]).filter(Boolean);
  container.replaceChildren();
  if (!entries.length) {
    container.hidden = true;
    return;
  }
  const list = document.createElement("ul");
  for (const entry of entries) {
    const item = document.createElement("li");
    item.textContent = typeof entry === "string" ? entry : entry.message;
    list.append(item);
  }
  container.append(list);
  container.hidden = false;
}

function render(status) {
  latestStatus = status;
  const configuration = status.configuration ?? { ready: true, needsSetup: false, issues: [] };
  const application = status.application;
  const integrity = status.integrity;
  const update = status.update;
  const operation = status.operation;
  const operationBusy = ["downloading", "restarting"].includes(operation?.state);

  setCard(
    "#configurationCard",
    configuration.ready ? "good" : "warning",
    "#configurationStatus",
    configuration.ready ? "Réglages prêts" : "Configuration nécessaire",
    "#configurationDetail",
    configuration.ready
      ? `${status.access?.accountCount ?? 0} compte(s) · services prêts.`
      : "Ouvrez l’administration pour terminer les réglages MJ."
  );

  setCard(
    "#applicationCard",
    application.ready ? "good" : application.error ? "bad" : "warning",
    "#applicationStatus",
    application.ready ? "Régie MJ active" : application.error ? "Démarrage interrompu" : "En attente du choix MJ/Joueur",
    "#applicationDetail",
    application.error || (application.ready
      ? "La table MJ locale est ouverte."
      : "Les services démarreront après la connexion d’un compte MJ.")
  );

  const integrityIssueCount = (integrity.missing?.length || 0)
    + (integrity.modified?.length || 0)
    + (integrity.unexpected?.length || 0)
    + (integrity.invalidEntries?.length || 0);
  setCard(
    "#integrityCard",
    integrity.ok ? "good" : "bad",
    "#integrityStatus",
    integrity.ok ? "Fichiers intacts" : "Réparation nécessaire",
    "#integrityDetail",
    integrity.ok
      ? `${integrity.checkedFiles} fichiers applicatifs ont été vérifiés.`
      : integrity.reason === "manifest-missing"
        ? "La liste de contrôle des fichiers est absente."
        : `${integrityIssueCount} fichier(s) doivent être restaurés.`
  );

  const updateTone = update.state === "available" || update.state === "trust-missing" || update.state === "not-configured"
    ? "warning"
    : update.state === "error" ? "bad"
      : update.state === "current" || update.state === "ahead" ? "good" : "";
  const updateTitle = update.state === "available" ? `Version ${update.availableVersion} disponible`
    : update.state === "current" ? "Application à jour"
      : update.state === "checking" ? "Recherche en cours"
        : update.state === "error" ? "Vérification impossible"
          : update.state === "trust-missing" ? "Vérification de sécurité indisponible"
            : update.state === "ahead" ? "Version plus récente installée"
              : "Mises à jour non configurées";
  setCard("#updateCard", updateTone, "#updateStatus", updateTitle, "#updateDetail", update.message);

  setStage("#stageApplication", application.error ? "error" : integrity.ok ? "complete" : "current");
  setStage("#stageIntegrity", integrity.ok ? "complete" : "error");
  setStage(
    "#stageUpdate",
    update.state === "checking" || update.state === "not-checked" ? "current"
      : update.state === "error" || update.state === "trust-missing" ? "error"
        : update.state === "available" || update.state === "not-configured" ? "current" : "complete"
  );

  if (operation?.state === "downloading") {
    setProgress(operation.progress, operation.message);
  } else if (operation?.state === "restarting") {
    setProgress(100, operation.message);
    showTransition({
      title: "Installation de la mise à jour",
      detail: "La nouvelle version est installée puis contrôlée. La Régie reviendra automatiquement dans cette fenêtre."
    });
  } else {
    const configurationProgress = configuration.ready ? 20 : 8;
    const appProgress = integrity.ok ? 22 : 8;
    const integrityProgress = integrity.ok || integrityIssueCount > 0 || integrity.reason ? 30 : 12;
    const updateResolved = !["not-checked", "checking"].includes(update.state);
    const updateProgress = updateResolved ? 28 : update.state === "checking" ? 14 : 4;
    const detail = application.error ? application.error
        : !integrity.ok ? "Les fichiers doivent être réparés avant utilisation."
          : update.state === "available" ? `La version ${update.availableVersion} est prête à être installée.`
            : "Choisissez maintenant l’accès MJ ou Joueur.";
    setProgress(configurationProgress + appProgress + integrityProgress + updateProgress, detail);
  }

  const global = $("#globalStatus");
  global.classList.remove("good", "bad");
  let globalMessage = "Préparation en cours…";
  if (application.error || !integrity.ok) {
    global.classList.add("bad");
    globalMessage = application.error ? "Le démarrage a été interrompu" : "Les fichiers doivent être réparés";
  } else if (operationBusy) {
    globalMessage = operation?.message || "Mise à jour en cours…";
  } else if (update.state === "available") {
    globalMessage = `Mise à jour ${update.availableVersion} disponible`;
  } else if (application.ready) {
    global.classList.add("good");
    globalMessage = "La table MJ est active";
  } else {
    global.classList.add("good");
    globalMessage = "Choisissez votre accès";
  }
  $("#globalStatusText").textContent = globalMessage;

  const repairAvailable = !integrity.ok && update.configured && ["available", "current"].includes(update.state);
  const updateAvailable = update.state === "available";
  const installButton = $("#installUpdate");
  installButton.hidden = !(repairAvailable || updateAvailable);
  installButton.disabled = operationBusy;
  if (repairAvailable) {
    $("#installUpdateLabel").textContent = "Réparer l’installation";
    $("#installUpdateDetail").textContent = "Restaurer automatiquement les fichiers endommagés";
  } else if (updateAvailable) {
    $("#installUpdateLabel").textContent = `Installer la version ${update.availableVersion}`;
    $("#installUpdateDetail").textContent = "Vos données et la version précédente seront conservées";
  }

  $("#openMj").disabled = !integrity.ok || operationBusy;
  $("#openPlayer").disabled = !integrity.ok || operationBusy;
  $("#checkUpdate").disabled = operationBusy || update.state === "checking";
  $("#verifyIntegrity").disabled = operationBusy;
  $("#openAdministration").disabled = operationBusy;
  $("#launcherMain").setAttribute("aria-busy", String(operationBusy));

  if (operation?.message && operationBusy) $("#operationMessage").textContent = operation.message;
  if (status.lastUpdate?.state === "installed" && status.lastUpdate.version === status.release.version) {
    $("#operationMessage").textContent = `Version ${status.lastUpdate.version} installée et vérifiée. La version précédente a été conservée.`;
  } else if (status.lastUpdate?.state === "error") {
    $("#operationMessage").textContent = status.lastUpdate.message;
  }

  if (restartExpectedVersion && status.release.version === restartExpectedVersion && status.lastUpdate?.state === "installed") {
    if (!restartCompleted) {
      restartCompleted = true;
      sessionStorage.removeItem(restartSessionKey);
      restartExpectedVersion = "";
      const refreshedUrl = new URL(location.href);
      refreshedUrl.searchParams.set("updated", status.release.version);
      refreshedUrl.searchParams.set("reload", String(Date.now()));
      location.replace(refreshedUrl.href);
    }
  } else if (restartExpectedVersion && status.lastUpdate?.state === "error") {
    restartExpectedVersion = "";
    sessionStorage.removeItem(restartSessionKey);
    hideTransition();
  }
}

async function request(path, { operation = "", body = undefined, admin = false } = {}) {
  if (operation) $("#operationMessage").textContent = operation;
  const headers = { "X-Xar-Launcher-Token": token };
  if (admin && adminSession) headers["X-Xar-Admin-Session"] = adminSession;
  if (body !== undefined) headers["Content-Type"] = "application/json";
  const response = await fetch(path, {
    method: "POST",
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const payload = await response.json();
  if (!response.ok || !payload.ok) {
    const error = new Error(payload.error || "Commande impossible.");
    error.status = payload.status;
    error.issues = payload.issues || payload.status?.configuration?.issues || [];
    throw error;
  }
  if (payload.release) render(payload);
  return payload;
}

async function refresh() {
  try {
    const response = await fetch("/api/status", { cache: "no-store" });
    if (!response.ok) throw new Error(`statut ${response.status}`);
    render(await response.json());
  } catch (error) {
    if (restartExpectedVersion || latestStatus?.operation?.state === "restarting") {
      showTransition({
        title: "Installation de la mise à jour",
        detail: "L’application redémarre. Cette fenêtre se reconnectera automatiquement."
      });
    } else {
      $("#operationMessage").textContent = `Le launcher ne répond plus : ${error.message}`;
    }
  }
}

$("#discordEnabled").addEventListener("change", (event) => {
  $("#discordFields").hidden = !event.currentTarget.checked;
});
$("#ovhEnabled").addEventListener("change", (event) => {
  $("#ovhFields").hidden = !event.currentTarget.checked;
});
$("#closeConfiguration").addEventListener("click", closeConfiguration);
$("#configurationOverlay").addEventListener("click", (event) => {
  if (event.target === event.currentTarget) closeConfiguration();
});
addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  if (!$("#configurationOverlay").hidden) closeConfiguration();
  for (const overlay of $$(".compact-overlay:not([hidden])")) closeOverlay(overlay.id);
});

$$('[data-close-overlay]').forEach((button) => button.addEventListener("click", () => closeOverlay(button.dataset.closeOverlay)));
$$('.compact-overlay').forEach((overlay) => overlay.addEventListener("click", (event) => {
  if (event.target === event.currentTarget) closeOverlay(overlay.id);
}));

$("#openAdministration").addEventListener("click", () => {
  $("#adminPassword").value = "";
  showIssues("#adminAccessIssues", []);
  showOverlay("adminAccessOverlay", "#adminPassword");
});

$("#adminAccessForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button[type="submit"]');
  button.disabled = true;
  showIssues("#adminAccessIssues", []);
  try {
    const payload = await request("/api/access/admin", { body: { password: $("#adminPassword").value } });
    adminSession = payload.adminSession;
    if (payload.status) render(payload.status);
    $("#adminPassword").value = "";
    closeOverlay("adminAccessOverlay");
    await openConfiguration();
  } catch (error) {
    showIssues("#adminAccessIssues", error.message);
  } finally {
    button.disabled = false;
  }
});

$("#createAccount").addEventListener("click", async () => {
  const button = $("#createAccount");
  button.disabled = true;
  showIssues("#accountIssues", []);
  try {
    const payload = await request("/api/accounts/create", {
      admin: true,
      body: {
        username: $("#accountUsername").value,
        displayName: $("#accountDisplayName").value,
        password: $("#accountPassword").value,
        role: $("#accountRole").value,
        playerId: $("#accountLegacyPlayer").value
      }
    });
    $("#accountUsername").value = "";
    $("#accountDisplayName").value = "";
    $("#accountPassword").value = "";
    $("#accountLegacyPlayer").value = "";
    renderAccounts(payload.accounts);
    await loadAccounts();
    $("#operationMessage").textContent = `Compte ${payload.account.username} créé.`;
  } catch (error) {
    showIssues("#accountIssues", error.message);
  } finally {
    button.disabled = false;
  }
});

$("#accountList").addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-account-action]");
  if (!button) return;
  const account = latestAccounts.find((entry) => entry.id === button.dataset.accountId);
  if (button.dataset.accountAction === "password") {
    $("#accountPasswordTarget").value = button.dataset.accountId;
    $("#accountPasswordIdentity").textContent = account ? `${account.displayName} · ${account.username}` : "Compte sélectionné";
    $("#accountNewPassword").value = "";
    $("#accountNewPasswordConfirm").value = "";
    showIssues("#accountPasswordIssues", []);
    showOverlay("accountPasswordOverlay", "#accountNewPassword");
    return;
  }
  if (button.dataset.accountAction === "delete") {
    if (!account || !confirm(`Supprimer définitivement le compte « ${account.username} » ? Ses fiches restent conservées jusqu’à leur suppression séparée.`)) return;
    button.disabled = true;
    showIssues("#accountIssues", []);
    try {
      const payload = await request("/api/accounts/delete", { admin: true, body: { id: account.id } });
      renderAccounts(payload.accounts);
      renderProfiles(payload.profiles);
      if (payload.status) render(payload.status);
      await loadAccounts();
    } catch (error) {
      showIssues("#accountIssues", error.message);
    } finally {
      button.disabled = false;
    }
    return;
  }
  button.disabled = true;
  showIssues("#accountIssues", []);
  try {
    const body = { id: button.dataset.accountId };
    if (button.dataset.accountAction === "role") body.role = button.dataset.nextRole;
    if (button.dataset.accountAction === "revoked") body.revoked = button.dataset.nextRevoked === "true";
    const payload = await request("/api/accounts/update", { admin: true, body });
    renderAccounts(payload.accounts);
    if (payload.status) render(payload.status);
  } catch (error) {
    showIssues("#accountIssues", error.message);
  } finally {
    button.disabled = false;
  }
});

$("#accountPasswordForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button[type="submit"]');
  const password = $("#accountNewPassword").value;
  button.disabled = true;
  showIssues("#accountPasswordIssues", []);
  try {
    if (password !== $("#accountNewPasswordConfirm").value) throw new Error("Les deux mots de passe ne correspondent pas.");
    const payload = await request("/api/accounts/update", {
      admin: true,
      body: { id: $("#accountPasswordTarget").value, password }
    });
    renderAccounts(payload.accounts);
    closeOverlay("accountPasswordOverlay");
    $("#operationMessage").textContent = "Mot de passe remplacé et anciennes sessions invalidées.";
  } catch (error) {
    showIssues("#accountPasswordIssues", error.message);
  } finally {
    button.disabled = false;
  }
});

$("#profileList").addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-profile-action='delete-character']");
  if (!button || !confirm(`Supprimer définitivement la fiche « ${button.dataset.characterName} » ? Une copie de sécurité locale sera conservée.`)) return;
  button.disabled = true;
  showIssues("#profileIssues", []);
  try {
    const payload = await request("/api/profiles/delete-character", {
      admin: true,
      body: { ownerPlayerId: button.dataset.ownerPlayerId, characterId: button.dataset.characterId }
    });
    renderProfiles(payload.profiles);
    $("#operationMessage").textContent = `Fiche ${payload.character.name} supprimée.`;
  } catch (error) {
    showIssues("#profileIssues", error.message);
  } finally {
    button.disabled = false;
  }
});

$("#configurationForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const saveButton = $("#saveConfiguration");
  saveButton.disabled = true;
  renderConfigurationIssues([]);
  const body = {
    discord: {
      images: { enabled: $("#discordEnabled").checked, value: $("#discordImages").value },
      dice: { enabled: $("#discordEnabled").checked, value: $("#discordDice").value },
      journal: { enabled: $("#discordEnabled").checked, value: $("#discordJournal").value }
    },
    ovh: {
      enabled: $("#ovhEnabled").checked,
      url: $("#ovhUrl").value,
      user: $("#ovhUser").value,
      password: $("#ovhPassword").value,
      publicBaseUrl: $("#ovhPublicBaseUrl").value
    }
  };
  try {
    const payload = await request("/api/configuration", {
      operation: "Enregistrement sécurisé des réglages…",
      body,
      admin: true
    });
    $("#configurationOverlay").hidden = true;
    document.body.classList.remove("dialog-open");
    $("#operationMessage").textContent = "Réglages enregistrés dans le coffre sécurisé.";
    render(payload);
  } catch (error) {
    if (error.status) render(error.status);
    renderConfigurationIssues(error.issues?.length ? error.issues : [{ message: error.message }]);
  } finally {
    saveButton.disabled = false;
  }
});

$("#openMj").addEventListener("click", () => {
  if (!latestStatus?.configuration?.ready || !latestStatus?.access?.gmAccountCount) {
    $("#operationMessage").textContent = !latestStatus?.configuration?.ready
      ? "Ouvrez l’administration pour terminer les réglages MJ."
      : "Créez ou promouvez au moins un compte MJ dans l’administration.";
    $("#openAdministration").click();
    return;
  }
  $("#mjUsername").value = "";
  $("#mjPassword").value = "";
  showIssues("#mjAccessIssues", []);
  showOverlay("mjAccessOverlay", "#mjUsername");
});

$("#mjAccessForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button[type="submit"]');
  button.disabled = true;
  showIssues("#mjAccessIssues", []);
  try {
    const payload = await request("/api/open-mj", {
      operation: "Ouverture de la Régie MJ…",
      body: { username: $("#mjUsername").value, password: $("#mjPassword").value }
    });
    $("#mjPassword").value = "";
    closeOverlay("mjAccessOverlay");
    transitionToApplication(payload.mjUrl, "mj");
  } catch (error) {
    showIssues("#mjAccessIssues", error.message);
  } finally {
    button.disabled = false;
  }
});

$("#openPlayer").addEventListener("click", () => {
  $("#playerConnectionUrl").value = "";
  $("#playerConnectionUrl").required = !latestStatus?.playerConnectionConfigured;
  showIssues("#playerAccessIssues", []);
  showOverlay("playerAccessOverlay", "#playerConnectionUrl");
});

$("#playerAccessForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button[type="submit"]');
  button.disabled = true;
  showIssues("#playerAccessIssues", []);
  try {
    const payload = await request("/api/open-player", { operation: "Connexion à la table…", body: { url: $("#playerConnectionUrl").value } });
    $("#playerConnectionUrl").value = "";
    closeOverlay("playerAccessOverlay");
    transitionToApplication(payload.playerUrl, "player");
  } catch (error) {
    showIssues("#playerAccessIssues", error.message);
  } finally {
    button.disabled = false;
  }
});

$("#checkUpdate").addEventListener("click", async () => {
  try {
    await request("/api/check-update", { operation: "Recherche de la dernière version…" });
    $("#operationMessage").textContent = "Vérification des mises à jour terminée.";
  } catch (error) {
    $("#operationMessage").textContent = error.message;
  }
});

$("#verifyIntegrity").addEventListener("click", async () => {
  try {
    const payload = await request("/api/verify-integrity", { operation: "Vérification des fichiers applicatifs…" });
    const removed = payload.cleanup?.removed?.length ?? 0;
    $("#operationMessage").textContent = payload.integrity.ok
      ? removed
        ? `${removed} ancien(s) fichier(s) supprimé(s). L’installation correspond maintenant exactement au build actuel.`
        : "Tous les fichiers applicatifs sont intacts et aucun reliquat n’a été trouvé."
      : payload.update.configured
        ? "Certains fichiers doivent être restaurés. Utilisez « Réparer l’installation »."
        : "Certains fichiers doivent être restaurés, mais le service de mise à jour n’est pas disponible.";
  } catch (error) {
    $("#operationMessage").textContent = error.message;
  }
});

$("#exportUserData").addEventListener("click", async () => {
  if (!globalThis.xarDesktop?.exportUserData) {
    $("#operationMessage").textContent = "L’export avec sélecteur de fichier est disponible dans l’application Windows.";
    return;
  }
  try {
    const result = await globalThis.xarDesktop.exportUserData();
    if (!result.canceled) $("#operationMessage").textContent = `${result.files} fichier(s) utilisateur exporté(s).`;
  } catch (error) {
    $("#operationMessage").textContent = error.message;
  }
});

$("#importUserData").addEventListener("click", async () => {
  if (!globalThis.xarDesktop?.importUserData) {
    $("#operationMessage").textContent = "La restauration avec sélecteur de fichier est disponible dans l’application Windows.";
    return;
  }
  if (!confirm("Réintégrer cette sauvegarde ? Les fichiers remplacés seront conservés dans une sauvegarde de sécurité.")) return;
  try {
    const result = await globalThis.xarDesktop.importUserData();
    if (!result.canceled) $("#operationMessage").textContent = `${result.importedFiles} fichier(s) réintégré(s).`;
  } catch (error) {
    $("#operationMessage").textContent = error.message;
  }
});

$("#installUpdate").addEventListener("click", async () => {
  const expectedVersion = latestStatus?.update?.availableVersion || latestStatus?.release?.version || initialVersion;
  restartExpectedVersion = expectedVersion;
  sessionStorage.setItem(restartSessionKey, expectedVersion);
  try {
    await request("/api/install-update", { operation: "Téléchargement et vérification de la mise à jour…" });
    showTransition({
      title: "Installation de la mise à jour",
      detail: "La nouvelle version est installée puis contrôlée. La Régie reviendra automatiquement dans cette fenêtre."
    });
  } catch (error) {
    restartExpectedVersion = "";
    sessionStorage.removeItem(restartSessionKey);
    hideTransition();
    $("#operationMessage").textContent = error.message;
  }
});

initializeMotionBudget();
initializeCinematicEffects();
initializeBrandForge();
if (restartExpectedVersion) {
  showTransition({
    title: "Redémarrage de l’application",
    detail: "La mise à jour est en cours. Cette fenêtre se reconnectera automatiquement."
  });
}
refresh();
setInterval(refresh, 1_500);
