# Régie du Seuil 1.14.1 — Candidate comptes et présence

Cette candidate part de la 1.14.0 candidate publiée et conserve la 1.13.1 stable intacte.

## Comptes et mots de passe

- La console d’administration peut remplacer le mot de passe d’un compte, le révoquer, modifier son niveau ou le supprimer définitivement.
- Chaque utilisateur peut modifier son propre mot de passe depuis l’interface Joueur ou MJ après vérification du mot de passe actuel.
- Un changement de mot de passe, de niveau, de révocation ou une suppression invalide immédiatement les sessions et connexions en direct du compte.
- Le registre principal et sa copie de récupération contiennent le même dernier état validé : une récupération après crash ne réactive pas un ancien mot de passe ni un compte supprimé.

## Mode Joueur ou MJ

- Le niveau permanent du compte et le mode effectif de la session sont désormais séparés côté serveur.
- Un compte de niveau MJ peut entrer depuis l’accès Joueur ; sa session reçoit uniquement les droits Joueur et ne peut pas appeler les routes MJ.
- Une ouverture par l’accès MJ reste réservée à un compte possédant le niveau MJ.

## Présence et fiches sauvegardées

- L’état « En ligne » provient d’une connexion de synchronisation réellement ouverte, pas de la simple existence d’un joueur ou d’une fiche.
- Les interfaces indiquent le mode de chaque connexion : Joueur ou MJ. Un compte MJ entré comme Joueur est affiché comme Joueur.
- La console liste les fiches sauvegardées et permet d’en supprimer une individuellement sans supprimer automatiquement son compte.
- Toute suppression de fiche crée d’abord une copie locale `characters-before-deletion-*.json`, retire ses tokens liés et inscrit un tombstone pour empêcher une ancienne sauvegarde de la ressusciter.

## Livraison

- Version applicative : `1.14.1`.
- Canal : `candidate` jusqu’à validation explicite.
- Le ZIP complet et le paquet d’auto-update restent distincts et sont retestés depuis des extractions neuves avant publication.
- Aucun compte, mot de passe, vérificateur, donnée utilisateur, coffre, webhook ou secret n’est inclus dans les paquets.
