function privateIpv4(hostname) {
  const parts = hostname.split(".").map(Number);
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  return parts[0] === 10
    || parts[0] === 127
    || (parts[0] === 169 && parts[1] === 254)
    || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31)
    || (parts[0] === 192 && parts[1] === 168);
}

function privateHost(hostname) {
  const host = String(hostname ?? "").toLowerCase();
  return host === "localhost"
    || host === "::1"
    || host.endsWith(".local")
    || privateIpv4(host)
    || /^(?:fc|fd|fe8|fe9|fea|feb)[0-9a-f:]+$/i.test(host);
}

export function normalizePlayerConnectionUrl(value) {
  const raw = String(value ?? "").trim();
  if (!raw || raw.length > 4096) throw new Error("L’adresse de la table est absente ou trop longue.");
  let parsed;
  try { parsed = new URL(raw); }
  catch { throw new Error("L’adresse de la table n’est pas valide."); }
  if (parsed.username || parsed.password) throw new Error("L’adresse ne doit jamais contenir d’identifiant ni de mot de passe.");
  if (parsed.protocol !== "https:" && !(parsed.protocol === "http:" && privateHost(parsed.hostname))) {
    throw new Error("La table doit utiliser HTTPS, ou HTTP sur le réseau local.");
  }
  if (parsed.search || parsed.hash) throw new Error("L’adresse de connexion ne doit contenir aucun paramètre ni secret.");
  if (parsed.pathname === "/" || parsed.pathname === "") parsed.pathname = "/player.html";
  if (!parsed.pathname.endsWith("/player.html")) throw new Error("Cette adresse n’ouvre pas la vue joueur de la Régie.");
  parsed.hash = "";
  return parsed.href;
}
