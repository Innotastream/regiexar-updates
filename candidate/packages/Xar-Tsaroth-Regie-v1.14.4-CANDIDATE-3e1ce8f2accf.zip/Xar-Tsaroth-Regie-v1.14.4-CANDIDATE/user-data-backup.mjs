import {
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  writeFileSync
} from "node:fs";
import { createHash, randomBytes } from "node:crypto";
import { gunzipSync, gzipSync } from "node:zlib";
import path from "node:path";

export const USER_BACKUP_ID = "xar-tsaroth.user-data-backup";
export const USER_BACKUP_SCHEMA_VERSION = 1;
export const USER_BACKUP_EXTENSION = ".xarbackup";
const MAX_ARCHIVE_SIZE = 1024 * 1024 * 1024;
const MAX_EXPANDED_SIZE = 2 * 1024 * 1024 * 1024;

const allowedRoots = [
  "data/session-state.json",
  "data/users/",
  "data/media/",
  "player-data/"
];

function normalizedPath(value) {
  const raw = String(value ?? "").replaceAll("\\", "/");
  if (!raw || raw.startsWith("/") || /^[a-zA-Z]:/.test(raw) || raw.includes("\0")) return null;
  const normalized = path.posix.normalize(raw);
  if (normalized === ".." || normalized.startsWith("../")) return null;
  return normalized;
}

export function backupPathIsAllowed(value) {
  const relative = normalizedPath(value);
  if (!relative || /(?:^|\/)(?:accounts\.json|secrets\.vault|access-control\.json|configuration\.json)$/i.test(relative)) return false;
  if (/(?:^|\/)(?:chatgpt-bridge\.json|\.env(?:\.local)?|desktop-key\.bin)$/i.test(relative)) return false;
  return allowedRoots.some((allowed) => allowed.endsWith("/") ? relative.startsWith(allowed) : relative === allowed);
}

function hash(buffer) {
  return createHash("sha256").update(buffer).digest("hex");
}

function collectFiles(privateRoot) {
  const root = path.resolve(privateRoot);
  const files = [];
  const visit = (directory, relativeDirectory) => {
    if (!existsSync(directory)) return;
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const relative = path.posix.join(relativeDirectory, entry.name);
      const absolute = path.join(directory, entry.name);
      if (entry.isSymbolicLink() || lstatSync(absolute).isSymbolicLink()) throw new Error(`Lien symbolique refusé dans les données : ${relative}`);
      if (entry.isDirectory()) visit(absolute, relative);
      else if (entry.isFile() && backupPathIsAllowed(relative)) files.push({ relative, absolute });
    }
  };
  visit(path.join(root, "data"), "data");
  visit(path.join(root, "player-data"), "player-data");
  return files.sort((left, right) => left.relative.localeCompare(right.relative, "fr"));
}

export function createUserDataBackup({ privateRoot, destinationPath, applicationId, applicationVersion }) {
  const files = collectFiles(privateRoot).map(({ relative, absolute }) => {
    const content = readFileSync(absolute);
    return { path: relative, size: content.length, sha256: hash(content), content: content.toString("base64") };
  });
  const envelope = {
    backup: USER_BACKUP_ID,
    schemaVersion: USER_BACKUP_SCHEMA_VERSION,
    applicationId,
    applicationVersion,
    exportedAt: new Date().toISOString(),
    excludedSecurityData: ["comptes", "mots de passe", "coffre de secrets", "jetons du pont ChatGPT"],
    files
  };
  const archive = gzipSync(Buffer.from(JSON.stringify(envelope)), { level: 9 });
  if (archive.length > MAX_ARCHIVE_SIZE) throw new Error("La sauvegarde dépasse la taille autorisée.");
  const destination = path.resolve(destinationPath);
  mkdirSync(path.dirname(destination), { recursive: true, mode: 0o700 });
  const temporary = `${destination}.${process.pid}.partial`;
  writeFileSync(temporary, archive, { mode: 0o600 });
  rmSync(destination, { force: true });
  renameSync(temporary, destination);
  return { path: destination, files: files.length, size: archive.length };
}

function readBackup(archivePath, expectedApplicationId) {
  const archive = readFileSync(path.resolve(archivePath));
  if (!archive.length || archive.length > MAX_ARCHIVE_SIZE) throw new Error("Archive de sauvegarde invalide ou trop volumineuse.");
  let envelope;
  try { envelope = JSON.parse(gunzipSync(archive, { maxOutputLength: MAX_EXPANDED_SIZE }).toString("utf8")); }
  catch { throw new Error("La sauvegarde est illisible."); }
  if (envelope?.backup !== USER_BACKUP_ID || Number(envelope?.schemaVersion) !== USER_BACKUP_SCHEMA_VERSION) throw new Error("Format de sauvegarde inconnu.");
  if (envelope.applicationId !== expectedApplicationId || !Array.isArray(envelope.files)) throw new Error("Cette sauvegarde appartient à une autre application.");
  let total = 0;
  const seen = new Set();
  const files = envelope.files.map((entry) => {
    const relative = normalizedPath(entry?.path);
    if (!relative || !backupPathIsAllowed(relative) || seen.has(relative.toLocaleLowerCase("fr"))) throw new Error("Chemin refusé dans la sauvegarde.");
    seen.add(relative.toLocaleLowerCase("fr"));
    const content = Buffer.from(String(entry.content ?? ""), "base64");
    total += content.length;
    if (total > MAX_EXPANDED_SIZE || content.length !== Number(entry.size) || hash(content) !== entry.sha256) throw new Error(`Contenu de sauvegarde invalide : ${relative}`);
    return { relative, content };
  });
  return { envelope, files };
}

export function importUserDataBackup({ privateRoot, archivePath, applicationId }) {
  const root = path.resolve(privateRoot);
  const { envelope, files } = readBackup(archivePath, applicationId);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupRoot = path.join(root, "backups", `avant-import-${stamp}`);
  const stageRoot = path.join(root, "imports", `.stage-${process.pid}-${randomBytes(5).toString("hex")}`);
  mkdirSync(stageRoot, { recursive: true, mode: 0o700 });
  try {
    for (const file of files) {
      const staged = path.resolve(stageRoot, ...file.relative.split("/"));
      if (!staged.startsWith(`${stageRoot}${path.sep}`)) throw new Error("Destination temporaire refusée.");
      mkdirSync(path.dirname(staged), { recursive: true, mode: 0o700 });
      writeFileSync(staged, file.content, { mode: 0o600 });
    }
    let replaced = 0;
    for (const file of files) {
      const target = path.resolve(root, ...file.relative.split("/"));
      if (!target.startsWith(`${root}${path.sep}`)) throw new Error("Destination de restauration refusée.");
      if (existsSync(target)) {
        const preserved = path.join(backupRoot, ...file.relative.split("/"));
        mkdirSync(path.dirname(preserved), { recursive: true, mode: 0o700 });
        copyFileSync(target, preserved);
        replaced += 1;
      }
      mkdirSync(path.dirname(target), { recursive: true, mode: 0o700 });
      const temporary = `${target}.${process.pid}.restore`;
      copyFileSync(path.join(stageRoot, ...file.relative.split("/")), temporary);
      rmSync(target, { force: true });
      renameSync(temporary, target);
    }
    return { importedFiles: files.length, replacedFiles: replaced, sourceVersion: envelope.applicationVersion, safetyBackup: replaced ? backupRoot : null };
  } finally {
    rmSync(stageRoot, { recursive: true, force: true });
  }
}
