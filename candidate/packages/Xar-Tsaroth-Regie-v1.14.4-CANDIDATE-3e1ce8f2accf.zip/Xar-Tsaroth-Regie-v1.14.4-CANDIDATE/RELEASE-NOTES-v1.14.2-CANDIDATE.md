# Régie du Seuil 1.14.2 — Candidate dialogue d’administration

Cette candidate part de la 1.14.1 stable et conserve son archive intacte.

## Console d’administration

- Le dialogue de remplacement du mot de passe possède désormais un niveau d’empilement explicite supérieur à celui de la console.
- Le formulaire reste donc visible, accessible et cliquable lorsqu’il est ouvert depuis la liste des comptes.
- Un test de régression vérifie l’ordre réel du DOM et la priorité du dialogue imbriqué.

## Livraison

- Version applicative : `1.14.2`.
- Canal : `candidate` jusqu’à validation explicite.
- Le ZIP complet et le paquet d’auto-update restent distincts et sont retestés depuis des extractions neuves avant publication.
- Aucun compte, mot de passe, vérificateur, donnée utilisateur, coffre, webhook ou secret n’est inclus dans les paquets.
