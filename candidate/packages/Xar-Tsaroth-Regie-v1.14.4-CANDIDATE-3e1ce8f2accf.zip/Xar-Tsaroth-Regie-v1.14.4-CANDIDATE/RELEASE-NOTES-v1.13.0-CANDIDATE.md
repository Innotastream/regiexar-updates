# Régie du Seuil 1.13.0 — Candidate

## Accès MJ et Joueur séparés

- Le bouton unique du launcher est remplacé par **Entrer comme MJ** et **Entrer comme joueur**.
- Le texte d’introduction redondant sous le titre a été supprimé sans remplacement.
- Le mode Joueur rejoint un lien personnel et n’affiche que la carte et les outils de combat, la présence visuelle du groupe et les fiches appartenant au joueur.
- Le serveur MJ n’est plus démarré automatiquement à l’ouverture du launcher.

## Accès locaux protégés

- L’entrée MJ exige un mot de passe quotidien défini depuis la console d’administration.
- Après validation, une session MJ aléatoire et éphémère protège chaque route sensible côté serveur ; être sur le même ordinateur ne suffit plus à obtenir les droits MJ.
- La console possède son propre mot de passe et limite les tentatives répétées.
- Aucun mot de passe n’est conservé de façon réversible : les vérificateurs utilisent scrypt avec sel aléatoire.
- Les secrets récupérables sont chiffrés en AES-256-GCM avec une clé protégée par le coffre Windows d’Electron.
- Les liens Joueur n’acceptent que `player`, `token` et `code` et ne peuvent pas transporter la session MJ.
- Une ancienne configuration contenant des secrets est migrée vers le coffre puis réécrite sans ces valeurs.

## Fiches et table Joueur

- Un joueur authentifié peut créer autant de fiches que nécessaire ; le serveur refuse toujours l’accès aux fiches d’un autre joueur.
- Chaque fiche est copiée sur le disque du joueur hors du dossier applicatif, avec écriture atomique, copie précédente, secours IndexedDB et reprise des modifications non synchronisées après crash.
- Le schéma de fiche 2 ajoute les invocations, familiers et compagnons liés. Les anciens formats sont convertis avec le mécanisme de sauvegarde existant.
- Le MJ peut invoquer le token principal ou chaque token lié depuis la fiche. Le serveur évite les doublons et attribue le contrôle au bon joueur.
- Un double-clic sur la carte crée un signal temporaire signé par son auteur et visible par tous.
- Chaque joueur peut couper séparément la musique et l’ambiance sur sa propre machine.

## Confidentialité et concurrence

- La présence des autres personnages est visible sous forme de résumé sans transmettre leurs fiches.
- Les détails tactiques d’un token joueur sont envoyés à son propriétaire ou après révélation explicite, pas automatiquement à tous les autres joueurs.
- Les ajouts de fiches et tokens réalisés pendant qu’un état MJ plus ancien est ouvert sont conservés lors de la fusion serveur.
- Des tombstones empêchent les suppressions de joueurs ou de personnages de réapparaître lors d’une sauvegarde concurrente.

## Statut

Cette livraison reste **candidate** jusqu’à validation visuelle et fonctionnelle explicite. La version stable de sécurité précédente reste intacte.
