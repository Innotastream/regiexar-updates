import test from "node:test";
import assert from "node:assert/strict";
import { existsSync, mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { createUserDataBackup, importUserDataBackup } from "../user-data-backup.mjs";

test("la sauvegarde exporte les fiches et exclut les secrets et comptes", () => {
  const root = mkdtempSync(path.join(tmpdir(), "xar-backup-"));
  const restored = mkdtempSync(path.join(tmpdir(), "xar-restore-"));
  try {
    mkdirSync(path.join(root, "data", "users", "abc"), { recursive: true });
    writeFileSync(path.join(root, "data", "users", "abc", "characters.json"), "fiche");
    writeFileSync(path.join(root, "data", "accounts.json"), "secret-verifier");
    writeFileSync(path.join(root, "secrets.vault"), "secret");
    const archive = path.join(root, "export.xarbackup");
    const exported = createUserDataBackup({ privateRoot: root, destinationPath: archive, applicationId: "xar", applicationVersion: "1.14.0" });
    assert.equal(exported.files, 1);
    const imported = importUserDataBackup({ privateRoot: restored, archivePath: archive, applicationId: "xar" });
    assert.equal(imported.importedFiles, 1);
    assert.equal(readFileSync(path.join(restored, "data", "users", "abc", "characters.json"), "utf8"), "fiche");
    assert.equal(existsSync(path.join(restored, "data", "accounts.json")), false);
    assert.equal(existsSync(path.join(restored, "secrets.vault")), false);
  } finally {
    rmSync(root, { recursive: true, force: true });
    rmSync(restored, { recursive: true, force: true });
  }
});

test("un import conserve une copie des fichiers qu’il remplace", () => {
  const source = mkdtempSync(path.join(tmpdir(), "xar-backup-source-"));
  const target = mkdtempSync(path.join(tmpdir(), "xar-backup-target-"));
  try {
    mkdirSync(path.join(source, "data"), { recursive: true });
    mkdirSync(path.join(target, "data"), { recursive: true });
    writeFileSync(path.join(source, "data", "session-state.json"), "nouveau");
    writeFileSync(path.join(target, "data", "session-state.json"), "ancien");
    const archive = path.join(source, "export.xarbackup");
    createUserDataBackup({ privateRoot: source, destinationPath: archive, applicationId: "xar", applicationVersion: "1.14.0" });
    const imported = importUserDataBackup({ privateRoot: target, archivePath: archive, applicationId: "xar" });
    assert.equal(imported.replacedFiles, 1);
    assert.equal(readFileSync(path.join(target, "data", "session-state.json"), "utf8"), "nouveau");
    assert.equal(readFileSync(path.join(imported.safetyBackup, "data", "session-state.json"), "utf8"), "ancien");
  } finally {
    rmSync(source, { recursive: true, force: true });
    rmSync(target, { recursive: true, force: true });
  }
});
