import test from "node:test";
import assert from "node:assert/strict";
import { generateKeyPairSync, sign } from "node:crypto";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import {
  canonicalUpdatePayload,
  compareApplicationVersions,
  createIntegrityManifest,
  extractZipArchive,
  verifyInstallation,
  removeUnexpectedInstallationFiles,
  verifySignedUpdateManifest,
  writeIntegrityManifest
} from "../launcher-core.mjs";
import { createStoredZip } from "./zip-fixture.mjs";

async function sampleRelease(context) {
  const root = await mkdtemp(path.join(tmpdir(), "xar-launcher-integrity-"));
  context.after(() => rm(root, { recursive: true, force: true }));
  await mkdir(path.join(root, "public"));
  await writeFile(path.join(root, "application.json"), JSON.stringify({ applicationId: "fr.xar.test", version: "1.8.0" }));
  await writeFile(path.join(root, "public", "app.js"), "export const ready = true;\n");
  await writeFile(path.join(root, ".env.local"), "SECRET=never-indexed\n");
  await writeFile(path.join(root, "release-publish-request.json"), "publication privée\n");
  await mkdir(path.join(root, "data"));
  await writeFile(path.join(root, "data", "session-state.json"), "private\n");
  for (const directory of [".github", "build", "desktop-payload", "dist"]) {
    await mkdir(path.join(root, directory));
    await writeFile(path.join(root, directory, "not-in-application.txt"), "construction uniquement\n");
  }
  return root;
}

test("le manifeste d’intégrité couvre le build mais exclut données et secrets", async (context) => {
  const root = await sampleRelease(context);
  const manifest = createIntegrityManifest(root);
  assert.deepEqual(manifest.files.map((entry) => entry.path), ["application.json", "build/not-in-application.txt", "public/app.js"]);
  writeIntegrityManifest(root);
  const verified = verifyInstallation(root);
  assert.equal(verified.ok, true);
  assert.equal(verified.checkedFiles, 3);
});

test("le contrôle d’intégrité détecte un fichier applicatif modifié", async (context) => {
  const root = await sampleRelease(context);
  writeIntegrityManifest(root);
  await writeFile(path.join(root, "public", "app.js"), "export const ready = false;\n");
  const verified = verifyInstallation(root);
  assert.equal(verified.ok, false);
  assert.deepEqual(verified.modified, ["public/app.js"]);
});

test("le contrôle d’intégrité détecte aussi un fichier applicatif inattendu", async (context) => {
  const root = await sampleRelease(context);
  writeIntegrityManifest(root);
  await writeFile(path.join(root, "injected.mjs"), "export default 'intrus';\n");
  const verified = verifyInstallation(root);
  assert.equal(verified.ok, false);
  assert.deepEqual(verified.unexpected, ["injected.mjs"]);
});

test("la réparation supprime seulement les reliquats inclus dans le périmètre applicatif", async (context) => {
  const root = await sampleRelease(context);
  writeIntegrityManifest(root);
  await writeFile(path.join(root, "injected.mjs"), "export default 'intrus';\n");
  await writeFile(path.join(root, "data", "fiche-privee.json"), "à conserver\n");
  const cleanup = removeUnexpectedInstallationFiles(root);
  assert.equal(cleanup.ok, true);
  assert.deepEqual(cleanup.removed, ["injected.mjs"]);
  await assert.rejects(readFile(path.join(root, "injected.mjs")), /ENOENT/);
  assert.equal(await readFile(path.join(root, "data", "fiche-privee.json"), "utf8"), "à conserver\n");
  assert.equal(await readFile(path.join(root, ".env.local"), "utf8"), "SECRET=never-indexed\n");
  assert.equal(verifyInstallation(root).ok, true);
});

test("les métadonnées créées par l’Explorateur Windows ne rendent pas le paquet invalide", async (context) => {
  const root = await sampleRelease(context);
  writeIntegrityManifest(root);
  await writeFile(path.join(root, "desktop.ini"), "[.ShellClassInfo]\n");
  await writeFile(path.join(root, "public", "Desktop.INI"), "[.ShellClassInfo]\n");
  const verified = verifyInstallation(root);
  assert.equal(verified.ok, true);
  assert.deepEqual(verified.unexpected, []);
});

test("les versions comparées sont les versions applicatives", () => {
  assert.equal(compareApplicationVersions("1.8.0", "1.8.0"), 0);
  assert.equal(compareApplicationVersions("1.8.0", "1.9.0"), -1);
  assert.equal(compareApplicationVersions("2.0.0", "1.99.99"), 1);
  assert.equal(compareApplicationVersions("1.12.0", "4.7.3"), -1);
});

test("un manifeste de mise à jour Ed25519 signé est accepté", () => {
  const { publicKey, privateKey } = generateKeyPairSync("ed25519");
  const manifest = {
    schemaVersion: 1,
    applicationId: "fr.xar.test",
    channel: "candidate",
    version: "1.9.0",
    publishedAt: "2026-08-17T12:00:00.000Z",
    package: {
      url: "https://updates.example.test/Xar-Tsaroth-Regie-v1.9.0.zip",
      sha256: "a".repeat(64),
      size: 12345
    }
  };
  manifest.signature = sign(null, Buffer.from(canonicalUpdatePayload(manifest)), privateKey).toString("base64");
  const verified = verifySignedUpdateManifest(manifest, {
    applicationId: "fr.xar.test",
    publicKey: publicKey.export({ type: "spki", format: "pem" })
  });
  assert.equal(verified.version, "1.9.0");
});

test("une mise à jour falsifiée ou servie sans HTTPS est refusée", () => {
  const { publicKey, privateKey } = generateKeyPairSync("ed25519");
  const manifest = {
    schemaVersion: 1,
    applicationId: "fr.xar.test",
    channel: "stable",
    version: "1.8.1",
    publishedAt: "2026-08-17T12:00:00.000Z",
    package: { url: "https://updates.example.test/release.zip", sha256: "b".repeat(64), size: 50 }
  };
  manifest.signature = sign(null, Buffer.from(canonicalUpdatePayload(manifest)), privateKey).toString("base64");
  const trust = { applicationId: "fr.xar.test", publicKey: publicKey.export({ type: "spki", format: "pem" }) };
  assert.throws(() => verifySignedUpdateManifest({ ...manifest, version: "1.8.2" }, trust), /Signature/);
  assert.throws(() => verifySignedUpdateManifest({ ...manifest, package: { ...manifest.package, url: "http://updates.example.test/release.zip" } }, trust), /HTTPS/);
});

test("une mise à jour signée pour un autre canal est refusée", () => {
  const { publicKey, privateKey } = generateKeyPairSync("ed25519");
  const manifest = {
    schemaVersion: 1,
    applicationId: "fr.xar.test",
    channel: "candidate",
    version: "1.9.0",
    publishedAt: "2026-08-17T12:00:00.000Z",
    package: { url: "https://updates.example.test/release.zip", sha256: "c".repeat(64), size: 50 }
  };
  manifest.signature = sign(null, Buffer.from(canonicalUpdatePayload(manifest)), privateKey).toString("base64");
  assert.throws(() => verifySignedUpdateManifest(manifest, {
    applicationId: "fr.xar.test",
    publicKey: publicKey.export({ type: "spki", format: "pem" }),
    channel: "stable"
  }), /autre canal/);
});

test("l’extracteur ZIP refuse toute sortie du dossier de staging", async (context) => {
  const root = await mkdtemp(path.join(tmpdir(), "xar-launcher-zip-slip-"));
  context.after(() => rm(root, { recursive: true, force: true }));
  const archive = path.join(root, "malicious.zip");
  await writeFile(archive, createStoredZip([{ path: "../escape.txt", data: "interdit" }]));
  await assert.rejects(() => extractZipArchive(archive, path.join(root, "staging")), /Chemin dangereux/);
  await assert.rejects(readFile(path.join(root, "escape.txt")), /ENOENT/);
});

test("l’extracteur ZIP applique une limite décompressée adaptée à son usage", async (context) => {
  const root = await mkdtemp(path.join(tmpdir(), "xar-launcher-zip-limit-"));
  context.after(() => rm(root, { recursive: true, force: true }));
  const archive = path.join(root, "large.zip");
  await writeFile(archive, createStoredZip([{ path: "word/document.xml", data: "contenu trop long" }]));
  await assert.rejects(
    () => extractZipArchive(archive, path.join(root, "staging"), { maximumExpandedSize: 5 }),
    /taille décompressée/i
  );
});
