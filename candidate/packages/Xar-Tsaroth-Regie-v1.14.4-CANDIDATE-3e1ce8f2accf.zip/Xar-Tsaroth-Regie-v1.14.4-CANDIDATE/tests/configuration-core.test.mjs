import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  mergeConfigurationInput,
  parseConfigurationJson,
  parseEnvironmentText,
  publicConfigurationStatus,
  serializeConfigurationJson,
  serializeEnvironment,
  validateConfiguration
} from "../configuration-core.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("une première ouverture ne dépend plus d’un fichier env ni d’un code joueurs global", () => {
  const status = publicConfigurationStatus({}, { fileExists: false });
  assert.equal(status.ready, true);
  assert.equal(status.needsSetup, false);
  assert.equal(status.storageFormat, "json+vault");
  assert.equal("playerAccessCodeConfigured" in status, false);
});

test("les services facultatifs peuvent rester désactivés sans secret global", () => {
  const result = validateConfiguration({ OVH_ENABLED: "false" });
  assert.equal(result.valid, true);
});

test("l’assistant refuse un faux webhook et une cible OVH dangereuse", () => {
  const result = validateConfiguration({
    DISCORD_IMAGE_WEBHOOK_URL: "https://discord.example/api/webhooks/1/token",
    OVH_FTP_URL: "sftp://ftp.example.test/www",
    OVH_FTP_USER: "mj",
    OVH_FTP_PASSWORD: "secret"
  });
  assert.equal(result.valid, false);
  assert.ok(result.issues.some((issue) => issue.field === "discord.images"));
  assert.ok(result.issues.some((issue) => issue.field === "ovh.url"));
});

test("un secret existant reste intact quand le champ masqué est laissé vide", () => {
  const current = {
    DISCORD_IMAGE_WEBHOOK_URL: "https://discord.com/api/webhooks/1/token",
    OVH_FTP_URL: "sftp://ftp.example.test/~/regie-media/",
    OVH_FTP_USER: "mj",
    OVH_FTP_PASSWORD: "mot-de-passe"
  };
  const merged = mergeConfigurationInput({
    discord: { images: { enabled: true, value: "" }, dice: { enabled: false }, journal: { enabled: false } },
    ovh: { enabled: true, url: "", user: "", password: "", publicBaseUrl: "" }
  }, current);
  assert.equal(merged.DISCORD_IMAGE_WEBHOOK_URL, current.DISCORD_IMAGE_WEBHOOK_URL);
  assert.equal(merged.OVH_FTP_PASSWORD, current.OVH_FTP_PASSWORD);
});

test("la sérialisation de configuration exclut tous les secrets", () => {
  const values = {
    PORT: "4173",
    PLAYER_ACCESS_CODE: "table privée #1",
    OVH_FTP_PASSWORD: "p@ss=word# avec espace"
  };
  assert.deepEqual(parseEnvironmentText(serializeEnvironment(values)), { PORT: "4173" });
  assert.doesNotMatch(serializeEnvironment(values), /table privée|p@ss=word/);
  assert.deepEqual(parseConfigurationJson(serializeConfigurationJson(values)), { PORT: "4173" });
  assert.doesNotMatch(serializeConfigurationJson(values), /table privée|p@ss=word/);
  const status = publicConfigurationStatus(values);
  assert.equal("playerAccessCode" in status, false);
  assert.equal("playerAccessCodeConfigured" in status, false);
  assert.equal("password" in status.ovh, false);
});

test("le launcher ne démarre pas le MJ et refuse la configuration sans session d’administration", { timeout: 30_000 }, async (context) => {
  const privateRoot = await mkdtemp(path.join(tmpdir(), "xar-guided-setup-"));
  const launcherPort = 46_000 + Math.floor(Math.random() * 1_000);
  const applicationPort = launcherPort + 1_500;
  const launcherOrigin = `http://127.0.0.1:${launcherPort}`;
  const child = spawn(process.execPath, [path.join(ROOT, "launcher.mjs")], {
    cwd: ROOT,
    env: {
      ...process.env,
      XAR_PRIVATE_ROOT: privateRoot,
      XAR_LAUNCHER_PORT: String(launcherPort),
      PORT: String(applicationPort),
      XAR_SECRET_VAULT_KEY: Buffer.alloc(32, 7).toString("base64"),
      XAR_UPDATE_MANIFEST_URL: "https://127.0.0.1:9/latest.json"
    },
    stdio: "ignore"
  });
  context.after(async () => {
    try { child.kill("SIGTERM"); } catch {}
    await rm(privateRoot, { recursive: true, force: true });
  });

  let html = "";
  for (let attempt = 0; attempt < 100; attempt += 1) {
    try {
      const response = await fetch(launcherOrigin, { signal: AbortSignal.timeout(300) });
      if (response.ok) {
        html = await response.text();
        break;
      }
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 80));
  }
  assert.ok(html, "le launcher doit répondre");
  const csrfToken = html.match(/data-launcher-token="([a-f0-9]{64})"/)?.[1];
  assert.ok(csrfToken);

  const initial = await fetch(`${launcherOrigin}/api/status`).then((response) => response.json());
  assert.equal(initial.configuration.ready, true);
  assert.equal(initial.application.ready, false);
  assert.equal(initial.application.running, false);
  assert.equal(initial.access.accountCount, 0);
  assert.equal(initial.access.gmAccountCount, 0);

  const configuredResponse = await fetch(`${launcherOrigin}/api/configuration`, {
    method: "POST",
    headers: {
      Origin: launcherOrigin,
      "Content-Type": "application/json",
      "X-Xar-Launcher-Token": csrfToken
    },
    body: JSON.stringify({ ovh: { enabled: false } })
  });
  assert.equal(configuredResponse.status, 403);
  assert.doesNotMatch(JSON.stringify(await configuredResponse.json()), /mot de passe|webhook|secret/i);

  await fetch(`${launcherOrigin}/api/shutdown`, {
    method: "POST",
    headers: { Origin: launcherOrigin, "X-Xar-Launcher-Token": csrfToken }
  }).catch(() => {});
});
