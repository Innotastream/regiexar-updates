import test from "node:test";
import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

async function source(relativePath) {
  return readFile(path.join(ROOT, relativePath), "utf8");
}

async function optionalSource(relativePath) {
  try {
    return await source(relativePath);
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    throw error;
  }
}

test("le launcher sépare clairement les accès MJ et joueur, protège l’administration et reste silencieux", async () => {
  const [html, css, client, launcher, environmentExample] = await Promise.all([
    source("launcher/index.html"),
    source("launcher/launcher.css"),
    source("launcher/launcher.js"),
    source("launcher.mjs"),
    source(".env.example")
  ]);
  assert.match(html, /Entrer comme MJ/);
  assert.match(html, /Entrer comme joueur/);
  assert.match(html, /Vérifier les mises à jour/);
  assert.match(html, /Vérifier les fichiers/);
  assert.match(html, /Notes de mise à jour/);
  assert.match(html, /Console de la Régie/);
  assert.match(html, /Enregistrer les réglages/);
  assert.match(html, /Connexion MJ/);
  assert.match(html, /Comptes joueurs et MJ/);
  assert.match(html, /Créer le compte/);
  assert.match(html, /Remplacer le mot de passe/);
  assert.match(html, /Fiches sauvegardées/);
  assert.match(html, /Mot de passe d’administration/);
  assert.match(html, /Exporter mes données/);
  assert.match(html, /Réintégrer mes données/);
  assert.doesNotMatch(html, /Mot de passe MJ du jour|Code d’accès joueurs/);
  assert.match(html, /Stockage OVH/);
  assert.match(html, /id="ovhEnabled"[^>]*checked/);
  assert.match(html, /Discord/);
  assert.match(html, /Régie du Seuil · version \{\{APP_VERSION\}\} · mises à jour actives/);
  assert.match(html, /<progress[^>]+id="launchProgress"/);
  assert.match(html, /id="arcaneCanvas"/);
  assert.doesNotMatch(html, /Architecture du portail|État du royaume|Ouverture des sceaux|>01<|>02<|>03</i);
  assert.doesNotMatch(html, /class="hero-intro"/);
  assert.doesNotMatch(html, /soundToggle|SFX|ambiance/i);
  assert.doesNotMatch(client, /AudioContext|webkitAudioContext|createOscillator/);
  assert.match(client, /api\/configuration/);
  assert.match(client, /api\/open-mj/);
  assert.match(client, /api\/open-player/);
  assert.match(client, /xarDesktop\?\.navigate/);
  assert.match(client, /transitionToApplication/);
  assert.match(client, /payload\.mjUrl/);
  assert.match(client, /api\/accounts\/create/);
  assert.match(client, /api\/accounts\/update/);
  assert.match(client, /api\/accounts\/delete/);
  assert.match(client, /api\/profiles\/delete-character/);
  assert.match(client, /exportUserData/);
  assert.match(client, /importUserData/);
  assert.match(launcher, /mergeConfigurationInput/);
  assert.match(launcher, /serializeConfigurationJson/);
  assert.match(launcher, /blockedByConfiguration/);
  assert.match(launcher, /readSecretVault/);
  assert.match(launcher, /verifyPassword/);
  assert.match(launcher, /AccountStore/);
  assert.match(launcher, /removeUnexpectedInstallationFiles/);
  assert.match(launcher, /XAR_LAUNCHER_SERVICE_TOKEN/);
  assert.match(launcher, /accountStore\.delete/);
  assert.doesNotMatch(launcher, /XAR_MJ_SESSION_TOKEN/);
  assert.doesNotMatch(launcher, /openApplicationShell\("application"/);
  assert.match(environmentExample, /développement uniquement/);
  assert.match(environmentExample, /configuration\.json et son coffre sécurisé/);
  assert.match(css, /prefers-reduced-motion/);
  assert.match(html, /aria-live="polite"/);
});

test("le dialogue de remplacement du mot de passe reste devant la console d’administration", async () => {
  const [html, css, client] = await Promise.all([
    source("launcher/index.html"),
    source("launcher/launcher.css"),
    source("launcher/launcher.js")
  ]);
  const baseLayer = css.match(/\.configuration-overlay\s*\{[^}]*z-index:\s*(\d+)/s);
  const nestedLayer = css.match(/\.configuration-overlay\.nested-overlay\s*\{[^}]*z-index:\s*(\d+)/s);

  assert.match(html, /class="[^"]*nested-overlay[^"]*" id="accountPasswordOverlay"/);
  assert.ok(html.indexOf('id="accountPasswordOverlay"') < html.indexOf('id="configurationOverlay"'), "le test couvre l’ordre DOM qui provoquait la régression");
  assert.ok(baseLayer && nestedLayer, "les deux niveaux d’empilement doivent rester explicites");
  assert.ok(Number(nestedLayer[1]) > Number(baseLayer[1]), "le dialogue imbriqué doit recouvrir la console");
  assert.match(client, /showOverlay\("accountPasswordOverlay", "#accountNewPassword"\)/);
});

test("le titre officiel Xar Tsaroth est forgé visuellement sans moteur audio", async () => {
  const [html, css, client, titleAsset] = await Promise.all([
    source("launcher/index.html"),
    source("launcher/launcher.css"),
    source("launcher/launcher.js"),
    stat(path.join(ROOT, "launcher", "xar-tsaroth-title.png"))
  ]);
  assert.match(html, /xar-tsaroth-title\.png/);
  assert.match(html, /id="brandForgeCanvas"/);
  assert.match(html, /forge-strike/);
  assert.match(html, /wave-one/);
  assert.match(html, /wave-two/);
  assert.match(css, /forged-title-reveal/);
  assert.match(css, /forge-filaments-reveal/);
  assert.match(css, /forge-strike/);
  assert.match(css, /forge-wave/);
  assert.match(client, /compact \? 520 : 980/);
  assert.match(client, /initializeBrandForge/);
  assert.ok(titleAsset.size > 100_000);
});

test("les effets du launcher respectent un budget puis cessent tout rendu GPU au repos", async () => {
  const [client, css] = await Promise.all([
    source("launcher/launcher.js"),
    source("launcher/launcher.css")
  ]);
  assert.match(client, /CINEMATIC_SETTLE_MS = 5_000/);
  assert.match(client, /ARCANE_FRAME_INTERVAL_MS = 1_000 \/ 12/);
  assert.match(client, /FORGE_FRAME_INTERVAL_MS = 1_000 \/ 30/);
  assert.match(client, /document\.hidden/);
  assert.match(client, /cancelAnimationFrame\(animationFrame\)/);
  assert.match(client, /classList\.add\("effects-settled"\)/);
  assert.match(css, /html\.effects-settled \.arcane-canvas\s*\{\s*display:\s*none/);
  assert.match(css, /animation-play-state:\s*paused !important/);
});

test("l’application Windows possède une icône multirésolution dédiée", async () => {
  const [ico, desktopIcon, launcherIcon, iconSource] = await Promise.all([
    readFile(path.join(ROOT, "build", "icon.ico")).catch((error) => error?.code === "ENOENT" ? null : Promise.reject(error)),
    stat(path.join(ROOT, "desktop", "icon.png")),
    stat(path.join(ROOT, "launcher", "xar-icon.png")),
    optionalSource("build/app-icon.svg")
  ]);
  assert.ok(desktopIcon.size > 100_000);
  assert.ok(launcherIcon.size > 40_000);
  if (ico !== null && iconSource !== null) {
    assert.deepEqual([...ico.subarray(0, 4)], [0, 0, 1, 0]);
    assert.ok(ico.length > 100_000);
    assert.match(iconSource, /Xar Tsaroth — Régie du Seuil/);
    assert.match(iconSource, /id="gold"/);
  }
});

test("l’installeur Windows fournit une seule fenêtre sécurisée, un coffre système et un moteur autonome", async () => {
  const [desktopMain, desktopPreload, desktopRuntime, desktopRelaunch, launcherClient, loading, packageJson, workflow, nsisInclude, updater, launcher, installer, installerCore, runtimeControl, windowsStart, unixStart, application] = await Promise.all([
    source("desktop/main.cjs"),
    source("desktop/preload.cjs"),
    source("desktop/runtime.cjs"),
    source("desktop/relaunch-after-update.cjs"),
    source("launcher/launcher.js"),
    source("desktop/loading.html"),
    source("package.json").then(JSON.parse),
    optionalSource(".github/workflows/build-windows-installer.yml"),
    source("build/installer.nsh"),
    source("updater.mjs"),
    source("launcher.mjs"),
    source("installer.mjs"),
    source("installer-core.mjs"),
    source("runtime-control.mjs"),
    optionalSource("start-windows.bat"),
    source("start.sh"),
    source("application.json").then(JSON.parse)
  ]);
  assert.match(desktopMain, /new BrowserWindow/);
  assert.match(desktopMain, /requestSingleInstanceLock/);
  assert.match(desktopMain, /utilityProcess\.fork/);
  assert.match(desktopMain, /contextIsolation: true/);
  assert.match(desktopMain, /nodeIntegration: false/);
  assert.match(desktopMain, /sandbox: true/);
  assert.match(desktopMain, /safeStorage\.encryptString/);
  assert.match(desktopMain, /XAR_SECRET_VAULT_KEY/);
  assert.match(desktopMain, /xar:player-sheets:save/);
  assert.match(desktopMain, /xar:user-data:export/);
  assert.match(desktopMain, /xar:user-data:import/);
  assert.match(desktopPreload, /contextBridge\.exposeInMainWorld/);
  assert.match(desktopMain, /setWindowOpenHandler/);
  assert.match(desktopMain, /XarTsarothRegie/);
  assert.match(desktopMain, /applicationRoot = path\.join\(privateRoot, "app"\)/);
  assert.match(desktopRuntime, /ELECTRON_RUN_AS_NODE/);
  assert.match(desktopRuntime, /runLauncher\(\{ openBrowser: false \}\)/);
  assert.match(desktopRuntime, /scheduleDesktopRelaunchAfterUpdate/);
  assert.match(desktopRuntime, /desktop-relaunch\.json/);
  assert.match(desktopRuntime, /status\.version !== release\?\.version/);
  assert.match(desktopRelaunch, /taskkill\.exe/);
  assert.match(desktopRelaunch, /spawn\(process\.execPath, \[\]/);
  assert.match(desktopRelaunch, /delete cleanEnvironment\[name\]/);
  assert.match(launcherClient, /location\.replace\(refreshedUrl\.href\)/);
  assert.match(loading, /Xar Tsaroth/);
  assert.match(updater, /XAR_DESKTOP_HOST !== "1"/);
  assert.match(launcher, /verifyInstallation/);
  assert.match(launcher, /fetchSignedUpdateManifest/);
  assert.match(launcher, /launchUpdaterAndExit/);
  assert.match(launcher, /\/api\/shutdown/);
  assert.match(installer, /stopInstalledRuntime/);
  assert.match(installerCore, /renameWithRetry/);
  assert.match(runtimeControl, /Get-CimInstance Win32_Process/);
  assert.equal(windowsStart, null);
  assert.match(unixStart, /node installer\.mjs/);
  assert.equal(packageJson.main, "desktop/main.cjs");
  assert.equal(packageJson.devDependencies.electron, "43.2.0");
  assert.equal(packageJson.devDependencies["electron-builder"], "26.15.7");
  assert.equal(packageJson.build.nsis.oneClick, false);
  assert.equal(packageJson.build.nsis.perMachine, true);
  assert.equal(packageJson.build.nsis.allowElevation, true);
  assert.equal(packageJson.build.nsis.include, "build/installer.nsh");
  assert.equal(packageJson.build.nsis.deleteAppDataOnUninstall, false);
  assert.equal(packageJson.build.forceCodeSigning, true);
  assert.match(nsisInclude, /\$PROGRAMFILES64\\Xar-Tsaroth/);
  assert.match(nsisInclude, /isForceMachineInstall/);
  assert.equal(packageJson.build.win.executableName, "Xar Tsaroth - Regie du Seuil");
  assert.match(packageJson.build.win.artifactName, /Xar-Tsaroth-Regie-Setup/);
  if (workflow !== null) {
    assert.match(workflow, /windows-latest/);
    assert.match(workflow, /desktop:build:windows/);
    assert.match(workflow, /actions\/upload-artifact@v4/);
    assert.match(workflow, /WIN_CSC_LINK/);
    assert.match(workflow, /Get-AuthenticodeSignature/);
    assert.match(workflow, /Join-Path \$env:ProgramFiles "Xar-Tsaroth"/);
    assert.match(workflow, /HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall/);
  }
  assert.equal(packageJson.version, application.version);
  assert.equal(application.version, "1.14.4");
  assert.match(application.updatePublicKey, /Y1kWBBN0aAByYzoaG6dEnoSSG0cGabibeJfXCYQ81Rw=/);
  assert.equal(application.desktopShellApiVersion, 3);
});

test("une mise à jour relance une seule fois Windows puis recharge le launcher du nouveau build", async () => {
  const [desktopRuntime, desktopRelaunch, launcherClient] = await Promise.all([
    source("desktop/runtime.cjs"),
    source("desktop/relaunch-after-update.cjs"),
    source("launcher/launcher.js")
  ]);
  assert.match(desktopRuntime, /const cycle = `\$\{status\.version\}:\$\{status\.updatedAt\}`/);
  assert.match(desktopRuntime, /readJson\(markerPath\)\?\.cycle === cycle/);
  assert.match(desktopRuntime, /delete helperEnvironment\.XAR_SECRET_VAULT_KEY/);
  assert.match(desktopRelaunch, /taskkill\.exe/);
  assert.match(desktopRelaunch, /"ELECTRON_RUN_AS_NODE"/);
  assert.match(desktopRelaunch, /spawn\(process\.execPath, \[\]/);
  assert.match(launcherClient, /sessionStorage\.removeItem\(restartSessionKey\)/);
  assert.match(launcherClient, /location\.replace\(refreshedUrl\.href\)/);
});

test("la Régie retrouve les mises à jour et protège les rôles par compte", async () => {
  const [appHtml, appClient, server] = await Promise.all([
    source("public/index.html"),
    source("public/app.js"),
    source("server.mjs")
  ]);
  assert.match(appHtml, /id="openUpdateCenter"/);
  assert.match(appHtml, /id="mjLoginOverlay"/);
  assert.match(appClient, /openUpdateCenter/);
  assert.match(appClient, /launcherUrl/);
  assert.match(appClient, /\/api\/auth\/login/);
  assert.match(appClient, /\/api\/auth\/password/);
  assert.doesNotMatch(appClient, /managerPlayerAccessCode|X-Xar-Mj-Session/);
  assert.doesNotMatch(server, /\/api\/system\/player-access-code/);
  assert.match(server, /\/api\/auth\/login/);
  assert.match(server, /accountStore\.resolveSession/);
  assert.match(server, /session\.mode/);
  assert.match(server, /livePresence/);
  assert.match(server, /isMjRequest/);
  assert.match(server, /XAR_LAUNCHER_ORIGIN/);
  assert.match(appClient, /api\/system\/open-chatgpt/);
});
