import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { characterDraftFromWordText, docxXmlToText, importCharacterDocx } from "../docx-character-import.mjs";
import { createStoredZip } from "./zip-fixture.mjs";

test("le texte Word français préremplit les champs reconnus", () => {
  const draft = characterDraftFromWordText("Nom : Lyra\nRace : Humaine\nForce : 12\nPV : 25\nPV max : 30\nCompétences : Alchimie", { ownerPlayerId: "player-01" });
  assert.equal(draft.character.name, "Lyra");
  assert.equal(draft.character.race, "Humaine");
  assert.equal(draft.character.stats.force, 12);
  assert.equal(draft.character.resources.hp, 25);
  assert.equal(draft.character.resources.maxHp, 30);
  assert.equal(draft.character.skills, "Alchimie");
});

test("un DOCX minimal est extrait sans dépendance externe", async () => {
  const root = mkdtempSync(path.join(tmpdir(), "xar-docx-test-"));
  try {
    const filePath = path.join(root, "lyra.docx");
    const xml = "<w:document><w:body><w:p><w:r><w:t>Nom : Lyra</w:t></w:r></w:p><w:p><w:r><w:t>Race : Elfe</w:t></w:r></w:p></w:body></w:document>";
    writeFileSync(filePath, createStoredZip([{ path: "word/document.xml", data: xml }]));
    assert.match(docxXmlToText(xml), /Nom : Lyra/);
    const draft = await importCharacterDocx(filePath, { ownerPlayerId: "player-01" });
    assert.equal(draft.character.name, "Lyra");
    assert.equal(draft.character.race, "Elfe");
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});
