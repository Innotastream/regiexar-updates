import { existsSync, mkdtempSync, readFileSync, rmSync } from "node:fs";
import path from "node:path";
import { tmpdir } from "node:os";
import { extractZipArchive } from "./launcher-core.mjs";
import { createCharacterSheet } from "./public/character-schema.js";

const labelMap = new Map([
  ["nom", "name"], ["prénom", "givenName"], ["prenom", "givenName"], ["race", "race"], ["âge", "age"], ["age", "age"],
  ["classe", "className"], ["classe avancée", "advancedClass"], ["classe avancee", "advancedClass"], ["profession", "profession"],
  ["ancienne profession", "previousProfession"], ["pronoms", "pronouns"], ["morale", "morale"], ["armure", "armorText"],
  ["armes", "weaponText"], ["arme", "weaponText"], ["passifs", "passives"], ["compétences", "skills"], ["competences", "skills"],
  ["compétences spéciales", "specialSkills"], ["competences speciales", "specialSkills"], ["langues", "languages"],
  ["inventaire", "inventory"], ["notes", "publicNotes"]
]);

function decodeXml(value) {
  return String(value ?? "")
    .replaceAll("&lt;", "<").replaceAll("&gt;", ">").replaceAll("&amp;", "&")
    .replaceAll("&quot;", "\"").replaceAll("&apos;", "'").replace(/&#(\d+);/g, (_all, code) => String.fromCodePoint(Number(code)));
}

export function docxXmlToText(xml) {
  return decodeXml(String(xml ?? "")
    .replace(/<w:tab\b[^>]*\/>/gi, "\t")
    .replace(/<w:br\b[^>]*\/>/gi, "\n")
    .replace(/<\/w:p>/gi, "\n")
    .replace(/<\/w:tc>/gi, "\t")
    .replace(/<[^>]+>/g, ""))
    .replace(/\u00a0/g, " ")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function key(value) {
  return String(value ?? "").normalize("NFD").replace(/\p{Diacritic}/gu, "").toLocaleLowerCase("fr").replace(/\s+/g, " ").trim();
}

function numberAfter(text, labels) {
  for (const label of labels) {
    const match = new RegExp(`(?:^|\\n)\\s*${label}\\s*[:=]?\\s*(-?\\d+(?:[.,]\\d+)?)`, "i").exec(text);
    if (match) return Number(match[1].replace(",", "."));
  }
  return null;
}

export function characterDraftFromWordText(text, { ownerPlayerId, filename = "fiche.docx" } = {}) {
  const lines = String(text ?? "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const values = {};
  for (const line of lines) {
    const separator = line.search(/[:=\t]/);
    if (separator < 1) continue;
    const rawLabel = line.slice(0, separator).trim();
    const rawValue = line.slice(separator + 1).trim();
    const field = [...labelMap.entries()].find(([label]) => key(label) === key(rawLabel))?.[1];
    if (field && rawValue) values[field] = rawValue.slice(0, 20_000);
  }
  const inferredName = values.name || values.givenName || path.basename(filename, path.extname(filename)) || "Personnage importé";
  const character = createCharacterSheet({ ownerPlayerId, name: inferredName });
  Object.assign(character, values);
  if (values.givenName && !values.name) character.name = values.givenName;
  const numericFields = [
    ["force", ["force"]], ["dexterity", ["dext[eé]rit[eé]"]], ["agility", ["agilit[eé]"]],
    ["spiritSocial", ["esprit social"]], ["intelligence", ["intelligence"]], ["instinct", ["instinct"]]
  ];
  for (const [field, labels] of numericFields) {
    const value = numberAfter(text, labels);
    if (value !== null) character.stats[field] = value;
  }
  const hp = numberAfter(text, ["pv", "points de vie"]);
  const maxHp = numberAfter(text, ["pv max", "points de vie max"]);
  const mana = numberAfter(text, ["mana"]);
  const maxMana = numberAfter(text, ["mana max"]);
  const fatigue = numberAfter(text, ["fatigue"]);
  const speed = numberAfter(text, ["vitesse"]);
  const initiative = numberAfter(text, ["initiative"]);
  const armor = numberAfter(text, ["armure"]);
  if (hp !== null) character.resources.hp = hp;
  if (maxHp !== null) character.resources.maxHp = maxHp;
  if (mana !== null) character.resources.mana = mana;
  if (maxMana !== null) character.resources.maxMana = maxMana;
  if (fatigue !== null) character.fatigue.current = fatigue;
  if (speed !== null) character.speed = speed;
  if (initiative !== null) character.initiativeBonus = initiative;
  if (armor !== null) character.armor = armor;
  const recognized = Object.keys(values).length + numericFields.filter(([field]) => character.stats[field] !== 0).length;
  return {
    character,
    source: { type: "docx", filename: path.basename(filename), extractedCharacters: String(text).length },
    warnings: recognized > 0 ? [] : ["Le document a été lu, mais sa mise en page ne contient pas de libellés reconnus. Vérifiez la fiche préremplie."],
    extractedText: String(text).slice(0, 200_000)
  };
}

export async function importCharacterDocx(filePath, options = {}) {
  if (path.extname(String(filePath)).toLocaleLowerCase("fr") !== ".docx") throw new Error("Seuls les fichiers Word .docx sont acceptés. Enregistrez un ancien .doc au format .docx.");
  const stage = mkdtempSync(path.join(tmpdir(), "xar-docx-"));
  try {
    await extractZipArchive(filePath, stage, {
      maximumEntries: 5_000,
      maximumExpandedSize: 100 * 1024 * 1024
    });
    const documentPath = path.join(stage, "word", "document.xml");
    if (!existsSync(documentPath)) throw new Error("Ce fichier .docx ne contient pas de document Word lisible.");
    const xml = readFileSync(documentPath, "utf8");
    if (Buffer.byteLength(xml) > 25 * 1024 * 1024) throw new Error("Le texte Word dépasse la taille autorisée.");
    return characterDraftFromWordText(docxXmlToText(xml), { ...options, filename: options.filename || path.basename(filePath) });
  } finally {
    rmSync(stage, { recursive: true, force: true });
  }
}
