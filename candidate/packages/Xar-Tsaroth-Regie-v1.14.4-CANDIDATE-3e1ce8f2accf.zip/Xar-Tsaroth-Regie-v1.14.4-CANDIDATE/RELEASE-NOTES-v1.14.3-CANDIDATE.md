# Régie du Seuil 1.14.3 — Candidate launcher économe et relancé

Cette candidate reprend la 1.14.2 et conserve intacte la 1.14.1 stable.

## Launcher

- Les particules de fond sont limitées à 12 images par seconde et la forge du titre à 30 images par seconde pendant l’introduction.
- Les rendus canvas et animations ambiantes sont suspendus lorsque la fenêtre est masquée, puis arrêtés après cinq secondes au repos.
- Après une mise à jour, Windows relance une seule fois l’enveloppe grâce à un marqueur de cycle ; la page recharge aussi explicitement le nouveau build.
- La version affichée ne reste donc plus celle de l’ancien document chargé avant l’installation.

## Livraison

- Version applicative : `1.14.3`.
- Canal : `candidate` jusqu’à validation explicite.
- Le ZIP complet et le paquet d’auto-update restent distincts et sont retestés depuis des extractions neuves avant publication.
- Aucun compte, mot de passe, vérificateur, donnée utilisateur, coffre, webhook ou secret n’est inclus dans les paquets.
