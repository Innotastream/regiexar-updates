const MANAGED_KEYS = [
  "OVH_ENABLED",
  "OVH_FTP_URL",
  "OVH_FTP_USER",
  "OVH_PUBLIC_BASE_URL"
];

const SECRET_KEYS = new Set([
  "PLAYER_ACCESS_CODE",
  "DISCORD_IMAGE_WEBHOOK_URL",
  "DISCORD_DICE_WEBHOOK_URL",
  "DISCORD_JOURNAL_WEBHOOK_URL",
  "OVH_FTP_PASSWORD",
  "PLAYER_LAST_CONNECTION_URL",
  "XAR_SECRET_VAULT_KEY"
]);

const DISCORD_KEYS = {
  images: "DISCORD_IMAGE_WEBHOOK_URL",
  dice: "DISCORD_DICE_WEBHOOK_URL",
  journal: "DISCORD_JOURNAL_WEBHOOK_URL"
};

function textValue(value, maximumLength, label) {
  const text = String(value ?? "").trim();
  if (text.length > maximumLength) throw new Error(`${label} est trop long.`);
  if (/[\0\r\n]/.test(text)) throw new Error(`${label} contient un caractère interdit.`);
  return text;
}

function validDiscordWebhook(value) {
  if (!value) return true;
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:"
      && new Set(["discord.com", "www.discord.com", "discordapp.com", "www.discordapp.com"]).has(parsed.hostname)
      && /^\/api\/webhooks\/[^/]+\/[^/]+\/?$/.test(parsed.pathname)
      && !parsed.username
      && !parsed.password;
  } catch {
    return false;
  }
}

function validOvhStorageUrl(value) {
  if (!value) return true;
  try {
    const parsed = new URL(value);
    if (!new Set(["sftp:", "ftps:", "ftp:"]).has(parsed.protocol) || !parsed.hostname) return false;
    const normalizedPath = decodeURIComponent(parsed.pathname).replaceAll("\\", "/").replace(/\/+$/, "");
    return Boolean(normalizedPath && normalizedPath !== "/" && !/(?:^|\/)www$/i.test(normalizedPath));
  } catch {
    return false;
  }
}

function validPublicBaseUrl(value) {
  if (!value) return true;
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:" && Boolean(parsed.hostname) && !parsed.username && !parsed.password;
  } catch {
    return false;
  }
}

function ovhConfigurationEnabled(values) {
  const flag = String(values.OVH_ENABLED ?? "");
  if (flag === "true") return true;
  if (flag === "false") return false;
  return Boolean(values.OVH_FTP_URL || values.OVH_FTP_USER || values.OVH_FTP_PASSWORD || values.OVH_PUBLIC_BASE_URL);
}

export function parseEnvironmentText(text) {
  const values = {};
  for (const rawLine of String(text ?? "").split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const separator = line.indexOf("=");
    if (separator < 1) continue;
    const key = line.slice(0, separator).trim();
    if (!/^[A-Z_][A-Z0-9_]*$/i.test(key)) continue;
    const encoded = line.slice(separator + 1).trim();
    let value = encoded;
    if (encoded.startsWith('"')) {
      try { value = JSON.parse(encoded); } catch { value = encoded.slice(1, encoded.endsWith('"') ? -1 : undefined); }
    } else if (encoded.startsWith("'") && encoded.endsWith("'")) {
      value = encoded.slice(1, -1);
    }
    values[key] = String(value ?? "");
  }
  return values;
}

export function serializeEnvironment(values) {
  const lines = [
    "# Configuration privée créée par l’assistant de la Régie du Seuil.",
    "# Modifiez-la depuis l’application : elle n’est jamais incluse dans une mise à jour.",
    ""
  ];
  const ordered = [...new Set(["PORT", ...MANAGED_KEYS, ...Object.keys(values).sort()])];
  for (const key of ordered) {
    if (!(key in values) || SECRET_KEYS.has(key) || !/^[A-Z_][A-Z0-9_]*$/i.test(key)) continue;
    lines.push(`${key}=${JSON.stringify(String(values[key] ?? ""))}`);
  }
  return `${lines.join("\n")}\n`;
}

export function validateConfiguration(values, { fileExists = true } = {}) {
  const issues = [];

  for (const [name, key] of Object.entries(DISCORD_KEYS)) {
    const value = String(values[key] ?? "").trim();
    if (!validDiscordWebhook(value)) issues.push({ field: `discord.${name}`, message: "Ce webhook Discord n’est pas une adresse de webhook HTTPS valide." });
  }

  const ovhUrl = String(values.OVH_FTP_URL ?? "").trim();
  const ovhUser = String(values.OVH_FTP_USER ?? "").trim();
  const ovhPassword = String(values.OVH_FTP_PASSWORD ?? "");
  const ovhPublicBaseUrl = String(values.OVH_PUBLIC_BASE_URL ?? "").trim();
  const ovhEnabled = ovhConfigurationEnabled(values);
  if (ovhEnabled) {
    if (!ovhUrl) issues.push({ field: "ovh.url", message: "Indiquez l’adresse SFTP/FTPS OVH." });
    else if (!validOvhStorageUrl(ovhUrl)) issues.push({ field: "ovh.url", message: "L’adresse OVH doit viser un dossier SFTP/FTPS précis, jamais la racine ni www." });
    if (!ovhUser) issues.push({ field: "ovh.user", message: "Indiquez l’identifiant OVH." });
    if (!ovhPassword) issues.push({ field: "ovh.password", message: "Indiquez le mot de passe OVH." });
    if (!validPublicBaseUrl(ovhPublicBaseUrl)) issues.push({ field: "ovh.publicBaseUrl", message: "L’adresse publique OVH doit utiliser HTTPS." });
  }
  return { valid: issues.length === 0, issues };
}

export function publicConfigurationStatus(values, { fileExists = true } = {}) {
  const validation = validateConfiguration(values, { fileExists });
  return {
    ready: validation.valid,
    needsSetup: !validation.valid,
    issues: validation.issues,
    storageFormat: "json+vault",
    discord: Object.fromEntries(Object.entries(DISCORD_KEYS).map(([name, key]) => [name, { configured: Boolean(String(values[key] ?? "").trim()) }])),
    ovh: {
      enabled: ovhConfigurationEnabled(values),
      configured: Boolean(String(values.OVH_FTP_URL ?? "").trim() && String(values.OVH_FTP_USER ?? "").trim() && String(values.OVH_FTP_PASSWORD ?? "")),
      url: String(values.OVH_FTP_URL ?? "").trim(),
      user: String(values.OVH_FTP_USER ?? "").trim(),
      passwordConfigured: Boolean(String(values.OVH_FTP_PASSWORD ?? "")),
      publicBaseUrl: String(values.OVH_PUBLIC_BASE_URL ?? "").trim()
    }
  };
}

export function mergeConfigurationInput(input, currentValues = {}) {
  const next = { ...currentValues, PORT: "4173" };

  for (const [name, key] of Object.entries(DISCORD_KEYS)) {
    const entry = input?.discord?.[name] ?? {};
    next[key] = entry.enabled === false
      ? ""
      : textValue(entry.value, 2048, `Le webhook Discord ${name}`) || String(currentValues[key] ?? "").trim();
  }

  const ovh = input?.ovh ?? {};
  if (ovh.enabled === false) {
    next.OVH_ENABLED = "false";
    for (const key of ["OVH_FTP_URL", "OVH_FTP_USER", "OVH_FTP_PASSWORD", "OVH_PUBLIC_BASE_URL"]) next[key] = "";
  } else {
    next.OVH_ENABLED = "true";
    next.OVH_FTP_URL = textValue(ovh.url, 2048, "L’adresse OVH") || String(currentValues.OVH_FTP_URL ?? "").trim();
    next.OVH_FTP_USER = textValue(ovh.user, 256, "L’identifiant OVH") || String(currentValues.OVH_FTP_USER ?? "").trim();
    next["OVH_FTP_PASSWORD"] = textValue(ovh.password, 4096, "Le mot de passe OVH") || String(currentValues["OVH_FTP_PASSWORD"] ?? "");
    next.OVH_PUBLIC_BASE_URL = textValue(ovh.publicBaseUrl, 2048, "L’adresse publique OVH") || String(currentValues.OVH_PUBLIC_BASE_URL ?? "").trim();
  }

  const validation = validateConfiguration(next, { fileExists: true });
  if (!validation.valid) {
    const error = new Error(validation.issues.map((issue) => issue.message).join(" "));
    error.issues = validation.issues;
    throw error;
  }
  return next;
}

export function parseConfigurationJson(text) {
  const parsed = JSON.parse(String(text ?? "{}"));
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Configuration JSON invalide.");
  const values = parsed.values && typeof parsed.values === "object" ? parsed.values : parsed;
  return Object.fromEntries(Object.entries(values).filter(([key, value]) => (
    /^[A-Z_][A-Z0-9_]*$/i.test(key) && typeof value === "string" && !SECRET_KEYS.has(key)
  )));
}

export function serializeConfigurationJson(values) {
  const publicValues = Object.fromEntries(Object.entries(values ?? {}).filter(([key, value]) => (
    /^[A-Z_][A-Z0-9_]*$/i.test(key) && typeof value === "string" && !SECRET_KEYS.has(key)
  )));
  return `${JSON.stringify({ schemaVersion: 1, values: publicValues }, null, 2)}\n`;
}
