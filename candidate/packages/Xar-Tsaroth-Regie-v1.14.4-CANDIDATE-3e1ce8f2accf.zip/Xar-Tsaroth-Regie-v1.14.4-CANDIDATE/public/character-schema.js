export const CHARACTER_SCHEMA_ID = "xar-tsaroth.character-sheet";
export const CHARACTER_SCHEMA_VERSION = 2;

export class UnsupportedCharacterSchemaVersionError extends Error {
  constructor(version) {
    super(`Cette fiche provient d’une version plus récente de la Régie. Elle a été conservée intacte : mettez l’application à jour pour l’ouvrir (format ${version}, format pris en charge ${CHARACTER_SCHEMA_VERSION}).`);
    this.name = "UnsupportedCharacterSchemaVersionError";
    this.version = version;
  }
}

function plainObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function finiteNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function clone(value) {
  return value === undefined ? undefined : structuredClone(value);
}

function migrateVersion0To1(source, ownerPlayerId) {
  const resources = plainObject(source.resources);
  const fatigue = plainObject(source.fatigue);
  const secret = plainObject(source.secret);
  const next = {
    ...source,
    characterSchema: CHARACTER_SCHEMA_ID,
    characterSchemaVersion: 1,
    ownerPlayerId: source.ownerPlayerId ?? ownerPlayerId ?? null,
    resources: {
      hp: finiteNumber(resources.hp ?? source.hp),
      maxHp: finiteNumber(resources.maxHp ?? source.maxHp),
      mana: finiteNumber(resources.mana ?? source.mana),
      maxMana: finiteNumber(resources.maxMana ?? source.maxMana)
    },
    stats: { ...plainObject(source.stats) },
    fatigue: {
      current: finiteNumber(fatigue.current ?? source.fatigueCurrent),
      max: finiteNumber(fatigue.max ?? source.fatigueMax, 100)
    },
    secret: {
      mentalResistance: finiteNumber(secret.mentalResistance ?? source.mentalResistance),
      mentalResistanceMax: finiteNumber(secret.mentalResistanceMax ?? source.mentalResistanceMax, 100),
      notes: String(secret.notes ?? source.privateNotes ?? "")
    },
    conditions: Array.isArray(source.conditions) ? [...source.conditions] : [],
    shortcuts: Array.isArray(source.shortcuts) ? [...source.shortcuts] : []
  };

  for (const legacyKey of [
    "hp", "maxHp", "mana", "maxMana", "fatigueCurrent", "fatigueMax",
    "mentalResistance", "mentalResistanceMax", "privateNotes"
  ]) delete next[legacyKey];
  return next;
}

const migrations = new Map([
  [0, migrateVersion0To1],
  [1, (source) => ({
    ...source,
    characterSchemaVersion: 2,
    linkedTokens: normalizeLinkedTokens(source.linkedTokens)
  })]
]);

export function normalizeLinkedTokens(value) {
  if (!Array.isArray(value)) return [];
  const seen = new Set();
  return value.slice(0, 200).map((entry, index) => {
    const source = plainObject(entry);
    const fallbackId = `linked-token-${index + 1}`;
    const id = String(source.id || fallbackId).replace(/[^a-zA-Z0-9_-]+/g, "-").slice(0, 120) || fallbackId;
    const uniqueId = seen.has(id) ? `${id}-${index + 1}` : id;
    seen.add(uniqueId);
    return {
      id: uniqueId,
      name: String(source.name || "Invocation").slice(0, 120),
      kind: ["pet", "summon", "companion"].includes(source.kind) ? source.kind : "summon",
      image: source.image ? String(source.image).slice(0, 2_000_000) : null,
      color: /^#[0-9a-f]{6}$/i.test(String(source.color || "")) ? String(source.color) : "#8d72cb",
      size: Math.min(220, Math.max(10, finiteNumber(source.size, 30)))
    };
  });
}

export function createCharacterSheet({ id, ownerPlayerId, name = "Nouveau personnage", color = "#8d72cb", now = Date.now() } = {}) {
  const safeName = String(name || "Nouveau personnage").trim().slice(0, 120) || "Nouveau personnage";
  return {
    characterSchema: CHARACTER_SCHEMA_ID,
    characterSchemaVersion: CHARACTER_SCHEMA_VERSION,
    id: String(id || `character-${globalThis.crypto.randomUUID()}`),
    ownerPlayerId: ownerPlayerId ?? null,
    name: safeName,
    surname: "",
    givenName: safeName,
    race: "",
    age: "",
    className: "",
    advancedClass: "",
    profession: "",
    previousProfession: "",
    pronouns: "",
    portrait: null,
    color: /^#[0-9a-f]{6}$/i.test(String(color)) ? String(color) : "#8d72cb",
    resources: { hp: 0, maxHp: 0, mana: 0, maxMana: 0 },
    stats: { force: 0, dexterity: 0, agility: 0, spiritSocial: 0, intelligence: 0, instinct: 0 },
    fatigue: { current: 0, max: 100 },
    morale: "",
    armor: 0,
    speed: 0,
    initiativeBonus: 0,
    personalAdvantageStock: 0,
    armorText: "",
    weaponText: "",
    passives: "",
    skills: "",
    specialSkills: "",
    languages: "",
    inventory: "",
    publicNotes: "",
    conditions: [],
    linkedTokens: [],
    secret: { mentalResistance: 0, mentalResistanceMax: 100, notes: "" },
    shortcuts: [
      { id: `shortcut-${globalThis.crypto.randomUUID()}`, label: "Initiative", formula: "1d100+0", kind: "initiative", visibility: "public" },
      { id: `shortcut-${globalThis.crypto.randomUUID()}`, label: "Perception", formula: "1d100+0", kind: "roll", visibility: "public" }
    ],
    _updatedAt: Number(now) || Date.now()
  };
}

export function characterSchemaVersion(value) {
  const parsed = Number(value?.characterSchemaVersion ?? 0);
  return Number.isInteger(parsed) && parsed >= 0 ? parsed : 0;
}

export function migrateCharacterSheet(value, { ownerPlayerId = null } = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError("Une fiche de personnage doit être un objet JSON.");
  }

  const fromVersion = characterSchemaVersion(value);
  if (fromVersion > CHARACTER_SCHEMA_VERSION) {
    throw new UnsupportedCharacterSchemaVersionError(fromVersion);
  }

  let currentVersion = fromVersion;
  let character = clone(value);
  const appliedMigrations = [];
  while (currentVersion < CHARACTER_SCHEMA_VERSION) {
    const migration = migrations.get(currentVersion);
    if (!migration) throw new Error(`Migration de fiche manquante pour le schéma ${currentVersion}.`);
    character = migration(character, ownerPlayerId);
    appliedMigrations.push(`${currentVersion}->${currentVersion + 1}`);
    currentVersion += 1;
  }

  character.characterSchema = CHARACTER_SCHEMA_ID;
  character.characterSchemaVersion = CHARACTER_SCHEMA_VERSION;
  character.linkedTokens = normalizeLinkedTokens(character.linkedTokens);
  if (ownerPlayerId !== null) character.ownerPlayerId = ownerPlayerId;
  return {
    character,
    fromVersion,
    toVersion: CHARACTER_SCHEMA_VERSION,
    appliedMigrations,
    changed: appliedMigrations.length > 0 || value.characterSchema !== CHARACTER_SCHEMA_ID
  };
}
