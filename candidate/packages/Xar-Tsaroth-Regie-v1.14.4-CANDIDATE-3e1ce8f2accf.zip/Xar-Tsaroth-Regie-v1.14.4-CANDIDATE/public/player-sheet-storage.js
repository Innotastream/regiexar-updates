import { migrateCharacterSheet } from "./character-schema.js";

const DATABASE_NAME = "xar-tsaroth-player-sheets";
const STORE_NAME = "drafts";

function cloneSheet(character) {
  const migrated = migrateCharacterSheet(structuredClone(character), { ownerPlayerId: character.ownerPlayerId }).character;
  delete migrated.accessToken;
  delete migrated.token;
  return migrated;
}

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, 1);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) database.createObjectStore(STORE_NAME, { keyPath: "key" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Stockage local indisponible."));
  });
}

function transactionRequest(database, mode, operation) {
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, mode);
    const request = operation(transaction.objectStore(STORE_NAME));
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Écriture locale impossible."));
  });
}

export class PlayerSheetStorage {
  constructor(namespace) {
    this.namespace = String(namespace || "player").replace(/[^a-zA-Z0-9_.:-]+/g, "-").slice(0, 240);
    this.databasePromise = typeof indexedDB === "undefined" ? Promise.resolve(null) : openDatabase().catch(() => null);
    this.nativeStorage = globalThis.xarDesktop?.loadPlayerSheets && globalThis.xarDesktop?.savePlayerSheet ? globalThis.xarDesktop : null;
    this.writeChain = Promise.resolve();
    globalThis.navigator?.storage?.persist?.().catch(() => false);
  }

  key(characterId) {
    return `${this.namespace}:${String(characterId)}`;
  }

  journalKey(characterId) {
    return `xar-player-sheet-journal:${this.key(characterId)}`;
  }

  saveDraft(character, { pending = true } = {}) {
    const sheet = cloneSheet(character);
    const record = { key: this.key(sheet.id), character: sheet, pending: Boolean(pending), savedAt: Date.now() };
    if (pending) {
      try { localStorage.setItem(this.journalKey(sheet.id), JSON.stringify(record)); }
      catch {
        try { localStorage.setItem(this.journalKey(sheet.id), JSON.stringify({ ...record, character: { ...sheet, portrait: null } })); }
        catch {}
      }
    }
    this.writeChain = this.writeChain.then(async () => {
      if (this.nativeStorage) await this.nativeStorage.savePlayerSheet(this.namespace, sheet, Boolean(pending)).catch(() => null);
      const database = await this.databasePromise;
      if (database) await transactionRequest(database, "readwrite", (store) => store.put(record));
    }).catch(() => {});
    return this.writeChain;
  }

  async markSynced(character) {
    try { localStorage.removeItem(this.journalKey(character.id)); } catch {}
    return this.saveDraft(character, { pending: false });
  }

  async loadDrafts() {
    const records = new Map();
    if (this.nativeStorage) {
      const nativeRecords = await this.nativeStorage.loadPlayerSheets(this.namespace).catch(() => []);
      for (const record of nativeRecords) if (record?.key?.startsWith(`${this.namespace}:`)) records.set(record.key, record);
    }
    const database = await this.databasePromise;
    if (database) {
      const all = await transactionRequest(database, "readonly", (store) => store.getAll()).catch(() => []);
      for (const record of all) if (record?.key?.startsWith(`${this.namespace}:`)) records.set(record.key, record);
    }
    try {
      const prefix = `xar-player-sheet-journal:${this.namespace}:`;
      for (let index = 0; index < localStorage.length; index += 1) {
        const key = localStorage.key(index);
        if (!key?.startsWith(prefix)) continue;
        const record = JSON.parse(localStorage.getItem(key) || "null");
        const previous = records.get(record?.key);
        if (record?.character && (!previous || Number(record.savedAt) >= Number(previous.savedAt))) records.set(record.key, record);
      }
    } catch {}
    return [...records.values()].flatMap((record) => {
      try { return [{ ...record, character: cloneSheet(record.character) }]; }
      catch { return []; }
    });
  }
}
