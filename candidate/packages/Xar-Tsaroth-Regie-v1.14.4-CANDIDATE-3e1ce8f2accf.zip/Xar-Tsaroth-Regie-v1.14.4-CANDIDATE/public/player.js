import { clamp, computeMapGeometry, mapPointFromClient } from "./map-geometry.js";
import { DEFAULT_TOKEN_SIZE } from "./combat-standards.js";
import { normalizeLinkedTokens } from "./character-schema.js";
import { PlayerSheetStorage } from "./player-sheet-storage.js";
import { evaluateTacticalExpression } from "./tactical-calculator.js";

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const escapeHtml = (value = "") => String(value)
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#039;");

let authenticatedIdentity = null;
let sheetStorage = null;
let state = null;
let lastRevision = -1;
let selectedCharacterId = "";
let eventSource = null;
let draggingTokenId = null;
let audioActivated = false;
let sheetSaveTimer = null;
let sheetChangeVersion = 0;
let localDraftsLoaded = false;
const dirtyCharacterPaths = new Map();
const renderedTokenPositions = new Map();
const playerAudio = { music: new Audio(), ambience: new Audio() };
const SILENT_AUDIO_DATA = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQQAAACAgICA";
const audioPreferences = (() => {
  try { return { musicMuted: false, ambienceMuted: false, ...JSON.parse(localStorage.getItem("xar-player-audio-preferences") || "{}") }; }
  catch { return { musicMuted: false, ambienceMuted: false }; }
})();
playerAudio.music.preload = "auto";
playerAudio.ambience.preload = "auto";
playerAudio.ambience.loop = true;

function initials(name) {
  return String(name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("") || "?";
}

function authenticatedUrl(url) {
  return new URL(url, location.origin);
}

async function api(url, options = {}) {
  const fetchOptions = { method: options.method || "GET", headers: {}, credentials: "same-origin" };
  if (options.rawBody !== undefined) {
    fetchOptions.body = options.rawBody;
    if (options.contentType) fetchOptions.headers["Content-Type"] = options.contentType;
    if (options.filename) fetchOptions.headers["X-Xar-Filename"] = options.filename;
  } else if (options.body !== undefined) {
    fetchOptions.headers["Content-Type"] = "application/json";
    fetchOptions.body = JSON.stringify(options.body);
  }
  const response = await fetch(authenticatedUrl(url), fetchOptions);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok === false) {
    const error = new Error(payload.error || `Erreur ${response.status}`);
    error.status = response.status;
    throw error;
  }
  return payload;
}

function currentToken() {
  if (state?.initiative?.active !== true) return null;
  if (state?.initiative && Object.prototype.hasOwnProperty.call(state.initiative, "currentTokenId")) {
    const explicit = state.initiative.currentTokenId;
    return explicit ? state.map?.tokens?.find((token) => token.id === explicit) ?? null : null;
  }
  const order = state?.initiative?.order ?? [];
  const index = clamp(Number(state?.initiative?.currentIndex ?? 0), 0, Math.max(0, order.length - 1));
  return state?.map?.tokens?.find((token) => token.id === order[index]) ?? null;
}

function applyPlayerMapViewport() {
  const battlefield = $("#playerBattlefield");
  const world = $("#playerMapWorld");
  if (!battlefield || !world || !state?.map) return;
  const geometry = computeMapGeometry(battlefield.clientWidth, battlefield.clientHeight, state.map);
  world.style.width = `${geometry.fitWidth}px`;
  world.style.height = `${geometry.fitHeight}px`;
  world.style.left = `${geometry.centerX}px`;
  world.style.top = `${geometry.centerY}px`;
  world.style.transform = `translate(-50%, -50%) scale(${geometry.zoom})`;
  world.style.setProperty("--grid-size", `${geometry.gridBaseSize}px`);
  world.style.setProperty("--grid-offset-x", `${geometry.gridOffsetBaseX}px`);
  world.style.setProperty("--grid-offset-y", `${geometry.gridOffsetBaseY}px`);
  world.style.setProperty("--grid-opacity", String(Number(state.map.gridOpacity ?? 28) / 100));
}

function renderMap() {
  const battlefield = $("#playerBattlefield");
  const map = state.map ?? {};
  const locked = state.tacticalLocked === true;
  battlefield.classList.toggle("grid-enabled", Boolean(map.grid));
  battlefield.classList.toggle("has-map", Boolean(map.background));
  battlefield.classList.toggle("tactical-locked", locked);
  $("#playerTacticalLock").classList.toggle("hidden", !locked);
  const movementMode = state?.initiative?.active === true && state.playerMovementMode === "combat" ? "combat" : "free";
  $("#playerMovementMode").textContent = locked
    ? "Déplacements verrouillés"
    : movementMode === "free" ? "Mode libre" : "Mode combat";
  $("#playerMovementMode").className = `status-badge ${locked ? "warning" : movementMode === "free" ? "success" : "neutral"}`;
  $("#playerMapWorld").classList.toggle("grid-enabled", Boolean(map.grid));
  $("#playerMapWorldImage").src = map.background || "";
  $("#playerMapWorldImage").classList.toggle("hidden", !map.background);
  $("#playerMapEmpty").classList.toggle("hidden", Boolean(map.background));
  applyPlayerMapViewport();
  renderPlayerTokenLayer();
  renderPlayerPings();
}

function renderPlayerPings() {
  const now = Date.now();
  $("#playerPingLayer").innerHTML = (state.mapPings ?? [])
    .filter((ping) => Number(ping.expiresAt || 0) > now)
    .map((ping) => `<span class="map-ping" style="--ping-x:${Number(ping.x)}%;--ping-y:${Number(ping.y)}%;--ping-color:${escapeHtml(ping.color || "#ffd782")};--ping-life:${Math.max(300, Number(ping.expiresAt) - now)}ms"><i></i><strong>${escapeHtml(ping.author || "Signal")}</strong></span>`)
    .join("");
}

function renderPlayerTokenLayer() {
  if (draggingTokenId) return;
  const layer = $("#playerTokenLayer");
  const currentId = currentToken()?.id;
  layer.innerHTML = (state.map?.tokens ?? []).map((token) => {
    const hpPercent = token.maxHp > 0 ? clamp((Number(token.hp) / Number(token.maxHp)) * 100, 0, 100) : 100;
    const manaPercent = token.maxMana > 0 ? clamp((Number(token.mana) / Number(token.maxMana)) * 100, 0, 100) : 100;
    const previous = renderedTokenPositions.get(token.id) ?? token;
    const title = token.controllable
      ? "Vous pouvez déplacer ce token"
      : token.ownedByYou && state.tacticalLocked ? "Le MJ a temporairement verrouillé la table"
      : token.ownedByYou ? "Ce token pourra être déplacé à son tour de jeu"
      : token.detailsVisible ? `${token.name} · PV ${token.hp ?? 0}/${token.maxHp ?? 0} · Mana ${token.mana ?? 0}/${token.maxMana ?? 0}` : token.name;
    return `<div class="map-token ${token.id === currentId ? "current-turn" : ""} ${token.controllable ? "controllable" : ""} ${token.ownedByYou && !token.controllable ? "owned-waiting" : ""}" data-player-token="${escapeHtml(token.id)}" style="--token-x:${previous.x}%;--token-y:${previous.y}%;--token-size:${token.size || DEFAULT_TOKEN_SIZE}px;--token-color:${escapeHtml(token.color || "#8d72cb")};--token-hp:${hpPercent}%;--token-mana:${manaPercent}%" title="${escapeHtml(title)}">
      <span class="token-core">${token.image ? `<img src="${token.image}" alt="" draggable="false" />` : escapeHtml(initials(token.name))}</span>
      ${token.detailsVisible && token.maxHp > 0 ? `<span class="token-hp"><i></i></span>` : ""}
      ${token.detailsVisible && token.maxMana > 0 ? `<span class="token-mana"><i></i></span>` : ""}
      <span class="token-name">${escapeHtml(token.name)}</span>
      ${token.ownedByYou ? `<span class="token-control-badge ${token.controllable ? "" : "waiting"}">${token.controllable ? "À vous" : "En attente"}</span>` : ""}
    </div>`;
  }).join("");
  $$('[data-player-token]', layer).forEach((element) => {
    const token = state.map.tokens.find((entry) => entry.id === element.dataset.playerToken);
    if (!token) return;
    if (token.controllable && !state.tacticalLocked) bindPlayerTokenDrag(element, token);
    requestAnimationFrame(() => {
      element.style.setProperty("--token-x", `${token.x}%`);
      element.style.setProperty("--token-y", `${token.y}%`);
    });
    renderedTokenPositions.set(token.id, { x: token.x, y: token.y });
  });
  for (const id of [...renderedTokenPositions.keys()]) if (!state.map.tokens.some((token) => token.id === id)) renderedTokenPositions.delete(id);
}

function bindPlayerTokenDrag(element, token) {
  element.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    draggingTokenId = token.id;
    element.setPointerCapture?.(event.pointerId);
    element.classList.add("dragging", "selected");
    const move = (moveEvent) => {
      const point = mapPointFromClient(moveEvent.clientX, moveEvent.clientY, $("#playerMapWorld").getBoundingClientRect(), state.map);
      token.x = point.x;
      token.y = point.y;
      element.style.setProperty("--token-x", `${token.x}%`);
      element.style.setProperty("--token-y", `${token.y}%`);
    };
    const end = async () => {
      element.removeEventListener("pointermove", move);
      element.removeEventListener("pointerup", end);
      element.removeEventListener("pointercancel", end);
      element.classList.remove("dragging");
      draggingTokenId = null;
      renderedTokenPositions.set(token.id, { x: token.x, y: token.y });
      setSyncStatus("Envoi du déplacement…", "warning");
      try {
        const response = await api("/api/session/token", { method: "PATCH", body: { tokenId: token.id, x: token.x, y: token.y } });
        lastRevision = Number(response.revision ?? lastRevision);
        setSyncStatus("Position synchronisée", "success");
        await poll({ force: true });
      } catch (error) {
        showError(error.message, { blocking: false });
        await poll({ force: true });
      }
    };
    element.addEventListener("pointermove", move);
    element.addEventListener("pointerup", end);
    element.addEventListener("pointercancel", end);
  });
}

function renderInitiative() {
  const combatActive = state.initiative?.active === true;
  const current = currentToken();
  $("#playerCurrentTurnLabel").textContent = combatActive ? "Tour en cours" : "Mode de jeu";
  $("#playerCurrentTurn").textContent = current?.name || (combatActive ? "En attente" : "Mode libre");
  $("#playerCurrentTurnMeta").textContent = current
    ? `Initiative d100 : ${current.initiative ?? "—"}${current.condition ? ` · ${current.condition}` : ""}`
    : combatActive ? "Le MJ prépare la séquence." : "Aucun tour actif · les déplacements sont libres.";
  const tokensById = new Map((state.map?.tokens ?? []).map((token) => [token.id, token]));
  const visibleOrder = (state.initiative?.order ?? []).filter((id) => tokensById.has(id));
  $("#playerInitiativeList").innerHTML = visibleOrder.map((id, index) => {
    const token = tokensById.get(id);
    const avatar = token.image ? `<img src="${token.image}" alt="" />` : escapeHtml(initials(token.name));
    return `<div class="initiative-entry ${id === current?.id ? "current" : ""}" style="--token-color:${escapeHtml(token.color || "#8d72cb")}">
      <span class="initiative-rank">${index + 1}</span><span class="initiative-avatar">${avatar}</span>
      <span class="initiative-name"><strong>${escapeHtml(token.name)}</strong><small>${escapeHtml(token.condition || "Prêt")}</small></span>
      <strong class="initiative-score">${token.initiative ?? "—"}</strong>
    </div>`;
  }).join("") || `<div class="empty-state small"><small>Aucune initiative préparée. Les tokens peuvent rester hors combat.</small></div>`;
}

function playerActionTimerStatus(timer) {
  const round = Math.max(1, Number(state.initiative?.round) || 1);
  const remaining = Math.max(0, Number(timer.readyRound) - round);
  return {
    ready: remaining === 0,
    remaining,
    label: remaining === 0 ? "Disponible" : `Disponible au round ${timer.readyRound} · ${remaining} tour${remaining > 1 ? "s" : ""}`
  };
}

function renderActionTimers() {
  const form = $("#playerTimerForm");
  const characters = state.myCharacters ?? [];
  const locked = state.tacticalLocked === true || state.initiative?.active !== true;
  form.classList.toggle("hidden", !characters.length);
  if (characters.length) {
    const select = $("#playerTimerCharacter");
    const selected = select.value || selectedCharacterId || characters[0].id;
    select.innerHTML = characters.map((character) => `<option value="${escapeHtml(character.id)}" ${character.id === selected ? "selected" : ""}>${escapeHtml(character.name)}</option>`).join("");
    $$('input, select, button', form).forEach((control) => { control.disabled = locked; });
    form.title = state.tacticalLocked ? "Le MJ a temporairement verrouillé la table." : state.initiative?.active !== true ? "Aucun combat en cours." : "";
  }
  const timers = state.actionTimers ?? [];
  $("#playerActionTimerList").innerHTML = timers.map((timer) => {
    const status = playerActionTimerStatus(timer);
    return `<article class="action-timer-card ${status.ready ? "ready" : "cooling"}"><div class="action-timer-glyph">${status.ready ? "✓" : status.remaining}</div><span class="action-timer-copy"><strong>${escapeHtml(timer.ownerLabel)} · ${escapeHtml(timer.label)}</strong><small>${escapeHtml(status.label)} · recharge ${timer.cooldown}</small><em>${timer.visibility === "public" ? "Visible de tous" : "Votre rappel privé"}</em></span>${timer.ownedByYou ? `<span class="action-timer-actions"><button type="button" data-player-reuse-timer="${escapeHtml(timer.id)}" ${locked ? "disabled" : ""} title="L’action vient d’être réutilisée">↻</button><button type="button" data-player-remove-timer="${escapeHtml(timer.id)}" title="Supprimer">×</button></span>` : ""}</article>`;
  }).join("") || `<div class="empty-state small"><small>Aucune action en recharge.</small></div>`;
  $$('[data-player-reuse-timer]').forEach((button) => button.addEventListener("click", () => reusePlayerActionTimer(button.dataset.playerReuseTimer)));
  $$('[data-player-remove-timer]').forEach((button) => button.addEventListener("click", () => removePlayerActionTimer(button.dataset.playerRemoveTimer)));
}

async function reusePlayerActionTimer(timerId) {
  try {
    const response = await api("/api/session/timer", { method: "PATCH", body: { timerId } });
    lastRevision = Number(response.revision ?? lastRevision);
    setSyncStatus("Recharge mise à jour", "success");
    await poll({ force: true });
  } catch (error) { showError(error.message, { blocking: false }); }
}

async function removePlayerActionTimer(timerId) {
  if (!confirm("Supprimer ce rappel de recharge ?")) return;
  try {
    const response = await api(`/api/session/timer?timerId=${encodeURIComponent(timerId)}`, { method: "DELETE" });
    lastRevision = Number(response.revision ?? lastRevision);
    await poll({ force: true });
  } catch (error) { showError(error.message, { blocking: false }); }
}

function renderRolls() {
  $("#playerRollHistory").innerHTML = (state.rolls ?? []).slice(0, 10).map((roll) => `<div class="roll-entry"><span><span class="roll-author">${escapeHtml(roll.rollerName || "MJ")}</span> · ${escapeHtml(roll.characterName ? `${roll.characterName} · ${roll.label}` : roll.label)}<small>${escapeHtml(roll.formula)} · ${escapeHtml(roll.breakdown)}</small></span><strong>${roll.total}</strong></div>`).join("") || `<div class="empty-state small"><small>Aucun jet révélé.</small></div>`;
}

function characterForm(character) {
  const portrait = character.portrait ? `<img src="${character.portrait}" alt="Portrait de ${escapeHtml(character.name)}" />` : `<span>${escapeHtml(initials(character.name))}</span>`;
  const conditions = (character.conditions ?? []).join(", ");
  const shortcuts = (character.shortcuts ?? []).map((shortcut) => `<div class="shortcut-editor-row" data-player-shortcut="${escapeHtml(shortcut.id)}">
    <input data-shortcut-field="label" value="${escapeHtml(shortcut.label)}" aria-label="Nom du raccourci" />
    <input data-shortcut-field="formula" value="${escapeHtml(shortcut.formula)}" aria-label="Formule" />
    <select data-shortcut-field="kind"><option value="roll" ${shortcut.kind === "roll" ? "selected" : ""}>Test d100</option><option value="initiative" ${shortcut.kind === "initiative" ? "selected" : ""}>Initiative d100</option><option value="damage" ${shortcut.kind === "damage" ? "selected" : ""}>Dégâts libres</option></select>
    <button type="button" class="icon-button danger" data-remove-player-shortcut="${escapeHtml(shortcut.id)}">×</button>
  </div>`).join("");
  const quickRolls = (character.shortcuts ?? []).map((shortcut) => `<button type="button" class="dice-chip player-roll-chip ${shortcut.kind === "initiative" ? "initiative-chip" : ""}" data-roll-player-shortcut="${escapeHtml(shortcut.id)}"><strong>${escapeHtml(shortcut.label)}</strong><small>${escapeHtml(shortcut.formula)}</small></button>`).join("");
  const linkedTokens = normalizeLinkedTokens(character.linkedTokens).map((token) => `<div class="linked-token-editor-row player-linked-token-row" data-player-linked-token="${escapeHtml(token.id)}">
    <input data-player-linked-field="name" value="${escapeHtml(token.name)}" aria-label="Nom du token lié" />
    <select data-player-linked-field="kind" aria-label="Type"><option value="summon" ${token.kind === "summon" ? "selected" : ""}>Invocation</option><option value="pet" ${token.kind === "pet" ? "selected" : ""}>Familier</option><option value="companion" ${token.kind === "companion" ? "selected" : ""}>Compagnon</option></select>
    <input data-player-linked-field="image" type="url" value="${escapeHtml(token.image || "")}" placeholder="Lien d’image" aria-label="Lien d’image" />
    <input data-player-linked-field="color" type="color" value="${escapeHtml(token.color)}" aria-label="Couleur" />
    <input data-player-linked-field="size" type="number" min="10" max="220" value="${token.size}" aria-label="Taille" />
    <button type="button" class="icon-button danger" data-remove-player-linked-token="${escapeHtml(token.id)}" aria-label="Supprimer ce token lié">×</button>
  </div>`).join("");
  return `<form id="playerCharacterForm" class="character-sheet-editor player-character-editor" style="--sheet-color:${escapeHtml(character.color || "#8d72cb")}">
    <section class="sheet-section identity-section"><div class="sheet-section-title"><span>Identité du personnage</span><small>Visible uniquement par vous et le MJ</small></div>
      <div class="portrait-editor"><label class="portrait-large player-portrait-upload" style="--player-color:${escapeHtml(character.color || "#8d72cb")}">${portrait}<input id="playerPortraitFile" type="file" accept="image/*" hidden /><small>Changer</small></label>
        <div class="identity-grid">
          <label>Nom affiché<input data-character-path="name" value="${escapeHtml(character.name)}" /></label><label>Couleur<input data-character-path="color" type="color" value="${escapeHtml(character.color || "#8d72cb")}" /></label>
          <label>Nom de famille<input data-character-path="surname" value="${escapeHtml(character.surname)}" /></label><label>Prénom<input data-character-path="givenName" value="${escapeHtml(character.givenName)}" /></label>
          <label>Race<input data-character-path="race" value="${escapeHtml(character.race)}" /></label><label>Âge<input data-character-path="age" value="${escapeHtml(character.age)}" /></label>
          <label>Classe<input data-character-path="className" value="${escapeHtml(character.className)}" /></label><label>Classe avancée<input data-character-path="advancedClass" value="${escapeHtml(character.advancedClass)}" /></label>
          <label>Profession<input data-character-path="profession" value="${escapeHtml(character.profession)}" /></label><label>Ex-profession<input data-character-path="previousProfession" value="${escapeHtml(character.previousProfession)}" /></label>
          <label>Pronoms<input data-character-path="pronouns" value="${escapeHtml(character.pronouns)}" /></label>
        </div>
      </div>
    </section>
    <section class="sheet-section"><div class="sheet-section-title"><span>Ressources</span><small>Synchronisées sur le token lié</small></div><div class="resource-grid">
      <label>PV actuels<input data-character-path="resources.hp" type="number" value="${character.resources?.hp ?? 0}" /></label><label>PV maximum<input data-character-path="resources.maxHp" type="number" value="${character.resources?.maxHp ?? 0}" /></label>
      <label>Mana actuelle<input data-character-path="resources.mana" type="number" value="${character.resources?.mana ?? 0}" /></label><label>Mana maximum<input data-character-path="resources.maxMana" type="number" value="${character.resources?.maxMana ?? 0}" /></label>
      <label>Fatigue<input data-character-path="fatigue.current" type="number" value="${character.fatigue?.current ?? 0}" /></label><label>Fatigue max<input data-character-path="fatigue.max" type="number" value="${character.fatigue?.max ?? 100}" /></label>
      <label>Défense<input data-character-path="armor" type="number" value="${character.armor ?? 0}" /></label><label>Vitesse<input data-character-path="speed" type="number" value="${character.speed ?? 0}" /></label>
      <label>Bonus initiative d100<input data-character-path="initiativeBonus" type="number" value="${character.initiativeBonus ?? 0}" /></label><label>Avantages personnels<input data-character-path="personalAdvantageStock" type="number" value="${character.personalAdvantageStock ?? 0}" /></label>
      <label>Morale<input data-character-path="morale" value="${escapeHtml(character.morale)}" /></label><label>États / conditions<input data-character-path="conditions" value="${escapeHtml(conditions)}" placeholder="Blessé, ralenti…" /></label>
    </div></section>
    <section class="sheet-section"><div class="sheet-section-title"><span>Statistiques d100</span><small>Force, adresse et perception suivent le système d100</small></div><div class="character-stats-grid">
      <label>Force<input data-character-path="stats.force" type="number" value="${character.stats?.force ?? 0}" /></label><label>Dextérité<input data-character-path="stats.dexterity" type="number" value="${character.stats?.dexterity ?? 0}" /></label>
      <label>Agilité<input data-character-path="stats.agility" type="number" value="${character.stats?.agility ?? 0}" /></label><label>Esprit / Social<input data-character-path="stats.spiritSocial" type="number" value="${character.stats?.spiritSocial ?? 0}" /></label>
      <label>Intelligence<input data-character-path="stats.intelligence" type="number" value="${character.stats?.intelligence ?? 0}" /></label><label>Instinct / Perception<input data-character-path="stats.instinct" type="number" value="${character.stats?.instinct ?? 0}" /></label>
    </div></section>
    <section class="sheet-section"><div class="sheet-section-title"><span>Équipement et capacités</span><small>D’après la fiche de référence</small></div>
      <div class="sheet-text-grid"><label>Armure<textarea data-character-path="armorText" rows="3">${escapeHtml(character.armorText)}</textarea></label><label>Armes / dégâts<textarea data-character-path="weaponText" rows="3">${escapeHtml(character.weaponText)}</textarea></label></div>
      <label>Passifs<textarea data-character-path="passives" rows="5">${escapeHtml(character.passives)}</textarea></label>
      <div class="sheet-text-grid"><label>Compétences<textarea data-character-path="skills" rows="6">${escapeHtml(character.skills)}</textarea></label><label>Compétences spéciales<textarea data-character-path="specialSkills" rows="6">${escapeHtml(character.specialSkills)}</textarea></label></div>
      <div class="sheet-text-grid"><label>Langues<textarea data-character-path="languages" rows="3">${escapeHtml(character.languages)}</textarea></label><label>Inventaire<textarea data-character-path="inventory" rows="7">${escapeHtml(character.inventory)}</textarea></label></div>
      <label>Notes partagées avec le MJ<textarea data-character-path="publicNotes" rows="4">${escapeHtml(character.publicNotes)}</textarea></label>
    </section>
    <section class="sheet-section player-quick-roll-section"><div class="sheet-section-title"><span>Lancer les dés</span><small>Chaque résultat affiche votre nom, puis celui du personnage</small></div><div class="player-quick-rolls">${quickRolls || `<small class="hint-copy">Ajoutez d’abord un raccourci ci-dessous.</small>`}</div></section>
    <section class="sheet-section"><div class="section-title-row"><strong>Mes raccourcis</strong><button id="addPlayerShortcut" class="button button-ghost button-small" type="button">+ Ajouter</button></div><div id="playerShortcutList" class="shortcut-editor-list">${shortcuts || `<small class="hint-copy">Aucun raccourci.</small>`}</div></section>
    <section class="sheet-section"><div class="section-title-row"><strong>Invocations, familiers et compagnons</strong><button id="addPlayerLinkedToken" class="button button-ghost button-small" type="button">+ Ajouter</button></div><div class="linked-token-editor-list">${linkedTokens || `<small class="hint-copy">Aucun token lié. Le MJ pourra les invoquer depuis cette fiche.</small>`}</div></section>
    <div class="sheet-save-bar"><span id="playerSheetSaveState">Les modifications s’enregistrent automatiquement.</span><button class="button button-primary" type="submit">Synchroniser maintenant</button></div>
  </form>`;
}

function renderCharacter() {
  const characters = state.myCharacters ?? [];
  const panel = $("#myCharacterPanel");
  panel.classList.remove("hidden");
  if (!characters.length) {
    $("#myCharacterName").textContent = "Personnages";
    $("#playerCharacterSelect").classList.add("hidden");
    $("#myCharacterContent").innerHTML = `<div class="empty-state"><strong>Aucune fiche personnelle</strong><small>Créez votre premier personnage avec le bouton ci-dessus.</small></div>`;
    return;
  }
  if (!characters.some((character) => character.id === selectedCharacterId)) selectedCharacterId = characters[0].id;
  const character = characters.find((entry) => entry.id === selectedCharacterId);
  const select = $("#playerCharacterSelect");
  select.innerHTML = characters.map((entry) => `<option value="${escapeHtml(entry.id)}" ${entry.id === selectedCharacterId ? "selected" : ""}>${escapeHtml(entry.name)}</option>`).join("");
  select.classList.toggle("hidden", characters.length < 2);
  $("#myCharacterName").textContent = character.name;
  $("#myCharacterContent").innerHTML = characterForm(character);
  bindCharacterForm(character);
}

function renderParty() {
  const mine = new Set((state.myCharacters ?? []).map((character) => character.id));
  const others = (state.party ?? []).filter((character) => !mine.has(character.id));
  const presence = Array.isArray(state.presence) ? state.presence : [];
  const presenceFor = (accountId) => {
    const entries = presence.filter((entry) => entry.accountId === accountId);
    const modes = new Set(entries.map((entry) => entry.mode));
    const label = modes.has("player") && modes.has("gm") ? "Joueur + MJ" : modes.has("gm") ? "MJ" : "Joueur";
    return { online: entries.length > 0, label, name: entries[0]?.displayName || "Compte connecté" };
  };
  const characterCards = others.map((character) => {
    const status = presenceFor(character.ownerPlayerId);
    return `<article class="player-party-card ${status.online ? "online" : "offline"}" style="--party-color:${escapeHtml(character.color || "#8d72cb")}">
    <span class="player-party-avatar">${character.portrait ? `<img src="${escapeHtml(character.portrait)}" alt="" />` : escapeHtml(initials(character.name))}</span>
    <span><strong>${escapeHtml(character.name || "Personnage")}</strong><small>${status.online ? `En ligne · ${status.label}` : "Hors ligne"}</small></span>
  </article>`;
  }).join("");
  const knownOwners = new Set((state.party ?? []).map((character) => character.ownerPlayerId));
  const sessionCards = [...new Set(presence.map((entry) => entry.accountId))]
    .filter((accountId) => accountId !== state.myPlayer?.id && !knownOwners.has(accountId))
    .map((accountId) => {
      const status = presenceFor(accountId);
      return `<article class="player-party-card online" style="--party-color:#c69758"><span class="player-party-avatar">${escapeHtml(initials(status.name))}</span><span><strong>${escapeHtml(status.name)}</strong><small>En ligne · ${status.label}</small></span></article>`;
    }).join("");
  $("#playerPartyList").innerHTML = `${characterCards}${sessionCards}` || `<div class="empty-state small"><small>Aucun autre participant à la table.</small></div>`;
}

function renderQuickShortcuts() {
  const container = $("#playerQuickShortcutList");
  const entries = (state.myCharacters ?? []).flatMap((character) => (character.shortcuts ?? []).map((shortcut) => ({ character, shortcut })));
  container.innerHTML = entries.map(({ character, shortcut }) => `<button type="button" class="player-quick-shortcut" data-quick-character="${escapeHtml(character.id)}" data-quick-shortcut="${escapeHtml(shortcut.id)}"><strong>${escapeHtml(shortcut.label || "Jet")}</strong><small>${escapeHtml(character.name)} · ${escapeHtml(shortcut.formula || "1d100")}</small></button>`).join("")
    || `<div class="empty-state small"><small>Les raccourcis de vos fiches apparaîtront ici.</small></div>`;
  $$('[data-quick-shortcut]', container).forEach((button) => button.addEventListener("click", () => {
    const character = (state.myCharacters ?? []).find((entry) => entry.id === button.dataset.quickCharacter);
    if (character) rollPlayerShortcut(character, button.dataset.quickShortcut, button);
  }));
}

function setNested(target, path, value) {
  const parts = path.split(".");
  let cursor = target;
  while (parts.length > 1) {
    const part = parts.shift();
    cursor[part] ??= {};
    cursor = cursor[part];
  }
  cursor[parts[0]] = value;
}

function inputValue(input, path) {
  if (path === "conditions") return input.value.split(",").map((value) => value.trim()).filter(Boolean);
  if (input.type === "number") return Number(input.value || 0);
  if (input.type === "checkbox") return input.checked;
  return input.value;
}

function scheduleCharacterSave() {
  clearTimeout(sheetSaveTimer);
  $("#playerSheetSaveState").textContent = "Modification en attente…";
  persistCurrentCharacterDraft();
  sheetSaveTimer = setTimeout(() => saveCharacterSheet(), 700);
}

function markCharacterPathDirty(path) {
  sheetChangeVersion += 1;
  dirtyCharacterPaths.set(path, sheetChangeVersion);
}

function bindCharacterForm(character) {
  const form = $("#playerCharacterForm");
  form.addEventListener("submit", (event) => { event.preventDefault(); saveCharacterSheet({ forceAll: true }); });
  $$('[data-character-path]', form).forEach((input) => {
    input.addEventListener("input", () => { markCharacterPathDirty(input.dataset.characterPath); scheduleCharacterSave(); });
    input.addEventListener("change", () => { markCharacterPathDirty(input.dataset.characterPath); scheduleCharacterSave(); });
  });
  $$('[data-shortcut-field]', form).forEach((input) => input.addEventListener("input", () => { markCharacterPathDirty("shortcuts"); scheduleCharacterSave(); }));
  $$('[data-player-linked-field]', form).forEach((input) => {
    const mark = () => { markCharacterPathDirty("linkedTokens"); scheduleCharacterSave(); };
    input.addEventListener("input", mark);
    input.addEventListener("change", mark);
  });
  $("#addPlayerShortcut", form).addEventListener("click", () => {
    Object.assign(character, currentCharacterSnapshot() ?? {});
    character.shortcuts ??= [];
    character.shortcuts.push({ id: `shortcut-${crypto.randomUUID()}`, label: "Nouveau test", formula: "1d100", kind: "roll", visibility: "public" });
    markCharacterPathDirty("shortcuts");
    renderCharacter();
    scheduleCharacterSave();
  });
  $$('[data-remove-player-shortcut]', form).forEach((button) => button.addEventListener("click", () => {
    Object.assign(character, currentCharacterSnapshot() ?? {});
    character.shortcuts = (character.shortcuts ?? []).filter((shortcut) => shortcut.id !== button.dataset.removePlayerShortcut);
    markCharacterPathDirty("shortcuts");
    renderCharacter();
    scheduleCharacterSave();
  }));
  $("#addPlayerLinkedToken", form).addEventListener("click", () => {
    Object.assign(character, currentCharacterSnapshot() ?? {});
    character.linkedTokens = [...normalizeLinkedTokens(character.linkedTokens), { id: `linked-${crypto.randomUUID()}`, name: "Nouvelle invocation", kind: "summon", image: null, color: character.color || "#8d72cb", size: DEFAULT_TOKEN_SIZE }];
    markCharacterPathDirty("linkedTokens");
    renderCharacter();
    scheduleCharacterSave();
  });
  $$('[data-remove-player-linked-token]', form).forEach((button) => button.addEventListener("click", () => {
    Object.assign(character, currentCharacterSnapshot() ?? {});
    character.linkedTokens = normalizeLinkedTokens(character.linkedTokens).filter((token) => token.id !== button.dataset.removePlayerLinkedToken);
    markCharacterPathDirty("linkedTokens");
    renderCharacter();
    scheduleCharacterSave();
  }));
  $$('[data-roll-player-shortcut]', form).forEach((button) => button.addEventListener("click", () => rollPlayerShortcut(character, button.dataset.rollPlayerShortcut, button)));
  $("#playerPortraitFile", form).addEventListener("change", async (event) => {
    if (!event.target.files[0]) return;
    try {
      Object.assign(character, currentCharacterSnapshot() ?? {});
      character.portrait = await imageFileToDataUrl(event.target.files[0], 640, 640, 0.9);
      markCharacterPathDirty("portrait");
      renderCharacter();
      scheduleCharacterSave();
    } catch (error) { showError(error.message, { blocking: false }); }
  });
}

async function rollPlayerShortcut(character, shortcutId, button) {
  const originalContent = button.innerHTML;
  button.disabled = true;
  button.textContent = "Lancement…";
  try {
    if (dirtyCharacterPaths.size && !(await saveCharacterSheet())) return;
    const response = await api("/api/session/roll", { method: "POST", body: { characterId: character.id, shortcutId } });
    button.textContent = `Résultat : ${response.roll.total}`;
    setSyncStatus(response.discordError ? "Jet enregistré · Discord indisponible" : "Jet synchronisé", response.discordError ? "warning" : "success");
    await poll({ force: true });
  } catch (error) {
    showError(error.message, { blocking: false });
  } finally {
    if (button.isConnected) {
      button.disabled = false;
      button.innerHTML = originalContent;
    }
  }
}

function collectShortcuts(form) {
  return $$('[data-player-shortcut]', form).map((row) => {
    const label = $('[data-shortcut-field="label"]', row).value.trim() || "Jet";
    const kind = $('[data-shortcut-field="kind"]', row).value;
    let formula = $('[data-shortcut-field="formula"]', row).value.trim() || "1d100";
    const damageDice = kind === "damage" || /d[eé]g[aâ]ts?|dommages?|damage/i.test(label);
    if (kind === "initiative" || !damageDice) {
      formula = /(?:\d*)d\d+/i.test(formula) ? formula.replace(/(?:\d*)d\d+/i, "1d100") : `1d100${formula ? `${/^[+\-]/.test(formula) ? "" : "+"}${formula}` : ""}`;
    }
    return { id: row.dataset.playerShortcut, label, formula, kind, visibility: "public" };
  });
}

function collectPlayerLinkedTokens(form) {
  return $$('[data-player-linked-token]', form).map((row) => ({
    id: row.dataset.playerLinkedToken,
    name: $('[data-player-linked-field="name"]', row).value.trim() || "Invocation",
    kind: $('[data-player-linked-field="kind"]', row).value,
    image: $('[data-player-linked-field="image"]', row).value.trim() || null,
    color: $('[data-player-linked-field="color"]', row).value,
    size: Number($('[data-player-linked-field="size"]', row).value || DEFAULT_TOKEN_SIZE)
  }));
}

function currentCharacterSnapshot() {
  const form = $("#playerCharacterForm");
  const character = state.myCharacters?.find((entry) => entry.id === selectedCharacterId);
  if (!form || !character) return null;
  const snapshot = structuredClone(character);
  $$('[data-character-path]', form).forEach((input) => setNested(snapshot, input.dataset.characterPath, inputValue(input, input.dataset.characterPath)));
  snapshot.shortcuts = collectShortcuts(form);
  snapshot.linkedTokens = collectPlayerLinkedTokens(form);
  snapshot._updatedAt = Date.now();
  return snapshot;
}

function persistCurrentCharacterDraft() {
  const snapshot = currentCharacterSnapshot();
  if (!snapshot || !sheetStorage) return;
  sheetStorage.saveDraft(snapshot, { pending: true });
}

async function saveCharacterSheet({ forceAll = false } = {}) {
  clearTimeout(sheetSaveTimer);
  const form = $("#playerCharacterForm");
  const character = state.myCharacters?.find((entry) => entry.id === selectedCharacterId);
  if (!form || !character) return true;
  const submittedVersions = new Map(dirtyCharacterPaths);
  const patch = {};
  $$('[data-character-path]', form).forEach((input) => {
    const path = input.dataset.characterPath;
    if (forceAll || dirtyCharacterPaths.has(path)) setNested(patch, path, inputValue(input, path));
  });
  if (forceAll || dirtyCharacterPaths.has("shortcuts")) patch.shortcuts = collectShortcuts(form);
  if (forceAll || dirtyCharacterPaths.has("linkedTokens")) patch.linkedTokens = collectPlayerLinkedTokens(form);
  if (forceAll || dirtyCharacterPaths.has("portrait")) patch.portrait = character.portrait;
  if (!Object.keys(patch).length) return true;
  $("#playerSheetSaveState").textContent = "Synchronisation…";
  setSyncStatus("Fiche en cours d’envoi…", "warning");
  try {
    const response = await api("/api/session/character", { method: "PATCH", body: { characterId: character.id, patch } });
    const index = state.myCharacters.findIndex((entry) => entry.id === character.id);
    if (response.character && index >= 0) state.myCharacters[index] = response.character;
    if (response.character) await sheetStorage?.markSynced(response.character);
    lastRevision = Number(response.revision ?? lastRevision);
    for (const [path, version] of submittedVersions) {
      if (dirtyCharacterPaths.get(path) === version) dirtyCharacterPaths.delete(path);
    }
    $("#playerSheetSaveState").textContent = "Fiche synchronisée avec le MJ.";
    setSyncStatus("Synchronisée", "success");
    if (dirtyCharacterPaths.size) scheduleCharacterSave();
    return true;
  } catch (error) {
    $("#playerSheetSaveState").textContent = "Échec de synchronisation — réessayez.";
    showError(error.message, { blocking: false });
    return false;
  }
}

function loadImage(source) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Impossible de lire cette image."));
    image.src = source;
  });
}

async function imageFileToDataUrl(file, maxWidth, maxHeight, quality) {
  const objectUrl = URL.createObjectURL(file);
  try {
    const image = await loadImage(objectUrl);
    const scale = Math.min(1, maxWidth / image.naturalWidth, maxHeight / image.naturalHeight);
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/webp", quality);
  } finally { URL.revokeObjectURL(objectUrl); }
}

function expectedAudioTime(playback, audio) {
  let seconds = playback.startedAt ? Math.max(0, (Date.now() - Number(playback.startedAt)) / 1000) : Number(playback.position || 0);
  if (audio.duration && Number.isFinite(audio.duration) && seconds > audio.duration) seconds = audio.loop ? seconds % audio.duration : Math.min(seconds, audio.duration);
  return seconds;
}

function mediaUrl(track) {
  return authenticatedUrl(track.url, { identity: false }).href;
}

async function syncAudioChannel(channel, { force = false } = {}) {
  const playback = state.audio?.[channel];
  const audio = playerAudio[channel];
  const track = (state.tracks ?? []).find((entry) => entry.id === playback?.trackId);
  const master = Number(state.audio?.masterVolume ?? 0) / 100;
  const channelVolume = Number(state.audio?.[`${channel}Volume`] ?? 0) / 100;
  const locallyMuted = channel === "music" ? audioPreferences.musicMuted : audioPreferences.ambienceMuted;
  audio.volume = state.audio?.muted || locallyMuted ? 0 : clamp(master * channelVolume, 0, 1);
  if (!track || !playback?.playing || state.audio?.muted || locallyMuted) {
    if (!audio.paused) audio.pause();
    if (track && audio.dataset.trackId === track.id && Number.isFinite(Number(playback?.position))) audio.currentTime = Number(playback.position);
    return;
  }
  if (!audioActivated) return;
  if (audio.dataset.trackId !== track.id) {
    audio.pause();
    audio.src = mediaUrl(track);
    audio.dataset.trackId = track.id;
    const initialPlay = audio.play();
    await new Promise((resolve) => {
      if (audio.readyState >= 1) resolve();
      else { audio.addEventListener("loadedmetadata", resolve, { once: true }); setTimeout(resolve, 1200); }
    });
    await initialPlay;
    force = true;
  }
  const desired = expectedAudioTime(playback, audio);
  if (force || Math.abs(Number(audio.currentTime || 0) - desired) > 0.65) {
    try { audio.currentTime = desired; } catch { /* le prochain événement média recale la piste */ }
  }
  if (audio.paused) await audio.play();
}

async function unlockPlayerAudio() {
  const attempts = Object.values(playerAudio).map((audio) => {
    if (audio.dataset.trackId) return Promise.resolve();
    audio.src = SILENT_AUDIO_DATA;
    const attempt = audio.play();
    return attempt.then(() => {
      audio.pause();
      audio.currentTime = 0;
      audio.removeAttribute("src");
      audio.load();
    });
  });
  await Promise.all(attempts);
}

async function syncPlayerAudio(options = {}) {
  if (!state?.audio) return;
  const musicTrack = state.tracks?.find((track) => track.id === state.audio.music?.trackId);
  const ambienceTrack = state.tracks?.find((track) => track.id === state.audio.ambience?.trackId);
  $("#playerMusicTitle").textContent = musicTrack?.name || "Silence";
  $("#playerAmbienceTitle").textContent = ambienceTrack?.name || "Silence";
  $("#playerVolumeLabel").textContent = state.audio.muted ? "Silence du MJ" : `Volume ${Math.round(Number(state.audio.masterVolume || 0))} %`;
  $(".player-audio-strip .music-orb")?.classList.toggle("playing", Boolean(state.audio.music?.playing && !state.audio.muted && !audioPreferences.musicMuted));
  $(".player-audio-strip .ambience-orb")?.classList.toggle("playing", Boolean(state.audio.ambience?.playing && !state.audio.muted && !audioPreferences.ambienceMuted));
  $("#mutePlayerMusic").textContent = audioPreferences.musicMuted ? "Réactiver" : "Couper";
  $("#mutePlayerMusic").setAttribute("aria-pressed", String(audioPreferences.musicMuted));
  $("#mutePlayerAmbience").textContent = audioPreferences.ambienceMuted ? "Réactiver" : "Couper";
  $("#mutePlayerAmbience").setAttribute("aria-pressed", String(audioPreferences.ambienceMuted));
  if (!audioActivated) return;
  try {
    await Promise.all([syncAudioChannel("music", options), syncAudioChannel("ambience", options)]);
    $("#activatePlayerAudio").textContent = "Son activé";
    $("#activatePlayerAudio").classList.add("button-outline");
  } catch (error) {
    audioActivated = false;
    $("#activatePlayerAudio").textContent = "Réactiver le son";
    showError(`Le navigateur a bloqué le son : ${error.message}`, { blocking: false });
  }
}

function toggleLocalAudioChannel(channel) {
  const key = channel === "music" ? "musicMuted" : "ambienceMuted";
  audioPreferences[key] = !audioPreferences[key];
  try { localStorage.setItem("xar-player-audio-preferences", JSON.stringify(audioPreferences)); } catch {}
  syncPlayerAudio({ force: true });
}

function setSyncStatus(label, kind = "neutral") {
  $("#playerSyncBadge").textContent = label;
  $("#playerSyncBadge").className = `status-badge ${kind}`;
  if (kind !== "danger") $("#playerSyncBadge").removeAttribute("title");
}

function showError(message, { blocking = true } = {}) {
  if (blocking) {
    $("#playerError").textContent = message;
    $("#playerError").classList.remove("hidden");
  }
  setSyncStatus("Connexion à vérifier", "danger");
  $("#playerSyncBadge").title = message;
}

function render() {
  if (!state) return;
  $("#playerSessionName").textContent = `${state.session?.name || "Session de Xar Tsaroth"} · Vue joueurs`;
  $("#playerSceneTitle").textContent = state.activeScene?.name || "Carte tactique";
  $("#playerRoundPill").textContent = state.initiative?.active === true ? `Round ${state.initiative?.round ?? 1}` : "Hors combat";
  $("#playerIdentityLabel").textContent = state.myPlayer ? `${state.myPlayer.name} · Joueur` : "Joueur";
  renderMap();
  renderInitiative();
  renderActionTimers();
  renderRolls();
  renderParty();
  renderQuickShortcuts();
  $("#createPlayerCharacter").disabled = !state.myPlayer;
  const activeElement = document.activeElement;
  if (!dirtyCharacterPaths.size && !$("#playerCharacterForm")?.contains(activeElement)) renderCharacter();
  syncPlayerAudio();
}

async function restoreLocalDrafts() {
  if (localDraftsLoaded || !sheetStorage) return false;
  localDraftsLoaded = true;
  const drafts = await sheetStorage.loadDrafts();
  let restored = false;
  for (const draft of drafts) {
    const index = (state.myCharacters ?? []).findIndex((character) => character.id === draft.character.id);
    if (index < 0 && state.myPlayer) {
      try {
        const recovered = await api("/api/session/character", { method: "POST", body: { draft: draft.character } });
        state.myCharacters.push(recovered.character);
        await sheetStorage.markSynced(recovered.character);
      } catch {}
      continue;
    }
    if (index < 0 || !draft.pending) continue;
    state.myCharacters[index] = { ...state.myCharacters[index], ...draft.character, ownerPlayerId: state.myCharacters[index].ownerPlayerId };
    restored = true;
  }
  return restored;
}

function setLiveSyncStatus() {
  if (state?.tacticalLocked) setSyncStatus("Table en préparation MJ", "warning");
  else setSyncStatus("Synchronisée en direct", "success");
}

async function poll({ force = false } = {}) {
  try {
    const response = await api("/api/session/public");
    $("#playerError").classList.add("hidden");
    if (!response.state) {
      setSyncStatus("En attente du MJ", "warning");
      return;
    }
    if (force || Number(response.state.revision ?? 0) !== lastRevision) {
      state = response.state;
      lastRevision = Number(state.revision ?? 0);
      const restoredDraft = await restoreLocalDrafts();
      if (!selectedCharacterId) selectedCharacterId = state.myCharacters?.[0]?.id || "";
      render();
      if (restoredDraft) setTimeout(() => saveCharacterSheet({ forceAll: true }), 80);
    }
    if (!state.myPlayer) showError("Ce compte n’est plus autorisé sur cette table.");
    else setLiveSyncStatus();
  } catch (error) {
    if (error.status === 401 || error.status === 403) return showPlayerLogin("Votre session a expiré. Reconnectez-vous.");
    showError(error.message);
  }
}

function connectLiveSync() {
  eventSource?.close();
  eventSource = new EventSource("/api/session/events");
  eventSource.addEventListener("revision", (event) => {
    const payload = JSON.parse(event.data || "{}");
    if (Number(payload.revision ?? 0) > lastRevision) poll({ force: true });
  });
  eventSource.addEventListener("presence", (event) => {
    const payload = JSON.parse(event.data || "{}");
    if (!state) return;
    state.presence = Array.isArray(payload.presence) ? payload.presence : [];
    renderParty();
  });
  eventSource.onerror = () => setSyncStatus("Reconnexion…", "warning");
}

function showPlayerPage(page) {
  $$('[data-player-page]').forEach((section) => section.classList.toggle("hidden", section.dataset.playerPage !== page));
  $$('[data-player-page-target]').forEach((button) => {
    const active = button.dataset.playerPageTarget === page;
    button.classList.toggle("active", active);
    if (active) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  });
  try { localStorage.setItem("xar-player-active-page", page); } catch {}
  if (page === "map") requestAnimationFrame(applyPlayerMapViewport);
}

function showPlayerLogin(message = "") {
  if (dirtyCharacterPaths.size) persistCurrentCharacterDraft();
  eventSource?.close();
  eventSource = null;
  authenticatedIdentity = null;
  sheetStorage = null;
  state = null;
  lastRevision = -1;
  localDraftsLoaded = false;
  $("#playerApplication").classList.add("hidden");
  $("#playerPasswordOverlay").classList.add("hidden");
  $("#playerLoginOverlay").classList.remove("hidden");
  $("#playerLoginError").textContent = message;
  $("#playerLoginError").classList.toggle("hidden", !message);
  requestAnimationFrame(() => $("#playerLoginUsername").focus());
}

async function startPlayerApplication(account) {
  authenticatedIdentity = account;
  sheetStorage = new PlayerSheetStorage(`${location.origin}:${account.id}`);
  state = null;
  lastRevision = -1;
  localDraftsLoaded = false;
  $("#playerLoginPassword").value = "";
  $("#playerLoginOverlay").classList.add("hidden");
  $("#playerApplication").classList.remove("hidden");
  $("#playerIdentityLabel").textContent = `${account.displayName} · Joueur`;
  try { localStorage.setItem("xar-player-last-username", account.username); } catch {}
  let page = "map";
  try { page = localStorage.getItem("xar-player-active-page") === "characters" ? "characters" : "map"; } catch {}
  showPlayerPage(page);
  await poll({ force: true });
  connectLiveSync();
}

async function restoreAuthenticatedSession() {
  try {
    const response = await api("/api/auth/me");
    await startPlayerApplication(response.account);
  } catch {
    let username = "";
    try { username = localStorage.getItem("xar-player-last-username") || ""; } catch {}
    $("#playerLoginUsername").value = username;
    showPlayerLogin();
  }
}

$("#playerLoginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button[type="submit"]');
  button.disabled = true;
  $("#playerLoginError").classList.add("hidden");
  try {
    const response = await api("/api/auth/login", {
      method: "POST",
      body: { username: $("#playerLoginUsername").value, password: $("#playerLoginPassword").value, scope: "player" }
    });
    await startPlayerApplication(response.account);
  } catch (error) {
    $("#playerLoginPassword").value = "";
    $("#playerLoginError").textContent = error.message;
    $("#playerLoginError").classList.remove("hidden");
  } finally {
    button.disabled = false;
  }
});

$("#playerLogout").addEventListener("click", async () => {
  try { await api("/api/auth/logout", { method: "POST" }); } catch {}
  showPlayerLogin("Vous êtes déconnecté.");
});

$("#playerChangePassword").addEventListener("click", () => {
  $("#playerCurrentPassword").value = "";
  $("#playerNewPassword").value = "";
  $("#playerNewPasswordConfirm").value = "";
  $("#playerPasswordError").textContent = "";
  $("#playerPasswordError").classList.add("hidden");
  $("#playerPasswordOverlay").classList.remove("hidden");
  requestAnimationFrame(() => $("#playerCurrentPassword").focus());
});

$("#cancelPlayerPassword").addEventListener("click", () => $("#playerPasswordOverlay").classList.add("hidden"));

$("#playerPasswordForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button[type="submit"]');
  const newPassword = $("#playerNewPassword").value;
  const error = $("#playerPasswordError");
  error.classList.add("hidden");
  if (newPassword !== $("#playerNewPasswordConfirm").value) {
    error.textContent = "Les deux nouveaux mots de passe ne correspondent pas.";
    error.classList.remove("hidden");
    return;
  }
  button.disabled = true;
  try {
    const response = await api("/api/auth/password", {
      method: "POST",
      body: { currentPassword: $("#playerCurrentPassword").value, newPassword }
    });
    authenticatedIdentity = response.account;
    $("#playerPasswordOverlay").classList.add("hidden");
    connectLiveSync();
    setSyncStatus("Mot de passe modifié", "success");
  } catch (failure) {
    error.textContent = failure.message;
    error.classList.remove("hidden");
  } finally {
    button.disabled = false;
  }
});

$$('[data-player-page-target]').forEach((button) => button.addEventListener("click", () => showPlayerPage(button.dataset.playerPageTarget)));

$("#playerCalculatorForm").addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    const result = evaluateTacticalExpression($("#playerCalculatorExpression").value);
    $("#playerCalculatorResult").textContent = result.exact === result.rounded ? String(result.rounded) : `${result.exact.toLocaleString("fr-FR")} · arrondi ${result.rounded}`;
    $("#playerCalculatorResult").classList.remove("error");
  } catch (error) {
    $("#playerCalculatorResult").textContent = error.message;
    $("#playerCalculatorResult").classList.add("error");
  }
});

$("#importPlayerWord").addEventListener("click", () => $("#playerWordImport").click());
$("#playerWordImport").addEventListener("change", async (event) => {
  const file = event.target.files?.[0];
  event.target.value = "";
  if (!file) return;
  const status = $("#playerWordImportStatus");
  if (!file.name.toLowerCase().endsWith(".docx")) {
    status.textContent = "Enregistrez les anciens fichiers .doc au format Word .docx avant l’import.";
    return;
  }
  if (file.size > 25 * 1024 * 1024) {
    status.textContent = "Ce document dépasse 25 Mo.";
    return;
  }
  $("#importPlayerWord").disabled = true;
  status.textContent = "Lecture et conversion du document Word…";
  try {
    const imported = await api("/api/session/character/import-docx", {
      method: "POST",
      rawBody: file,
      contentType: file.type || "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      filename: file.name
    });
    const created = await api("/api/session/character", { method: "POST", body: { draft: imported.draft } });
    state.myCharacters ??= [];
    state.myCharacters.push(created.character);
    selectedCharacterId = created.character.id;
    lastRevision = Number(created.revision ?? lastRevision);
    await sheetStorage?.markSynced(created.character);
    renderCharacter();
    renderQuickShortcuts();
    showPlayerPage("characters");
    status.textContent = imported.warnings?.length
      ? `Fiche créée. ${imported.warnings.join(" ")}`
      : "Fiche Word convertie et préremplie. Vérifiez les champs avant de jouer.";
  } catch (error) {
    status.textContent = error.message;
  } finally {
    $("#importPlayerWord").disabled = false;
  }
});

$("#playerCharacterSelect").addEventListener("change", async (event) => {
  const nextCharacterId = event.target.value;
  if (dirtyCharacterPaths.size && !(await saveCharacterSheet())) { event.target.value = selectedCharacterId; return; }
  selectedCharacterId = nextCharacterId;
  dirtyCharacterPaths.clear();
  renderCharacter();
});
$("#createPlayerCharacter").addEventListener("click", async () => {
  if (!state?.myPlayer) return showError("Une connexion joueur est nécessaire pour créer une fiche.", { blocking: false });
  const name = prompt("Nom du nouveau personnage", "Nouveau personnage");
  if (name === null) return;
  const button = $("#createPlayerCharacter");
  button.disabled = true;
  try {
    const response = await api("/api/session/character", { method: "POST", body: { name: name.trim() || "Nouveau personnage" } });
    state.myCharacters ??= [];
    state.myCharacters.push(response.character);
    selectedCharacterId = response.character.id;
    lastRevision = Number(response.revision ?? lastRevision);
    await sheetStorage?.markSynced(response.character);
    renderCharacter();
    renderParty();
    setSyncStatus("Fiche créée", "success");
  } catch (error) {
    showError(error.message, { blocking: false });
  } finally {
    button.disabled = !state?.myPlayer;
  }
});
$("#activatePlayerAudio").addEventListener("click", async () => {
  audioActivated = true;
  $("#activatePlayerAudio").textContent = "Activation…";
  try {
    await unlockPlayerAudio();
    await syncPlayerAudio({ force: true });
  } catch (error) {
    audioActivated = false;
    $("#activatePlayerAudio").textContent = "Réactiver le son";
    showError(`Le navigateur a bloqué le son : ${error.message}`, { blocking: false });
  }
});
$("#mutePlayerMusic").addEventListener("click", () => toggleLocalAudioChannel("music"));
$("#mutePlayerAmbience").addEventListener("click", () => toggleLocalAudioChannel("ambience"));
$("#playerTimerForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const label = $("#playerTimerLabel").value.trim();
  if (!label) return;
  const button = $("#playerTimerForm button[type='submit']");
  button.disabled = true;
  try {
    const response = await api("/api/session/timer", { method: "POST", body: {
      characterId: $("#playerTimerCharacter").value,
      label,
      cooldown: Number($("#playerTimerCooldown").value || 1),
      visibility: $("#playerTimerPublic").checked ? "public" : "private"
    } });
    lastRevision = Number(response.revision ?? lastRevision);
    $("#playerTimerLabel").value = "";
    setSyncStatus("Recharge ajoutée", "success");
    await poll({ force: true });
  } catch (error) { showError(error.message, { blocking: false }); }
  finally { button.disabled = state?.tacticalLocked === true || state?.initiative?.active !== true; }
});
$("#playerBattlefield").addEventListener("dblclick", async (event) => {
  if (!state?.map?.background || !state?.myPlayer) return;
  const point = mapPointFromClient(event.clientX, event.clientY, $("#playerMapWorld").getBoundingClientRect(), state.map);
  try {
    const response = await api("/api/session/ping", { method: "POST", body: point });
    state.mapPings = [...(state.mapPings ?? []).filter((ping) => Number(ping.expiresAt || 0) > Date.now()), response.ping].slice(-20);
    lastRevision = Number(response.revision ?? lastRevision);
    renderPlayerPings();
  } catch (error) {
    showError(error.message, { blocking: false });
  }
});
window.addEventListener("resize", () => requestAnimationFrame(applyPlayerMapViewport));
window.addEventListener("beforeunload", () => {
  if (dirtyCharacterPaths.size) persistCurrentCharacterDraft();
  eventSource?.close();
});

restoreAuthenticatedSession();
setInterval(() => { if (authenticatedIdentity) poll(); }, 12000);
