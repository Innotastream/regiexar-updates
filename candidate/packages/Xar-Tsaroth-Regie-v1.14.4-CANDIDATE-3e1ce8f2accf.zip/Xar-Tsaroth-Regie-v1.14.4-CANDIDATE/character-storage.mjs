import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  renameSync,
  writeFileSync
} from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";
import {
  CHARACTER_SCHEMA_ID,
  CHARACTER_SCHEMA_VERSION,
  migrateCharacterSheet
} from "./public/character-schema.js";

export const USER_CHARACTER_STORE_ID = "xar-tsaroth.user-character-store";
export const USER_CHARACTER_STORE_SCHEMA_VERSION = 1;

function timestampForFilename(value = new Date()) {
  return value.toISOString().replace(/[:.]/g, "-");
}

function atomicWriteJson(filePath, value) {
  mkdirSync(path.dirname(filePath), { recursive: true, mode: 0o700 });
  const serialized = `${JSON.stringify(value, null, 2)}\n`;
  if (existsSync(filePath) && readFileSync(filePath, "utf8") === serialized) return false;
  const temporary = `${filePath}.${process.pid}.tmp`;
  writeFileSync(temporary, serialized, { encoding: "utf8", mode: 0o600 });
  renameSync(temporary, filePath);
  return true;
}

function ownerStorageKey(ownerPlayerId) {
  return createHash("sha256").update(String(ownerPlayerId)).digest("hex").slice(0, 32);
}

export function userCharacterStorePath(dataDirectory, ownerPlayerId) {
  return path.join(path.resolve(dataDirectory), "users", ownerStorageKey(ownerPlayerId), "characters.json");
}

function normalizeEnvelope(candidate, ownerPlayerId, applicationVersion) {
  const source = Array.isArray(candidate)
    ? { schemaVersion: 0, characters: candidate }
    : candidate && typeof candidate === "object"
      ? candidate
      : { schemaVersion: 0, characters: [] };
  const envelopeVersion = Number(source.schemaVersion ?? 0);
  if (!Number.isInteger(envelopeVersion) || envelopeVersion < 0) {
    throw new Error("Version de stockage utilisateur invalide.");
  }
  if (envelopeVersion > USER_CHARACTER_STORE_SCHEMA_VERSION) {
    throw new Error(`Le stockage utilisateur utilise le schéma ${envelopeVersion}, plus récent que le schéma ${USER_CHARACTER_STORE_SCHEMA_VERSION} pris en charge.`);
  }

  const rawCharacters = Array.isArray(source.characters)
    ? source.characters
    : Array.isArray(source.sheets)
      ? source.sheets
      : [];
  const characters = [];
  const knownIds = new Set();
  const migrations = [];
  for (const rawCharacter of rawCharacters) {
    const result = migrateCharacterSheet(rawCharacter, { ownerPlayerId });
    if (!result.character.id || knownIds.has(result.character.id)) continue;
    knownIds.add(result.character.id);
    characters.push(result.character);
    migrations.push(...result.appliedMigrations.map((step) => ({ characterId: result.character.id, step })));
  }

  return {
    envelope: {
      store: USER_CHARACTER_STORE_ID,
      schemaVersion: USER_CHARACTER_STORE_SCHEMA_VERSION,
      characterSchema: CHARACTER_SCHEMA_ID,
      characterSchemaVersion: CHARACTER_SCHEMA_VERSION,
      ownerPlayerId,
      applicationVersion,
      updatedAt: String(source.updatedAt || new Date().toISOString()),
      characters
    },
    migrations,
    changed: envelopeVersion !== USER_CHARACTER_STORE_SCHEMA_VERSION
      || source.store !== USER_CHARACTER_STORE_ID
      || source.ownerPlayerId !== ownerPlayerId
      || migrations.length > 0
  };
}

function mergeCharacterLists(sessionCharacters, storedCharacters) {
  const byId = new Map(storedCharacters.map((character) => [character.id, character]));
  for (const sessionCharacter of sessionCharacters) {
    const storedCharacter = byId.get(sessionCharacter.id);
    if (!storedCharacter) {
      byId.set(sessionCharacter.id, sessionCharacter);
      continue;
    }
    const sessionUpdatedAt = Number(sessionCharacter._updatedAt ?? 0);
    const storedUpdatedAt = Number(storedCharacter._updatedAt ?? 0);
    if (sessionUpdatedAt >= storedUpdatedAt) byId.set(sessionCharacter.id, sessionCharacter);
  }
  return [...byId.values()];
}

export class UserCharacterStorage {
  constructor(dataDirectory, { applicationVersion = "dev", now = () => new Date() } = {}) {
    this.dataDirectory = path.resolve(dataDirectory);
    this.applicationVersion = applicationVersion;
    this.now = now;
    this.blockedOwners = new Set();
    this.status = {
      mode: "per-user-files",
      storeSchemaVersion: USER_CHARACTER_STORE_SCHEMA_VERSION,
      characterSchemaVersion: CHARACTER_SCHEMA_VERSION,
      userStores: 0,
      storedCharacters: 0,
      migrationsApplied: 0,
      warnings: []
    };
  }

  #recordWarning(message) {
    if (!this.status.warnings.includes(message)) this.status.warnings.push(message);
    this.status.warnings = this.status.warnings.slice(-20);
  }

  #readOwnerStore(ownerPlayerId) {
    const filePath = userCharacterStorePath(this.dataDirectory, ownerPlayerId);
    if (!existsSync(filePath)) return { filePath, exists: false, envelope: null, migrations: [] };
    let raw;
    try {
      raw = JSON.parse(readFileSync(filePath, "utf8"));
    } catch {
      this.blockedOwners.add(ownerPlayerId);
      this.#recordWarning("Un stockage de fiches illisible a été conservé sans être écrasé.");
      return { filePath, exists: true, blocked: true, envelope: null, migrations: [] };
    }
    try {
      const normalized = normalizeEnvelope(raw, ownerPlayerId, this.applicationVersion);
      if (normalized.changed) {
        const backupDirectory = path.join(path.dirname(filePath), "backups");
        mkdirSync(backupDirectory, { recursive: true, mode: 0o700 });
        const backupPath = path.join(backupDirectory, `characters-before-migration-${timestampForFilename(this.now())}.json`);
        copyFileSync(filePath, backupPath);
        atomicWriteJson(filePath, {
          ...normalized.envelope,
          updatedAt: this.now().toISOString()
        });
      }
      return { filePath, exists: true, ...normalized };
    } catch (error) {
      this.blockedOwners.add(ownerPlayerId);
      this.#recordWarning(String(error?.message || "Migration de fiches impossible."));
      return { filePath, exists: true, blocked: true, envelope: null, migrations: [] };
    }
  }

  #writeOwnerStore(ownerPlayerId, characters) {
    if (this.blockedOwners.has(ownerPlayerId)) return false;
    const migratedCharacters = characters.map((character) => migrateCharacterSheet(character, { ownerPlayerId }).character);
    return atomicWriteJson(userCharacterStorePath(this.dataDirectory, ownerPlayerId), {
      store: USER_CHARACTER_STORE_ID,
      schemaVersion: USER_CHARACTER_STORE_SCHEMA_VERSION,
      characterSchema: CHARACTER_SCHEMA_ID,
      characterSchemaVersion: CHARACTER_SCHEMA_VERSION,
      ownerPlayerId,
      applicationVersion: this.applicationVersion,
      updatedAt: this.now().toISOString(),
      characters: migratedCharacters
    });
  }

  hydrateSession(sessionState) {
    if (!sessionState || typeof sessionState !== "object") {
      return { state: sessionState, changed: false, status: this.publicStatus() };
    }
    const players = Array.isArray(sessionState.players) ? sessionState.players : [];
    const originalCharacters = Array.isArray(sessionState.characters) ? sessionState.characters : [];
    const deletedCharacterIds = new Set((sessionState.characterTombstones ?? []).map((entry) => entry?.id).filter(Boolean));
    const ownerIds = new Set(players.map((player) => player?.id).filter(Boolean));
    const retainedCharacters = originalCharacters.filter((character) => !ownerIds.has(character?.ownerPlayerId));
    const hydratedCharacters = [...retainedCharacters];
    let changed = false;
    let migrationsApplied = 0;
    let storedCharacters = 0;
    let userStores = 0;

    for (const ownerPlayerId of ownerIds) {
      const sessionMigrationResults = originalCharacters
        .filter((character) => character?.ownerPlayerId === ownerPlayerId)
        .map((character) => migrateCharacterSheet(character, { ownerPlayerId }));
      const sessionOwned = sessionMigrationResults.map((result) => result.character);
      migrationsApplied += sessionMigrationResults.reduce((total, result) => total + result.appliedMigrations.length, 0);
      if (sessionMigrationResults.some((result) => result.changed)) changed = true;
      const loaded = this.#readOwnerStore(ownerPlayerId);
      if (loaded.exists) userStores += 1;
      migrationsApplied += loaded.migrations?.length ?? 0;
      const storedOwned = (loaded.envelope?.characters ?? []).filter((character) => !deletedCharacterIds.has(character.id));
      const merged = loaded.blocked ? sessionOwned : mergeCharacterLists(sessionOwned, storedOwned);
      storedCharacters += merged.length;
      hydratedCharacters.push(...merged);
      if (!loaded.blocked) {
        this.#writeOwnerStore(ownerPlayerId, merged);
        userStores += loaded.exists ? 0 : 1;
      }
      if (JSON.stringify(merged) !== JSON.stringify(sessionOwned)) changed = true;
    }

    this.status = {
      ...this.status,
      userStores,
      storedCharacters,
      migrationsApplied,
      warnings: this.status.warnings
    };
    return {
      state: { ...sessionState, characters: hydratedCharacters },
      changed,
      status: this.publicStatus()
    };
  }

  persistSession(sessionState) {
    if (!sessionState || typeof sessionState !== "object") return this.publicStatus();
    const players = Array.isArray(sessionState.players) ? sessionState.players : [];
    const characters = Array.isArray(sessionState.characters) ? sessionState.characters : [];
    let userStores = 0;
    let storedCharacters = 0;
    for (const player of players) {
      if (!player?.id || this.blockedOwners.has(player.id)) continue;
      const owned = characters.filter((character) => character?.ownerPlayerId === player.id);
      try {
        this.#writeOwnerStore(player.id, owned);
        userStores += 1;
        storedCharacters += owned.length;
      } catch (error) {
        this.blockedOwners.add(player.id);
        this.#recordWarning(String(error?.message || "Écriture du stockage de fiches impossible."));
      }
    }
    this.status = { ...this.status, userStores, storedCharacters, warnings: this.status.warnings };
    return this.publicStatus();
  }

  deleteCharacter(ownerPlayerId, characterId) {
    const loaded = this.#readOwnerStore(ownerPlayerId);
    if (loaded.blocked) throw new Error("Ce stockage de fiches est protégé car il est illisible ou provient d’une version plus récente.");
    const characters = loaded.envelope?.characters ?? [];
    const character = characters.find((entry) => entry.id === characterId);
    if (!character) return { deleted: false, character: null };
    const backupDirectory = path.join(path.dirname(loaded.filePath), "backups");
    mkdirSync(backupDirectory, { recursive: true, mode: 0o700 });
    copyFileSync(loaded.filePath, path.join(backupDirectory, `characters-before-deletion-${timestampForFilename(this.now())}.json`));
    this.#writeOwnerStore(ownerPlayerId, characters.filter((entry) => entry.id !== characterId));
    return { deleted: true, character: { id: character.id, name: character.name } };
  }

  publicStatus() {
    return structuredClone(this.status);
  }
}
