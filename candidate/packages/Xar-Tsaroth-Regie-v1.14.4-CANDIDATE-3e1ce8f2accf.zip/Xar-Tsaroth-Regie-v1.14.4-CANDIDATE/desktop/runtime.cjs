const path = require("node:path");
const { spawn } = require("node:child_process");
const { existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } = require("node:fs");
const { pathToFileURL } = require("node:url");

const applicationRoot = path.resolve(__dirname, "..");
process.env.ELECTRON_RUN_AS_NODE = "1";
process.env.XAR_DESKTOP_HOST = "1";
process.env.XAR_INSTALL_ROOT = process.env.XAR_INSTALL_ROOT || applicationRoot;
process.env.XAR_LAUNCHER_PORT = process.env.XAR_LAUNCHER_PORT || "4169";
process.env.PORT = process.env.PORT || "4173";

function readJson(filePath) {
  try { return JSON.parse(readFileSync(filePath, "utf8")); }
  catch { return null; }
}

function scheduleDesktopRelaunchAfterUpdate() {
  if (process.platform !== "win32" || process.env.XAR_DESKTOP_HOST !== "1") return false;
  const privateRoot = path.resolve(process.env.XAR_PRIVATE_ROOT || "");
  const release = readJson(path.join(applicationRoot, "application.json"));
  const status = readJson(path.join(privateRoot, "updates", "update-status.json"));
  if (!privateRoot || status?.state !== "installed" || status.version !== release?.version || !status.updatedAt) return false;

  const markerPath = path.join(privateRoot, "updates", "desktop-relaunch.json");
  const cycle = `${status.version}:${status.updatedAt}`;
  if (readJson(markerPath)?.cycle === cycle) return false;

  mkdirSync(path.dirname(markerPath), { recursive: true, mode: 0o700 });
  const temporary = `${markerPath}.${process.pid}.partial`;
  writeFileSync(temporary, `${JSON.stringify({ schemaVersion: 1, cycle }, null, 2)}\n`, { mode: 0o600 });
  rmSync(markerPath, { force: true });
  renameSync(temporary, markerPath);

  const helperPath = path.join(applicationRoot, "desktop", "relaunch-after-update.cjs");
  if (!existsSync(helperPath)) return false;
  const helperEnvironment = { ...process.env, ELECTRON_RUN_AS_NODE: "1" };
  delete helperEnvironment.XAR_SECRET_VAULT_KEY;
  const helper = spawn(process.execPath, [helperPath, String(process.ppid)], {
    cwd: applicationRoot,
    env: helperEnvironment,
    detached: true,
    stdio: "ignore",
    windowsHide: true
  });
  helper.unref();
  return true;
}

(async () => {
  if (scheduleDesktopRelaunchAfterUpdate()) return;
  const { runLauncher } = await import(pathToFileURL(path.join(applicationRoot, "launcher.mjs")).href);
  await runLauncher({ openBrowser: false });
})().catch((error) => {
  console.error(`Régie locale impossible : ${error.message}`);
  process.exitCode = 1;
});
