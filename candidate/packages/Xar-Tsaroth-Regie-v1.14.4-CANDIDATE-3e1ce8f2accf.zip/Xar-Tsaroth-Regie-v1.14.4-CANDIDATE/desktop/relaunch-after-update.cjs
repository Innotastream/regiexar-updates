const { spawn } = require("node:child_process");

function wait(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function processStillRunning(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === "EPERM";
  }
}

function run(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: "ignore", windowsHide: true });
    child.once("error", reject);
    child.once("exit", (code) => code === 0 || code === 128 ? resolve() : reject(new Error(`Commande de relance refusée (${code}).`)));
  });
}

async function relaunch() {
  const desktopPid = Number(process.argv[2]);
  if (!Number.isSafeInteger(desktopPid) || desktopPid < 1 || desktopPid === process.pid) {
    throw new Error("Processus Windows à relancer invalide.");
  }

  await wait(350);
  if (processStillRunning(desktopPid)) await run("taskkill.exe", ["/PID", String(desktopPid), "/F"]);
  for (let attempt = 0; attempt < 80 && processStillRunning(desktopPid); attempt += 1) await wait(125);
  if (processStillRunning(desktopPid)) throw new Error("L’ancienne fenêtre Windows ne s’est pas arrêtée.");

  const cleanEnvironment = { ...process.env };
  for (const name of [
    "ELECTRON_RUN_AS_NODE",
    "XAR_DESKTOP_HOST",
    "XAR_INSTALL_ROOT",
    "XAR_LAUNCHER_PORT",
    "XAR_PRIVATE_ROOT",
    "XAR_SECRET_VAULT_KEY",
    "PORT"
  ]) delete cleanEnvironment[name];
  const desktop = spawn(process.execPath, [], {
    env: cleanEnvironment,
    detached: true,
    stdio: "ignore",
    windowsHide: false
  });
  desktop.unref();
}

relaunch().catch(() => {
  process.exitCode = 1;
});
