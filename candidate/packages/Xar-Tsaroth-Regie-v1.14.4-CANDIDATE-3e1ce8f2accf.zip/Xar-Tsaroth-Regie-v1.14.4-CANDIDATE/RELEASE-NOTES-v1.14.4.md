# Régie du Seuil 1.14.4 — Correctif de publication

- Le contrôle final du paquet public affiche désormais la version réellement extraite.
- Les correctifs précédents du dialogue administrateur, de consommation GPU et de relance après mise à jour sont conservés.
- Le code source est maintenu directement sur `main` ; l’installeur Windows n’est construit que sur demande explicite afin d’éviter les échecs automatiques sans certificat Authenticode.
- Aucun compte, mot de passe, vérificateur, donnée utilisateur, coffre, webhook ou secret n’est inclus dans les paquets.
