import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  downloadVerifiedPackage,
  extractZipArchive,
  loadApplicationRelease,
  locateExtractedApplicationRoot,
  validateExtractedUpdate,
  verifyInstallation,
  verifySignedUpdateManifest
} from "../launcher-core.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const manifestPath = process.argv[2];
if (!manifestPath) throw new Error("Usage : node scripts/verify-signed-package.mjs <latest-signe.json>");

const release = loadApplicationRelease(root);
const manifest = verifySignedUpdateManifest(JSON.parse(readFileSync(path.resolve(manifestPath), "utf8")), {
  applicationId: release.applicationId,
  publicKey: release.updatePublicKey,
  channel: release.channel
});
const temporaryRoot = mkdtempSync(path.join(tmpdir(), "xar-update-prepublication-"));
try {
  const archive = path.join(temporaryRoot, `Xar-Tsaroth-Regie-v${manifest.version}.zip`);
  const downloaded = await downloadVerifiedPackage(manifest.package, archive);
  const extractionRoot = path.join(temporaryRoot, "extracted");
  await extractZipArchive(archive, extractionRoot);
  const applicationRoot = locateExtractedApplicationRoot(extractionRoot);
  const extractedRelease = validateExtractedUpdate(applicationRoot, manifest, release, { allowSameVersion: true });
  const integrity = verifyInstallation(applicationRoot);
  if (!integrity.ok) throw new Error("Le paquet distant extrait n’est pas intact.");
  console.log(JSON.stringify({
    version: extractedRelease.release.version,
    bytes: downloaded.size,
    sha256: downloaded.sha256,
    files: integrity.checkedFiles,
    status: "paquet signé distant valide avant activation"
  }, null, 2));
} finally {
  rmSync(temporaryRoot, { recursive: true, force: true });
}
