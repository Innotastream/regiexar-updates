import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { pathToFileURL, fileURLToPath } from "node:url";
import {
  compareApplicationVersions,
  downloadVerifiedPackage,
  extractZipArchive,
  fetchSignedUpdateManifest,
  loadApplicationRelease,
  locateExtractedApplicationRoot
} from "../launcher-core.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const targetManifestPath = process.argv[2];
if (!targetManifestPath) throw new Error("Usage : node scripts/verify-update-compatibility.mjs <latest-signe.json>");

const release = loadApplicationRelease(root);
const distributedManifest = await fetchSignedUpdateManifest(release.updateManifestUrl, {
  applicationId: release.applicationId,
  publicKey: release.updatePublicKey,
  channel: release.channel
});
const targetManifest = JSON.parse(readFileSync(path.resolve(targetManifestPath), "utf8"));
if (compareApplicationVersions(distributedManifest.version, targetManifest.version) >= 0) {
  throw new Error("Le canal doit encore annoncer la version précédente pendant le contrôle de compatibilité.");
}

const temporaryRoot = mkdtempSync(path.join(tmpdir(), "xar-update-compatibility-"));
try {
  const distributedArchive = path.join(temporaryRoot, "distributed.zip");
  await downloadVerifiedPackage(distributedManifest.package, distributedArchive);
  const distributedExtraction = path.join(temporaryRoot, "distributed");
  await extractZipArchive(distributedArchive, distributedExtraction);
  const distributedRoot = locateExtractedApplicationRoot(distributedExtraction);
  const previousCore = await import(`${pathToFileURL(path.join(distributedRoot, "launcher-core.mjs")).href}?compatibility=${Date.now()}`);
  const previousRelease = previousCore.loadApplicationRelease(distributedRoot);
  const previousIntegrity = previousCore.verifyInstallation(distributedRoot);
  if (!previousIntegrity.ok) throw new Error("La version actuellement distribuée n’est pas intègre.");

  const verifiedTarget = previousCore.verifySignedUpdateManifest(targetManifest, {
    applicationId: previousRelease.applicationId,
    publicKey: previousRelease.updatePublicKey,
    channel: previousRelease.channel
  });
  const targetArchive = path.join(temporaryRoot, "target.zip");
  await previousCore.downloadVerifiedPackage(verifiedTarget.package, targetArchive);
  const targetExtraction = path.join(temporaryRoot, "target");
  await previousCore.extractZipArchive(targetArchive, targetExtraction);
  const targetRoot = previousCore.locateExtractedApplicationRoot(targetExtraction);
  const checked = previousCore.validateExtractedUpdate(targetRoot, verifiedTarget, previousRelease);
  console.log(JSON.stringify({
    fromVersion: previousRelease.version,
    toVersion: checked.release.version,
    files: checked.integrity.checkedFiles,
    status: "paquet accepté par l’updater actuellement distribué"
  }, null, 2));
} finally {
  rmSync(temporaryRoot, { recursive: true, force: true });
}
