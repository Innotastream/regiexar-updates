import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  downloadVerifiedPackage,
  extractZipArchive,
  fetchSignedUpdateManifest,
  loadApplicationRelease,
  locateExtractedApplicationRoot,
  validateExtractedUpdate,
  verifyInstallation
} from "../launcher-core.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const release = loadApplicationRelease(root);
const manifestUrl = process.argv[2] || release.updateManifestUrl;
if (!manifestUrl) throw new Error("Adresse du canal de mise à jour absente.");

const temporaryRoot = mkdtempSync(path.join(tmpdir(), "xar-update-publication-"));
try {
  const manifest = await fetchSignedUpdateManifest(manifestUrl, {
    applicationId: release.applicationId,
    publicKey: release.updatePublicKey,
    channel: release.channel
  });
  const archive = path.join(temporaryRoot, `Xar-Tsaroth-Regie-v${manifest.version}.zip`);
  const downloaded = await downloadVerifiedPackage(manifest.package, archive);
  const extractionRoot = path.join(temporaryRoot, "extracted");
  await extractZipArchive(archive, extractionRoot);
  const applicationRoot = locateExtractedApplicationRoot(extractionRoot);
  const extractedRelease = validateExtractedUpdate(applicationRoot, manifest, release, { allowSameVersion: true });
  const integrity = verifyInstallation(applicationRoot);
  if (!integrity.ok) throw new Error("Le paquet distant extrait n’est pas intact.");
  console.log(JSON.stringify({
    manifestUrl,
    version: extractedRelease.release.version,
    bytes: downloaded.size,
    sha256: downloaded.sha256,
    files: integrity.checkedFiles,
    status: "publication distante valide"
  }, null, 2));
} finally {
  rmSync(temporaryRoot, { recursive: true, force: true });
}
