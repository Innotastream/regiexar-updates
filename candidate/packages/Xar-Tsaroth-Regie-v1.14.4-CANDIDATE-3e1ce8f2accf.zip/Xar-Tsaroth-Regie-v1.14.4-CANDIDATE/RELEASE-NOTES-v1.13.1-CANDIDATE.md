# Régie du Seuil 1.13.1 — Candidate de transition

## Rotation explicite de la clé de mise à jour

- Remplace la clé publique Ed25519 historique dont la partie privée n’est plus récupérable.
- La nouvelle clé privée est conservée dans le secret GitHub Actions `XAR_UPDATE_SIGNING_KEY_PEM` du dépôt source privé et dans une sauvegarde chiffrée distincte.
- Un contrôle Actions dérive la clé publique depuis le secret et exécute une signature de test sans afficher la valeur privée.
- Les paquets, empreintes et manifestes restent vérifiés avant toute installation ; aucun téléchargement non signé n’est accepté.

## Transition unique

- Les installations 1.12.0 et antérieures doivent installer manuellement la 1.13.1 une seule fois, car elles ne peuvent pas faire confiance à une nouvelle clé sans signature de l’ancienne paire.
- Après cette installation, les mises à jour signées par la nouvelle clé sont de nouveau détectées automatiquement.
- Les scènes, fiches, médias et paramètres restent dans le profil utilisateur séparé et ne sont pas remplacés par l’installation.

## Contenu fonctionnel conservé

- Reprend intégralement la 1.13.0 candidate : entrées MJ/Joueur séparées, accès MJ quotidien, coffre de secrets, fiches locales persistantes, invocations liées, pings de carte et mutes audio locaux.
- Cette livraison reste **candidate** tant qu’elle n’a pas reçu la validation visuelle et fonctionnelle explicite de l’utilisateur.
