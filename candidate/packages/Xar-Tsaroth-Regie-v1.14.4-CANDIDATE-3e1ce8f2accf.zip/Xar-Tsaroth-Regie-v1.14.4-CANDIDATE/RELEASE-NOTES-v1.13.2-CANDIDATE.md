# Régie du Seuil 1.13.2 — Candidate d’installation Windows

## Installation commune

- Supprime la page proposant une installation limitée à l’utilisateur courant.
- Installe toujours l’enveloppe Windows pour tous les comptes après élévation administrateur.
- Utilise par défaut `C:\Program Files\Xar-Tsaroth`.
- Crée les raccourcis communs tout en conservant les scènes, fiches, médias, réglages et secrets dans le profil privé de chaque utilisateur.

## Signature Windows obligatoire

- Refuse de construire ou publier un installeur si le certificat Authenticode public est absent.
- Vérifie après construction la signature de l’application et du programme d’installation ainsi que la présence de l’identité d’éditeur.
- Conserve séparément la signature Ed25519 du canal de mise à jour ; aucune clé privée n’entre dans le projet ou les livrables.

## Base préservée

- Repart sans rollback de la 1.13.1, désormais validée stable.
- Ne modifie aucune donnée de partie ni aucun schéma de fiche.
