import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { chmodSync, existsSync, readFileSync, renameSync, rmSync, writeFileSync } from "node:fs";

export const SECRET_ENVIRONMENT_KEYS = Object.freeze([
  "PLAYER_ACCESS_CODE",
  "DISCORD_IMAGE_WEBHOOK_URL",
  "DISCORD_DICE_WEBHOOK_URL",
  "DISCORD_JOURNAL_WEBHOOK_URL",
  "OVH_FTP_PASSWORD",
  "PLAYER_LAST_CONNECTION_URL"
]);

const AUTHENTICATED_DATA = Buffer.from("xar-tsaroth-regie-secret-vault-v1", "utf8");

export function vaultKeyFromEnvironment(environment = process.env) {
  const encoded = String(environment.XAR_SECRET_VAULT_KEY ?? "").trim();
  if (!encoded) return null;
  const key = Buffer.from(encoded, "base64");
  if (key.length !== 32) throw new Error("La clé du coffre système est invalide.");
  return key;
}

function normalizedSecrets(value) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  return Object.fromEntries(SECRET_ENVIRONMENT_KEYS
    .filter((key) => Object.prototype.hasOwnProperty.call(source, key))
    .map((key) => [key, String(source[key] ?? "")]));
}

export function splitSecretEnvironment(values = {}) {
  const publicValues = { ...values };
  const secrets = {};
  for (const key of SECRET_ENVIRONMENT_KEYS) {
    if (!Object.prototype.hasOwnProperty.call(publicValues, key)) continue;
    secrets[key] = String(publicValues[key] ?? "");
    delete publicValues[key];
  }
  return { publicValues, secrets };
}

export function encryptSecrets(secrets, key) {
  if (!Buffer.isBuffer(key) || key.length !== 32) throw new Error("Clé de coffre indisponible.");
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  cipher.setAAD(AUTHENTICATED_DATA);
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(normalizedSecrets(secrets)), "utf8"), cipher.final()]);
  return {
    schemaVersion: 1,
    cipher: "aes-256-gcm",
    iv: iv.toString("base64"),
    tag: cipher.getAuthTag().toString("base64"),
    ciphertext: ciphertext.toString("base64")
  };
}

export function decryptSecrets(payload, key) {
  if (!Buffer.isBuffer(key) || key.length !== 32) throw new Error("Clé de coffre indisponible.");
  if (payload?.schemaVersion !== 1 || payload?.cipher !== "aes-256-gcm") throw new Error("Format de coffre non pris en charge.");
  const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(payload.iv, "base64"));
  decipher.setAAD(AUTHENTICATED_DATA);
  decipher.setAuthTag(Buffer.from(payload.tag, "base64"));
  const plaintext = Buffer.concat([decipher.update(Buffer.from(payload.ciphertext, "base64")), decipher.final()]);
  return normalizedSecrets(JSON.parse(plaintext.toString("utf8")));
}

export function readSecretVault(filePath, key) {
  if (!existsSync(filePath)) return {};
  return decryptSecrets(JSON.parse(readFileSync(filePath, "utf8")), key);
}

export function writeSecretVault(filePath, secrets, key) {
  const temporary = `${filePath}.${process.pid}.partial`;
  writeFileSync(temporary, `${JSON.stringify(encryptSecrets(secrets, key), null, 2)}\n`, { mode: 0o600 });
  rmSync(filePath, { force: true });
  renameSync(temporary, filePath);
  try { chmodSync(filePath, 0o600); } catch {}
}
