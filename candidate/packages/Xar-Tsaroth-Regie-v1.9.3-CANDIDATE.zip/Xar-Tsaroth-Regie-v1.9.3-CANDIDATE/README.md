# Xar Tsaroth — Régie du Seuil 1.9.3 candidate

Une régie autonome et collaborative pour mener une partie de **Xar Tsaroth** sans modifier le site public. Elle réunit scènes, fiches MJ/joueurs, carte tactique, initiative, musique, ambiances, jets, Discord, OVH et une forge d’images assistée par ChatGPT.

## Démarrage

### Windows

1. Installez [Node.js 20 LTS ou plus récent](https://nodejs.org/) si ce n’est pas déjà fait. Cette dépendance reste provisoire jusqu’au futur installateur Tauri.
2. Décompressez entièrement le ZIP.
3. Double-cliquez sur `start-windows.bat`.
4. Le mini-installateur contrôle le ZIP, copie le programme dans `%LOCALAPPDATA%\Programs\XarTsarothRegie`, puis ouvre le **Launcher de la Régie** sur `http://127.0.0.1:4169`. L’application locale répond sur `http://127.0.0.1:4173`.

### macOS ou Linux

Dans le dossier de l’application :

```bash
chmod +x start.sh
./start.sh
```

Le script de démarrage installe d’abord le programme dans un répertoire applicatif dédié au compte utilisateur (`LocalAppData/Programs/XarTsarothRegie` sous Windows, `~/Applications/Xar Tsaroth Regie` sous macOS ou `~/.local/share/xar-tsaroth-regie/app` sous Linux). Relancer un ZIP plus récent actualise ce dossier sans retour arrière silencieux. Le launcher vérifie ensuite la version **applicative** déclarée dans `application.json` ; la version de Node.js n’est pas le numéro du build.

La première ouverture crée séparément un dossier de données privé dans le profil du compte utilisateur (`LocalAppData/XarTsarothRegie/data` sous Windows, dossier de configuration utilisateur sous macOS/Linux). La session, les scènes, le bestiaire, les pistes audio et les fiches n’habitent donc jamais dans le répertoire du programme. Mise à jour, réinstallation ou suppression du seul dossier applicatif ne les efface pas. Si une ancienne version contient encore un dossier `data`, l’installateur le copie une seule fois vers cet emplacement partagé.

Chaque joueur possède en plus son propre stockage de fiches dans `data/users/<identifiant-technique>/characters.json`. Cet identifiant est un condensat irréversible de l’identifiant interne du joueur : aucun jeton d’accès n’est écrit dans ce fichier. Une suppression de l’ancien dossier applicatif ou l’installation d’un nouveau build ne supprime donc plus les fiches.

Chaque fiche contient un `characterSchemaVersion`. Lorsqu’un build ajoute des champs, la Régie applique les migrations dans l’ordre et crée d’abord une copie `backups/characters-before-migration-*.json`. La fiche s’actualise donc avec le build sans perdre son contenu. Si elle provient réellement d’une version future, elle reste intacte et l’interface demande simplement de mettre la Régie à jour au lieu de l’écraser.

Au premier lancement avec un `.env.local`, le launcher en conserve automatiquement une copie privée dans le profil du compte utilisateur (`LocalAppData` sous Windows, dossier de configuration utilisateur sous macOS/Linux). Chaque nouveau build la relit directement, même si les anciens dossiers ont été supprimés. Le fichier privé n’est jamais inclus dans le ZIP partageable : les webhooks et le mot de passe FTP ne peuvent donc pas être distribués par erreur.

### Canal de mise à jour actif en 1.9.3 candidate

Le moteur d’auto-update est relié au canal public signé `regiexar-updates` : contrôle du manifeste Ed25519, téléchargement borné, empreinte SHA-256, extraction ZIP protégée, validation du manifeste interne, remplacement atomique du programme, point de retour et relance automatique. Le dépôt public ne contient que les artefacts distribuables ; la source demeure dans le dépôt privé de la Régie. La clé publique de confiance est intégrée tandis que la clé privée reste hors du projet, de Git et du ZIP. Le protocole est décrit dans [`MISES-A-JOUR-APPLICATION.md`](MISES-A-JOUR-APPLICATION.md).

## MJ, joueurs et personnages

- **Joueur** : la personne qui reçoit un lien privé.
- **Personnage** : sa fiche de jeu. Un joueur peut en posséder plusieurs.
- **Vue du groupe** : carte, ordre des tours, scène, jets révélés et audio.
- **Lien personnel** : ajoute la fiche privée du joueur et le contrôle de ses tokens attribués.

Dans l’onglet **Personnages**, sélectionnez un joueur puis utilisez **Copier le lien personnel**. Le lien contient un jeton d’accès propre à ce joueur. Si vous le régénérez, l’ancien lien cesse de fonctionner.

Adresses typiques :

- Régie MJ : `http://localhost:4173`
- Vue du groupe : `http://localhost:4173/player.html`
- Autre appareil du même réseau : remplacez `localhost` par l’adresse locale du PC du MJ, par exemple `http://192.168.1.25:4173/player.html`.

La fiche complète MJ n’est accessible que depuis la machine qui lance l’application. Un joueur authentifié ne reçoit que ses propres fiches ; les notes secrètes, la résistance mentale secrète, les jets MJ et les tokens cachés sont filtrés côté serveur.

## Fonctions principales

- **Scènes réellement indépendantes** : quatre scènes génériques `Scène 1` à `Scène 4`, renommables immédiatement. Chaque scène conserve sa propre map, ses tokens, son cadrage, sa grille, son initiative, son round et son tour actif. Le rail des scènes reste uniquement dans l’onglet Régie. Une nouvelle scène peut partir vide ou dupliquer le combat courant.
- **Mode libre par défaut** : ouvrir une scène ou poser un token ne crée aucun tour actif. Aucun halo de tour n’est affiché et les joueurs peuvent déplacer les tokens qui leur appartiennent.
- **Initiative volontaire en d100** : un token présent sur la carte n’entre pas automatiquement dans la séquence. Le MJ peut lancer l’initiative d’un token depuis sa fiche, lancer tous les tokens présents, modifier ou trier les scores, puis retirer individuellement un participant. Un joueur peut également lancer l’initiative de son personnage avant le combat ; le jet prépare la liste sans activer les tours.
- **Cycle de combat explicite** : **Démarrer le combat** exige au moins une initiative préparée, remet le round à 1 et active le premier token. **Repasser en libre** supprime immédiatement tout tour actif et tout halo, mais conserve la carte et la liste préparée.
- **Déplacements joueurs sécurisés** : en combat, un joueur ne peut déplacer que le token qui lui appartient pendant son tour actif ; en mode libre, il peut déplacer tous ses tokens. Le mode est déduit et contrôlé par le serveur, pas seulement affiché dans l’interface.
- **Préparation secrète MJ** : un bouton fige la dernière table publiée chez les joueurs et verrouille leurs déplacements pendant que le MJ ajoute, positionne ou masque des créatures. **Publier & reprendre** révèle ensuite le nouvel état en une seule fois.
- **Jets identifiés** : initiative, perception et tests généraux normalisés en `1d100`; formules de dégâts libres comme `2d6+4`; jets publics, secrets MJ ou masqués puis révélables. Les résultats indiquent toujours le lanceur (`MJ` ou nom du joueur), et chaque joueur peut lancer ses raccourcis depuis sa fiche.
- **Raccourcis intuitifs** : depuis Combat ou Régie, créez en quelques clics une initiative, une perception, un test d100, des dégâts ou une formule personnalisée pour le MJ ou un personnage nommé. Chaque raccourci peut être public, secret ou masqué, puis supprimé depuis la même liste.
- **Calculatrice tactique** : calcul libre sécurisé avec `+`, `−`, `×`, `÷`, parenthèses et `%`, plus un assistant explicite pour « 15 % de 54 », ajouter un pourcentage ou le retirer. Tous les résultats utilisent l’arrondi demandé : décimale inférieure à `0,5` vers le bas, décimale supérieure ou égale à `0,5` vers le haut.
- **Actions et temps de recharge** : le MJ ou un joueur peut noter une action utilisée et sa recharge en tours. Une action utilisée au round 1 avec une recharge de 5 redevient disponible au round 6. Les rappels privés d’un joueur ne sont visibles que par lui et le MJ ; une case permet de les partager à tous.
- **Carte tactique** : import d’image, zoom de 25 % à 450 %, panoramique, grille par défaut de 50 px qui suit exactement l’échelle de la map, opacité, recentrage et étalonnage par décalage X/Y ou glisser direct de la grille.
- **Commandes tactiques centralisées** : un repère `Carte → Tokens → Combat` guide la préparation. Les réglages **Map & grille**, la fiche du **Token sélectionné** et le **Partage** disposent chacun de leur propre volet rétractable en haut de l’écran ; l’ajout de tokens est regroupé dans un menu unique et les tokens restent sélectionnables au clavier.
- **Interface défilable** : sur ordinateur, chaque onglet défile dans la zone centrale sans faire disparaître la navigation ni le lecteur audio ; sur mobile, la page conserve son défilement naturel.
- **Panoramique contenu** : le clic-glissé déplace la map uniquement à l’intérieur de son cadre et bloque le glisser natif de l’image dans Chrome, Firefox et Edge.
- **Mises à jour sans ancien cache** : l’interface locale n’est plus mise en cache entre deux builds servis sur la même adresse.
- **Launcher applicatif thématique** : écran violet métallique, sceau animé, barre de progression dorée/orangée, états techniques lisibles, navigation clavier, réduction des animations selon la préférence système et version discrète en pied d’écran.
- **Auto-update réellement installable** : téléchargement signé, extraction anti-traversée, contrôle des fichiers inattendus, sauvegarde de retour, remplacement atomique et reconnexion automatique au launcher mis à jour.
- **Programme séparé des données** : le mini-installateur gère un répertoire applicatif dédié tandis que les fiches, scènes, médias et réglages restent dans un autre emplacement persistant.
- **Fiches durables par joueur** : fichier privé distinct pour chaque propriétaire, synchronisé côté serveur à chaque sauvegarde, restauré après mise à jour et migré avec sauvegarde préalable.
- **Tokens-fiches** : image, nom, couleur, taille manuelle et gabarits petite `20`, normale `30`, grosse `60`, très grosse `90`, PV, mana, dégâts en dés, défense, vitesse, état, statistiques libres, notes, initiative, personnage lié et joueur contrôleur. Chaque déplacement s’aimante au centre d’une case, se synchronise après relâchement et s’anime sur les autres écrans.
- **Bestiaire persistant** : depuis la fiche d’un token, enregistrez ou mettez à jour un modèle complet, recherchez-le puis invoquez un nouvel exemplaire dans n’importe quelle scène. Les modèles conservent image, fiche et confidentialité, mais ne recopient jamais un lien joueur/personnage.
- **Confidentialité des créatures** : les PV, mana, dégâts, états, statistiques et notes partageables des tokens MJ sont cachés aux joueurs par défaut. Une case permet de les révéler ; les notes secrètes MJ ne sont jamais envoyées. Les tokens attribués aux joueurs partagent automatiquement leur fiche tactique.
- **Capture Discord publique** : le rendu envoyé reprend le cadrage, le zoom, l’étalonnage de grille et la taille des tokens de la vue MJ, mais retire les tokens cachés et les informations secrètes comme les PV des monstres non révélés. Sa légende est modifiable et une case choisit si le round et le tour actif sont ajoutés.
- **Fiches reliées** : identité, HP/mana, fatigue, morale, six statistiques d100, armure, armes/dégâts, passifs, compétences, langues, inventaire, notes et raccourcis. Le joueur et le MJ peuvent modifier la fiche en direct.
- **Zone secrète MJ** : résistance mentale, malédictions, secrets et déclencheurs ne sont jamais transmis au joueur.
- **Audio en direct** : pistes musique et ambiance stockées par le serveur local, deux volumes de canal, volume maître et Silence global. Chaque joueur clique une seule fois sur **Activer le son** à cause des règles des navigateurs.
- **Pont navigateur ChatGPT facultatif** : deux conversations ciblées, prompts préparés, jusqu’à huit références jointes simultanément, liste claire et suppression individuelle, raccourcis depuis les portraits des personnages et import du résultat en un clic visible.
- **Prompts de cartes étalonnés** : le raccourci Carte de combat demande une échelle virtuelle de 50 px par case, une porte double de deux cases / 100 px et interdit toute grille dessinée dans l’image.
- **Images sans facturation API** : le pont utilise la session ChatGPT déjà ouverte dans Chrome/Edge sans lire ses cookies ; le collage/import/glisser-déposer manuel reste toujours disponible.
- **Sauvegarde** : état serveur automatique, secours navigateur et export/import JSON. Les jetons privés sont volontairement retirés des exports et régénérés à l’import.

## Configuration des services

Copiez `.env.example` sous le nom `.env.local`, puis remplissez uniquement les services utilisés. Redémarrez la régie après toute modification.

```dotenv
DISCORD_IMAGE_WEBHOOK_URL=https://discord.com/api/webhooks/...
DISCORD_DICE_WEBHOOK_URL=https://discord.com/api/webhooks/...
DISCORD_JOURNAL_WEBHOOK_URL=https://discord.com/api/webhooks/...

OVH_FTP_URL=sftp://ftp.cluster129.hosting.ovh.net:22/~/regie-media/
OVH_FTP_USER=votre-identifiant-ovh
OVH_FTP_PASSWORD=...
OVH_PUBLIC_BASE_URL=

PLAYER_ACCESS_CODE=...
```

### Discord

Créez un webhook dans chaque salon ciblé, puis affectez-le à la variable correspondante : illustrations/captures, jets/dégâts et journal. Aucun mot de passe Discord n’est demandé à l’application.

### OVH

Le dossier `~/regie-media` créé à côté de `www` se configure de préférence avec l’adresse `sftp://ftp.cluster129.hosting.ovh.net:22/~/regie-media/`. La notation `/~/` dans l’URL signifie « depuis le dossier personnel de l’utilisateur » ; la Régie la traduit correctement pour chaque client de transfert. Le dossier ne modifie pas les fichiers du site.

Sous Windows, certaines versions de `curl` n’intègrent pas le protocole SFTP. Si ce cas est détecté, la Régie utilise automatiquement le client OpenSSH sécurisé de Windows (`sftp.exe`) en session standard pilotée, afin de conserver l’authentification normale par mot de passe utilisée par FileZilla. Elle n’utilise pas le mode batch OpenSSH, qui peut couper cette authentification. Le mot de passe n’est écrit ni dans une commande ni dans un fichier persistant : un assistant temporaire est créé pour la connexion puis supprimé. La Régie ne replie jamais la connexion vers du FTP non chiffré. Si Windows signale que `sftp.exe` est introuvable, activez la fonctionnalité facultative **Client OpenSSH** dans les paramètres Windows.

Une adresse `ftp://` configurée directement reste forcée en TLS avec `--ssl-reqd`. Pour OVH, conservez de préférence l’adresse SFTP affichée dans votre espace client, avec son port.

Ce dossier n’est pas automatiquement visible sur le Web. Laissez `OVH_PUBLIC_BASE_URL` vide tant qu’aucun domaine ou chemin HTTP ne lui est rattaché. L’envoi direct sur Discord reste fonctionnel sans URL OVH publique.

#### Nettoyage automatique des médias OVH

- Chaque image envoyée par la Régie reçoit un nom interne protégé et est inscrite dans un petit registre distant.
- Au premier démarrage de chaque nouveau build, les médias enregistrés par les anciens builds sont supprimés automatiquement.
- La première exécution de chaque build effectue aussi une migration des anciens fichiers v1.2.0 reconnaissables à leur nom horodaté.
- Le bouton **Nettoyer maintenant** permet de relancer immédiatement le contrôle.
- Les fichiers inconnus dont le nom ne correspond ni au format protégé actuel ni au format historique de la Régie ne sont jamais supprimés. La Régie refuse également de nettoyer la racine FTP ou un dossier nommé `www`.
- Si une suppression échoue, le fichier reste dans le registre et sera retenté au prochain démarrage.

### ChatGPT et la Forge d’images

La Régie ne demande aucune clé API OpenAI. Deux flux coexistent :

#### Pont navigateur assisté

1. Ouvrez deux conversations ChatGPT que vous souhaitez réserver, par exemple **Personnages & portraits** et **Scènes, décors & cartes**.
2. Dans la Forge, cliquez sur **Configurer** et collez leurs adresses contenant `/c/`.
3. Ouvrez `chrome://extensions` ou `edge://extensions`, activez le mode développeur puis chargez le dossier `extension-chatgpt-xar` comme extension non empaquetée.
4. Copiez le code d’appairage affiché dans la Forge et collez-le dans l’extension.
5. Dans la Régie, choisissez la conversation, rédigez le prompt et sélectionnez les portraits à joindre.
6. Cliquez sur **Préparer dans ChatGPT**. Dans le panneau Xar de la conversation, choisissez **Préparer** ou **Préparer + envoyer**.
7. Sous une grande image générée, cliquez sur **Importer dans la Régie**.

Le pont n’extrait aucun cookie et ne connaît pas votre mot de passe. Il communique uniquement avec `127.0.0.1`/`localhost`, vérifie un code aléatoire propre à l’installation et n’agit que dans les deux conversations enregistrées. Chaque envoi et chaque import nécessite un clic visible. Comme il s’appuie sur l’interface web de ChatGPT, une évolution de cette interface peut nécessiter une mise à jour de l’extension.

#### Secours manuel

Le bouton **Copier / ouvrir manuellement** conserve le fonctionnement de la v1.1.1 : prompt dans le presse-papiers, ouverture de ChatGPT, puis collage, glisser-déposer ou import du résultat dans la Forge. Ce flux reste disponible même si l’extension n’est pas installée.

## Raccourcis clavier MJ

| Touche | Action |
|---|---|
| `N` | Tour suivant |
| `P` | Tour précédent |
| `I` | Préparer ou relancer toutes les initiatives d100 sans démarrer automatiquement le combat |
| `M` | Couper ou rétablir l’audio pour tout le monde |

## Sécurité et accès distant

- Ne partagez jamais `.env.local`, les webhooks Discord ou le mot de passe FTP.
- Pour une mise à jour manuelle, lancez simplement le nouveau build : le mini-installateur ne remplace que le programme et relit la configuration, la session et les fiches depuis le profil privé. Pour une mise à jour distante, le launcher appliquera le même principe après validation cryptographique.
- Ne partagez pas `data/chatgpt-bridge.json` : il contient le code local d’appairage et les identifiants des deux conversations ciblées.
- `.env.local`, `data/session-state.json`, `data/media/`, `data/chatgpt-bridge.json` et les imports temporaires sont ignorés par Git.
- Définissez `PLAYER_ACCESS_CODE` pour ajouter un code global à la vue joueurs. Les liens personnels restent en plus protégés par leur propre jeton aléatoire.
- Pour jouer à distance, privilégiez un VPN privé comme Tailscale/ZeroTier ou un proxy HTTPS authentifié. N’exposez pas directement le port `4173` sur Internet.
- La régie MJ complète demeure limitée aux connexions locales de l’ordinateur hôte.
- Le launcher 1.9.3 candidate réalise le cycle local d’installation et d’auto-update depuis un canal GitHub public signé, mais utilise encore Node.js 20+. Sous Windows, les métadonnées inoffensives `desktop.ini` créées par l’Explorateur sont ignorées, tandis qu’un réel écart d’intégrité affiche désormais le nom précis des fichiers concernés. Le plan des futurs exécutables sécurisés MJ/Joueur est détaillé dans [`ARCHITECTURE-SECURITE-LAUNCHERS.md`](ARCHITECTURE-SECURITE-LAUNCHERS.md). Il prévoit Tauri 2, Supabase Auth, PostgreSQL/RLS, Realtime filtré et stockage privé. Le présent serveur local n’est pas encore destiné à une exposition Internet directe et le stockage par compte multi-PC n’est pas encore activé.

## Vérification technique

```bash
npm test
```

Les tests couvrent la géométrie map/grille/tokens, l’isolation des combats par scène, le bestiaire privé, la séparation MJ/joueurs, les accès individuels, la modification parallèle des fiches, le contrôle des tokens, le filtrage des secrets, les médias avec lecture partielle, les stockages individuels, les migrations et sauvegardes de fiches, l’installation séparée des données, le manifeste d’intégrité, les signatures, l’extraction ZIP hostile, le remplacement atomique, le retour de sécurité, le repli sécurisé d’un `curl` Windows sans SFTP et une simulation complète du nettoyage FTP entre deux builds.
