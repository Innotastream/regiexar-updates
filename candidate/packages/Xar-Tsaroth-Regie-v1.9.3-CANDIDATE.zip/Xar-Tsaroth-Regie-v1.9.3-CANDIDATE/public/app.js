import { clamp, computeMapGeometry, mapPanFromDrag, mapPointFromClient, mapTokenScreenPosition, snapMapPercentPoint } from "./map-geometry.js";
import {
  DEFAULT_DISCORD_CAPTURE,
  DEFAULT_GRID_SIZE,
  DEFAULT_TOKEN_SIZE,
  TOKEN_SIZE_PRESETS,
  closestTokenSizePreset,
  withBattlemapScaleGuide
} from "./combat-standards.js";
import {
  cloneStateValue,
  createCombatSnapshot,
  createEmptyInitiativeState,
  createEmptyMapState,
  prepareSceneCombats,
  switchSceneCombat
} from "./scene-state.js";
import {
  normalizeInitiativeState as normalizeInitiativeRoster,
  sanitizeInitiativeOrder,
  sortInitiativeTokenIds
} from "./initiative-state.js";
import { applyPercentage, evaluateTacticalExpression, percentageOf } from "./tactical-calculator.js";
import {
  CHARACTER_SCHEMA_ID,
  CHARACTER_SCHEMA_VERSION,
  migrateCharacterSheet
} from "./character-schema.js";

const STORAGE_KEY = "xar-regie-state-v2";
const LEGACY_STORAGE_KEY = "xar-regie-state-v1";
const DB_NAME = "xar-regie-assets";
const DB_STORE = "assets";
const SCHEMA_VERSION = 8;
const MAX_FORGE_ATTACHMENTS = 8;
const MAX_TOKEN_TEMPLATES = 200;
const MAX_ACTION_TIMERS = 300;

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const uid = (prefix = "id") => `${prefix}-${crypto.randomUUID()}`;
const escapeHtml = (value = "") => String(value)
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#039;");

const CHARACTER_COLORS = {
  Inho: "#2f6fda",
  Hira: "#c94452",
  Gohachu: "#7b818b",
  Arvin: "#8056c7",
  Krael: "#63c9ee",
  Keyrie: "#4da467",
  Vraska: "#a84e1b"
};
const DEFAULT_CHARACTERS = Object.entries(CHARACTER_COLORS);

function slugify(value) {
  return String(value || "xar-tsaroth")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64) || "xar-tsaroth";
}

function newAccessToken() {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return [...bytes].map((value) => value.toString(16).padStart(2, "0")).join("");
}

function createDefaultPlayer(characterName = "") {
  const suffix = characterName ? slugify(characterName) : crypto.randomUUID();
  return {
    id: `player-${suffix}`,
    name: "À renseigner",
    accessToken: newAccessToken(),
    _updatedAt: Date.now()
  };
}

function createDefaultCharacter(name = "Personnage", color = "#8d72cb", ownerPlayerId = null) {
  return {
    characterSchema: CHARACTER_SCHEMA_ID,
    characterSchemaVersion: CHARACTER_SCHEMA_VERSION,
    id: `character-${slugify(name)}-${crypto.randomUUID().slice(0, 8)}`,
    ownerPlayerId,
    name,
    surname: "",
    givenName: name,
    race: "",
    age: "",
    className: "",
    advancedClass: "",
    profession: "",
    previousProfession: "",
    pronouns: "",
    portrait: null,
    color,
    resources: { hp: 0, maxHp: 0, mana: 0, maxMana: 0 },
    stats: { force: 0, dexterity: 0, agility: 0, spiritSocial: 0, intelligence: 0, instinct: 0 },
    fatigue: { current: 0, max: 100 },
    morale: "",
    armor: 0,
    speed: 0,
    initiativeBonus: 0,
    personalAdvantageStock: 0,
    armorText: "",
    weaponText: "",
    passives: "",
    skills: "",
    specialSkills: "",
    languages: "",
    inventory: "",
    publicNotes: "",
    conditions: [],
    secret: { mentalResistance: 0, mentalResistanceMax: 100, notes: "" },
    shortcuts: [
      { id: uid("character-shortcut"), label: "Initiative", formula: "1d100+0", kind: "initiative", visibility: "public" },
      { id: uid("character-shortcut"), label: "Perception", formula: "1d100+0", kind: "roll", visibility: "public" }
    ],
    _updatedAt: Date.now()
  };
}

function usesDamageDice(label = "") {
  return /d[eé]g[aâ]ts?|dommages?|damage/i.test(String(label));
}

function d100Formula(formula = "1d100") {
  const clean = String(formula || "1d100").replaceAll(" ", "");
  return /(?:\d*)d\d+/i.test(clean)
    ? clean.replace(/(?:\d*)d\d+/i, "1d100")
    : `1d100${clean ? `${/^[+\-]/.test(clean) ? "" : "+"}${clean}` : ""}`;
}

function defaultScenes() {
  const accents = ["#b78b52", "#5bb89a", "#718fce", "#9a6ee2"];
  return accents.map((accent, index) => ({
    id: `scene-${index + 1}`,
    name: `Scène ${index + 1}`,
    subtitle: "À préparer",
    description: "",
    accent,
    prompt: "",
    combat: createCombatSnapshot()
  }));
}

function initialState() {
  const players = [];
  const characters = [];
  for (const [name, color] of DEFAULT_CHARACTERS) {
    const player = createDefaultPlayer(name);
    const character = createDefaultCharacter(name, color, player.id);
    player.id = `player-${slugify(name)}`;
    character.id = `character-${slugify(name)}`;
    character.ownerPlayerId = player.id;
    players.push(player);
    characters.push(character);
  }
  return {
    schemaVersion: SCHEMA_VERSION,
    revision: 0,
    session: { name: "Session de Xar Tsaroth", gmName: "Innota", voiceLabel: "Discord", phase: "Préparation" },
    scenes: defaultScenes(),
    activeSceneId: null,
    activeScene: null,
    players,
    characters,
    map: createEmptyMapState(),
    discordCapture: { ...DEFAULT_DISCORD_CAPTURE },
    initiative: createEmptyInitiativeState(),
    tacticalSync: {
      paused: false,
      pausedAt: null,
      playerMovementMode: "free",
      publishedMap: null,
      publishedInitiative: null,
      publishedActiveScene: null
    },
    actionTimers: [],
    actionTimerTombstones: [],
    tokenLibrary: [],
    shortcuts: [
      { id: "shortcut-test", label: "Test général", formula: "1d100", visibility: "public" },
      { id: "shortcut-perception", label: "Perception", formula: "1d100", visibility: "public" },
      { id: "shortcut-furtivite", label: "Furtivité", formula: "1d100", visibility: "public" },
      { id: "shortcut-damage", label: "Dégâts", formula: "2d6+4", visibility: "public" },
      { id: "shortcut-secret", label: "Perception secrète", formula: "1d100", visibility: "gm" }
    ],
    rolls: [],
    tracks: [],
    audio: {
      masterVolume: 70,
      musicVolume: 72,
      ambienceVolume: 48,
      muted: false,
      music: { trackId: null, playing: false, position: 0, startedAt: null },
      ambience: { trackId: null, playing: false, position: 0, startedAt: null }
    },
    forge: { imageDataUrl: null, prompt: "", revisedPrompt: null }
  };
}

function normalizeCharacter(raw, ownerPlayerId = null) {
  const migrated = migrateCharacterSheet(raw ?? {}, { ownerPlayerId }).character;
  const fallback = createDefaultCharacter(migrated.name || migrated.characterName || "Personnage", migrated.color || "#8d72cb", ownerPlayerId);
  const resources = migrated.resources ?? { hp: migrated.hp ?? 0, maxHp: migrated.maxHp ?? 0, mana: 0, maxMana: 0 };
  const knownColor = CHARACTER_COLORS[migrated.name || migrated.characterName];
  return {
    ...fallback,
    ...migrated,
    characterSchema: CHARACTER_SCHEMA_ID,
    characterSchemaVersion: CHARACTER_SCHEMA_VERSION,
    name: migrated.name || migrated.characterName || fallback.name,
    ownerPlayerId: migrated.ownerPlayerId ?? ownerPlayerId ?? fallback.ownerPlayerId,
    color: migrated.color || knownColor || fallback.color,
    resources: { ...fallback.resources, ...resources },
    stats: { ...fallback.stats, ...(migrated.stats ?? {}) },
    fatigue: { ...fallback.fatigue, ...(migrated.fatigue ?? {}) },
    secret: { ...fallback.secret, ...(migrated.secret ?? {}) },
    conditions: Array.isArray(migrated.conditions) ? migrated.conditions : [],
    shortcuts: Array.isArray(raw?.shortcuts) ? migrated.shortcuts.map(normalizeShortcut) : fallback.shortcuts,
    _updatedAt: Number(migrated._updatedAt ?? 0)
  };
}

function normalizeShortcut(shortcut) {
  const label = shortcut?.label || "Jet";
  const kind = ["roll", "initiative", "damage"].includes(shortcut?.kind) ? shortcut.kind : "roll";
  let formula = shortcut?.formula || "1d100";
  if (kind !== "damage" && (kind === "initiative" || !usesDamageDice(label))) formula = d100Formula(formula);
  return { id: shortcut?.id || uid("shortcut"), label, formula, kind, visibility: shortcut?.visibility || "public" };
}

function normalizeTokenStats(stats) {
  if (Array.isArray(stats)) {
    return stats.slice(0, 20).map((entry) => ({
      id: entry?.id || uid("token-stat"),
      label: String(entry?.label || "Stat").slice(0, 40),
      value: String(entry?.value ?? "").slice(0, 80)
    }));
  }
  if (stats && typeof stats === "object") {
    return Object.entries(stats).slice(0, 20).map(([label, value]) => ({ id: uid("token-stat"), label, value: String(value ?? "") }));
  }
  return [];
}

function characterTokenStats(character) {
  const labels = {
    force: "Force", dexterity: "Dextérité", agility: "Agilité", spiritSocial: "Esprit / Social",
    intelligence: "Intelligence", instinct: "Instinct / Perception"
  };
  return Object.entries(character?.stats ?? {}).map(([key, value]) => ({
    id: `character-stat-${key}`,
    label: labels[key] || key,
    value: String(value ?? "")
  }));
}

function migrateLegacyState(legacy) {
  const base = initialState();
  if (!legacy || typeof legacy !== "object") return base;
  const players = [];
  const characters = [];
  const legacyPlayerToCharacter = new Map();
  for (const legacyPlayer of legacy.players ?? []) {
    const name = legacyPlayer.characterName || "Personnage";
    const player = {
      id: legacyPlayer.id || uid("player"),
      name: legacyPlayer.playerName || "À renseigner",
      accessToken: newAccessToken(),
      _updatedAt: 0
    };
    const color = CHARACTER_COLORS[name] || legacyPlayer.color || "#8d72cb";
    const character = normalizeCharacter({ ...legacyPlayer, id: `character-${slugify(name)}-${crypto.randomUUID().slice(0, 6)}`, name, color }, player.id);
    players.push(player);
    characters.push(character);
    legacyPlayerToCharacter.set(player.id, character.id);
  }
  for (const [name, color] of DEFAULT_CHARACTERS) {
    if (characters.some((character) => character.name.toLowerCase() === name.toLowerCase())) continue;
    const player = createDefaultPlayer(name);
    player.id = `player-${slugify(name)}`;
    const character = createDefaultCharacter(name, color, player.id);
    character.id = `character-${slugify(name)}`;
    players.push(player);
    characters.push(character);
  }
  const scenes = Array.isArray(legacy.scenes) && legacy.scenes.length
    ? legacy.scenes.map((scene, index) => ({ ...scene, name: `Scène ${index + 1}` }))
    : base.scenes;
  const tokens = (legacy.map?.tokens ?? []).map((token) => ({
    ...token,
    size: Number(token.size) === 62 ? DEFAULT_TOKEN_SIZE : (Number(token.size) || DEFAULT_TOKEN_SIZE),
    characterId: token.characterId || legacyPlayerToCharacter.get(token.playerId) || null,
    controllerPlayerId: token.controllerPlayerId || token.playerId || null,
    followCharacter: Boolean(token.playerId),
    _updatedAt: 0,
    _movedAt: 0
  }));
  const musicTrackId = legacy.audio?.music?.trackId ?? legacy.audio?.musicTrackId ?? null;
  const ambienceTrackId = legacy.audio?.ambience?.trackId ?? legacy.audio?.ambienceTrackId ?? null;
  return {
    ...base,
    ...legacy,
    schemaVersion: SCHEMA_VERSION,
    session: { ...base.session, ...(legacy.session ?? {}) },
    scenes,
    activeScene: legacy.activeScene ? { ...legacy.activeScene, name: scenes.find((scene) => scene.id === legacy.activeSceneId)?.name || legacy.activeScene.name } : null,
    players,
    characters,
    map: {
      ...base.map,
      ...(legacy.map ?? {}),
      zoom: 1,
      panX: 0,
      panY: 0,
      gridSize: Number(legacy.map?.gridSize) === 64 ? DEFAULT_GRID_SIZE : (Number(legacy.map?.gridSize) || DEFAULT_GRID_SIZE),
      gridOffsetX: 0,
      gridOffsetY: 0,
      tokens
    },
    discordCapture: { ...base.discordCapture, ...(legacy.discordCapture ?? {}) },
    shortcuts: (legacy.shortcuts ?? base.shortcuts).map(normalizeShortcut),
    tracks: Array.isArray(legacy.tracks) ? legacy.tracks : [],
    audio: {
      ...base.audio,
      ...(legacy.audio ?? {}),
      music: { ...base.audio.music, ...(legacy.audio?.music ?? {}), trackId: musicTrackId },
      ambience: { ...base.audio.ambience, ...(legacy.audio?.ambience ?? {}), trackId: ambienceTrackId }
    },
    forge: { ...base.forge, ...(legacy.forge ?? {}) }
  };
}

function normalizeToken(token, migrateLegacyDefaults = false, map = {}) {
  const sourceSize = Number(token?.size);
  const migratedSize = migrateLegacyDefaults && sourceSize === 62 ? DEFAULT_TOKEN_SIZE : sourceSize;
  const point = migrateLegacyDefaults
    ? snapMapPercentPoint(token?.x ?? 50, token?.y ?? 50, map)
    : { x: Number(token?.x ?? 50), y: Number(token?.y ?? 50) };
  return {
    ...(token ?? {}),
    x: point.x,
    y: point.y,
    size: clamp(Number.isFinite(migratedSize) && migratedSize > 0 ? migratedSize : DEFAULT_TOKEN_SIZE, 10, 220),
    mana: Number(token?.mana ?? 0),
    maxMana: Number(token?.maxMana ?? 0),
    damageDice: String(token?.damageDice ?? "").slice(0, 80),
    armor: Number(token?.armor ?? 0),
    speed: Number(token?.speed ?? 0),
    stats: normalizeTokenStats(token?.stats),
    notes: String(token?.notes ?? "").slice(0, 4000),
    gmNotes: String(token?.gmNotes ?? "").slice(0, 4000),
    revealDetailsToPlayers: Boolean(token?.revealDetailsToPlayers)
  };
}

function normalizeMapState(rawMap, migrateLegacyDefaults = false) {
  const fallback = createEmptyMapState();
  const normalized = {
    ...fallback,
    ...(rawMap ?? {}),
    zoom: clamp(Number(rawMap?.zoom) || 1, 0.25, 4.5),
    panX: Number(rawMap?.panX) || 0,
    panY: Number(rawMap?.panY) || 0,
    gridSize: migrateLegacyDefaults && Number(rawMap?.gridSize) === 64
      ? DEFAULT_GRID_SIZE
      : clamp(Number(rawMap?.gridSize) || DEFAULT_GRID_SIZE, 12, 240),
    gridOffsetX: clamp(Number(rawMap?.gridOffsetX) || 0, -240, 240),
    gridOffsetY: clamp(Number(rawMap?.gridOffsetY) || 0, -240, 240),
    gridOpacity: clamp(Number(rawMap?.gridOpacity) || 0, 0, 70)
  };
  normalized.tokens = Array.isArray(rawMap?.tokens)
    ? rawMap.tokens.map((token) => normalizeToken(token, migrateLegacyDefaults, normalized))
    : [];
  return normalized;
}

function normalizeInitiativeState(rawInitiative, tokens = [], options = {}) {
  return normalizeInitiativeRoster(rawInitiative, tokens, options);
}

function normalizeTokenTemplate(template) {
  const token = normalizeToken({
    ...(template ?? {}),
    x: 50,
    y: 50,
    controllerPlayerId: null,
    characterId: null,
    followCharacter: false,
    initiative: null
  });
  return {
    id: template?.id || uid("token-template"),
    name: String(token.name || "Créature").slice(0, 100),
    image: token.image || null,
    color: token.color || "#8d72cb",
    size: token.size,
    hp: Number(token.hp ?? 0),
    maxHp: Number(token.maxHp ?? 0),
    mana: Number(token.mana ?? 0),
    maxMana: Number(token.maxMana ?? 0),
    damageDice: token.damageDice,
    armor: token.armor,
    speed: token.speed,
    stats: token.stats,
    initiativeBonus: Number(token.initiativeBonus ?? 0),
    condition: String(token.condition || "").slice(0, 200),
    notes: token.notes,
    gmNotes: token.gmNotes,
    hidden: Boolean(token.hidden),
    revealDetailsToPlayers: Boolean(token.revealDetailsToPlayers),
    createdAt: template?.createdAt || new Date().toISOString(),
    updatedAt: template?.updatedAt || new Date().toISOString()
  };
}

function normalizeActionTimer(timer) {
  const usedRound = Math.max(1, Math.trunc(Number(timer?.usedRound) || 1));
  const cooldown = clamp(Math.trunc(Number(timer?.cooldown) || 1), 1, 999);
  return {
    id: timer?.id || uid("action-timer"),
    sceneId: timer?.sceneId || null,
    label: String(timer?.label || "Action").slice(0, 120),
    cooldown,
    usedRound,
    readyRound: Math.max(usedRound + cooldown, Math.trunc(Number(timer?.readyRound) || 0)),
    ownerPlayerId: timer?.ownerPlayerId || null,
    characterId: timer?.characterId || null,
    ownerLabel: String(timer?.ownerLabel || "MJ").slice(0, 120),
    visibility: timer?.visibility === "public" ? "public" : "private",
    createdByRole: timer?.createdByRole === "player" ? "player" : "gm",
    createdAt: String(timer?.createdAt || new Date().toISOString()),
    updatedAt: String(timer?.updatedAt || timer?.createdAt || new Date().toISOString())
  };
}

function sceneMetadata(scene, index = 0) {
  return {
    id: scene?.id || uid("scene"),
    name: String(scene?.name || `Scène ${index + 1}`).slice(0, 100),
    subtitle: String(scene?.subtitle || "À préparer").slice(0, 160),
    description: String(scene?.description || "").slice(0, 4000),
    accent: String(scene?.accent || "#8c6ad5").slice(0, 30),
    prompt: String(scene?.prompt || "").slice(0, 12000)
  };
}

function activeSceneMetadata(scene) {
  if (!scene) return null;
  return sceneMetadata(scene);
}

function normalizeTacticalSync(rawSync, fallbackMap, fallbackInitiative, fallbackActiveScene, initiativeMigrationOptions = {}) {
  const paused = rawSync?.paused === true;
  const playerMovementMode = fallbackInitiative?.active === true ? "combat" : "free";
  if (!paused) {
    return {
      paused: false,
      pausedAt: null,
      playerMovementMode,
      publishedMap: null,
      publishedInitiative: null,
      publishedActiveScene: null
    };
  }
  const publishedMap = normalizeMapState(rawSync?.publishedMap ?? cloneStateValue(fallbackMap));
  return {
    paused: true,
    pausedAt: String(rawSync?.pausedAt || new Date().toISOString()),
    playerMovementMode,
    publishedMap,
    publishedInitiative: normalizeInitiativeState(
      rawSync?.publishedInitiative ?? cloneStateValue(fallbackInitiative),
      publishedMap.tokens,
      initiativeMigrationOptions
    ),
    publishedActiveScene: rawSync?.publishedActiveScene === null
      ? null
      : activeSceneMetadata(rawSync?.publishedActiveScene ?? fallbackActiveScene)
  };
}

function normalizeState(candidate) {
  const candidateSchemaVersion = Number(candidate?.schemaVersion ?? 0);
  const source = candidate?.schemaVersion >= 2 ? candidate : migrateLegacyState(candidate);
  const fallback = initialState();
  const migrateLegacyTokenDefaults = candidateSchemaVersion < 4;
  const migrateSceneCombats = candidateSchemaVersion < SCHEMA_VERSION;
  const initiativeMigrationOptions = {
    inferLegacyActive: candidateSchemaVersion < SCHEMA_VERSION,
    clearLegacyInactiveRoster: candidateSchemaVersion < SCHEMA_VERSION
  };
  const players = Array.isArray(source.players) ? source.players.map((player) => ({
    id: player.id || uid("player"),
    name: player.name || player.playerName || "À renseigner",
    accessToken: player.accessToken || newAccessToken(),
    _updatedAt: Number(player._updatedAt ?? 0)
  })) : fallback.players;
  const playerIds = new Set(players.map((player) => player.id));
  const characters = Array.isArray(source.characters)
    ? source.characters.map((character) => normalizeCharacter(character, playerIds.has(character.ownerPlayerId) ? character.ownerPlayerId : null))
    : fallback.characters;
  const normalizedMap = normalizeMapState(source.map, migrateLegacyTokenDefaults);
  const normalizedInitiative = normalizeInitiativeState(source.initiative, normalizedMap.tokens, initiativeMigrationOptions);
  const rawScenes = Array.isArray(source.scenes) && source.scenes.length ? source.scenes : fallback.scenes;
  const knownActiveSceneId = rawScenes.some((scene) => scene.id === source.activeSceneId) ? source.activeSceneId : null;
  const preparedScenes = prepareSceneCombats(rawScenes, {
    activeSceneId: knownActiveSceneId,
    currentMap: normalizedMap,
    currentInitiative: normalizedInitiative,
    migrateLegacyCombat: migrateSceneCombats
  });
  const scenes = preparedScenes.map((scene, index) => {
    const map = normalizeMapState(scene.combat?.map, migrateLegacyTokenDefaults);
    return {
      ...sceneMetadata(scene, index),
      combat: {
        map,
        initiative: normalizeInitiativeState(scene.combat?.initiative, map.tokens, initiativeMigrationOptions)
      }
    };
  });
  const activeSceneEntry = scenes.find((scene) => scene.id === knownActiveSceneId) ?? null;
  return {
    ...fallback,
    ...source,
    schemaVersion: SCHEMA_VERSION,
    session: { ...fallback.session, ...(source.session ?? {}) },
    scenes,
    activeSceneId: activeSceneEntry?.id ?? null,
    activeScene: activeSceneMetadata(activeSceneEntry),
    players,
    characters,
    map: normalizedMap,
    discordCapture: {
      ...fallback.discordCapture,
      ...(source.discordCapture ?? {}),
      message: String(source.discordCapture?.message ?? fallback.discordCapture.message).slice(0, 1200),
      includeCurrentTurn: source.discordCapture?.includeCurrentTurn !== false
    },
    initiative: normalizedInitiative,
    tacticalSync: normalizeTacticalSync(source.tacticalSync, normalizedMap, normalizedInitiative, activeSceneEntry, initiativeMigrationOptions),
    actionTimers: Array.isArray(source.actionTimers)
      ? source.actionTimers.slice(0, MAX_ACTION_TIMERS).map(normalizeActionTimer)
      : [],
    actionTimerTombstones: Array.isArray(source.actionTimerTombstones)
      ? source.actionTimerTombstones.slice(-1000).map((entry) => ({ id: String(entry?.id || ""), deletedAt: String(entry?.deletedAt || new Date().toISOString()) })).filter((entry) => entry.id)
      : [],
    tokenLibrary: Array.isArray(source.tokenLibrary)
      ? source.tokenLibrary.slice(0, MAX_TOKEN_TEMPLATES).map(normalizeTokenTemplate)
      : [],
    shortcuts: Array.isArray(source.shortcuts) ? source.shortcuts.map(normalizeShortcut) : fallback.shortcuts,
    rolls: Array.isArray(source.rolls) ? source.rolls.map((roll) => ({ ...roll, rollerName: roll?.rollerName || "MJ", rollerRole: roll?.rollerRole || "gm" })) : [],
    tracks: Array.isArray(source.tracks) ? source.tracks : [],
    audio: {
      ...fallback.audio,
      ...(source.audio ?? {}),
      music: { ...fallback.audio.music, ...(source.audio?.music ?? {}) },
      ambience: { ...fallback.audio.ambience, ...(source.audio?.ambience ?? {}) }
    },
    forge: { ...fallback.forge, ...(source.forge ?? {}) }
  };
}

function readLocalState() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_STORAGE_KEY) || "null");
  } catch {
    return null;
  }
}

let state = normalizeState(readLocalState());
let services = { chatgptAssist: true, chatgptBridge: false, discordImages: false, discordDice: false, discordJournal: false, ovh: false, playerAccessProtected: false };
let selectedPlayerId = state.players[0]?.id ?? null;
let selectedCharacterId = state.characters.find((character) => character.ownerPlayerId === selectedPlayerId)?.id ?? null;
let selectedTokenId = null;
let forgeFreeAttachments = [];
let bridgeConfig = {
  connected: false,
  pairingToken: "",
  conversations: [
    { id: "characters", label: "Personnages & portraits", url: "" },
    { id: "scenes", label: "Scènes, décors & cartes", url: "" }
  ],
  pendingImports: 0
};
let selectedBridgeConversationId = "characters";
const selectedForgeCharacterIds = new Set();
const consumedBridgeImportIds = new Set();
let bridgeImportInFlight = false;
let ovhCleanupInFlight = false;
let ovhStorageStatus = {
  buildVersion: "",
  automatic: true,
  initialized: false,
  trackedFiles: 0,
  lastCleanupAt: null,
  lastDeletedCount: 0,
  warnings: []
};
let syncTimer = null;
let syncInFlight = false;
let tacticalControlInFlight = false;
let lastServerRevision = Number(state.revision ?? 0);
let dragInitiativeId = null;
let draggingTokenId = null;
let gridCalibrationMode = false;
let currentTabName = "regie";
let eventSource = null;
let mjCharacterSaveTimer = null;
let mjCharacterChangeVersion = 0;
const mjDirtyCharacterPaths = new Map();
const objectUrls = new Map();
const renderedTokenPositions = new Map();

const audioElements = { music: new Audio(), ambience: new Audio() };
audioElements.music.preload = "metadata";
audioElements.ambience.preload = "metadata";
audioElements.ambience.loop = true;
audioElements.music.addEventListener("timeupdate", updateAudioProgress);
audioElements.music.addEventListener("loadedmetadata", updateAudioProgress);
audioElements.music.addEventListener("ended", () => playAdjacentTrack("music", 1));
audioElements.ambience.addEventListener("ended", () => playAdjacentTrack("ambience", 1));

function persistLocalState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    const lean = cloneStateValue(state);
    for (const character of lean.characters) character.portrait = null;
    lean.map.background = null;
    for (const token of lean.map.tokens) token.image = null;
    for (const scene of lean.scenes ?? []) {
      if (!scene.combat?.map) continue;
      scene.combat.map.background = null;
      for (const token of scene.combat.map.tokens ?? []) token.image = null;
    }
    if (lean.tacticalSync?.publishedMap) {
      lean.tacticalSync.publishedMap.background = null;
      for (const token of lean.tacticalSync.publishedMap.tokens ?? []) token.image = null;
    }
    for (const template of lean.tokenLibrary ?? []) template.image = null;
    lean.forge.imageDataUrl = null;
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(lean)); } catch (fallbackError) { console.warn("Sauvegarde locale légère indisponible", fallbackError); }
    console.warn("Les médias lourds restent dans la sauvegarde serveur", error);
  }
}

function storeActiveSceneCombat() {
  const scene = state.scenes.find((entry) => entry.id === state.activeSceneId);
  if (!scene) return;
  scene.combat = createCombatSnapshot(state.map, state.initiative);
  state.activeScene = activeSceneMetadata(scene);
}

function loadSceneCombat(scene) {
  const combat = scene?.combat?.map && scene?.combat?.initiative ? scene.combat : createCombatSnapshot();
  state.map = normalizeMapState(cloneStateValue(combat.map));
  state.initiative = normalizeInitiativeState(cloneStateValue(combat.initiative), state.map.tokens);
  scene.combat = createCombatSnapshot(state.map, state.initiative);
  selectedTokenId = null;
  draggingTokenId = null;
  gridCalibrationMode = false;
  renderedTokenPositions.clear();
}

function commit({ render = true, sync = true, captureScene = true } = {}) {
  if (captureScene) {
    ensureInitiativeOrder();
    storeActiveSceneCombat();
  }
  state.revision = Number(state.revision ?? 0) + 1;
  state.updatedAt = new Date().toISOString();
  persistLocalState();
  if (render) renderAll();
  if (sync) scheduleServerSync();
}

function scheduleServerSync() {
  clearTimeout(syncTimer);
  syncTimer = setTimeout(pushStateToServer, 280);
}

async function pushStateToServer() {
  if (syncInFlight) return scheduleServerSync();
  syncInFlight = true;
  try {
    await sendStateToServer();
  } catch (error) {
    console.warn("Synchronisation locale indisponible", error);
  } finally {
    syncInFlight = false;
  }
}

async function sendStateToServer() {
  const response = await api("/api/session/state", { method: "POST", body: { state } });
  if (response.state) state = normalizeState(response.state);
  else state.revision = Number(response.revision ?? state.revision);
  lastServerRevision = state.revision;
  persistLocalState();
  renderAll();
  return response;
}

async function waitForSyncIdle(timeoutMs = 3000) {
  const deadline = Date.now() + timeoutMs;
  while (syncInFlight && Date.now() < deadline) await new Promise((resolve) => setTimeout(resolve, 25));
  if (syncInFlight) throw new Error("Une synchronisation est encore en cours. Réessayez dans un instant.");
}

async function synchronizeStateImmediately() {
  clearTimeout(syncTimer);
  await waitForSyncIdle();
  syncInFlight = true;
  try {
    return await sendStateToServer();
  } finally {
    syncInFlight = false;
  }
}

function capturePublishedTacticalTable() {
  return {
    paused: true,
    pausedAt: new Date().toISOString(),
    playerMovementMode: state.initiative.active === true ? "combat" : "free",
    publishedMap: cloneStateValue(state.map),
    publishedInitiative: cloneStateValue(state.initiative),
    publishedActiveScene: activeSceneMetadata(activeScene())
  };
}

function liveTacticalSync() {
  return {
    paused: false,
    pausedAt: null,
    playerMovementMode: state.initiative.active === true ? "combat" : "free",
    publishedMap: null,
    publishedInitiative: null,
    publishedActiveScene: null
  };
}

async function updateTacticalControl(mutator, { successMessage, failureMessage } = {}) {
  if (tacticalControlInFlight) return;
  tacticalControlInFlight = true;
  clearTimeout(syncTimer);
  renderTacticalSyncControls();
  try {
    await waitForSyncIdle();
    const previous = cloneStateValue(state);
    ensureInitiativeOrder();
    storeActiveSceneCombat();
    mutator();
    state.revision = Number(state.revision ?? 0) + 1;
    state.updatedAt = new Date().toISOString();
    persistLocalState();
    renderAll();
    try {
      await synchronizeStateImmediately();
      if (successMessage) showToast(successMessage, "success", 4400);
    } catch (error) {
      state = normalizeState(previous);
      lastServerRevision = Number(state.revision ?? lastServerRevision);
      persistLocalState();
      renderAll();
      throw error;
    }
  } catch (error) {
    showToast(`${failureMessage || "Modification tactique impossible"} : ${error.message}`, "error", 5200);
  } finally {
    tacticalControlInFlight = false;
    renderTacticalSyncControls();
  }
}

function toggleTacticalSync() {
  const pausing = state.tacticalSync?.paused !== true;
  return updateTacticalControl(
    () => { state.tacticalSync = pausing ? capturePublishedTacticalTable() : liveTacticalSync(); },
    {
      successMessage: pausing
        ? "Préparation secrète active : les joueurs restent sur la dernière table publiée."
        : "Table publiée : la synchronisation joueurs reprend.",
      failureMessage: pausing ? "Impossible de figer la table" : "Impossible de republier la table"
    }
  );
}

async function pollServerState({ force = false } = {}) {
  if (syncInFlight || (!force && document.visibilityState === "hidden")) return;
  try {
    const response = await api("/api/session/full");
    const serverState = response.state;
    if (serverState && (force || Number(serverState.revision ?? 0) > lastServerRevision)) {
      state = normalizeState(serverState);
      lastServerRevision = Number(state.revision ?? 0);
      ensureSelections();
      persistLocalState();
      renderAll();
    }
  } catch {
    // La régie continue hors ligne et retentera automatiquement.
  }
}

async function api(url, options = {}) {
  const fetchOptions = { method: options.method || "GET", headers: { ...(options.headers ?? {}) } };
  if (options.body !== undefined) {
    fetchOptions.headers["Content-Type"] = "application/json";
    fetchOptions.body = JSON.stringify(options.body);
  }
  const response = await fetch(url, fetchOptions);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok === false) throw new Error(payload.error || `Erreur ${response.status}`);
  return payload;
}

async function uploadRaw(url, file) {
  const response = await fetch(url, { method: "POST", headers: { "Content-Type": file.type || "audio/mpeg" }, body: file });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok === false) throw new Error(payload.error || `Erreur ${response.status}`);
  return payload;
}

function connectLiveSync() {
  eventSource?.close();
  eventSource = new EventSource("/api/session/events");
  eventSource.addEventListener("revision", (event) => {
    const payload = JSON.parse(event.data || "{}");
    if (Number(payload.revision ?? 0) > Number(state.revision ?? 0)) pollServerState({ force: true });
  });
}

function ensureSelections() {
  if (!state.players.some((player) => player.id === selectedPlayerId)) selectedPlayerId = state.players[0]?.id ?? null;
  const owned = state.characters.filter((character) => character.ownerPlayerId === selectedPlayerId);
  if (!owned.some((character) => character.id === selectedCharacterId)) selectedCharacterId = owned[0]?.id ?? state.characters[0]?.id ?? null;
}

function selectedPlayer() { return state.players.find((player) => player.id === selectedPlayerId) ?? null; }
function selectedCharacter() { return state.characters.find((character) => character.id === selectedCharacterId) ?? null; }
function charactersForPlayer(playerId) { return state.characters.filter((character) => character.ownerPlayerId === playerId); }
function activeScene() { return state.scenes.find((scene) => scene.id === state.activeSceneId) ?? state.activeScene ?? null; }

function initials(name) {
  return String(name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("") || "?";
}

function timestampForFilename() {
  const now = new Date();
  return [now.getFullYear(), String(now.getMonth() + 1).padStart(2, "0"), String(now.getDate()).padStart(2, "0"), String(now.getHours()).padStart(2, "0"), String(now.getMinutes()).padStart(2, "0")].join("");
}

function formatTime(seconds) {
  if (!Number.isFinite(seconds)) return "0:00";
  return `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;
}

function formatCalculatorNumber(value) {
  if (!Number.isFinite(Number(value))) return "—";
  return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 8 }).format(Number(value));
}

function calculatorExactLabel(exact, rounded) {
  if (Math.abs(Number(exact) - Number(rounded)) < 1e-10) return "Le résultat est déjà entier.";
  return `Valeur exacte ${formatCalculatorNumber(exact)} · arrondie ${formatCalculatorNumber(rounded)}`;
}

function showCalculatorError(message) {
  const result = $("#calculatorResult");
  const detail = $("#calculatorExact");
  if (result) result.textContent = "—";
  if (detail) detail.textContent = message;
}

function calculateExpressionFromInterface() {
  const input = $("#calculatorExpression");
  if (!input) return;
  try {
    const calculation = evaluateTacticalExpression(input.value);
    $("#calculatorResult").textContent = formatCalculatorNumber(calculation.rounded);
    $("#calculatorExact").textContent = calculatorExactLabel(calculation.exact, calculation.rounded);
  } catch (error) {
    showCalculatorError(error.message);
  }
}

function calculatePercentageFromInterface(mode = "of") {
  const rateInput = $("#percentageRate");
  const baseInput = $("#percentageBase");
  if (!rateInput || !baseInput) return;
  const rate = Number(String(rateInput.value).replace(",", "."));
  const base = Number(String(baseInput.value).replace(",", "."));
  try {
    const calculation = mode === "of" ? percentageOf(rate, base) : applyPercentage(rate, base, mode);
    const operation = mode === "add" ? `augmenté de ${formatCalculatorNumber(rate)} %` : mode === "subtract" ? `diminué de ${formatCalculatorNumber(rate)} %` : `${formatCalculatorNumber(rate)} % de`;
    $("#percentageResult").textContent = mode === "of"
      ? `${operation} ${formatCalculatorNumber(base)} = ${formatCalculatorNumber(calculation.rounded)}`
      : `${formatCalculatorNumber(base)} ${operation} = ${formatCalculatorNumber(calculation.rounded)}`;
    $("#percentageExact").textContent = calculatorExactLabel(calculation.exact, calculation.rounded);
    $$('[data-percentage-mode]').forEach((button) => button.classList.toggle("active", button.dataset.percentageMode === mode));
  } catch (error) {
    $("#percentageResult").textContent = "Calcul impossible";
    $("#percentageExact").textContent = error.message;
  }
}

function appendCalculatorValue(value) {
  const input = $("#calculatorExpression");
  if (!input) return;
  input.value += value;
  input.focus();
}

function showToast(message, type = "info", duration = 3200) {
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  $("#toastRegion").append(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(12px)";
    setTimeout(() => toast.remove(), 180);
  }, duration);
}

function openDialog(title, bodyHtml, setup) {
  $("#dialogTitle").textContent = title;
  $("#dialogBody").innerHTML = bodyHtml;
  $("#dialogBackdrop").classList.remove("hidden");
  setup?.($("#dialogBody"));
  setTimeout(() => $("#dialogBody input, #dialogBody textarea")?.focus(), 20);
}

function closeDialog() {
  $("#dialogBackdrop").classList.add("hidden");
  $("#dialogBody").innerHTML = "";
}

function setActiveTab(tabName) {
  currentTabName = tabName;
  $$(".tab-panel").forEach((panel) => panel.classList.toggle("active", panel.id === `tab-${tabName}`));
  $$(".nav-button").forEach((button) => button.classList.toggle("active", button.dataset.tabTarget === tabName));
  $("#sceneRail")?.classList.toggle("hidden", tabName !== "regie");
  $("#workspace")?.classList.toggle("scene-rail-hidden", tabName !== "regie");
  if (tabName === "map") requestAnimationFrame(renderMap);
}

function renderAll() {
  ensureInitiativeOrder();
  renderScenes();
  renderOverview();
  renderInitiative();
  renderActionTimers();
  renderPlayerCards();
  const participantFieldFocused = $("#participantEditor")?.contains(document.activeElement) && document.activeElement?.matches("input, textarea, select");
  if (!mjDirtyCharacterPaths.size && !participantFieldFocused) renderParticipantEditor();
  renderMap();
  renderDice();
  renderPlaylist();
  renderAudioDock();
  renderSettings();
  renderForge();
  renderServices();
}

function renderScenes() {
  const container = $("#sceneList");
  container.innerHTML = state.scenes.map((scene) => {
    const tokenCount = scene.combat?.map?.tokens?.length ?? 0;
    const mapLabel = scene.combat?.map?.backgroundName || (scene.combat?.map?.background ? "Map préparée" : "Aucune map");
    return `
    <div class="scene-card ${scene.id === state.activeSceneId ? "active" : ""}" style="--scene-accent:${escapeHtml(scene.accent || "#9b7cff")}">
      <button class="scene-launch" data-scene-id="${escapeHtml(scene.id)}"><strong>${escapeHtml(scene.name)}</strong><small>${escapeHtml(scene.subtitle || "Scène personnalisée")}</small><small class="scene-combat-meta">${escapeHtml(mapLabel)} · ${tokenCount} token${tokenCount > 1 ? "s" : ""}</small></button>
      <button class="scene-edit" data-edit-scene="${escapeHtml(scene.id)}" title="Renommer et modifier">✎</button>
    </div>
  `;
  }).join("");
  $$('[data-scene-id]', container).forEach((button) => button.addEventListener("click", () => launchScene(button.dataset.sceneId)));
  $$('[data-edit-scene]', container).forEach((button) => button.addEventListener("click", () => editSceneDialog(button.dataset.editScene)));
}

function renderOverview() {
  const scene = activeScene();
  const combatActive = state.initiative.active === true;
  $("#sessionTitle").textContent = state.session.name;
  $("#roundStat").textContent = combatActive ? state.initiative.round : "—";
  $("#combatantStat").textContent = state.initiative.order.length;
  $("#playerStat").textContent = state.players.length;
  $("#roundPill").textContent = combatActive ? `Round ${state.initiative.round}` : "Hors combat";
  $("#roundPillMap").textContent = combatActive ? `Round ${state.initiative.round}` : "Hors combat";
  $("#activeSceneMini").textContent = scene?.name || "Aucune scène lancée";
  $("#activeSceneTitle").textContent = scene?.name || "Préparez votre première scène";
  $("#activeSceneDescription").textContent = scene?.description || "Choisissez une scène, renommez-la puis préparez ses informations utiles.";
  $("#activeSceneBadge").textContent = combatActive ? "Combat en cours" : "Mode libre";
}

function renderServices() {
  $("#serviceSummary").innerHTML = Object.values(services).map((enabled) => `<i class="service-light ${enabled ? "on" : ""}"></i>`).join("");
  const labels = [
    ["ChatGPT · génération assistée sans API", services.chatgptAssist],
    ["Pont navigateur ChatGPT", services.chatgptBridge],
    ["Discord · illustrations", services.discordImages],
    ["Discord · jets", services.discordDice],
    ["Discord · journal", services.discordJournal],
    ["OVH · dépôt de médias", services.ovh],
    ["Vue joueurs · code d’accès", services.playerAccessProtected]
  ];
  $("#serviceDetails").innerHTML = labels.map(([label, enabled]) => `<div class="service-detail"><span>${escapeHtml(label)}</span><span>${enabled ? "Configuré" : "À configurer"}</span><i class="${enabled ? "on" : ""}"></i></div>`).join("");
}

function renderForge() {
  const preview = $("#forgePreview");
  const image = state.forge.imageDataUrl;
  preview.classList.toggle("empty-state", !image);
  preview.innerHTML = image
    ? `<img src="${image}" alt="Illustration prête à être publiée" />`
    : `<div class="empty-sigil">◇</div><strong>Aucune vision chargée</strong><small>Collez, importez ou glissez ici l’image créée dans ChatGPT.</small>`;
  if (document.activeElement !== $("#imagePrompt")) $("#imagePrompt").value = state.forge.prompt || "";
  ["#sendImageDiscord", "#sendImageOvh", "#sendImageBoth", "#useImageAsMap", "#downloadImage"].forEach((selector) => { $(selector).disabled = !image; });
  const configuredConversations = bridgeConfig.conversations ?? [];
  if (!configuredConversations.some((entry) => entry.id === selectedBridgeConversationId)) {
    selectedBridgeConversationId = configuredConversations[0]?.id ?? "characters";
  }
  const conversationSelect = $("#chatGptConversationSelect");
  conversationSelect.innerHTML = configuredConversations.map((entry) => `<option value="${escapeHtml(entry.id)}">${escapeHtml(entry.label)}${entry.url ? "" : " · à configurer"}</option>`).join("");
  conversationSelect.value = selectedBridgeConversationId;
  const bridgeBadge = $("#chatGptBridgeStatus");
  bridgeBadge.textContent = bridgeConfig.connected ? "Extension connectée" : "Pont non connecté";
  bridgeBadge.className = `status-badge ${bridgeConfig.connected ? "success" : "neutral"}`;
  services.chatgptBridge = Boolean(bridgeConfig.connected);
  renderOvhCleanupStatus();

  for (const characterId of [...selectedForgeCharacterIds]) {
    if (!state.characters.some((entry) => entry.id === characterId && entry.portrait)) selectedForgeCharacterIds.delete(characterId);
  }
  const referenceContainer = $("#characterReferenceShortcuts");
  referenceContainer.innerHTML = state.characters.map((character) => {
    const selected = selectedForgeCharacterIds.has(character.id);
    const avatar = character.portrait
      ? `<img src="${character.portrait}" alt="" />`
      : `<span class="reference-initials">${escapeHtml(initials(character.name))}</span>`;
    return `<button type="button" class="reference-shortcut ${selected ? "selected" : ""}" data-reference-character="${escapeHtml(character.id)}" style="--reference-color:${escapeHtml(character.color || "#8d72cb")}" ${character.portrait ? "" : "disabled"} title="${character.portrait ? `Joindre ${escapeHtml(character.name)}` : "Ajoutez d’abord un portrait dans sa fiche"}">${avatar}<span>${escapeHtml(character.name)}</span></button>`;
  }).join("");
  $$('[data-reference-character]', referenceContainer).forEach((button) => button.addEventListener("click", () => {
    const id = button.dataset.referenceCharacter;
    if (selectedForgeCharacterIds.has(id)) selectedForgeCharacterIds.delete(id);
    else if (selectedForgeCharacterIds.size + forgeFreeAttachments.length >= MAX_FORGE_ATTACHMENTS) {
      return showToast(`Le pont accepte ${MAX_FORGE_ATTACHMENTS} pièces jointes au maximum. Retirez-en une avant d’en ajouter.`, "warning", 5200);
    } else selectedForgeCharacterIds.add(id);
    renderForge();
  }));

  const selectedCharacters = selectedForgeCharacters();
  const attachmentCount = selectedCharacters.length + forgeFreeAttachments.length;
  const badge = $("#referenceBadge");
  badge.classList.toggle("hidden", !attachmentCount);
  badge.innerHTML = attachmentCount ? `<div class="reference-badge-heading"><strong>${attachmentCount}/${MAX_FORGE_ATTACHMENTS} pièces jointes prêtes</strong><small>Cliquez sur × pour en retirer une.</small></div>
    <div class="reference-file-list">
      ${selectedCharacters.map((character) => `<span class="reference-file-chip character-reference" style="--reference-color:${escapeHtml(character.color || "#8d72cb")}">${character.portrait ? `<img src="${character.portrait}" alt="" />` : ""}<span>${escapeHtml(character.name)}</span><button type="button" data-remove-reference-character="${escapeHtml(character.id)}" aria-label="Retirer ${escapeHtml(character.name)}">×</button></span>`).join("")}
      ${forgeFreeAttachments.map((attachment) => `<span class="reference-file-chip"><img src="${attachment.dataUrl}" alt="" /><span>${escapeHtml(attachment.name)}</span><button type="button" data-remove-reference-file="${escapeHtml(attachment.id)}" aria-label="Retirer ${escapeHtml(attachment.name)}">×</button></span>`).join("")}
    </div>` : "";
  $$('[data-remove-reference-character]', badge).forEach((button) => button.addEventListener("click", () => {
    selectedForgeCharacterIds.delete(button.dataset.removeReferenceCharacter);
    renderForge();
  }));
  $$('[data-remove-reference-file]', badge).forEach((button) => button.addEventListener("click", () => {
    forgeFreeAttachments = forgeFreeAttachments.filter((attachment) => attachment.id !== button.dataset.removeReferenceFile);
    renderForge();
  }));
}

function renderOvhCleanupStatus() {
  const badge = $("#ovhCleanupStatus");
  const details = $("#ovhCleanupDetails");
  const button = $("#cleanupOvhMedia");
  if (!badge || !details || !button) return;
  button.disabled = !services.ovh || ovhCleanupInFlight;
  if (!services.ovh) {
    badge.textContent = "OVH non configuré";
    badge.className = "status-badge neutral";
    details.textContent = "Ajoutez les accès du dossier regie-media dans .env.local.";
    return;
  }
  if (ovhCleanupInFlight) {
    badge.textContent = "Nettoyage en cours…";
    badge.className = "status-badge warning";
    details.textContent = "Vérification du registre distant et des anciens builds.";
    return;
  }
  const warnings = ovhStorageStatus.warnings?.length ?? 0;
  if (warnings) {
    badge.textContent = "Nettoyage incomplet";
    badge.className = "status-badge warning";
    details.textContent = `${warnings} élément(s) seront retentés au prochain démarrage.`;
    return;
  }
  if (ovhStorageStatus.initialized) {
    badge.textContent = `FTP propre · ${ovhStorageStatus.trackedFiles ?? 0} actif(s)`;
    badge.className = "status-badge success";
    const deleted = Number(ovhStorageStatus.lastDeletedCount ?? 0);
    details.textContent = deleted
      ? `${deleted} ancien(s) média(s) retiré(s) pour ce build.`
      : "Aucun média obsolète détecté pour ce build.";
    return;
  }
  badge.textContent = "Nettoyage automatique prêt";
  badge.className = "status-badge neutral";
  details.textContent = "Il sera lancé automatiquement au démarrage de la Régie.";
}

function primaryCharacter(playerId) {
  return charactersForPlayer(playerId)[0] ?? null;
}

function renderPlayerCards() {
  const cards = state.players.map((player) => {
    const character = primaryCharacter(player.id);
    const hp = Number(character?.resources?.hp ?? 0);
    const maxHp = Number(character?.resources?.maxHp ?? 0);
    const percent = maxHp > 0 ? clamp((hp / maxHp) * 100, 0, 100) : 0;
    const portrait = character?.portrait ? `<img src="${character.portrait}" alt="" />` : escapeHtml(initials(character?.name || player.name));
    return `<button class="player-card ${player.id === selectedPlayerId ? "selected" : ""}" data-player-card="${escapeHtml(player.id)}" style="--player-color:${escapeHtml(character?.color || "#8d72cb")}">
      <span class="player-portrait">${portrait}</span>
      <span class="player-card-copy"><small>Joueur · ${escapeHtml(player.name || "À renseigner")}</small><strong>${escapeHtml(character?.name || "Aucun personnage")}</strong><span class="hp-line"><span class="hp-bar" style="--hp-percent:${percent}%"><i></i></span><span>${maxHp > 0 ? `${hp}/${maxHp}` : "PV —"}</span></span></span>
    </button>`;
  }).join("") || `<div class="empty-state"><strong>Aucun joueur</strong><small>Ajoutez les participants de la session.</small></div>`;
  $("#playerCards").innerHTML = cards;
  $("#playerCardsCompact").innerHTML = cards;
  $$('[data-player-card]').forEach((card) => card.addEventListener("click", async () => {
    if (mjDirtyCharacterPaths.size && !(await saveMjCharacterPatch())) return;
    selectedPlayerId = card.dataset.playerCard;
    selectedCharacterId = charactersForPlayer(selectedPlayerId)[0]?.id ?? null;
    setActiveTab("players");
    renderPlayerCards();
    renderParticipantEditor();
  }));
}

function optionList(items, selectedId, label) {
  return items.map((item) => `<option value="${escapeHtml(item.id)}" ${item.id === selectedId ? "selected" : ""}>${escapeHtml(label(item))}</option>`).join("");
}

function shortcutEditorHtml(character) {
  return (character.shortcuts ?? []).map((shortcut) => `
    <div class="shortcut-editor-row" data-character-shortcut="${escapeHtml(shortcut.id)}">
      <input data-shortcut-field="label" value="${escapeHtml(shortcut.label)}" aria-label="Nom du raccourci" />
      <input data-shortcut-field="formula" value="${escapeHtml(shortcut.formula)}" aria-label="Formule" />
      <select data-shortcut-field="kind"><option value="roll" ${shortcut.kind === "roll" ? "selected" : ""}>Test d100</option><option value="initiative" ${shortcut.kind === "initiative" ? "selected" : ""}>Initiative d100</option><option value="damage" ${shortcut.kind === "damage" ? "selected" : ""}>Dégâts libres</option></select>
      <button type="button" class="icon-button danger" data-remove-character-shortcut="${escapeHtml(shortcut.id)}">×</button>
    </div>`).join("") || `<small class="hint-copy">Aucun raccourci pour ce personnage.</small>`;
}

function renderParticipantEditor() {
  const player = selectedPlayer();
  const character = selectedCharacter();
  $("#playerEditorEmpty").classList.toggle("hidden", Boolean(player));
  $("#participantEditor").classList.toggle("hidden", !player);
  if (!player) return;
  const ownedCharacters = charactersForPlayer(player.id);
  const portrait = character?.portrait ? `<img src="${character.portrait}" alt="Portrait de ${escapeHtml(character.name)}" />` : `<span>Ajouter<br />un portrait</span>`;
  const conditions = (character?.conditions ?? []).join(", ");
  $("#participantEditor").innerHTML = `
    <div class="panel-heading participant-heading">
      <div><span class="eyebrow">Joueur connecté</span><h2>${escapeHtml(player.name || "À renseigner")}</h2></div>
      <button id="deletePlayerButton" class="icon-button danger" type="button" title="Supprimer le joueur">×</button>
    </div>
    <section class="participant-block">
      <label>Nom ou pseudo du joueur<input id="editParticipantName" value="${escapeHtml(player.name || "")}" /></label>
      <label>Personnage affiché<select id="selectedCharacterSelect">${optionList(ownedCharacters, character?.id, (entry) => entry.name)}</select></label>
      <div class="participant-link-actions"><button id="copyPersonalLinkInline" class="button button-outline" type="button">Copier son lien privé</button><button id="regeneratePlayerToken" class="button button-ghost" type="button">Régénérer l’accès</button></div>
    </section>
    ${character ? `<form id="characterEditor" class="character-sheet-editor" style="--sheet-color:${escapeHtml(character.color)}">
      <div class="sheet-heading"><div><span class="eyebrow">Fiche du personnage</span><h2>${escapeHtml(character.name)}</h2></div><button id="deleteCharacterButton" class="button button-danger button-small" type="button">Supprimer ce personnage</button></div>
      <section class="sheet-section identity-section"><div class="sheet-section-title"><span>Identité</span><small>Visible par le joueur assigné</small></div>
        <div class="portrait-editor">
          <button id="changePlayerPortrait" type="button" class="portrait-large" style="--player-color:${escapeHtml(character.color)}">${portrait}</button>
          <div class="identity-grid">
            <label>Nom affiché<input id="editCharacterName" data-mj-character-path="name" value="${escapeHtml(character.name)}" /></label>
            <label>Joueur propriétaire<select id="editCharacterOwner" data-mj-character-path="ownerPlayerId">${optionList(state.players, character.ownerPlayerId, (entry) => entry.name)}</select></label>
            <label>Nom de famille<input id="editSurname" data-mj-character-path="surname" value="${escapeHtml(character.surname)}" /></label>
            <label>Prénom<input id="editGivenName" data-mj-character-path="givenName" value="${escapeHtml(character.givenName)}" /></label>
            <label>Race<input id="editRace" data-mj-character-path="race" value="${escapeHtml(character.race)}" /></label>
            <label>Âge<input id="editAge" data-mj-character-path="age" value="${escapeHtml(character.age)}" /></label>
            <label>Classe<input id="editClassName" data-mj-character-path="className" value="${escapeHtml(character.className)}" /></label>
            <label>Classe avancée<input id="editAdvancedClass" data-mj-character-path="advancedClass" value="${escapeHtml(character.advancedClass)}" /></label>
            <label>Profession<input id="editProfession" data-mj-character-path="profession" value="${escapeHtml(character.profession)}" /></label>
            <label>Ex-profession<input id="editPreviousProfession" data-mj-character-path="previousProfession" value="${escapeHtml(character.previousProfession)}" /></label>
            <label>Pronoms<input id="editPronouns" data-mj-character-path="pronouns" value="${escapeHtml(character.pronouns)}" /></label>
            <label>Couleur<input id="editCharacterColor" data-mj-character-path="color" type="color" value="${escapeHtml(character.color)}" /></label>
          </div>
        </div>
      </section>
      <section class="sheet-section"><div class="sheet-section-title"><span>Ressources</span><small>HP, mana et état</small></div>
        <div class="resource-grid">
          <label>PV actuels<input id="editHp" data-mj-character-path="resources.hp" type="number" value="${character.resources.hp}" /></label><label>PV maximum<input id="editMaxHp" data-mj-character-path="resources.maxHp" type="number" value="${character.resources.maxHp}" /></label>
          <label>Mana actuelle<input id="editMana" data-mj-character-path="resources.mana" type="number" value="${character.resources.mana}" /></label><label>Mana maximum<input id="editMaxMana" data-mj-character-path="resources.maxMana" type="number" value="${character.resources.maxMana}" /></label>
          <label>Fatigue<input id="editFatigue" data-mj-character-path="fatigue.current" type="number" value="${character.fatigue.current}" /></label><label>Fatigue max<input id="editFatigueMax" data-mj-character-path="fatigue.max" type="number" value="${character.fatigue.max}" /></label>
          <label>Défense<input id="editArmor" data-mj-character-path="armor" type="number" value="${character.armor}" /></label><label>Vitesse<input id="editSpeed" data-mj-character-path="speed" type="number" value="${character.speed}" /></label>
          <label>Bonus initiative d100<input id="editInitiativeBonus" data-mj-character-path="initiativeBonus" type="number" value="${character.initiativeBonus}" /></label><label>Avantages personnels<input id="editPersonalAdvantages" data-mj-character-path="personalAdvantageStock" type="number" value="${character.personalAdvantageStock}" /></label>
          <label>Morale<input id="editMorale" data-mj-character-path="morale" value="${escapeHtml(character.morale)}" /></label><label>États / conditions<input id="editConditions" data-mj-character-path="conditions" value="${escapeHtml(conditions)}" placeholder="Blessé, ralenti…" /></label>
        </div>
      </section>
      <section class="sheet-section"><div class="sheet-section-title"><span>Statistiques d100</span><small>La valeur est directement utilisable pour les tests</small></div>
        <div class="character-stats-grid">
          <label>Force<input id="statForce" data-mj-character-path="stats.force" type="number" value="${character.stats.force}" /></label><label>Dextérité<input id="statDexterity" data-mj-character-path="stats.dexterity" type="number" value="${character.stats.dexterity}" /></label>
          <label>Agilité<input id="statAgility" data-mj-character-path="stats.agility" type="number" value="${character.stats.agility}" /></label><label>Esprit / Social<input id="statSpiritSocial" data-mj-character-path="stats.spiritSocial" type="number" value="${character.stats.spiritSocial}" /></label>
          <label>Intelligence<input id="statIntelligence" data-mj-character-path="stats.intelligence" type="number" value="${character.stats.intelligence}" /></label><label>Instinct<input id="statInstinct" data-mj-character-path="stats.instinct" type="number" value="${character.stats.instinct}" /></label>
        </div>
      </section>
      <section class="sheet-section"><div class="sheet-section-title"><span>Équipement et capacités</span><small>Zones longues inspirées du modèle fourni</small></div>
        <div class="sheet-text-grid"><label>Armure<textarea id="editArmorText" data-mj-character-path="armorText" rows="3">${escapeHtml(character.armorText)}</textarea></label><label>Armes / dégâts<textarea id="editWeaponText" data-mj-character-path="weaponText" rows="3">${escapeHtml(character.weaponText)}</textarea></label></div>
        <label>Passifs<textarea id="editPassives" data-mj-character-path="passives" rows="5">${escapeHtml(character.passives)}</textarea></label>
        <div class="sheet-text-grid"><label>Compétences<textarea id="editSkills" data-mj-character-path="skills" rows="6">${escapeHtml(character.skills)}</textarea></label><label>Compétences spéciales<textarea id="editSpecialSkills" data-mj-character-path="specialSkills" rows="6">${escapeHtml(character.specialSkills)}</textarea></label></div>
        <div class="sheet-text-grid"><label>Langues<textarea id="editLanguages" data-mj-character-path="languages" rows="3">${escapeHtml(character.languages)}</textarea></label><label>Inventaire<textarea id="editInventory" data-mj-character-path="inventory" rows="7">${escapeHtml(character.inventory)}</textarea></label></div>
        <label>Notes partagées avec le joueur<textarea id="editPublicNotes" data-mj-character-path="publicNotes" rows="4">${escapeHtml(character.publicNotes)}</textarea></label>
      </section>
      <section class="sheet-section private-field"><div class="sheet-section-title"><span>Zone secrète MJ</span><small>Jamais transmise au joueur</small></div>
        <div class="secret-grid"><label>Résistance mentale<input id="editMentalResistance" data-mj-character-path="secret.mentalResistance" type="number" value="${character.secret.mentalResistance}" /></label><label>Maximum<input id="editMentalResistanceMax" data-mj-character-path="secret.mentalResistanceMax" type="number" value="${character.secret.mentalResistanceMax}" /></label></div>
        <label>Secrets, malédictions et déclencheurs<textarea id="editSecretNotes" data-mj-character-path="secret.notes" rows="5">${escapeHtml(character.secret.notes)}</textarea></label>
      </section>
      <section class="sheet-section"><div class="section-title-row"><strong>Raccourcis du personnage</strong><button id="addCharacterShortcut" class="button button-ghost button-small" type="button">+ Ajouter</button></div><div id="characterShortcutList" class="shortcut-editor-list">${shortcutEditorHtml(character)}</div></section>
      <div class="sheet-save-bar"><button id="addPlayerToMap" type="button" class="button button-outline">Créer / retrouver son token</button><span>Toute modification est visible en direct par le joueur assigné.</span><button class="button button-primary" type="submit">Enregistrer la fiche</button></div>
    </form>` : `<div class="empty-state editor-empty"><strong>Aucun personnage attribué</strong><small>Ajoutez un personnage à ce joueur.</small></div>`}
  `;
  bindParticipantEditor(player, character);
}

function bindParticipantEditor(player, character) {
  $("#deletePlayerButton")?.addEventListener("click", deleteSelectedPlayer);
  $("#copyPersonalLinkInline")?.addEventListener("click", copySelectedPlayerLink);
  $("#regeneratePlayerToken")?.addEventListener("click", () => {
    if (!confirm("L’ancien lien personnel cessera immédiatement de fonctionner. Continuer ?")) return;
    player.accessToken = newAccessToken();
    player._updatedAt = Date.now();
    commit();
    showToast("Nouvel accès joueur créé.", "success");
  });
  $("#selectedCharacterSelect")?.addEventListener("change", async (event) => {
    const nextCharacterId = event.target.value;
    if (mjDirtyCharacterPaths.size && !(await saveMjCharacterPatch())) { event.target.value = selectedCharacterId; return; }
    selectedCharacterId = nextCharacterId;
    renderParticipantEditor();
  });
  if (!character) return;
  $("#characterEditor").addEventListener("submit", saveCharacterEditor);
  $("#changePlayerPortrait").addEventListener("click", () => $("#playerPortraitInput").click());
  $("#deleteCharacterButton").addEventListener("click", deleteSelectedCharacter);
  $("#addPlayerToMap").addEventListener("click", addCharacterToken);
  $$('[data-mj-character-path]', $("#characterEditor")).forEach((input) => {
    const mark = () => { markMjCharacterPathDirty(input.dataset.mjCharacterPath); scheduleMjCharacterSave(); };
    input.addEventListener("input", mark);
    input.addEventListener("change", mark);
  });
  $$('[data-shortcut-field]', $("#characterEditor")).forEach((input) => {
    const mark = () => { markMjCharacterPathDirty("shortcuts"); scheduleMjCharacterSave(); };
    input.addEventListener("input", mark);
    input.addEventListener("change", mark);
  });
  $("#addCharacterShortcut").addEventListener("click", () => {
    character.shortcuts.push({ id: uid("character-shortcut"), label: "Nouveau test", formula: "1d100", kind: "roll", visibility: "public" });
    character._updatedAt = Date.now();
    commit();
  });
  $$('[data-remove-character-shortcut]').forEach((button) => button.addEventListener("click", () => {
    character.shortcuts = character.shortcuts.filter((shortcut) => shortcut.id !== button.dataset.removeCharacterShortcut);
    character._updatedAt = Date.now();
    commit();
  }));
}

function markMjCharacterPathDirty(path) {
  mjCharacterChangeVersion += 1;
  mjDirtyCharacterPaths.set(path, mjCharacterChangeVersion);
}

function scheduleMjCharacterSave() {
  clearTimeout(mjCharacterSaveTimer);
  $("#characterEditor .sheet-save-bar span")?.replaceChildren("Modification détectée · synchronisation automatique…");
  mjCharacterSaveTimer = setTimeout(saveMjCharacterPatch, 650);
}

function setPatchPath(target, path, value) {
  const parts = path.split(".");
  let cursor = target;
  while (parts.length > 1) {
    const part = parts.shift();
    cursor[part] ??= {};
    cursor = cursor[part];
  }
  cursor[parts[0]] = value;
}

function mjEditorValue(input, path) {
  if (path === "conditions") return input.value.split(",").map((value) => value.trim()).filter(Boolean);
  if (input.type === "number") return Number(input.value || 0);
  if (input.type === "checkbox") return input.checked;
  return input.value;
}

async function saveMjCharacterPatch() {
  clearTimeout(mjCharacterSaveTimer);
  const character = selectedCharacter();
  const form = $("#characterEditor");
  if (!character || !form || !mjDirtyCharacterPaths.size) return true;
  const submittedVersions = new Map(mjDirtyCharacterPaths);
  const patch = {};
  $$('[data-mj-character-path]', form).forEach((input) => {
    const path = input.dataset.mjCharacterPath;
    if (submittedVersions.has(path)) setPatchPath(patch, path, mjEditorValue(input, path));
  });
  if (submittedVersions.has("shortcuts")) patch.shortcuts = collectShortcutRows();
  try {
    const response = await api("/api/session/character", { method: "PATCH", body: { characterId: character.id, patch } });
    const index = state.characters.findIndex((entry) => entry.id === character.id);
    if (response.character && index >= 0) {
      state.characters[index] = normalizeCharacter(response.character, response.character.ownerPlayerId);
      syncTokensFromCharacter(state.characters[index]);
    }
    state.revision = Number(response.revision ?? state.revision);
    lastServerRevision = state.revision;
    for (const [path, version] of submittedVersions) {
      if (mjDirtyCharacterPaths.get(path) === version) mjDirtyCharacterPaths.delete(path);
    }
    persistLocalState();
    $("#characterEditor .sheet-save-bar span")?.replaceChildren("Synchronisé en direct avec le joueur.");
    renderPlayerCards();
    renderMap();
    renderInitiative();
    renderDice();
    if (mjDirtyCharacterPaths.size) scheduleMjCharacterSave();
    return true;
  } catch (error) {
    showToast(`Fiche non synchronisée : ${error.message}`, "error", 5200);
    scheduleMjCharacterSave();
    return false;
  }
}

function collectShortcutRows() {
  return $$('[data-character-shortcut]').map((row) => normalizeShortcut({
    id: row.dataset.characterShortcut,
    label: $('[data-shortcut-field="label"]', row).value.trim() || "Jet",
    formula: $('[data-shortcut-field="formula"]', row).value.trim() || "1d100",
    kind: $('[data-shortcut-field="kind"]', row).value,
    visibility: "public"
  }));
}

function saveCharacterEditor(event) {
  event.preventDefault();
  clearTimeout(mjCharacterSaveTimer);
  const player = selectedPlayer();
  const character = selectedCharacter();
  if (!player || !character) return;
  player.name = $("#editParticipantName").value.trim() || "À renseigner";
  player._updatedAt = Date.now();
  Object.assign(character, {
    name: $("#editCharacterName").value.trim() || "Personnage",
    ownerPlayerId: $("#editCharacterOwner").value,
    surname: $("#editSurname").value.trim(), givenName: $("#editGivenName").value.trim(), race: $("#editRace").value.trim(), age: $("#editAge").value.trim(),
    className: $("#editClassName").value.trim(), advancedClass: $("#editAdvancedClass").value.trim(), profession: $("#editProfession").value.trim(), previousProfession: $("#editPreviousProfession").value.trim(), pronouns: $("#editPronouns").value.trim(), color: $("#editCharacterColor").value,
    resources: { hp: Number($("#editHp").value || 0), maxHp: Number($("#editMaxHp").value || 0), mana: Number($("#editMana").value || 0), maxMana: Number($("#editMaxMana").value || 0) },
    fatigue: { current: Number($("#editFatigue").value || 0), max: Number($("#editFatigueMax").value || 100) },
    morale: $("#editMorale").value.trim(), armor: Number($("#editArmor").value || 0), speed: Number($("#editSpeed").value || 0), initiativeBonus: Number($("#editInitiativeBonus").value || 0), personalAdvantageStock: Number($("#editPersonalAdvantages").value || 0),
    conditions: $("#editConditions").value.split(",").map((value) => value.trim()).filter(Boolean),
    stats: { force: Number($("#statForce").value || 0), dexterity: Number($("#statDexterity").value || 0), agility: Number($("#statAgility").value || 0), spiritSocial: Number($("#statSpiritSocial").value || 0), intelligence: Number($("#statIntelligence").value || 0), instinct: Number($("#statInstinct").value || 0) },
    armorText: $("#editArmorText").value, weaponText: $("#editWeaponText").value, passives: $("#editPassives").value, skills: $("#editSkills").value, specialSkills: $("#editSpecialSkills").value, languages: $("#editLanguages").value, inventory: $("#editInventory").value, publicNotes: $("#editPublicNotes").value,
    secret: { mentalResistance: Number($("#editMentalResistance").value || 0), mentalResistanceMax: Number($("#editMentalResistanceMax").value || 100), notes: $("#editSecretNotes").value },
    shortcuts: collectShortcutRows(),
    _updatedAt: Date.now()
  });
  const initiativeShortcut = character.shortcuts.find((shortcut) => shortcut.kind === "initiative");
  if (initiativeShortcut && /^1d100[+-]\d+$/i.test(initiativeShortcut.formula.replaceAll(" ", ""))) initiativeShortcut.formula = `1d100${character.initiativeBonus >= 0 ? "+" : ""}${character.initiativeBonus}`;
  syncTokensFromCharacter(character);
  selectedPlayerId = character.ownerPlayerId;
  mjDirtyCharacterPaths.clear();
  commit();
  showToast("Fiche synchronisée avec son joueur.", "success");
}

function syncTokensFromCharacter(character) {
  const tokenCollections = [state.map.tokens];
  for (const scene of state.scenes) {
    if (scene.id === state.activeSceneId || !Array.isArray(scene.combat?.map?.tokens)) continue;
    tokenCollections.push(scene.combat.map.tokens);
  }
  for (const tokens of tokenCollections) {
    for (const token of tokens) {
      if (token.characterId !== character.id || !token.followCharacter) continue;
      token.name = character.name;
      token.color = character.color;
      token.image = character.portrait;
      token.hp = character.resources.hp;
      token.maxHp = character.resources.maxHp;
      token.mana = character.resources.mana;
      token.maxMana = character.resources.maxMana;
      token.armor = character.armor;
      token.speed = character.speed;
      token.stats = characterTokenStats(character);
      token.initiativeBonus = character.initiativeBonus;
      token.controllerPlayerId = character.ownerPlayerId;
      token._updatedAt = character._updatedAt;
    }
  }
}

function launchScene(sceneId) {
  const switched = switchSceneCombat({
    scenes: state.scenes,
    activeSceneId: state.activeSceneId,
    nextSceneId: sceneId,
    map: state.map,
    initiative: state.initiative
  });
  if (!switched) return;
  state.scenes = switched.scenes;
  const scene = state.scenes.find((entry) => entry.id === sceneId);
  state.activeSceneId = scene.id;
  state.map = normalizeMapState(switched.map);
  state.initiative = normalizeInitiativeState(switched.initiative, state.map.tokens);
  state.activeScene = activeSceneMetadata(scene);
  state.session.phase = scene.subtitle || "Scène active";
  state.forge.prompt = scene.prompt || "";
  selectedTokenId = null;
  draggingTokenId = null;
  gridCalibrationMode = false;
  renderedTokenPositions.clear();
  commit();
  const mapSummary = state.map.background ? (state.map.backgroundName || "map préparée") : "aucune map";
  showToast(`« ${scene.name} » chargée · ${mapSummary} · ${state.map.tokens.length} token${state.map.tokens.length > 1 ? "s" : ""}.`, "success");
}

function nextSceneName() {
  let index = 1;
  const names = new Set(state.scenes.map((scene) => scene.name.toLowerCase()));
  while (names.has(`scène ${index}`) || names.has(`scene ${index}`)) index += 1;
  return `Scène ${index}`;
}

function sceneDialog(scene = null) {
  const isEdit = Boolean(scene);
  const tokenCount = scene?.combat?.map?.tokens?.length ?? 0;
  const mapSummary = scene?.combat?.map?.backgroundName || (scene?.combat?.map?.background ? "Map préparée" : "Aucune map");
  openDialog(isEdit ? "Modifier la scène" : "Nouvelle scène", `<form id="sceneDialogForm" class="dialog-form">
    <label>Nom<input id="dialogSceneName" required value="${escapeHtml(scene?.name || nextSceneName())}" /></label>
    <label>Type / ambiance<input id="dialogSceneSubtitle" value="${escapeHtml(scene?.subtitle || "À préparer")}" placeholder="Combat · tension" /></label>
    <label>Description<textarea id="dialogSceneDescription" rows="3">${escapeHtml(scene?.description || "")}</textarea></label>
    <label>Prompt visuel<textarea id="dialogScenePrompt" rows="3">${escapeHtml(scene?.prompt || "")}</textarea></label>
    <label>Couleur d’accent<input id="dialogSceneColor" type="color" value="${escapeHtml(scene?.accent || "#8c6ad5")}" /></label>
    ${isEdit ? `<div class="scene-combat-summary"><strong>Combat propre à cette scène</strong><span>${escapeHtml(mapSummary)} · ${tokenCount} token${tokenCount > 1 ? "s" : ""} · round ${scene.combat?.initiative?.round || 1}</span></div>` : (activeScene() ? `<label class="checkbox-line"><input id="dialogSceneCopyCombat" type="checkbox" /> Dupliquer la carte, les tokens et l’initiative de la scène actuelle</label>` : "")}
    <div class="dialog-actions">${isEdit ? `<button id="deleteSceneDialog" type="button" class="button button-danger">Supprimer</button>` : ""}<button type="button" class="button button-ghost" data-cancel-dialog>Annuler</button><button class="button button-primary">${isEdit ? "Enregistrer" : "Créer"}</button></div>
  </form>`, (root) => {
    $('[data-cancel-dialog]', root).addEventListener("click", closeDialog);
    $("#deleteSceneDialog", root)?.addEventListener("click", () => {
      if (!confirm(`Supprimer « ${scene.name} » ?`)) return;
      const wasActive = state.activeSceneId === scene.id;
      state.scenes = state.scenes.filter((entry) => entry.id !== scene.id);
      if (wasActive) {
        const next = state.scenes[0] ?? null;
        state.activeSceneId = next?.id ?? null;
        state.activeScene = activeSceneMetadata(next);
        if (next) loadSceneCombat(next);
        else {
          state.map = createEmptyMapState();
          state.initiative = createEmptyInitiativeState();
          selectedTokenId = null;
        }
      }
      commit();
      closeDialog();
    });
    $("#sceneDialogForm", root).addEventListener("submit", (event) => {
      event.preventDefault();
      const values = {
        name: $("#dialogSceneName", root).value.trim() || nextSceneName(),
        subtitle: $("#dialogSceneSubtitle", root).value.trim(),
        description: $("#dialogSceneDescription", root).value.trim(),
        prompt: $("#dialogScenePrompt", root).value.trim(),
        accent: $("#dialogSceneColor", root).value
      };
      if (scene) Object.assign(scene, values);
      else {
        storeActiveSceneCombat();
        const copyCombat = Boolean($("#dialogSceneCopyCombat", root)?.checked && activeScene());
        const created = { id: uid("scene"), ...values, combat: copyCombat ? createCombatSnapshot(state.map, state.initiative) : createCombatSnapshot() };
        state.scenes.push(created);
        state.activeSceneId = created.id;
        state.activeScene = activeSceneMetadata(created);
        loadSceneCombat(created);
        state.session.phase = created.subtitle || "Scène active";
        state.forge.prompt = created.prompt || "";
      }
      if (scene && state.activeSceneId === scene.id) {
        state.activeScene = activeSceneMetadata(scene);
        state.session.phase = scene.subtitle || "Scène active";
        state.forge.prompt = scene.prompt || "";
      }
      commit();
      closeDialog();
    });
  });
}

function addSceneDialog() { sceneDialog(); }
function editSceneDialog(sceneId) { sceneDialog(state.scenes.find((scene) => scene.id === sceneId)); }

function addPlayerDialog() {
  openDialog("Ajouter un joueur", `<form id="playerDialogForm" class="dialog-form">
    <p class="dialog-explainer">Le joueur est la personne qui recevra un lien privé. Son personnage est une fiche séparée.</p>
    <label>Nom ou pseudo du joueur<input id="dialogPlayerName" placeholder="Joueur" /></label>
    <label>Premier personnage (facultatif)<input id="dialogCharacterName" placeholder="Nom du personnage" /></label>
    <label>Couleur du personnage<input id="dialogPlayerColor" type="color" value="#8d72cb" /></label>
    <div class="dialog-actions"><button type="button" class="button button-ghost" data-cancel-dialog>Annuler</button><button class="button button-primary">Ajouter</button></div>
  </form>`, (root) => {
    $('[data-cancel-dialog]', root).addEventListener("click", closeDialog);
    $("#playerDialogForm", root).addEventListener("submit", (event) => {
      event.preventDefault();
      const player = createDefaultPlayer();
      player.name = $("#dialogPlayerName", root).value.trim() || "À renseigner";
      state.players.push(player);
      const characterName = $("#dialogCharacterName", root).value.trim();
      if (characterName) {
        const character = createDefaultCharacter(characterName, $("#dialogPlayerColor", root).value, player.id);
        state.characters.push(character);
        selectedCharacterId = character.id;
      } else selectedCharacterId = null;
      selectedPlayerId = player.id;
      commit();
      closeDialog();
    });
  });
}

function addCharacterDialog() {
  if (!state.players.length) return showToast("Ajoutez d’abord un joueur.", "warning");
  openDialog("Ajouter un personnage", `<form id="characterDialogForm" class="dialog-form">
    <label>Nom du personnage<input id="dialogNewCharacterName" required placeholder="Personnage" /></label>
    <label>Joueur propriétaire<select id="dialogCharacterOwner">${optionList(state.players, selectedPlayerId, (entry) => entry.name)}</select></label>
    <label>Couleur<input id="dialogCharacterColor" type="color" value="#8d72cb" /></label>
    <div class="dialog-actions"><button type="button" class="button button-ghost" data-cancel-dialog>Annuler</button><button class="button button-primary">Ajouter</button></div>
  </form>`, (root) => {
    $('[data-cancel-dialog]', root).addEventListener("click", closeDialog);
    $("#characterDialogForm", root).addEventListener("submit", (event) => {
      event.preventDefault();
      const ownerPlayerId = $("#dialogCharacterOwner", root).value;
      const character = createDefaultCharacter($("#dialogNewCharacterName", root).value.trim(), $("#dialogCharacterColor", root).value, ownerPlayerId);
      state.characters.push(character);
      selectedPlayerId = ownerPlayerId;
      selectedCharacterId = character.id;
      commit();
      closeDialog();
    });
  });
}

function removeLinkedTokensEverywhere(predicate) {
  const filterCombat = (map, initiative) => {
    const removedIds = new Set((map.tokens ?? []).filter(predicate).map((token) => token.id));
    map.tokens = (map.tokens ?? []).filter((token) => !removedIds.has(token.id));
    initiative.order = (initiative.order ?? []).filter((tokenId) => !removedIds.has(tokenId));
    initiative.currentIndex = initiative.order.length ? clamp(Number(initiative.currentIndex || 0), 0, initiative.order.length - 1) : 0;
  };
  filterCombat(state.map, state.initiative);
  for (const scene of state.scenes) {
    if (scene.id === state.activeSceneId || !scene.combat?.map || !scene.combat?.initiative) continue;
    filterCombat(scene.combat.map, scene.combat.initiative);
  }
}

function deleteSelectedPlayer() {
  const player = selectedPlayer();
  if (!player || !confirm(`Supprimer le joueur « ${player.name} », ses personnages et leurs tokens ?`)) return;
  const characterIds = new Set(charactersForPlayer(player.id).map((character) => character.id));
  state.players = state.players.filter((entry) => entry.id !== player.id);
  state.characters = state.characters.filter((character) => !characterIds.has(character.id));
  removeLinkedTokensEverywhere((token) => token.controllerPlayerId === player.id || characterIds.has(token.characterId));
  clearTimeout(mjCharacterSaveTimer);
  mjDirtyCharacterPaths.clear();
  selectedPlayerId = state.players[0]?.id ?? null;
  selectedCharacterId = charactersForPlayer(selectedPlayerId)[0]?.id ?? null;
  commit();
}

function deleteSelectedCharacter() {
  const character = selectedCharacter();
  if (!character || !confirm(`Supprimer la fiche de « ${character.name} » et ses tokens liés ?`)) return;
  state.characters = state.characters.filter((entry) => entry.id !== character.id);
  clearTimeout(mjCharacterSaveTimer);
  mjDirtyCharacterPaths.clear();
  removeLinkedTokensEverywhere((token) => token.characterId === character.id);
  selectedCharacterId = charactersForPlayer(selectedPlayerId)[0]?.id ?? null;
  commit();
}

async function copySelectedPlayerLink() {
  const player = selectedPlayer();
  if (!player) return showToast("Sélectionnez un joueur.", "warning");
  const url = buildPlayerViewUrl({ player });
  try { await navigator.clipboard.writeText(url.href); showToast("Lien personnel copié. Il donne accès uniquement aux fiches de ce joueur.", "success"); }
  catch { prompt("Copiez ce lien privé :", url.href); }
}

function touchInitiative() {
  state.initiative._updatedAt = Date.now();
}

function ensureInitiativeOrder() {
  const previousCurrentId = state.initiative.active === true
    ? state.initiative.order[Number(state.initiative.currentIndex || 0)] ?? null
    : null;
  state.initiative.order = sanitizeInitiativeOrder(state.initiative.order, state.map.tokens);
  state.initiative.currentIndex = state.initiative.order.length
    ? previousCurrentId && state.initiative.order.includes(previousCurrentId)
      ? state.initiative.order.indexOf(previousCurrentId)
      : clamp(Number(state.initiative.currentIndex || 0), 0, state.initiative.order.length - 1)
    : 0;
  if (state.initiative.active === true && !state.initiative.order.length) {
    state.initiative.active = false;
    state.initiative.turnsStarted = false;
  }
  state.tacticalSync.playerMovementMode = state.initiative.active === true ? "combat" : "free";
}

function currentToken() {
  if (state.initiative.active !== true) return null;
  return state.map.tokens.find((token) => token.id === state.initiative.order[state.initiative.currentIndex]) ?? null;
}

function sortInitiativeOrder({ preserveCurrent = false } = {}) {
  const currentId = preserveCurrent ? currentToken()?.id ?? null : null;
  state.initiative.order = sortInitiativeTokenIds(state.initiative.order, state.map.tokens);
  state.initiative.currentIndex = currentId ? Math.max(0, state.initiative.order.indexOf(currentId)) : 0;
}

function addTokenToInitiative(tokenId) {
  if (!state.map.tokens.some((token) => token.id === tokenId)) return false;
  if (!state.initiative.order.includes(tokenId)) state.initiative.order.push(tokenId);
  return true;
}

function removeTokenFromInitiative(tokenId) {
  const token = state.map.tokens.find((entry) => entry.id === tokenId);
  if (!token || !state.initiative.order.includes(tokenId)) return;
  const previousCurrentId = currentToken()?.id ?? null;
  const previousIndex = Number(state.initiative.currentIndex || 0);
  state.initiative.order = state.initiative.order.filter((id) => id !== tokenId);
  token.initiative = null;
  token._updatedAt = Date.now();
  if (!state.initiative.order.length) {
    state.initiative.currentIndex = 0;
    state.initiative.active = false;
    state.initiative.turnsStarted = false;
    state.tacticalSync.playerMovementMode = "free";
  } else if (previousCurrentId && previousCurrentId !== tokenId && state.initiative.order.includes(previousCurrentId)) {
    state.initiative.currentIndex = state.initiative.order.indexOf(previousCurrentId);
  } else {
    state.initiative.currentIndex = Math.min(previousIndex, state.initiative.order.length - 1);
  }
  touchInitiative();
  commit();
  showToast(`${token.name} a été retiré de l’initiative.${state.initiative.active !== true ? " Le mode libre reste actif." : ""}`);
}

async function rollTokenInitiative(token) {
  if (!token) return;
  const bonus = Number($("#tokenEditBonus")?.value ?? token.initiativeBonus ?? 0);
  const formula = `1d100${bonus >= 0 ? "+" : ""}${bonus}`;
  const result = parseRoll(formula);
  token.initiativeBonus = bonus;
  token.initiative = result.total;
  token._updatedAt = Date.now();
  addTokenToInitiative(token.id);
  sortInitiativeOrder({ preserveCurrent: state.initiative.active === true });
  touchInitiative();
  const visibility = token.hidden ? "gm" : "public";
  const roll = createRollRecord(`${token.name} · Initiative`, formula, result, visibility);
  state.rolls.unshift(roll);
  state.rolls = state.rolls.slice(0, 100);
  commit();
  if (visibility === "public") await postRollToDiscord(roll);
  showToast(
    `${token.name} obtient ${result.total} (${result.breakdown}) et rejoint l’initiative.${state.initiative.active === true ? "" : " Le jeu reste en mode libre."}`,
    "success"
  );
}

function renderInitiative() {
  renderInitiativeList($("#initiativeCompact"), true);
  renderInitiativeList($("#initiativeList"), false);
  const combatActive = state.initiative.active === true;
  const initiativeReady = state.initiative.order.length > 0
    && state.initiative.order.every((id) => state.map.tokens.find((entry) => entry.id === id)?.initiative != null);
  const token = currentToken();
  $("#currentTurnLabel").textContent = combatActive ? "Tour en cours" : "Mode de jeu";
  $("#currentTurnName").textContent = token?.name || (combatActive ? "Aucun combattant" : "Mode libre");
  $("#currentTurnMeta").textContent = token
    ? `Initiative d100 : ${token.initiative ?? "—"}${token.hidden ? " · masqué aux joueurs" : ""}`
    : state.initiative.order.length
      ? `${state.initiative.order.length} initiative${state.initiative.order.length > 1 ? "s" : ""} préparée${state.initiative.order.length > 1 ? "s" : ""} · aucun tour actif.`
      : "Déplacements libres · aucune initiative requise hors combat.";
  $("#endCombatButton").disabled = !combatActive;
  $("#newCombatButton").disabled = combatActive || !initiativeReady;
  $("#newCombatButton").title = combatActive
    ? "Le combat est déjà en cours."
    : initiativeReady ? "Activer le round 1 et le premier token." : "Préparez au moins une initiative complète.";
  $("#rollAllInitiative").disabled = !state.map.tokens.length;
  $("#rollAllInitiativeCompact").disabled = !state.map.tokens.length;
  for (const selector of ["#previousTurnButton", "#nextTurnButton", "#delayTurnButton", "#previousTurnCompact", "#nextTurnCompact"]) {
    $(selector).disabled = !combatActive || !state.initiative.order.length;
  }
}

function renderInitiativeList(container, compact) {
  const currentId = currentToken()?.id;
  if (!state.initiative.order.length) {
    container.innerHTML = `<div class="empty-state small"><small>Aucune initiative préparée. Les tokens peuvent rester hors de la séquence.</small></div>`;
    return;
  }
  container.innerHTML = state.initiative.order.map((id, index) => {
    const token = state.map.tokens.find((entry) => entry.id === id);
    if (!token) return "";
    const avatar = token.image ? `<img src="${token.image}" alt="" />` : escapeHtml(initials(token.name));
    return `<div class="initiative-entry ${compact ? "" : "removable"} ${id === currentId ? "current" : ""} ${token.hidden ? "hidden-entry" : ""}" data-initiative-id="${escapeHtml(id)}" ${compact ? "" : 'draggable="true"'} style="--token-color:${escapeHtml(token.color || "#8d72cb")}">
      <span class="initiative-rank">${index + 1}</span><span class="initiative-avatar">${avatar}</span>
      <span class="initiative-name"><strong>${escapeHtml(token.name)}</strong><small>${escapeHtml(token.condition || (token.hidden ? "Secret MJ" : "Prêt"))}</small></span>
      ${compact ? `<strong class="initiative-score">${token.initiative ?? "—"}</strong>` : `<input class="initiative-score" type="number" value="${token.initiative ?? ""}" data-initiative-score="${escapeHtml(id)}" aria-label="Initiative de ${escapeHtml(token.name)}" title="Modifiez le score : le plus petit joue en premier" />`}
      ${compact ? "" : `<button class="initiative-remove" type="button" data-remove-initiative="${escapeHtml(id)}" draggable="false" aria-label="Retirer ${escapeHtml(token.name)} de l’initiative" title="Retirer de l’initiative">×</button>`}
    </div>`;
  }).join("");
  if (!compact) bindInitiativeDrag(container);
}

function bindInitiativeDrag(container) {
  $$('[data-initiative-id]', container).forEach((row) => {
    row.addEventListener("dragstart", () => { dragInitiativeId = row.dataset.initiativeId; row.classList.add("dragging"); });
    row.addEventListener("dragend", () => { dragInitiativeId = null; row.classList.remove("dragging"); });
    row.addEventListener("dragover", (event) => event.preventDefault());
    row.addEventListener("drop", (event) => {
      event.preventDefault();
      const targetId = row.dataset.initiativeId;
      if (!dragInitiativeId || dragInitiativeId === targetId) return;
      const currentId = currentToken()?.id;
      const order = [...state.initiative.order];
      const [moved] = order.splice(order.indexOf(dragInitiativeId), 1);
      order.splice(order.indexOf(targetId), 0, moved);
      state.initiative.order = order;
      state.initiative.currentIndex = Math.max(0, order.indexOf(currentId));
      touchInitiative();
      commit();
    });
  });
  $$('[data-initiative-score]', container).forEach((input) => {
    const updateValue = () => {
      const token = state.map.tokens.find((entry) => entry.id === input.dataset.initiativeScore);
      if (!token) return;
      token.initiative = input.value === "" ? null : Number(input.value);
      token._updatedAt = Date.now();
      if (currentToken()?.id === token.id) $("#currentTurnMeta").textContent = `Initiative d100 : ${token.initiative ?? "—"}${token.hidden ? " · masqué aux joueurs" : ""}`;
    };
    input.addEventListener("input", updateValue);
    input.addEventListener("change", () => {
      updateValue();
      sortInitiativeOrder({ preserveCurrent: state.initiative.active === true });
      touchInitiative();
      commit();
    });
  });
  $$('[data-remove-initiative]', container).forEach((button) => button.addEventListener("click", (event) => {
    event.stopPropagation();
    removeTokenFromInitiative(button.dataset.removeInitiative);
  }));
}

function rollAllInitiative() {
  if (!state.map.tokens.length) return showToast("Ajoutez d’abord des tokens à la carte.", "error");
  const combatActive = state.initiative.active === true;
  const currentId = currentToken()?.id ?? null;
  for (const token of state.map.tokens) token.initiative = randomInt(1, 100) + Number(token.initiativeBonus || 0);
  state.initiative.order = sortInitiativeTokenIds(state.map.tokens.map((token) => token.id), state.map.tokens);
  state.initiative.currentIndex = currentId && state.initiative.order.includes(currentId)
    ? state.initiative.order.indexOf(currentId)
    : 0;
  if (!combatActive) state.initiative.round = 1;
  state.initiative.active = combatActive;
  state.initiative.turnsStarted = combatActive;
  state.tacticalSync.playerMovementMode = combatActive ? "combat" : "free";
  for (const token of state.map.tokens) token._updatedAt = Date.now();
  touchInitiative();
  commit();
  showToast(
    combatActive
      ? "Toutes les initiatives ont été relancées et triées sans changer le tour actif."
      : "Toutes les initiatives sont préparées. Démarrez le combat quand vous êtes prêt.",
    "success"
  );
}

function nextTurn(direction = 1) {
  if (state.initiative.active !== true) return showToast("Démarrez le combat avant d’avancer les tours.", "warning");
  const length = state.initiative.order.length;
  if (!length) return showToast("L’ordre des tours est vide.", "error");
  const previousIndex = state.initiative.currentIndex;
  state.initiative.turnsStarted = true;
  state.initiative.currentIndex = (previousIndex + direction + length) % length;
  if (direction > 0 && previousIndex === length - 1) state.initiative.round += 1;
  if (direction < 0 && previousIndex === 0 && state.initiative.round > 1) state.initiative.round -= 1;
  touchInitiative();
  commit();
}

function endCombat() {
  if (state.initiative.active !== true) return;
  if (!confirm("Terminer ce combat ? La map et les tokens resteront en place, mais les déplacements joueurs redeviendront libres.")) return;
  updateTacticalControl(() => {
    state.initiative.active = false;
    state.initiative.turnsStarted = false;
    state.initiative.currentIndex = 0;
    state.tacticalSync.playerMovementMode = "free";
    touchInitiative();
    storeActiveSceneCombat();
  }, {
    successMessage: "Mode libre activé : aucun tour n’est actif. La map et les initiatives préparées sont conservées.",
    failureMessage: "Impossible de terminer le combat"
  });
}

function startCombat() {
  ensureInitiativeOrder();
  if (state.initiative.active === true) return;
  if (!state.initiative.order.length) return showToast("Lancez l’initiative d’au moins un token avant de démarrer le combat.", "warning");
  const missingScore = state.initiative.order.some((id) => state.map.tokens.find((token) => token.id === id)?.initiative == null);
  if (missingScore) return showToast("Chaque token de la liste doit avoir un score d’initiative.", "warning");
  const sceneTimers = (state.actionTimers ?? []).filter((timer) => timer.sceneId === state.activeSceneId);
  if (sceneTimers.length && !confirm("Démarrer un nouveau combat ? Les anciens minuteurs de cette scène seront effacés, mais les initiatives préparées seront conservées.")) return;
  updateTacticalControl(() => {
    sortInitiativeOrder();
    state.initiative.currentIndex = 0;
    state.initiative.round = 1;
    state.initiative.active = true;
    state.initiative.turnsStarted = true;
    touchInitiative();
    const removedTimerIds = sceneTimers.map((timer) => timer.id);
    state.actionTimers = (state.actionTimers ?? []).filter((timer) => timer.sceneId !== state.activeSceneId);
    state.actionTimerTombstones.push(...removedTimerIds.map((id) => ({ id, deletedAt: new Date().toISOString() })));
    state.actionTimerTombstones = state.actionTimerTombstones.slice(-1000);
    state.tacticalSync.playerMovementMode = "combat";
    storeActiveSceneCombat();
  }, {
    successMessage: "Combat démarré : round 1, premier token actif et déplacements limités au tour en cours.",
    failureMessage: "Impossible de commencer un nouveau combat"
  });
}

function delayCurrentTurn() {
  if (state.initiative.active !== true) return showToast("Le retard de tour est disponible uniquement en combat.", "warning");
  const order = state.initiative.order;
  if (order.length < 2) return;
  const [current] = order.splice(state.initiative.currentIndex, 1);
  const insertAt = Math.min(state.initiative.currentIndex + 1, order.length);
  order.splice(insertAt, 0, current);
  state.initiative.currentIndex = insertAt;
  state.initiative.turnsStarted = true;
  touchInitiative();
  commit();
  showToast("Le tour actif a été retardé d’une position.");
}

function activeActionTimers() {
  return (state.actionTimers ?? []).filter((timer) => timer.sceneId === state.activeSceneId);
}

function actionTimerStatus(timer) {
  const round = Math.max(1, Number(state.initiative.round) || 1);
  const remaining = Math.max(0, Number(timer.readyRound) - round);
  return {
    ready: remaining === 0,
    remaining,
    label: remaining === 0 ? "Disponible" : `Disponible au round ${timer.readyRound} · ${remaining} tour${remaining > 1 ? "s" : ""}`
  };
}

function renderActionTimers() {
  const container = $("#actionTimerList");
  if (!container) return;
  const timers = activeActionTimers();
  $("#addActionTimerButton").disabled = state.initiative.active !== true;
  container.innerHTML = timers.map((timer) => {
    const status = actionTimerStatus(timer);
    return `<article class="action-timer-card ${status.ready ? "ready" : "cooling"}">
      <div class="action-timer-glyph">${status.ready ? "✓" : status.remaining}</div>
      <span class="action-timer-copy"><strong>${escapeHtml(timer.ownerLabel)} · ${escapeHtml(timer.label)}</strong><small>${escapeHtml(status.label)} · recharge ${timer.cooldown}</small><em>${timer.visibility === "public" ? "Visible de tous" : timer.ownerPlayerId ? "MJ + joueur" : "Privé MJ"}</em></span>
      <span class="action-timer-actions"><button type="button" data-reuse-action-timer="${escapeHtml(timer.id)}" title="L’action vient d’être réutilisée">↻</button><button type="button" data-remove-action-timer="${escapeHtml(timer.id)}" title="Supprimer">×</button></span>
    </article>`;
  }).join("") || `<div class="empty-state small"><small>Aucune action en recharge pour cette scène.</small></div>`;
  $$('[data-reuse-action-timer]', container).forEach((button) => button.addEventListener("click", () => reuseActionTimer(button.dataset.reuseActionTimer)));
  $$('[data-remove-action-timer]', container).forEach((button) => button.addEventListener("click", () => removeActionTimer(button.dataset.removeActionTimer)));
}

function addActionTimerDialog() {
  if (state.initiative.active !== true) return showToast("Démarrez le combat avant d’ajouter une recharge.", "warning");
  const targets = [`<option value="gm">MJ</option>`, ...state.characters.map((character) => `<option value="${escapeHtml(character.id)}">${escapeHtml(shortcutOwnerLabel(character))}</option>`)].join("");
  openDialog("Action & temps de recharge", `<form id="actionTimerForm" class="dialog-form">
    <p class="dialog-explainer">Une action utilisée au round ${state.initiative.round} avec 5 tours de recharge redevient disponible au round ${state.initiative.round + 5}.</p>
    <label>Personnage / propriétaire<select id="actionTimerOwner">${targets}</select></label>
    <label>Action effectuée<input id="actionTimerLabel" required placeholder="Ex. Souffle draconique" /></label>
    <label>Temps de recharge en tours<input id="actionTimerCooldown" type="number" min="1" max="999" value="5" required /></label>
    <label class="checkbox-line"><input id="actionTimerPublic" type="checkbox" /> Afficher ce minuteur à tous les joueurs</label>
    <div class="timer-ready-preview">Utilisé au round <strong>${state.initiative.round}</strong> · disponible au round <strong id="actionTimerReadyPreview">${state.initiative.round + 5}</strong></div>
    <div class="dialog-actions"><button type="button" class="button button-ghost" data-cancel-dialog>Annuler</button><button class="button button-primary">Ajouter la recharge</button></div>
  </form>`, (root) => {
    const refreshPreview = () => { $("#actionTimerReadyPreview", root).textContent = String(state.initiative.round + clamp(Math.trunc(Number($("#actionTimerCooldown", root).value) || 1), 1, 999)); };
    $("#actionTimerCooldown", root).addEventListener("input", refreshPreview);
    $('[data-cancel-dialog]', root).addEventListener("click", closeDialog);
    $("#actionTimerForm", root).addEventListener("submit", (event) => {
      event.preventDefault();
      if ((state.actionTimers ?? []).length >= MAX_ACTION_TIMERS) return showToast(`Maximum ${MAX_ACTION_TIMERS} minuteurs par session.`, "warning");
      const ownerValue = $("#actionTimerOwner", root).value;
      const character = state.characters.find((entry) => entry.id === ownerValue);
      const cooldown = clamp(Math.trunc(Number($("#actionTimerCooldown", root).value) || 1), 1, 999);
      state.actionTimers.unshift(normalizeActionTimer({
        sceneId: state.activeSceneId,
        label: $("#actionTimerLabel", root).value.trim(),
        cooldown,
        usedRound: state.initiative.round,
        readyRound: state.initiative.round + cooldown,
        ownerPlayerId: character?.ownerPlayerId || null,
        characterId: character?.id || null,
        ownerLabel: character?.name || "MJ",
        visibility: $("#actionTimerPublic", root).checked ? "public" : "private",
        createdByRole: "gm"
      }));
      commit();
      closeDialog();
      showToast(`Recharge ajoutée : disponible au round ${state.initiative.round + cooldown}.`, "success");
    });
  });
}

function reuseActionTimer(timerId) {
  const timer = state.actionTimers.find((entry) => entry.id === timerId);
  if (!timer || state.initiative.active !== true) return;
  timer.usedRound = state.initiative.round;
  timer.readyRound = state.initiative.round + timer.cooldown;
  timer.updatedAt = new Date().toISOString();
  commit();
  showToast(`${timer.label} sera de nouveau disponible au round ${timer.readyRound}.`, "success");
}

function removeActionTimer(timerId) {
  const timer = state.actionTimers.find((entry) => entry.id === timerId);
  if (!timer || !confirm(`Supprimer le minuteur « ${timer.ownerLabel} · ${timer.label} » ?`)) return;
  state.actionTimers = state.actionTimers.filter((entry) => entry.id !== timerId);
  state.actionTimerTombstones.push({ id: timerId, deletedAt: new Date().toISOString() });
  state.actionTimerTombstones = state.actionTimerTombstones.slice(-1000);
  commit();
}

function applyMapViewport() {
  const battlefield = $("#battlefield");
  const world = $("#mapWorld");
  if (!battlefield || !world) return null;
  const geometry = computeMapGeometry(battlefield.clientWidth, battlefield.clientHeight, state.map);
  world.style.width = `${geometry.fitWidth}px`;
  world.style.height = `${geometry.fitHeight}px`;
  world.style.left = `${geometry.centerX}px`;
  world.style.top = `${geometry.centerY}px`;
  world.style.transform = `translate(-50%, -50%) scale(${geometry.zoom})`;
  world.style.setProperty("--grid-size", `${geometry.gridBaseSize}px`);
  world.style.setProperty("--grid-offset-x", `${geometry.gridOffsetBaseX}px`);
  world.style.setProperty("--grid-offset-y", `${geometry.gridOffsetBaseY}px`);
  world.style.setProperty("--grid-opacity", String(Number(state.map.gridOpacity) / 100));
  return geometry;
}

function gridCalibrationSummary() {
  return `X ${Math.round(Number(state.map.gridOffsetX) || 0)} px · Y ${Math.round(Number(state.map.gridOffsetY) || 0)} px`;
}

function renderGridCalibrationControls() {
  const xInput = $("#gridOffsetX");
  const yInput = $("#gridOffsetY");
  if (!xInput || !yInput) return;
  if (document.activeElement !== xInput) xInput.value = Math.round(Number(state.map.gridOffsetX) || 0);
  if (document.activeElement !== yInput) yInput.value = Math.round(Number(state.map.gridOffsetY) || 0);
  $("#gridCalibrationValue").textContent = gridCalibrationSummary();
  $("#calibrateGridButton").classList.toggle("active", gridCalibrationMode);
  $("#calibrateGridButton").textContent = gridCalibrationMode ? "Terminer l’étalonnage" : "Déplacer la grille sur la map";
  $("#gridCalibrationHint").textContent = gridCalibrationMode
    ? "Mode actif : faites glisser la map pour déplacer uniquement la grille. Les tokens sont temporairement verrouillés."
    : "Ajustez la taille, puis déplacez la grille jusqu’à superposer ses lignes aux repères de la map.";
}

function setGridCalibrationMode(enabled) {
  const wasCalibrating = gridCalibrationMode;
  gridCalibrationMode = Boolean(enabled && state.map.background);
  if (gridCalibrationMode) state.map.grid = true;
  if (wasCalibrating && !gridCalibrationMode) {
    snapAllTokensToGrid();
    commit();
    showToast("Grille étalonnée : les tokens sont recentrés dans leurs cases.", "success");
    return;
  }
  renderMap();
  if (gridCalibrationMode) showToast("Étalonnage actif : glissez la grille sur la map, puis cliquez sur Terminer.");
}

function discordCaptureTurnSummary() {
  if (state.initiative.active !== true) return "Mode libre";
  const token = currentToken();
  if (token && !token.hidden) return `Round ${state.initiative.round} · Tour de ${token.name}`;
  return `Round ${state.initiative.round}`;
}

function renderTacticalSyncControls() {
  const paused = state.tacticalSync?.paused === true;
  const combatActive = state.initiative.active === true;
  const pauseButton = $("#toggleTacticalSyncButton");
  const gameModeStatus = $("#gameModeStatus");
  const banner = $("#tacticalPauseBanner");
  if (pauseButton) {
    pauseButton.disabled = tacticalControlInFlight;
    pauseButton.textContent = tacticalControlInFlight
      ? "Synchronisation…"
      : paused ? "Publier & reprendre" : "Préparation secrète";
    pauseButton.classList.toggle("active", paused);
    pauseButton.classList.toggle("button-primary", paused);
    pauseButton.classList.toggle("button-outline", !paused);
    pauseButton.title = paused
      ? "Publier la table préparée et rendre les déplacements joueurs possibles"
      : "Figer la vue joueurs pendant une préparation invisible";
  }
  if (gameModeStatus) {
    gameModeStatus.textContent = combatActive ? "Mode combat" : "Mode libre";
    gameModeStatus.className = `status-badge ${combatActive ? "warning" : "success"}`;
    gameModeStatus.title = combatActive
      ? "Les tours sont actifs et seul le token du tour en cours est déplaçable par son joueur."
      : "Aucun tour n’est actif et chaque joueur peut déplacer ses tokens.";
  }
  if (banner) banner.classList.toggle("hidden", !paused);
  $("#battlefield")?.classList.toggle("tactical-draft", paused);
}

const TACTICAL_DRAWER_IDS = ["mapControlsDrawer", "tokenInspectorDrawer", "shareControlsDrawer"];

function closeTacticalMenus({ except = null } = {}) {
  let closed = false;
  for (const id of TACTICAL_DRAWER_IDS) {
    const drawer = $(`#${id}`);
    if (drawer?.open && drawer !== except) {
      drawer.open = false;
      closed = true;
    }
  }
  const addTokenMenu = $("#addTokenMenu");
  if (addTokenMenu?.open && addTokenMenu !== except) {
    addTokenMenu.open = false;
    closed = true;
  }
  return closed;
}

function openTacticalDrawer(id, { focusSummary = false } = {}) {
  const drawer = $(`#${id}`);
  if (!drawer) return;
  closeTacticalMenus({ except: drawer });
  drawer.open = true;
  if (focusSummary) drawer.querySelector("summary")?.focus();
}

function revealSelectedTokenInspector() {
  requestAnimationFrame(() => openTacticalDrawer("tokenInspectorDrawer"));
}

function updateTacticalSetupStep(id, { complete = false, current = false, status = "" } = {}) {
  const step = $(`#${id}`);
  if (!step) return;
  step.classList.toggle("complete", complete);
  step.classList.toggle("current", current);
  if (current) step.setAttribute("aria-current", "step");
  else step.removeAttribute("aria-current");
  const statusElement = $(`#${id}Status`);
  if (statusElement) statusElement.textContent = status;
}

function renderTacticalCommandCenter() {
  const hasMap = Boolean(state.map.background);
  const tokenCount = state.map.tokens.length;
  const combatActive = state.initiative.active === true;
  const currentStage = !hasMap ? "map" : tokenCount === 0 ? "tokens" : "combat";
  updateTacticalSetupStep("mapSetupStep", {
    complete: hasMap,
    current: currentStage === "map",
    status: hasMap ? (state.map.backgroundName || "Prête") : "À importer"
  });
  updateTacticalSetupStep("tokenSetupStep", {
    complete: tokenCount > 0,
    current: currentStage === "tokens",
    status: tokenCount ? `${tokenCount} sur la carte` : "À ajouter"
  });
  updateTacticalSetupStep("combatSetupStep", {
    complete: combatActive,
    current: currentStage === "combat",
    status: combatActive
      ? `Round ${state.initiative.round}`
      : state.initiative.order.length
        ? `${state.initiative.order.length} initiative${state.initiative.order.length > 1 ? "s" : ""} prête${state.initiative.order.length > 1 ? "s" : ""}`
        : tokenCount ? "Mode libre" : "À préparer"
  });

  const gridLabel = state.map.grid ? "grille active" : "grille masquée";
  const mapStatus = $("#mapControlsStatus");
  if (mapStatus) mapStatus.textContent = hasMap
    ? `Zoom ${Math.round(Number(state.map.zoom) * 100)} % · ${gridLabel}`
    : `Aucune map · ${gridLabel}`;
  const toggleGridButton = $("#toggleGridButton");
  if (toggleGridButton) {
    toggleGridButton.textContent = state.map.grid ? "Grille active" : "Grille masquée";
    toggleGridButton.setAttribute("aria-pressed", String(Boolean(state.map.grid)));
  }

  const selectedToken = state.map.tokens.find((entry) => entry.id === selectedTokenId);
  const tokenStatus = $("#selectedTokenMenuStatus");
  if (tokenStatus) tokenStatus.textContent = selectedToken
    ? `${selectedToken.name}${selectedToken.maxHp > 0 ? ` · PV ${selectedToken.hp}/${selectedToken.maxHp}` : ""}`
    : tokenCount ? `${tokenCount} token${tokenCount > 1 ? "s" : ""} · cliquez pour choisir` : "Aucun token";
  $("#tokenInspectorDrawer")?.classList.toggle("has-selection", Boolean(selectedToken));

  const shareStatus = $("#shareControlsStatus");
  if (shareStatus) shareStatus.textContent = services.discordImages ? "Discord prêt" : "Discord à configurer";
}

function bindTacticalMenus() {
  for (const id of TACTICAL_DRAWER_IDS) {
    const drawer = $(`#${id}`);
    drawer?.addEventListener("toggle", () => {
      if (drawer.open) closeTacticalMenus({ except: drawer });
    });
  }
  const addTokenMenu = $("#addTokenMenu");
  addTokenMenu?.addEventListener("toggle", () => {
    if (addTokenMenu.open) closeTacticalMenus({ except: addTokenMenu });
  });
  $$("button", addTokenMenu).forEach((button) => button.addEventListener("click", () => { addTokenMenu.open = false; }));
  document.addEventListener("pointerdown", (event) => {
    if (event.target.closest("#tacticalCommandCenter, #addTokenMenu")) return;
    closeTacticalMenus();
  });
}

function renderMap() {
  const battlefield = $("#battlefield");
  if (!battlefield) return;
  if (!state.map.background) gridCalibrationMode = false;
  renderTacticalSyncControls();
  battlefield.classList.toggle("grid-enabled", Boolean(state.map.grid));
  battlefield.classList.toggle("has-map", Boolean(state.map.background));
  battlefield.classList.toggle("calibrating-grid", gridCalibrationMode);
  $("#mapWorld").classList.toggle("grid-enabled", Boolean(state.map.grid));
  $("#mapWorldImage").src = state.map.background || "";
  $("#mapWorldImage").classList.toggle("hidden", !state.map.background);
  $("#mapEmptyState").classList.toggle("hidden", Boolean(state.map.background));
  $("#toggleGridButton").classList.toggle("active", Boolean(state.map.grid));
  $("#mapZoom").value = Math.round(Number(state.map.zoom) * 100);
  $("#mapZoomValue").textContent = `${Math.round(Number(state.map.zoom) * 100)} %`;
  if (document.activeElement !== $("#gridSize")) $("#gridSize").value = state.map.gridSize;
  $("#gridOpacity").value = state.map.gridOpacity;
  $("#gridSizeValue").textContent = `${state.map.gridSize} px · 1 case`;
  $("#gridOpacityValue").textContent = `${state.map.gridOpacity} %`;
  $("#tokenLibraryButtonLabel").textContent = `Bestiaire · ${state.tokenLibrary.length}`;
  $("#calibrateGridButton").disabled = !state.map.background;
  renderGridCalibrationControls();
  const messageField = $("#discordCaptureMessage");
  if (document.activeElement !== messageField) messageField.value = state.discordCapture.message || "";
  $("#discordIncludeCurrentTurn").checked = Boolean(state.discordCapture.includeCurrentTurn);
  $("#discordTurnPreview").textContent = state.discordCapture.includeCurrentTurn
    ? `Ajouté au message : ${discordCaptureTurnSummary()}`
    : "Le mode de jeu et, en combat, le round et le tour actif ne seront pas ajoutés.";
  renderTacticalCommandCenter();
  applyMapViewport();
  renderTokenLayer();
  renderTokenInspector();
}

function renderTokenLayer() {
  const layer = $("#tokenLayer");
  if (!layer || draggingTokenId) return;
  const currentId = currentToken()?.id;
  layer.innerHTML = state.map.tokens.map((token) => {
    const percent = token.maxHp > 0 ? clamp((Number(token.hp) / Number(token.maxHp)) * 100, 0, 100) : 100;
    const manaPercent = token.maxMana > 0 ? clamp((Number(token.mana) / Number(token.maxMana)) * 100, 0, 100) : 100;
    const previous = renderedTokenPositions.get(token.id) ?? token;
    return `<div class="map-token ${token.id === selectedTokenId ? "selected" : ""} ${token.id === currentId ? "current-turn" : ""} ${token.hidden ? "hidden-token" : ""}" data-token-id="${escapeHtml(token.id)}" role="button" tabindex="0" aria-pressed="${token.id === selectedTokenId}" aria-label="Sélectionner le token ${escapeHtml(token.name)}" style="--token-x:${previous.x}%;--token-y:${previous.y}%;--token-size:${token.size || DEFAULT_TOKEN_SIZE}px;--token-color:${escapeHtml(token.color || "#8d72cb")};--token-hp:${percent}%;--token-mana:${manaPercent}%">
      <span class="token-core">${token.image ? `<img src="${token.image}" alt="" draggable="false" />` : escapeHtml(initials(token.name))}</span>
      ${token.maxHp > 0 ? `<span class="token-hp"><i></i></span>` : ""}${token.maxMana > 0 ? `<span class="token-mana"><i></i></span>` : ""}<span class="token-name">${escapeHtml(token.name)}</span>
    </div>`;
  }).join("");
  $$('[data-token-id]', layer).forEach((element) => {
    bindTokenDrag(element);
    const token = state.map.tokens.find((entry) => entry.id === element.dataset.tokenId);
    if (!token) return;
    element.addEventListener("keydown", (event) => {
      if (!["Enter", " "].includes(event.key)) return;
      event.preventDefault();
      selectedTokenId = token.id;
      renderTokenLayer();
      renderTokenInspector();
      renderTacticalCommandCenter();
      openTacticalDrawer("tokenInspectorDrawer");
      requestAnimationFrame(() => $(`[data-token-id="${CSS.escape(token.id)}"]`)?.focus());
    });
    requestAnimationFrame(() => {
      element.style.setProperty("--token-x", `${token.x}%`);
      element.style.setProperty("--token-y", `${token.y}%`);
    });
    renderedTokenPositions.set(token.id, { x: token.x, y: token.y });
  });
  for (const id of [...renderedTokenPositions.keys()]) if (!state.map.tokens.some((token) => token.id === id)) renderedTokenPositions.delete(id);
}

function bindTokenDrag(element) {
  element.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    const id = element.dataset.tokenId;
    const token = state.map.tokens.find((entry) => entry.id === id);
    if (!token) return;
    const startX = event.clientX;
    const startY = event.clientY;
    let moved = false;
    selectedTokenId = id;
    draggingTokenId = id;
    element.setPointerCapture?.(event.pointerId);
    element.classList.add("selected", "dragging");
    renderTokenInspector();
    renderTacticalCommandCenter();
    const world = $("#mapWorld");
    const move = (moveEvent) => {
      if (Math.hypot(moveEvent.clientX - startX, moveEvent.clientY - startY) > 4) moved = true;
      const point = mapPointFromClient(moveEvent.clientX, moveEvent.clientY, world.getBoundingClientRect(), state.map);
      token.x = point.x;
      token.y = point.y;
      element.style.setProperty("--token-x", `${token.x}%`);
      element.style.setProperty("--token-y", `${token.y}%`);
    };
    const end = async (endEvent) => {
      element.removeEventListener("pointermove", move);
      element.removeEventListener("pointerup", end);
      element.removeEventListener("pointercancel", end);
      element.classList.remove("dragging");
      snapTokenToGrid(token);
      element.style.setProperty("--token-x", `${token.x}%`);
      element.style.setProperty("--token-y", `${token.y}%`);
      token._movedAt = Date.now();
      draggingTokenId = null;
      renderedTokenPositions.set(token.id, { x: token.x, y: token.y });
      storeActiveSceneCombat();
      persistLocalState();
      renderInitiative();
      if (!moved && endEvent.type === "pointerup") openTacticalDrawer("tokenInspectorDrawer");
      try {
        const response = await api("/api/session/token", { method: "PATCH", body: { tokenId: token.id, x: token.x, y: token.y } });
        if (response.token) {
          token.x = Number(response.token.x);
          token.y = Number(response.token.y);
          renderedTokenPositions.set(token.id, { x: token.x, y: token.y });
          storeActiveSceneCombat();
          persistLocalState();
        }
        state.revision = Number(response.revision ?? state.revision);
        lastServerRevision = state.revision;
      } catch (error) {
        showToast(`Position non synchronisée : ${error.message}`, "error");
        scheduleServerSync();
      }
    };
    element.addEventListener("pointermove", move);
    element.addEventListener("pointerup", end);
    element.addEventListener("pointercancel", end);
  });
}

function bindMapPan() {
  const battlefield = $("#battlefield");
  battlefield.addEventListener("dragstart", (event) => event.preventDefault());
  battlefield.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || (!gridCalibrationMode && event.target.closest(".map-token")) || !state.map.background) return;
    event.preventDefault();
    const geometry = computeMapGeometry(battlefield.clientWidth, battlefield.clientHeight, state.map);
    const calibrating = gridCalibrationMode;
    const start = {
      x: event.clientX,
      y: event.clientY,
      panX: Number(state.map.panX),
      panY: Number(state.map.panY),
      gridOffsetX: Number(state.map.gridOffsetX) || 0,
      gridOffsetY: Number(state.map.gridOffsetY) || 0
    };
    const pointerId = event.pointerId;
    let moved = false;
    battlefield.classList.add(calibrating ? "calibrating-grid-drag" : "panning");
    battlefield.focus({ preventScroll: true });
    battlefield.setPointerCapture?.(pointerId);
    const move = (moveEvent) => {
      if (moveEvent.pointerId !== pointerId) return;
      moveEvent.preventDefault();
      if (calibrating) {
        state.map.gridOffsetX = clamp(start.gridOffsetX + ((moveEvent.clientX - start.x) / Math.max(1, geometry.worldWidth)) * geometry.naturalWidth, -240, 240);
        state.map.gridOffsetY = clamp(start.gridOffsetY + ((moveEvent.clientY - start.y) / Math.max(1, geometry.worldHeight)) * geometry.naturalHeight, -240, 240);
        renderGridCalibrationControls();
      } else {
        const pan = mapPanFromDrag(
          { ...state.map, panX: start.panX, panY: start.panY },
          moveEvent.clientX - start.x,
          moveEvent.clientY - start.y,
          geometry.fitWidth,
          geometry.fitHeight
        );
        state.map.panX = pan.panX;
        state.map.panY = pan.panY;
      }
      moved = true;
      applyMapViewport();
    };
    const end = (endEvent) => {
      if (endEvent?.pointerId !== undefined && endEvent.pointerId !== pointerId) return;
      battlefield.removeEventListener("pointermove", move);
      battlefield.removeEventListener("pointerup", end);
      battlefield.removeEventListener("pointercancel", end);
      battlefield.removeEventListener("lostpointercapture", end);
      if (battlefield.hasPointerCapture?.(pointerId)) battlefield.releasePointerCapture(pointerId);
      battlefield.classList.remove("panning", "calibrating-grid-drag");
      if (moved) commit({ render: false });
    };
    battlefield.addEventListener("pointermove", move);
    battlefield.addEventListener("pointerup", end);
    battlefield.addEventListener("pointercancel", end);
    battlefield.addEventListener("lostpointercapture", end);
  });
}

function setMapZoom(nextZoom, { render = true } = {}) {
  state.map.zoom = clamp(Number(nextZoom), 0.25, 4.5);
  if (render) renderMap(); else applyMapViewport();
}

function resetMapView() {
  state.map.zoom = 1;
  state.map.panX = 0;
  state.map.panY = 0;
  commit();
}

function tokenSizePresetButtons(size) {
  const activePreset = closestTokenSizePreset(size)?.id;
  return TOKEN_SIZE_PRESETS.map((preset) => `<button type="button" class="token-size-preset ${preset.id === activePreset ? "active" : ""}" data-token-size-preset="${preset.size}">${escapeHtml(preset.label)} <small>${preset.size}</small></button>`).join("");
}

function bindTokenSizePresetButtons(root, inputSelector) {
  const input = $(inputSelector, root);
  $$('[data-token-size-preset]', root).forEach((button) => button.addEventListener("click", () => {
    input.value = button.dataset.tokenSizePreset;
    $$('[data-token-size-preset]', root).forEach((entry) => entry.classList.toggle("active", entry === button));
  }));
  input.addEventListener("input", () => {
    $$('[data-token-size-preset]', root).forEach((button) => button.classList.toggle("active", Number(button.dataset.tokenSizePreset) === Number(input.value)));
  });
}

function tokenStatEditorRow(stat = {}) {
  return `<div class="token-stat-row" data-token-stat-row="${escapeHtml(stat.id || uid("token-stat"))}">
    <input data-token-stat-label value="${escapeHtml(stat.label || "")}" placeholder="Nom de la stat" aria-label="Nom de la statistique" />
    <input data-token-stat-value value="${escapeHtml(stat.value ?? "")}" placeholder="Valeur" aria-label="Valeur de la statistique" />
    <button type="button" class="icon-button danger" data-remove-token-stat title="Retirer cette statistique">×</button>
  </div>`;
}

function applyTokenInspectorFields(token) {
  const damageDice = $("#tokenEditDamageDice")?.value.trim() || "";
  if (damageDice) {
    try { parseRoll(damageDice); } catch (error) { showToast(`Dégâts : ${error.message}`, "error"); return false; }
  }
  token.name = $("#tokenEditName").value.trim() || token.name;
  token.color = $("#tokenEditColor").value;
  token.size = clamp(Number($("#tokenEditSize").value || DEFAULT_TOKEN_SIZE), 10, 220);
  token.characterId = $("#tokenEditCharacter").value || null;
  token.controllerPlayerId = $("#tokenEditController").value || null;
  token.followCharacter = $("#tokenEditFollow").checked;
  token.hp = Number($("#tokenEditHp").value || 0);
  token.maxHp = Number($("#tokenEditMaxHp").value || 0);
  token.mana = Number($("#tokenEditMana").value || 0);
  token.maxMana = Number($("#tokenEditMaxMana").value || 0);
  token.damageDice = damageDice;
  token.armor = Number($("#tokenEditArmor").value || 0);
  token.speed = Number($("#tokenEditSpeed").value || 0);
  token.initiative = $("#tokenEditInitiative").value === "" ? null : Number($("#tokenEditInitiative").value);
  token.initiativeBonus = Number($("#tokenEditBonus").value || 0);
  token.condition = $("#tokenEditCondition").value.trim();
  token.stats = $$('[data-token-stat-row]', $("#tokenStatsEditor")).map((row) => ({
    id: row.dataset.tokenStatRow || uid("token-stat"),
    label: $("[data-token-stat-label]", row).value.trim(),
    value: $("[data-token-stat-value]", row).value.trim()
  })).filter((stat) => stat.label || stat.value);
  token.notes = $("#tokenEditNotes").value.trim();
  token.gmNotes = $("#tokenEditGmNotes").value.trim();
  token.revealDetailsToPlayers = !token.controllerPlayerId && $("#tokenEditRevealDetails").checked;
  token.hidden = $("#tokenEditHidden").checked;
  token._updatedAt = Date.now();
  const character = state.characters.find((entry) => entry.id === token.characterId);
  if (character && token.followCharacter) {
    token.controllerPlayerId = character.ownerPlayerId;
    syncOneTokenFromCharacter(token, character);
  }
  return true;
}

function tokenTemplateFromToken(token, existing = null) {
  return normalizeTokenTemplate({
    ...cloneStateValue(token),
    id: existing?.id || uid("token-template"),
    characterId: null,
    controllerPlayerId: null,
    followCharacter: false,
    initiative: null,
    createdAt: existing?.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  });
}

function saveTokenToLibrary(token) {
  const existingIndex = state.tokenLibrary.findIndex((entry) => entry.id === token.libraryTemplateId);
  if (existingIndex < 0 && state.tokenLibrary.length >= MAX_TOKEN_TEMPLATES) {
    showToast(`Le bestiaire est limité à ${MAX_TOKEN_TEMPLATES} modèles.`, "warning");
    return;
  }
  const existing = existingIndex >= 0 ? state.tokenLibrary[existingIndex] : null;
  const template = tokenTemplateFromToken(token, existing);
  if (existingIndex >= 0) state.tokenLibrary[existingIndex] = template;
  else state.tokenLibrary.push(template);
  token.libraryTemplateId = template.id;
  token._updatedAt = Date.now();
  commit();
  showToast(existing ? `Modèle « ${template.name} » mis à jour.` : `« ${template.name} » ajouté au bestiaire.`, "success");
}

function renderTokenInspector() {
  const container = $("#tokenInspector");
  const token = state.map.tokens.find((entry) => entry.id === selectedTokenId);
  if (!token) {
    container.className = "token-inspector empty-state small";
    container.innerHTML = `<small>Sélectionnez un token sur la carte.</small>`;
    return;
  }
  const playerOptions = `<option value="">Contrôle MJ uniquement</option>${optionList(state.players, token.controllerPlayerId, (entry) => entry.name)}`;
  const characterOptions = `<option value="">Aucun personnage lié</option>${optionList(state.characters, token.characterId, (entry) => entry.name)}`;
  const playerOwned = Boolean(token.controllerPlayerId);
  const storedTemplate = state.tokenLibrary.find((entry) => entry.id === token.libraryTemplateId);
  const inInitiative = state.initiative.order.includes(token.id);
  container.className = "token-inspector";
  container.innerHTML = `<div class="token-inspector-form">
    <label>Nom du token<input id="tokenEditName" value="${escapeHtml(token.name)}" /></label>
    <div class="inline-fields"><label>Couleur<input id="tokenEditColor" type="color" value="${escapeHtml(token.color || "#8d72cb")}" /></label><label>Taille manuelle<input id="tokenEditSize" type="number" min="10" max="220" value="${token.size || DEFAULT_TOKEN_SIZE}" /></label></div>
    <div class="token-size-presets" aria-label="Gabarits de créatures">${tokenSizePresetButtons(token.size)}</div>
    <small class="hint-copy token-size-hint">Petite 20 · normale 30 · grosse 60 · très grosse 90. La valeur manuelle reste libre.</small>
    <div class="token-image-actions"><button id="changeTokenImage" class="button button-ghost" type="button">Changer l’image</button><button id="removeTokenImage" class="button button-ghost" type="button">Sans image</button></div>
    <label>Personnage lié<select id="tokenEditCharacter">${characterOptions}</select></label>
    <label>Joueur autorisé à le déplacer<select id="tokenEditController">${playerOptions}</select></label>
    <label class="checkbox-line"><input id="tokenEditFollow" type="checkbox" ${token.followCharacter ? "checked" : ""} /> Synchroniser identité, PV, mana et stats avec la fiche</label>
    <div class="token-sheet-divider"><strong>Fiche tactique</strong><small>Visible en entier par le MJ</small></div>
    <div class="inline-fields"><label>PV<input id="tokenEditHp" type="number" value="${token.hp ?? 0}" /></label><label>PV max<input id="tokenEditMaxHp" type="number" value="${token.maxHp ?? 0}" /></label></div>
    <div class="inline-fields"><label>Mana<input id="tokenEditMana" type="number" value="${token.mana ?? 0}" /></label><label>Mana max<input id="tokenEditMaxMana" type="number" value="${token.maxMana ?? 0}" /></label></div>
    <label>Dégâts en dés<input id="tokenEditDamageDice" value="${escapeHtml(token.damageDice || "")}" placeholder="Ex. 2d6+4" /></label>
    <div class="inline-fields"><label>Défense<input id="tokenEditArmor" type="number" value="${token.armor ?? 0}" /></label><label>Vitesse<input id="tokenEditSpeed" type="number" value="${token.speed ?? 0}" /></label></div>
    <div class="inline-fields"><label>Initiative d100<input id="tokenEditInitiative" type="number" value="${token.initiative ?? ""}" /></label><label>Bonus<input id="tokenEditBonus" type="number" value="${token.initiativeBonus ?? 0}" /></label></div>
    <div class="token-initiative-card ${inInitiative ? "prepared" : ""}">
      <span><strong>${inInitiative ? "Présent dans l’initiative" : "Hors initiative"}</strong><small>${inInitiative ? `Score actuel : ${token.initiative ?? "—"}` : "Ce token peut rester sur la carte sans participer au combat."}</small></span>
      <div class="token-initiative-actions"><button id="rollTokenInitiative" class="button button-outline" type="button">${inInitiative ? "Relancer son initiative" : "Lancer son initiative"}</button>${inInitiative ? `<button id="removeTokenInitiative" class="button button-danger" type="button">Retirer</button>` : ""}</div>
    </div>
    <label>État<input id="tokenEditCondition" value="${escapeHtml(token.condition || "")}" placeholder="Ralenti, blessé…" /></label>
    <div class="token-sheet-divider"><strong>Stats optionnelles</strong><button id="addTokenStat" class="button button-ghost button-small" type="button">+ Stat</button></div>
    <div id="tokenStatsEditor" class="token-stats-editor">${normalizeTokenStats(token.stats).map(tokenStatEditorRow).join("") || `<small class="hint-copy token-stats-empty">Aucune statistique supplémentaire.</small>`}</div>
    <label>Notes partageables<textarea id="tokenEditNotes" rows="3" placeholder="Capacités, résistances, équipement…">${escapeHtml(token.notes || "")}</textarea></label>
    <label class="private-token-field">Notes secrètes MJ<textarea id="tokenEditGmNotes" rows="3" placeholder="Tactique, secret, déclencheur…">${escapeHtml(token.gmNotes || "")}</textarea></label>
    <label class="checkbox-line"><input id="tokenEditRevealDetails" type="checkbox" ${playerOwned || token.revealDetailsToPlayers ? "checked" : ""} ${playerOwned ? "disabled" : ""} /> Afficher PV, mana, dégâts, état et stats aux joueurs</label>
    <small id="tokenDetailsPrivacyHint" class="hint-copy">${playerOwned ? "Ce token appartient à un joueur : sa fiche tactique est visible. Les notes secrètes MJ restent toujours cachées." : "Par défaut, seule l’apparence de ce token MJ est visible. Cochez cette case pour partager sa fiche tactique."}</small>
    <label class="checkbox-line"><input id="tokenEditHidden" type="checkbox" ${token.hidden ? "checked" : ""} /> Caché aux joueurs</label>
    <div class="token-sheet-actions"><button id="rollTokenDamage" class="button button-outline" type="button" ${token.damageDice ? "" : "disabled"}>Lancer les dégâts</button><button id="saveTokenButton" class="button button-primary" type="button">Appliquer</button></div>
    <div class="token-library-save"><button id="saveTokenToLibrary" class="button button-ghost full-width" type="button">${storedTemplate ? "Mettre à jour dans le bestiaire" : "Enregistrer dans le bestiaire"}</button><small>Le modèle garde l’image et la fiche, mais jamais le lien joueur ou personnage.</small></div>
    <button id="removeTokenButton" class="button button-danger full-width" type="button">Retirer de la carte</button>
  </div>`;
  bindTokenSizePresetButtons(container, "#tokenEditSize");
  $("#changeTokenImage").addEventListener("click", () => $("#tokenCustomImageInput").click());
  $("#removeTokenImage").addEventListener("click", () => { token.image = null; token._updatedAt = Date.now(); commit(); });
  $("#tokenEditDamageDice").addEventListener("input", (event) => { $("#rollTokenDamage").disabled = !event.target.value.trim(); });
  $("#tokenEditController").addEventListener("change", (event) => {
    const owned = Boolean(event.target.value);
    $("#tokenEditRevealDetails").checked = owned ? true : Boolean(token.revealDetailsToPlayers);
    $("#tokenEditRevealDetails").disabled = owned;
    $("#tokenDetailsPrivacyHint").textContent = owned
      ? "Ce token appartient à un joueur : sa fiche tactique est visible. Les notes secrètes MJ restent toujours cachées."
      : "Par défaut, seule l’apparence de ce token MJ est visible. Cochez cette case pour partager sa fiche tactique.";
  });
  $("#addTokenStat").addEventListener("click", () => {
    const editor = $("#tokenStatsEditor");
    if ($$('[data-token-stat-row]', editor).length >= 20) return showToast("Un token peut contenir au maximum 20 statistiques.", "warning");
    $(".token-stats-empty", editor)?.remove();
    editor.insertAdjacentHTML("beforeend", tokenStatEditorRow());
  });
  $("#tokenStatsEditor").addEventListener("click", (event) => {
    const button = event.target.closest("[data-remove-token-stat]");
    if (!button) return;
    button.closest("[data-token-stat-row]")?.remove();
    if (!$$('[data-token-stat-row]', $("#tokenStatsEditor")).length) $("#tokenStatsEditor").innerHTML = `<small class="hint-copy token-stats-empty">Aucune statistique supplémentaire.</small>`;
  });
  $("#rollTokenDamage").addEventListener("click", () => performRoll(`${$("#tokenEditName").value.trim() || token.name} · Dégâts`, $("#tokenEditDamageDice").value.trim(), "public"));
  $("#rollTokenInitiative").addEventListener("click", () => rollTokenInitiative(token));
  $("#removeTokenInitiative")?.addEventListener("click", () => removeTokenFromInitiative(token.id));
  $("#saveTokenButton").addEventListener("click", () => {
    if (applyTokenInspectorFields(token)) {
      ensureInitiativeOrder();
      sortInitiativeOrder({ preserveCurrent: state.initiative.active === true });
      touchInitiative();
      commit();
    }
  });
  $("#saveTokenToLibrary").addEventListener("click", () => {
    if (applyTokenInspectorFields(token)) {
      ensureInitiativeOrder();
      sortInitiativeOrder({ preserveCurrent: state.initiative.active === true });
      touchInitiative();
      saveTokenToLibrary(token);
    }
  });
  $("#removeTokenButton").addEventListener("click", () => removeToken(token.id));
}

function syncOneTokenFromCharacter(token, character) {
  Object.assign(token, {
    name: character.name, color: character.color, image: character.portrait,
    hp: character.resources.hp, maxHp: character.resources.maxHp,
    mana: character.resources.mana, maxMana: character.resources.maxMana,
    armor: character.armor, speed: character.speed, stats: characterTokenStats(character),
    initiativeBonus: character.initiativeBonus, controllerPlayerId: character.ownerPlayerId,
    _updatedAt: Date.now()
  });
}

function snapTokenToGrid(token) {
  const point = snapMapPercentPoint(token.x, token.y, state.map);
  token.x = point.x;
  token.y = point.y;
  return token;
}

function snapAllTokensToGrid() {
  if (!state.map.grid) return;
  for (const token of state.map.tokens) snapTokenToGrid(token);
}

function createToken(data = {}) {
  const controllerPlayerId = data.controllerPlayerId ?? null;
  return snapTokenToGrid({
    id: uid("token"), libraryTemplateId: data.libraryTemplateId ?? null, characterId: data.characterId ?? null, controllerPlayerId: data.controllerPlayerId ?? null,
    followCharacter: Boolean(data.followCharacter), name: data.name || "Nouveau token", image: data.image ?? null,
    color: data.color || "#8d72cb", x: data.x ?? 50, y: data.y ?? 50, size: data.size ?? DEFAULT_TOKEN_SIZE,
    hp: Number(data.hp ?? 0), maxHp: Number(data.maxHp ?? 0), initiative: data.initiative ?? null,
    mana: Number(data.mana ?? 0), maxMana: Number(data.maxMana ?? 0), damageDice: String(data.damageDice ?? ""),
    armor: Number(data.armor ?? 0), speed: Number(data.speed ?? 0), stats: normalizeTokenStats(data.stats),
    initiativeBonus: Number(data.initiativeBonus ?? 0), condition: data.condition || "", hidden: Boolean(data.hidden),
    revealDetailsToPlayers: controllerPlayerId ? false : Boolean(data.revealDetailsToPlayers),
    notes: data.notes || "", gmNotes: data.gmNotes || "",
    _updatedAt: Date.now(), _movedAt: Date.now()
  });
}

function summonTokenTemplate(templateId) {
  const template = state.tokenLibrary.find((entry) => entry.id === templateId);
  if (!template) return showToast("Ce modèle n’existe plus dans le bestiaire.", "warning");
  const token = createToken({
    ...cloneStateValue(template),
    libraryTemplateId: template.id,
    characterId: null,
    controllerPlayerId: null,
    followCharacter: false,
    initiative: null,
    x: 43 + (state.map.tokens.length % 4) * 6,
    y: 44 + (state.map.tokens.length % 3) * 7
  });
  state.map.tokens.push(token);
  selectedTokenId = token.id;
  commit();
  closeDialog();
  revealSelectedTokenInspector();
  showToast(`« ${token.name} » invoqué dans ${activeScene()?.name || "le combat actuel"}.`, "success");
}

function removeTokenTemplate(templateId, rerender) {
  const template = state.tokenLibrary.find((entry) => entry.id === templateId);
  if (!template || !confirm(`Supprimer « ${template.name} » du bestiaire ? Les exemplaires déjà placés resteront sur leurs cartes.`)) return;
  state.tokenLibrary = state.tokenLibrary.filter((entry) => entry.id !== templateId);
  const collections = [state.map.tokens, ...state.scenes.map((scene) => scene.combat?.map?.tokens ?? [])];
  for (const tokens of collections) {
    for (const token of tokens) if (token.libraryTemplateId === templateId) token.libraryTemplateId = null;
  }
  commit();
  rerender?.();
  showToast(`« ${template.name} » retiré du bestiaire.`);
}

function openTokenLibraryDialog() {
  openDialog("Bestiaire & modèles", `<div class="token-library-browser">
    <p class="dialog-explainer">Les modèles sont conservés avec la session et peuvent être invoqués dans chaque scène. Les liens vers un joueur ou un personnage ne sont jamais copiés.</p>
    <label>Rechercher<input id="tokenLibrarySearch" type="search" placeholder="Nom, dégâts, note…" autocomplete="off" /></label>
    <div id="tokenLibraryList" class="token-library-list"></div>
    <div class="dialog-actions"><button type="button" class="button button-ghost" data-cancel-dialog>Fermer</button></div>
  </div>`, (root) => {
    const search = $("#tokenLibrarySearch", root);
    const list = $("#tokenLibraryList", root);
    const renderList = () => {
      const query = search.value.trim().toLocaleLowerCase("fr");
      const templates = state.tokenLibrary.filter((template) => !query || [template.name, template.damageDice, template.condition, template.notes, template.gmNotes].some((value) => String(value || "").toLocaleLowerCase("fr").includes(query)));
      list.innerHTML = templates.length ? templates.map((template) => {
        const details = [
          template.maxHp > 0 ? `PV ${template.hp}/${template.maxHp}` : "",
          template.maxMana > 0 ? `PM ${template.mana}/${template.maxMana}` : "",
          template.damageDice ? `Dégâts ${template.damageDice}` : "",
          `Taille ${template.size}`
        ].filter(Boolean).join(" · ");
        return `<article class="token-library-card" style="--token-library-color:${escapeHtml(template.color || "#8d72cb")}">
          <div class="token-library-avatar">${template.image ? `<img src="${template.image}" alt="" />` : escapeHtml(initials(template.name))}</div>
          <div class="token-library-copy"><strong>${escapeHtml(template.name)}</strong><span>${escapeHtml(details)}</span><small>${template.revealDetailsToPlayers ? "Fiche visible des joueurs" : "Détails privés MJ par défaut"}</small></div>
          <div class="token-library-actions"><button class="button button-primary button-small" type="button" data-summon-token-template="${escapeHtml(template.id)}">Invoquer</button><button class="icon-button danger" type="button" data-remove-token-template="${escapeHtml(template.id)}" title="Supprimer du bestiaire">×</button></div>
        </article>`;
      }).join("") : `<div class="empty-state token-library-empty"><div class="empty-sigil">◇</div><strong>${query ? "Aucun modèle trouvé" : "Bestiaire vide"}</strong><small>${query ? "Essayez une autre recherche." : "Sélectionnez un token sur la carte puis choisissez “Enregistrer dans le bestiaire”."}</small></div>`;
      $$('[data-summon-token-template]', list).forEach((button) => button.addEventListener("click", () => summonTokenTemplate(button.dataset.summonTokenTemplate)));
      $$('[data-remove-token-template]', list).forEach((button) => button.addEventListener("click", () => removeTokenTemplate(button.dataset.removeTokenTemplate, renderList)));
    };
    search.addEventListener("input", renderList);
    $("[data-cancel-dialog]", root).addEventListener("click", closeDialog);
    renderList();
  });
}

function addCharacterToken() {
  const character = selectedCharacter();
  if (!character) return;
  const existing = state.map.tokens.find((token) => token.characterId === character.id);
  if (existing) { selectedTokenId = existing.id; setActiveTab("map"); renderMap(); revealSelectedTokenInspector(); return showToast("Token lié retrouvé sur la carte."); }
  const token = createToken({ characterId: character.id, controllerPlayerId: character.ownerPlayerId, followCharacter: true, x: 42 + (state.map.tokens.length % 4) * 6, y: 48 + (state.map.tokens.length % 3) * 7 });
  syncOneTokenFromCharacter(token, character);
  state.map.tokens.push(token);
  selectedTokenId = token.id;
  commit();
  setActiveTab("map");
  revealSelectedTokenInspector();
  showToast(`${character.name} ajouté à la carte et contrôlable par son joueur.`, "success");
}

function addBlankTokenDialog() {
  const sizeOptions = TOKEN_SIZE_PRESETS.map((preset) => `<option value="${preset.size}" ${preset.size === DEFAULT_TOKEN_SIZE ? "selected" : ""}>${escapeHtml(preset.label)} · ${preset.size} px</option>`).join("");
  openDialog("Ajouter un token", `<form id="tokenDialogForm" class="dialog-form">
    <label>Nom<input id="dialogTokenName" required value="Créature" /></label><label>Couleur<input id="dialogTokenColor" type="color" value="#b05f73" /></label>
    <label>Personnage lié<select id="dialogTokenCharacter"><option value="">Aucun</option>${optionList(state.characters, "", (entry) => entry.name)}</select></label>
    <label>Contrôlé par<select id="dialogTokenController"><option value="">MJ uniquement</option>${optionList(state.players, "", (entry) => entry.name)}</select></label>
    <div class="form-grid"><label>Gabarit<select id="dialogTokenSizePreset">${sizeOptions}<option value="custom">Personnalisée</option></select></label><label>Taille manuelle<input id="dialogTokenSize" type="number" min="10" max="220" value="${DEFAULT_TOKEN_SIZE}" /></label></div>
    <div class="form-grid"><label>PV<input id="dialogTokenHp" type="number" value="0" /></label><label>PV max<input id="dialogTokenMaxHp" type="number" value="0" /></label></div>
    <div class="form-grid"><label>Mana<input id="dialogTokenMana" type="number" value="0" /></label><label>Mana max<input id="dialogTokenMaxMana" type="number" value="0" /></label></div>
    <div class="form-grid"><label>Dégâts en dés<input id="dialogTokenDamageDice" value="" placeholder="2d6+4" /></label><label>Bonus initiative d100<input id="dialogTokenBonus" type="number" value="0" /></label></div>
    <label class="checkbox-line"><input id="dialogTokenRevealDetails" type="checkbox" /> Montrer sa fiche tactique aux joueurs</label>
    <small id="dialogTokenPrivacyHint" class="hint-copy">Pour une créature MJ, les PV et les autres informations restent cachés par défaut.</small>
    <label class="checkbox-line"><input id="dialogTokenHidden" type="checkbox" /> Cacher entièrement le token aux joueurs</label>
    <div class="dialog-actions"><button type="button" class="button button-ghost" data-cancel-dialog>Annuler</button><button class="button button-primary">Ajouter</button></div>
  </form>`, (root) => {
    $('[data-cancel-dialog]', root).addEventListener("click", closeDialog);
    $("#dialogTokenCharacter", root).addEventListener("change", (event) => {
      const character = state.characters.find((entry) => entry.id === event.target.value);
      if (character) {
        $("#dialogTokenName", root).value = character.name;
        $("#dialogTokenColor", root).value = character.color;
        $("#dialogTokenController", root).value = character.ownerPlayerId || "";
        $("#dialogTokenHp", root).value = character.resources?.hp ?? 0;
        $("#dialogTokenMaxHp", root).value = character.resources?.maxHp ?? 0;
        $("#dialogTokenMana", root).value = character.resources?.mana ?? 0;
        $("#dialogTokenMaxMana", root).value = character.resources?.maxMana ?? 0;
        $("#dialogTokenRevealDetails", root).checked = Boolean(character.ownerPlayerId);
        $("#dialogTokenRevealDetails", root).disabled = Boolean(character.ownerPlayerId);
      } else {
        $("#dialogTokenController", root).value = "";
        $("#dialogTokenRevealDetails", root).checked = false;
        $("#dialogTokenRevealDetails", root).disabled = false;
      }
    });
    $("#dialogTokenController", root).addEventListener("change", (event) => {
      const controlled = Boolean(event.target.value);
      $("#dialogTokenRevealDetails", root).checked = controlled;
      $("#dialogTokenRevealDetails", root).disabled = controlled;
      $("#dialogTokenPrivacyHint", root).textContent = controlled
        ? "Un token contrôlé par un joueur partage automatiquement sa fiche tactique."
        : "Pour une créature MJ, les PV et les autres informations restent cachés par défaut.";
    });
    $("#dialogTokenSizePreset", root).addEventListener("change", (event) => {
      if (event.target.value !== "custom") $("#dialogTokenSize", root).value = event.target.value;
    });
    $("#dialogTokenSize", root).addEventListener("input", (event) => {
      $("#dialogTokenSizePreset", root).value = closestTokenSizePreset(event.target.value)?.size || "custom";
    });
    $("#tokenDialogForm", root).addEventListener("submit", (event) => {
      event.preventDefault();
      const characterId = $("#dialogTokenCharacter", root).value || null;
      const controllerPlayerId = $("#dialogTokenController", root).value || null;
      const damageDice = $("#dialogTokenDamageDice", root).value.trim();
      if (damageDice) {
        try { parseRoll(damageDice); } catch (error) { return showToast(`Dégâts : ${error.message}`, "error"); }
      }
      const token = createToken({
        name: $("#dialogTokenName", root).value.trim(), color: $("#dialogTokenColor", root).value,
        size: clamp(Number($("#dialogTokenSize", root).value) || DEFAULT_TOKEN_SIZE, 10, 220), characterId, controllerPlayerId,
        followCharacter: Boolean(characterId), hp: $("#dialogTokenHp", root).value, maxHp: $("#dialogTokenMaxHp", root).value,
        mana: $("#dialogTokenMana", root).value, maxMana: $("#dialogTokenMaxMana", root).value, damageDice,
        initiativeBonus: $("#dialogTokenBonus", root).value, hidden: $("#dialogTokenHidden", root).checked,
        revealDetailsToPlayers: !controllerPlayerId && $("#dialogTokenRevealDetails", root).checked,
        x: 45 + (state.map.tokens.length % 4) * 5, y: 45 + (state.map.tokens.length % 3) * 7
      });
      const character = state.characters.find((entry) => entry.id === characterId);
      if (character) syncOneTokenFromCharacter(token, character);
      state.map.tokens.push(token); selectedTokenId = token.id; commit(); closeDialog(); revealSelectedTokenInspector();
    });
  });
}

function removeToken(id) {
  state.map.tokens = state.map.tokens.filter((token) => token.id !== id);
  state.initiative.order = state.initiative.order.filter((tokenId) => tokenId !== id);
  touchInitiative();
  selectedTokenId = null;
  commit();
}

function randomInt(minimum, maximum) {
  const array = new Uint32Array(1);
  crypto.getRandomValues(array);
  return minimum + (array[0] % (maximum - minimum + 1));
}

function parseRoll(formula) {
  const normalized = String(formula).toLowerCase().replaceAll(" ", "");
  if (!normalized || !/^[+\-]?((\d*)d\d+|\d+)([+\-]((\d*)d\d+|\d+))*$/.test(normalized)) throw new Error("Formule invalide. Exemple : 1d100+10 ou 2d40+12.");
  const terms = normalized.match(/[+\-]?[^+\-]+/g) || [];
  let total = 0;
  const parts = [];
  for (const term of terms) {
    const sign = term.startsWith("-") ? -1 : 1;
    const clean = term.replace(/^[+\-]/, "");
    if (clean.includes("d")) {
      const [countText, sidesText] = clean.split("d");
      const count = Number(countText || 1);
      const sides = Number(sidesText);
      if (count < 1 || count > 100 || sides < 2 || sides > 1000) throw new Error("Dés hors limites (maximum 100 dés de 1000 faces).");
      const results = Array.from({ length: count }, () => randomInt(1, sides));
      total += results.reduce((sum, value) => sum + value, 0) * sign;
      parts.push(`${sign < 0 ? "−" : parts.length ? "+" : ""}[${results.join(", ")}]`);
    } else {
      const value = Number(clean) * sign;
      total += value;
      parts.push(`${value >= 0 && parts.length ? "+" : ""}${value}`);
    }
  }
  return { total, breakdown: parts.join(" ") };
}

function renderDice() {
  const globalShortcuts = state.shortcuts.map((shortcut) => `<button class="dice-chip" data-dice-shortcut="${escapeHtml(shortcut.id)}">${escapeHtml(shortcut.label)} · ${escapeHtml(shortcut.formula)}</button>`).join("");
  const characterShortcuts = state.characters.flatMap((character) => (character.shortcuts ?? []).map((shortcut) => `
    <button class="dice-chip ${shortcut.kind === "initiative" ? "initiative-chip" : ""}" data-character-dice-shortcut="${escapeHtml(character.id)}|${escapeHtml(shortcut.id)}" style="--shortcut-color:${escapeHtml(character.color)}">${escapeHtml(character.name)} · ${escapeHtml(shortcut.label)} ${escapeHtml(shortcut.formula)}</button>`)).join("");
  $("#diceShortcuts").innerHTML = globalShortcuts + characterShortcuts;
  const combatShortcuts = $("#combatDiceShortcuts");
  if (combatShortcuts) {
    const globalRows = state.shortcuts.map((shortcut) => `<div class="combat-shortcut-row"><button class="dice-chip" data-dice-shortcut="${escapeHtml(shortcut.id)}"><strong>MJ · ${escapeHtml(shortcut.label)}</strong><small>${escapeHtml(shortcut.formula)}</small></button><button class="combat-shortcut-remove" type="button" data-remove-quick-shortcut="global|${escapeHtml(shortcut.id)}" title="Supprimer ce raccourci">×</button></div>`);
    const characterRows = state.characters.flatMap((character) => (character.shortcuts ?? []).map((shortcut) => `<div class="combat-shortcut-row" style="--shortcut-color:${escapeHtml(character.color)}"><button class="dice-chip ${shortcut.kind === "initiative" ? "initiative-chip" : ""}" data-character-dice-shortcut="${escapeHtml(character.id)}|${escapeHtml(shortcut.id)}"><strong>${escapeHtml(character.name)} · ${escapeHtml(shortcut.label)}</strong><small>${escapeHtml(shortcut.formula)}</small></button><button class="combat-shortcut-remove" type="button" data-remove-quick-shortcut="${escapeHtml(character.id)}|${escapeHtml(shortcut.id)}" title="Supprimer ce raccourci">×</button></div>`));
    combatShortcuts.innerHTML = [...globalRows, ...characterRows].join("") || `<small class="hint-copy">Aucun raccourci. Utilisez + pour en créer un.</small>`;
  }
  $$('[data-dice-shortcut]').forEach((button) => button.addEventListener("click", () => {
    const shortcut = state.shortcuts.find((entry) => entry.id === button.dataset.diceShortcut);
    if (shortcut) performRoll(shortcut.label, shortcut.formula, shortcut.visibility, shortcut.kind === "damage");
  }));
  $$('[data-character-dice-shortcut]').forEach((button) => button.addEventListener("click", () => {
    const [characterId, shortcutId] = button.dataset.characterDiceShortcut.split("|");
    performCharacterShortcut(characterId, shortcutId);
  }));
  $$('[data-remove-quick-shortcut]').forEach((button) => button.addEventListener("click", () => removeQuickShortcut(button.dataset.removeQuickShortcut)));
  $("#rollHistory").innerHTML = state.rolls.slice(0, 10).map((roll) => `<div class="roll-entry ${roll.visibility === "gm" ? "secret" : roll.visibility === "queued" && !roll.revealed ? "queued" : ""}">
    <span>${roll.visibility === "gm" ? "◐ " : roll.visibility === "queued" && !roll.revealed ? "◇ " : ""}<span class="roll-author">${escapeHtml(roll.rollerName || "MJ")}</span> · ${escapeHtml(roll.characterName ? `${roll.characterName} · ${roll.label}` : roll.label)}<small>${escapeHtml(roll.formula)} · ${escapeHtml(roll.breakdown)}</small></span>
    <span><strong>${roll.total}</strong>${roll.visibility === "queued" && !roll.revealed ? `<button data-reveal-roll="${escapeHtml(roll.id)}">Révéler</button>` : ""}</span></div>`).join("") || `<div class="empty-state small"><small>Aucun jet effectué.</small></div>`;
  $$('[data-reveal-roll]').forEach((button) => button.addEventListener("click", () => revealRoll(button.dataset.revealRoll)));
}

function shortcutOwnerLabel(character) {
  if (!character) return "MJ / général";
  const player = state.players.find((entry) => entry.id === character.ownerPlayerId);
  return player ? `${character.name} · joueur ${player.name}` : character.name;
}

function removeQuickShortcut(reference, { confirmRemoval = true, rerender } = {}) {
  const [ownerId, shortcutId] = String(reference || "").split("|");
  const character = ownerId === "global" ? null : state.characters.find((entry) => entry.id === ownerId);
  const shortcut = ownerId === "global"
    ? state.shortcuts.find((entry) => entry.id === shortcutId)
    : character?.shortcuts?.find((entry) => entry.id === shortcutId);
  if (!shortcut) return;
  if (confirmRemoval && !confirm(`Supprimer le raccourci « ${shortcutOwnerLabel(character)} · ${shortcut.label} » ?`)) return;
  if (ownerId === "global") state.shortcuts = state.shortcuts.filter((entry) => entry.id !== shortcutId);
  else {
    character.shortcuts = (character.shortcuts ?? []).filter((entry) => entry.id !== shortcutId);
    character._updatedAt = Date.now();
  }
  commit();
  rerender?.();
  showToast("Raccourci supprimé.");
}

async function performCharacterShortcut(characterId, shortcutId) {
  const character = state.characters.find((entry) => entry.id === characterId);
  const shortcut = character?.shortcuts?.find((entry) => entry.id === shortcutId);
  if (!character || !shortcut) return;
  if (shortcut.kind !== "initiative") return performRoll(`${character.name} · ${shortcut.label}`, shortcut.formula, shortcut.visibility || "public", shortcut.kind === "damage");
  const formula = d100Formula(shortcut.formula);
  shortcut.formula = formula;
  let result;
  try { result = parseRoll(formula); } catch (error) { return showToast(error.message, "error"); }
  let token = state.map.tokens.find((entry) => entry.characterId === character.id);
  if (!token) {
    token = createToken({ characterId: character.id, controllerPlayerId: character.ownerPlayerId, followCharacter: true, x: 42 + (state.map.tokens.length % 4) * 6, y: 48 + (state.map.tokens.length % 3) * 7 });
    syncOneTokenFromCharacter(token, character);
    state.map.tokens.push(token);
  }
  token.initiative = result.total;
  token._updatedAt = Date.now();
  ensureInitiativeOrder();
  addTokenToInitiative(token.id);
  sortInitiativeOrder({ preserveCurrent: state.initiative.active === true });
  touchInitiative();
  selectedTokenId = token.id;
  const roll = createRollRecord(`${character.name} · ${shortcut.label}`, formula, result, shortcut.visibility || "public");
  state.rolls.unshift(roll);
  state.rolls = state.rolls.slice(0, 100);
  commit();
  if (roll.visibility === "public") await postRollToDiscord(roll);
  showToast(
    `${character.name} obtient l’initiative ${result.total} (${result.breakdown}).${state.initiative.active === true ? "" : " Le jeu reste en mode libre."}`,
    "success"
  );
}

function createRollRecord(label, formula, result, visibility = "public", rollerName = "MJ", rollerRole = "gm") {
  return {
    id: uid("roll"), label: label || "Jet", formula, total: result.total, breakdown: result.breakdown,
    visibility, revealed: visibility === "public", rollerName, rollerRole, createdAt: new Date().toISOString()
  };
}

async function performRoll(label, formula, visibility = "public", damageRoll = false) {
  if (!damageRoll && !usesDamageDice(label)) formula = d100Formula(formula);
  let result;
  try { result = parseRoll(formula); } catch (error) { return showToast(error.message, "error"); }
  const roll = createRollRecord(label, formula, result, visibility);
  state.rolls.unshift(roll);
  state.rolls = state.rolls.slice(0, 100);
  commit();
  if (visibility === "public") await postRollToDiscord(roll);
  else showToast(visibility === "gm" ? `Jet secret : ${roll.total}` : `Jet masqué prêt à être révélé : ${roll.total}`);
}

async function postRollToDiscord(roll) {
  if (!services.discordDice) return showToast(`Jet public enregistré : ${roll.total}. Discord n’est pas configuré.`, "warning");
  try {
    await api("/api/discord/post", { method: "POST", body: { target: "dice", content: `🎲 **${roll.rollerName || "MJ"} · ${roll.label}** — \`${roll.formula}\`\nRésultat : **${roll.total}** · ${roll.breakdown}` } });
    showToast("Jet publié dans le salon Discord des jets.", "success");
  } catch (error) { showToast(error.message, "error"); }
}

async function revealRoll(id) {
  const roll = state.rolls.find((entry) => entry.id === id);
  if (!roll) return;
  roll.revealed = true;
  commit();
  await postRollToDiscord(roll);
}

function manageShortcutsDialog() {
  const targets = [`<option value="global">MJ / général</option>`, ...state.characters.map((character) => `<option value="${escapeHtml(character.id)}">${escapeHtml(shortcutOwnerLabel(character))}</option>`)].join("");
  openDialog("Raccourcis de jets", `<div class="shortcut-manager">
    <p class="dialog-explainer">Choisissez un personnage pour afficher son nom sur le jet. Initiative, perception et tests utilisent toujours 1d100 ; les dégâts gardent leur formule libre.</p>
    <div class="shortcut-preset-grid"><button type="button" data-shortcut-preset="initiative">Initiative</button><button type="button" data-shortcut-preset="perception">Perception</button><button type="button" data-shortcut-preset="test">Test d100</button><button type="button" data-shortcut-preset="damage">Dégâts</button></div>
    <form id="shortcutDialogForm" class="dialog-form shortcut-creation-form">
      <label>Lanceur<select id="dialogShortcutTarget">${targets}</select></label>
      <label>Type<select id="dialogShortcutKind"><option value="roll">Test d100</option><option value="initiative">Initiative d100</option><option value="damage">Dégâts libres</option></select></label>
      <label>Nom du raccourci<input id="dialogShortcutLabel" required value="Nouveau test" /></label>
      <label>Formule<input id="dialogShortcutFormula" required value="1d100" /></label>
      <label>Visibilité<select id="dialogShortcutVisibility"><option value="public">Public · Discord</option><option value="gm">Secret MJ</option><option value="queued">Masqué puis révélable</option></select></label>
      <button class="button button-primary full-width">Ajouter le raccourci</button>
    </form>
    <div class="shortcut-manager-heading"><strong>Raccourcis existants</strong><small>Suppression immédiate</small></div><div id="shortcutManagerList" class="shortcut-manager-list"></div>
    <div class="dialog-actions"><button type="button" class="button button-ghost" data-cancel-dialog>Fermer</button></div>
  </div>`, (root) => {
    const renderManagerList = () => {
      const rows = [
        ...state.shortcuts.map((shortcut) => ({ reference: `global|${shortcut.id}`, owner: "MJ / général", shortcut, color: "#8d72cb" })),
        ...state.characters.flatMap((character) => (character.shortcuts ?? []).map((shortcut) => ({ reference: `${character.id}|${shortcut.id}`, owner: shortcutOwnerLabel(character), shortcut, color: character.color })))
      ];
      $("#shortcutManagerList", root).innerHTML = rows.map((entry) => `<div class="shortcut-manager-row" style="--shortcut-color:${escapeHtml(entry.color || "#8d72cb")}"><span><strong>${escapeHtml(entry.owner)} · ${escapeHtml(entry.shortcut.label)}</strong><small>${escapeHtml(entry.shortcut.formula)} · ${entry.shortcut.visibility === "gm" ? "secret MJ" : entry.shortcut.visibility === "queued" ? "masqué" : "public"}</small></span><button type="button" class="icon-button danger" data-remove-managed-shortcut="${escapeHtml(entry.reference)}">×</button></div>`).join("") || `<small class="hint-copy">Aucun raccourci.</small>`;
      $$('[data-remove-managed-shortcut]', root).forEach((button) => button.addEventListener("click", () => removeQuickShortcut(button.dataset.removeManagedShortcut, { rerender: renderManagerList })));
    };
    const applyPreset = (preset) => {
      const fields = {
        initiative: { label: "Initiative", formula: "1d100", kind: "initiative" },
        perception: { label: "Perception", formula: "1d100", kind: "roll" },
        test: { label: "Test général", formula: "1d100", kind: "roll" },
        damage: { label: "Dégâts", formula: "2d6+4", kind: "damage" }
      }[preset];
      if (!fields) return;
      if (fields.kind === "initiative" && $("#dialogShortcutTarget", root).value === "global" && state.characters[0]) {
        $("#dialogShortcutTarget", root).value = state.characters[0].id;
      }
      const targetCharacter = state.characters.find((entry) => entry.id === $("#dialogShortcutTarget", root).value);
      if (fields.kind === "initiative" && targetCharacter) fields.formula = `1d100${Number(targetCharacter.initiativeBonus || 0) >= 0 ? "+" : ""}${Number(targetCharacter.initiativeBonus || 0)}`;
      $("#dialogShortcutLabel", root).value = fields.label;
      $("#dialogShortcutFormula", root).value = fields.formula;
      $("#dialogShortcutKind", root).value = fields.kind;
    };
    $$('[data-shortcut-preset]', root).forEach((button) => button.addEventListener("click", () => applyPreset(button.dataset.shortcutPreset)));
    $("#dialogShortcutKind", root).addEventListener("change", (event) => applyPreset(event.target.value === "roll" ? "test" : event.target.value));
    $('[data-cancel-dialog]', root).addEventListener("click", closeDialog);
    $("#shortcutDialogForm", root).addEventListener("submit", (event) => {
      event.preventDefault();
      const targetId = $("#dialogShortcutTarget", root).value;
      const kind = $("#dialogShortcutKind", root).value;
      if (kind === "initiative" && targetId === "global") return showToast("Choisissez un personnage pour qu’une initiative mette à jour son token.", "warning");
      const shortcut = normalizeShortcut({
        id: uid("shortcut"),
        label: $("#dialogShortcutLabel", root).value.trim() || "Jet",
        formula: $("#dialogShortcutFormula", root).value.trim() || (kind === "damage" ? "1d6" : "1d100"),
        kind,
        visibility: $("#dialogShortcutVisibility", root).value
      });
      try { parseRoll(shortcut.formula); } catch (error) { return showToast(error.message, "error"); }
      if (targetId === "global") state.shortcuts.push(shortcut);
      else {
        const character = state.characters.find((entry) => entry.id === targetId);
        if (!character) return showToast("Personnage introuvable.", "error");
        character.shortcuts ??= [];
        character.shortcuts.push(shortcut);
        character._updatedAt = Date.now();
      }
      commit();
      renderManagerList();
      showToast("Raccourci ajouté.", "success");
    });
    renderManagerList();
  });
}

function loadImage(source) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Impossible de lire cette image."));
    image.src = source;
  });
}

async function imageFileToDataUrl(file, maxWidth = 2048, maxHeight = 2048, quality = 0.9) {
  const objectUrl = URL.createObjectURL(file);
  try {
    const image = await loadImage(objectUrl);
    const scale = Math.min(1, maxWidth / image.naturalWidth, maxHeight / image.naturalHeight);
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/webp", quality);
  } finally { URL.revokeObjectURL(objectUrl); }
}

async function setMapBackground(dataUrl, name) {
  const image = await loadImage(dataUrl);
  state.map.background = dataUrl;
  state.map.backgroundName = name;
  state.map.naturalWidth = image.naturalWidth;
  state.map.naturalHeight = image.naturalHeight;
  state.map.zoom = 1; state.map.panX = 0; state.map.panY = 0;
  state.map.gridSize = DEFAULT_GRID_SIZE;
  state.map.gridOffsetX = 0;
  state.map.gridOffsetY = 0;
  gridCalibrationMode = false;
  commit();
  setActiveTab("map");
}

async function importMapFile(file) {
  if (!file) return;
  try { await setMapBackground(await imageFileToDataUrl(file, 3200, 2400, 0.92), file.name); showToast("Image de map ajoutée.", "success"); }
  catch (error) { showToast(error.message, "error"); }
}

async function importTokenFile(file) {
  if (!file) return;
  try {
    const image = await imageFileToDataUrl(file, 640, 640, 0.92);
    const name = file.name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ");
    const token = createToken({ name, image, x: 50, y: 50 });
    state.map.tokens.push(token); selectedTokenId = token.id; commit(); revealSelectedTokenInspector(); showToast(`Token « ${name} » ajouté et prêt à être personnalisé.`, "success");
  } catch (error) { showToast(error.message, "error"); }
}

async function importForgeImage(file) {
  if (!file) return;
  try {
    state.forge.imageDataUrl = await imageFileToDataUrl(file, 2048, 2048, 0.92);
    state.forge.prompt ||= file.name.replace(/\.[^.]+$/, "");
    $("#imageStatus").textContent = "Prête";
    $("#imageStatus").className = "status-badge success";
    commit();
    showToast("Illustration récupérée dans la forge.", "success");
  }
  catch (error) { showToast(error.message, "error"); }
}

async function addReferenceImages(files) {
  const imageFiles = files.filter((file) => file?.type?.startsWith("image/"));
  if (!imageFiles.length) return;
  const remaining = MAX_FORGE_ATTACHMENTS - selectedForgeCharacterIds.size - forgeFreeAttachments.length;
  if (remaining <= 0) return showToast(`Retirez d’abord une pièce jointe : la limite est de ${MAX_FORGE_ATTACHMENTS}.`, "warning");
  const accepted = imageFiles.slice(0, remaining);
  try {
    const prepared = await Promise.all(accepted.map(async (file) => ({
      id: uid("forge-reference"),
      name: file.name || "référence libre",
      dataUrl: await imageFileToDataUrl(file, 1536, 1536, 0.92)
    })));
    forgeFreeAttachments.push(...prepared);
    renderForge();
    const ignored = imageFiles.length - accepted.length;
    showToast(`${prepared.length} référence${prepared.length > 1 ? "s ajoutées" : " ajoutée"}${ignored ? ` · ${ignored} ignorée${ignored > 1 ? "s" : ""} (limite atteinte)` : ""}.`, ignored ? "warning" : "success", 5200);
  } catch (error) { showToast(error.message, "error"); }
}

function styledPrompt(rawPrompt) {
  return `${withBattlemapScaleGuide(rawPrompt)}\n\nDirection visuelle Xar Tsaroth : anime / semi-réaliste haut de gamme, anatomie crédible, contours propres, rendu lisse et net, proportions naturelles, éclairage cinématique contrôlé. Éviter tout grain, bruit, trame répétitive, moiré, hachures, texture toile, points lumineux parasites et surenchère de détails. Aucun texte ni watermark.`;
}

function selectedForgeCharacters() {
  return state.characters.filter((character) => selectedForgeCharacterIds.has(character.id) && character.portrait);
}

function forgeReferenceNames() {
  return [
    ...selectedForgeCharacters().map((character) => character.name),
    ...forgeFreeAttachments.map((attachment) => attachment.name || "référence libre")
  ];
}

function forgeBridgeAttachments() {
  const characterAttachments = selectedForgeCharacters().map((character) => ({
    name: `${slugify(character.name)}-reference.webp`,
    dataUrl: character.portrait
  }));
  characterAttachments.push(...forgeFreeAttachments.map((attachment) => ({
    name: safeClientFilename(attachment.name || "reference-libre.webp"),
    dataUrl: attachment.dataUrl
  })));
  return characterAttachments;
}

function safeClientFilename(value) {
  const clean = String(value || "reference.webp").replace(/[^a-zA-Z0-9À-ÿ._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 100);
  return clean || "reference.webp";
}

function chatGptPrompt(rawPrompt) {
  const references = forgeReferenceNames();
  const referenceInstruction = references.length
    ? `\n\nJe joins ${references.length === 1 ? "une image de référence" : `${references.length} images de référence`} (${references.join(", ")}). Utilise chacune uniquement pour le personnage ou l’élément correspondant. Préserve strictement les identités, visages, couleurs, tenues et signes distinctifs ; ne copie pas une pose sauf demande explicite.`
    : "";
  return `${styledPrompt(rawPrompt)}${referenceInstruction}\n\nCrée directement l’image finale.`;
}

function selectedBridgeConversation() {
  return (bridgeConfig.conversations ?? []).find((entry) => entry.id === selectedBridgeConversationId) ?? bridgeConfig.conversations?.[0] ?? null;
}

async function refreshChatGptBridgeStatus({ rerender = true } = {}) {
  try {
    const response = await api("/api/chatgpt-bridge/status");
    bridgeConfig = { ...bridgeConfig, ...response };
    services.chatgptBridge = Boolean(bridgeConfig.connected);
    if (rerender) {
      renderForge();
      renderServices();
    }
  } catch {
    bridgeConfig.connected = false;
    services.chatgptBridge = false;
    if (rerender) renderForge();
  }
}

function chatGptBridgeConfigDialog() {
  const [characters, scenes] = bridgeConfig.conversations ?? [];
  openDialog("Pont navigateur ChatGPT", `
    <div class="bridge-config-grid">
      <p class="forge-chatgpt-note"><strong>Deux conversations ciblées :</strong> ouvrez chaque discussion dans ChatGPT puis copiez son adresse complète contenant <code>/c/</code>.</p>
      <label>${escapeHtml(characters?.label || "Personnages & portraits")}<input id="bridgeCharactersUrl" type="url" value="${escapeHtml(characters?.url || "")}" placeholder="https://chatgpt.com/c/…" /></label>
      <label>${escapeHtml(scenes?.label || "Scènes, décors & cartes")}<input id="bridgeScenesUrl" type="url" value="${escapeHtml(scenes?.url || "")}" placeholder="https://chatgpt.com/c/…" /></label>
      <div><span class="field-label">Code d’appairage local</span><div class="bridge-pairing-code"><input id="bridgePairingToken" readonly value="${escapeHtml(bridgeConfig.pairingToken || "")}" /><button id="copyBridgePairingToken" class="button button-outline" type="button">Copier</button></div></div>
      <ol class="bridge-install-steps">
        <li>Ouvrez <code>chrome://extensions</code> ou <code>edge://extensions</code>.</li>
        <li>Activez le mode développeur puis « Charger l’extension non empaquetée ».</li>
        <li>Choisissez le dossier <code>extension-chatgpt-xar</code> fourni avec la Régie.</li>
        <li>Dans l’icône de l’extension, collez ce code puis cliquez sur « Appairer ».</li>
      </ol>
      <p class="bridge-privacy-note">La session ChatGPT reste entièrement dans votre navigateur. L’extension ne lit ni cookies ni mot de passe ; elle ne communique qu’avec la Régie locale.</p>
      <div class="button-row wrap"><button id="saveBridgeConfig" class="button button-primary" type="button">Enregistrer</button><button id="rotateBridgeToken" class="button button-ghost" type="button">Changer le code</button></div>
    </div>
  `, (root) => {
    $("#copyBridgePairingToken", root).addEventListener("click", async () => {
      try { await navigator.clipboard.writeText($("#bridgePairingToken", root).value); showToast("Code d’appairage copié.", "success"); }
      catch { showToast("Sélectionnez puis copiez manuellement le code.", "warning"); }
    });
    $("#saveBridgeConfig", root).addEventListener("click", async () => {
      try {
        const response = await api("/api/chatgpt-bridge/config", {
          method: "POST",
          body: { conversations: [
            { id: "characters", label: characters?.label || "Personnages & portraits", url: $("#bridgeCharactersUrl", root).value.trim() },
            { id: "scenes", label: scenes?.label || "Scènes, décors & cartes", url: $("#bridgeScenesUrl", root).value.trim() }
          ] }
        });
        bridgeConfig = { ...bridgeConfig, ...response };
        closeDialog();
        renderForge();
        showToast("Conversations ChatGPT enregistrées.", "success");
      } catch (error) { showToast(error.message, "error", 5600); }
    });
    $("#rotateBridgeToken", root).addEventListener("click", async () => {
      if (!confirm("Changer le code déconnectera l’extension actuelle. Continuer ?")) return;
      try {
        const response = await api("/api/chatgpt-bridge/rotate-token", { method: "POST", body: {} });
        bridgeConfig = { ...bridgeConfig, ...response };
        $("#bridgePairingToken", root).value = bridgeConfig.pairingToken;
        showToast("Nouveau code créé. Appairez de nouveau l’extension.", "success", 5200);
        renderForge();
      } catch (error) { showToast(error.message, "error"); }
    });
  });
}

async function preparePromptInChatGpt() {
  const rawPrompt = $("#imagePrompt").value.trim();
  if (!rawPrompt) return showToast("Décrivez d’abord l’image à créer.", "error");
  const conversation = selectedBridgeConversation();
  if (!conversation?.url) {
    chatGptBridgeConfigDialog();
    return showToast("Indiquez d’abord l’adresse de la conversation ciblée.", "warning", 5200);
  }
  state.forge.prompt = rawPrompt;
  persistLocalState();
  try {
    const response = await api("/api/chatgpt-bridge/jobs", {
      method: "POST",
      body: {
        conversationId: conversation.id,
        prompt: chatGptPrompt(rawPrompt),
        attachments: forgeBridgeAttachments()
      }
    });
    window.open(response.job.conversationUrl, "_blank", "noopener,noreferrer");
    $("#imageStatus").textContent = "Prête dans le pont";
    $("#imageStatus").className = "status-badge warning";
    showToast(`${bridgeConfig.connected ? "Demande transmise" : "Demande mise en attente"}. Ouvrez la conversation et validez-la dans le panneau Xar.`, bridgeConfig.connected ? "success" : "warning", 6500);
  } catch (error) {
    showToast(`Pont ChatGPT : ${error.message}`, "error", 6200);
  }
}

async function copyPromptAndOpenChatGPT() {
  const rawPrompt = $("#imagePrompt").value.trim();
  if (!rawPrompt) return showToast("Décrivez d’abord l’image à créer.", "error");
  state.forge.prompt = rawPrompt;
  persistLocalState();
  window.open(selectedBridgeConversation()?.url || "https://chatgpt.com/", "_blank", "noopener,noreferrer");
  const completePrompt = chatGptPrompt(rawPrompt);
  let copied = false;
  try {
    await navigator.clipboard.writeText(completePrompt);
    copied = true;
  } catch {
    globalThis.prompt("Copiez ce prompt dans ChatGPT :", completePrompt);
  }
  $("#imageStatus").textContent = "Dans ChatGPT";
  $("#imageStatus").className = "status-badge warning";
  const referenceReminder = forgeReferenceNames().length ? ` Joignez aussi ${forgeReferenceNames().length} référence(s).` : "";
  showToast(`${copied ? "Prompt copié." : "Prompt préparé."} Collez-le dans ChatGPT puis ramenez l’image ici.${referenceReminder}`, "success", 6200);
}

async function collectChatGptBridgeImports() {
  if (bridgeImportInFlight) return;
  bridgeImportInFlight = true;
  try {
    const response = await api("/api/chatgpt-bridge/imports");
    bridgeConfig.pendingImports = response.imports?.length ?? 0;
    for (const entry of response.imports ?? []) {
      if (consumedBridgeImportIds.has(entry.id)) continue;
      consumedBridgeImportIds.add(entry.id);
      try {
        const imageResponse = await fetch(`/api/chatgpt-bridge/imports/${encodeURIComponent(entry.id)}/content`, { cache: "no-store" });
        if (!imageResponse.ok) throw new Error(`Erreur ${imageResponse.status}`);
        const blob = await imageResponse.blob();
        await importForgeImage(new File([blob], entry.filename || `chatgpt-${Date.now()}.png`, { type: entry.contentType || blob.type }));
        await api(`/api/chatgpt-bridge/imports/${encodeURIComponent(entry.id)}`, { method: "DELETE" });
        $("#imageStatus").textContent = "Importée de ChatGPT";
        $("#imageStatus").className = "status-badge success";
      } catch (error) {
        consumedBridgeImportIds.delete(entry.id);
        showToast(`Import du pont impossible : ${error.message}`, "error", 5200);
      }
    }
  } catch {
    // Le pont est facultatif ; le collage et l’import manuel restent disponibles.
  } finally {
    bridgeImportInFlight = false;
  }
}

async function pasteForgeImageFromClipboard() {
  if (!navigator.clipboard?.read) {
    return showToast("Le collage d’image n’est pas disponible dans ce navigateur. Utilisez Importer un fichier ou glissez l’image dans la forge.", "warning", 5200);
  }
  try {
    const items = await navigator.clipboard.read();
    for (const item of items) {
      const imageType = item.types.find((type) => type.startsWith("image/"));
      if (!imageType) continue;
      const blob = await item.getType(imageType);
      const extension = imageType.split("/")[1]?.replace("jpeg", "jpg") || "png";
      await importForgeImage(new File([blob], `chatgpt-${Date.now()}.${extension}`, { type: imageType }));
      return;
    }
    showToast("Le presse-papiers ne contient pas d’image. Téléchargez-la depuis ChatGPT puis importez-la ou glissez-la ici.", "warning", 5200);
  } catch (error) {
    showToast(`Impossible de lire l’image du presse-papiers : ${error.message}`, "error", 5200);
  }
}

function bindForgeDropZone() {
  const preview = $("#forgePreview");
  for (const eventName of ["dragenter", "dragover"]) {
    preview.addEventListener(eventName, (event) => {
      event.preventDefault();
      preview.classList.add("drag-over");
    });
  }
  for (const eventName of ["dragleave", "drop"]) {
    preview.addEventListener(eventName, (event) => {
      event.preventDefault();
      preview.classList.remove("drag-over");
    });
  }
  preview.addEventListener("drop", (event) => {
    const file = [...(event.dataTransfer?.files ?? [])].find((entry) => entry.type.startsWith("image/"));
    if (!file) return showToast("Déposez un fichier image dans la forge.", "warning");
    importForgeImage(file);
  });
}

function currentImageFilename() { return `${slugify(state.forge.prompt || activeScene()?.name)}-${timestampForFilename()}.webp`; }

function applyOvhStorageStatus(payload) {
  if (!payload || typeof payload !== "object") return;
  ovhStorageStatus = { ...ovhStorageStatus, ...payload };
  renderOvhCleanupStatus();
}

async function cleanupOvhMedia({ forceLegacy = false, manual = false } = {}) {
  if (!services.ovh) {
    if (manual) showToast("Configurez d’abord le dépôt OVH dans .env.local.", "warning");
    return;
  }
  if (ovhCleanupInFlight) return;
  ovhCleanupInFlight = true;
  renderOvhCleanupStatus();
  try {
    const response = await api("/api/ovh/cleanup", { method: "POST", body: { forceLegacy } });
    applyOvhStorageStatus(response.storage);
    const deleted = Number(response.cleanup?.deletedCount ?? 0);
    if (deleted) showToast(`${deleted} ancien(s) média(s) OVH supprimé(s).`, "success", 5200);
    else if (manual) showToast("Le dépôt OVH est déjà propre.", "success");
    const warnings = response.cleanup?.warnings?.length ?? 0;
    if (warnings) showToast(`${warnings} suppression(s) seront retentées automatiquement.`, "warning", 6200);
  } catch (error) {
    ovhStorageStatus = { ...ovhStorageStatus, warnings: [error.message] };
    if (manual) showToast(`Nettoyage OVH impossible : ${error.message}`, "error", 6200);
    else console.warn("Nettoyage OVH automatique indisponible", error);
  } finally {
    ovhCleanupInFlight = false;
    renderOvhCleanupStatus();
  }
}

async function publishImage(destination) {
  if (!state.forge.imageDataUrl) return;
  const filename = currentImageFilename();
  const caption = `**${activeScene()?.name || "Vision de Xar Tsaroth"}**\n${state.forge.prompt || "Illustration de session"}`;
  const actions = [];
  if (["discord", "both"].includes(destination)) actions.push(api("/api/discord/post", { method: "POST", body: { target: "images", content: caption, imageDataUrl: state.forge.imageDataUrl, filename } }).then(() => "Discord"));
  if (["ovh", "both"].includes(destination)) actions.push(api("/api/ovh/upload", { method: "POST", body: { imageDataUrl: state.forge.imageDataUrl, filename } }).then((response) => {
    applyOvhStorageStatus(response.storage);
    return "OVH";
  }));
  try { showToast(`Illustration envoyée vers ${(await Promise.all(actions)).join(" et ")}.`, "success"); }
  catch (error) { showToast(error.message, "error", 5200); }
}

function downloadDataUrl(dataUrl, filename) {
  const anchor = document.createElement("a"); anchor.href = dataUrl; anchor.download = filename; document.body.append(anchor); anchor.click(); anchor.remove();
}

async function renderMapCanvas({ includeHidden = false } = {}) {
  const battlefield = $("#battlefield");
  const logicalWidth = Math.max(640, Math.round(battlefield.clientWidth || 1000));
  const logicalHeight = Math.max(360, Math.round(battlefield.clientHeight || 600));
  const pixelRatio = clamp(1800 / logicalWidth, 1, 2);
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(logicalWidth * pixelRatio);
  canvas.height = Math.round(logicalHeight * pixelRatio);
  const context = canvas.getContext("2d");
  context.scale(pixelRatio, pixelRatio);
  context.fillStyle = "#070914";
  context.fillRect(0, 0, logicalWidth, logicalHeight);
  const geometry = computeMapGeometry(logicalWidth, logicalHeight, state.map);
  context.save();
  context.beginPath(); context.rect(0, 0, logicalWidth, logicalHeight); context.clip();
  if (state.map.background) {
    const image = await loadImage(state.map.background);
    context.drawImage(image, geometry.left, geometry.top, geometry.worldWidth, geometry.worldHeight);
  }
  if (state.map.grid) {
    const cell = geometry.gridScreenSize;
    const offsetX = ((geometry.gridOffsetScreenX % cell) + cell) % cell;
    const offsetY = ((geometry.gridOffsetScreenY % cell) + cell) % cell;
    context.strokeStyle = `rgba(228, 212, 174, ${Number(state.map.gridOpacity) / 100})`;
    context.lineWidth = Math.max(1 / pixelRatio, geometry.zoom * 0.8);
    for (let x = geometry.left + offsetX; x <= geometry.left + geometry.worldWidth + 0.1; x += cell) { context.beginPath(); context.moveTo(x, geometry.top); context.lineTo(x, geometry.top + geometry.worldHeight); context.stroke(); }
    for (let y = geometry.top + offsetY; y <= geometry.top + geometry.worldHeight + 0.1; y += cell) { context.beginPath(); context.moveTo(geometry.left, y); context.lineTo(geometry.left + geometry.worldWidth, y); context.stroke(); }
  }
  const tokens = state.map.tokens.filter((token) => includeHidden || !token.hidden);
  for (const token of tokens) {
    const screen = mapTokenScreenPosition(token, geometry);
    const baseTokenSize = Number(token.size) || DEFAULT_TOKEN_SIZE;
    const outerSize = screen.size;
    const coreInset = clamp(baseTokenSize * 0.065, 2, 4) * geometry.zoom;
    const tokenBorder = clamp(baseTokenSize * 0.05, 2, 3) * geometry.zoom;
    const radius = Math.max(3, outerSize / 2 - coreInset);
    context.save();
    context.beginPath(); context.arc(screen.x, screen.y, radius, 0, Math.PI * 2); context.clip();
    if (token.image) {
      const image = await loadImage(token.image);
      const scale = Math.max((radius * 2) / image.naturalWidth, (radius * 2) / image.naturalHeight);
      const width = image.naturalWidth * scale; const height = image.naturalHeight * scale;
      context.drawImage(image, screen.x - width / 2, screen.y - height / 2, width, height);
    } else {
      context.fillStyle = token.color || "#8d72cb"; context.fillRect(screen.x - radius, screen.y - radius, radius * 2, radius * 2);
      context.fillStyle = "#fff"; context.font = `900 ${Math.max(8, outerSize * 0.23)}px sans-serif`; context.textAlign = "center"; context.textBaseline = "middle"; context.fillText(initials(token.name), screen.x, screen.y);
    }
    context.restore();
    context.strokeStyle = token.color || "#8d72cb"; context.lineWidth = tokenBorder; context.beginPath(); context.arc(screen.x, screen.y, radius, 0, Math.PI * 2); context.stroke();
    if (token.id === currentToken()?.id) { context.strokeStyle = "rgba(246,218,145,.9)"; context.lineWidth = Math.max(2, 2 * geometry.zoom); context.beginPath(); context.arc(screen.x, screen.y, radius + 4 * geometry.zoom, 0, Math.PI * 2); context.stroke(); }
    const publicDetailsVisible = Boolean(token.controllerPlayerId) || token.revealDetailsToPlayers === true;
    if (publicDetailsVisible && token.maxHp > 0) {
      const hpPercent = clamp(Number(token.hp) / Number(token.maxHp), 0, 1);
      const barWidth = outerSize * 0.8; const barHeight = Math.max(3, 4 * geometry.zoom); const barY = screen.y - outerSize / 2 - 2 * geometry.zoom;
      context.fillStyle = "#170a0e"; context.fillRect(screen.x - barWidth / 2, barY, barWidth, barHeight);
      context.fillStyle = "#d75e6b"; context.fillRect(screen.x - barWidth / 2, barY, barWidth * hpPercent, barHeight);
    }
    const fontSize = Math.max(7, 8 * geometry.zoom);
    context.font = `700 ${fontSize}px sans-serif`; context.textAlign = "center"; context.textBaseline = "top";
    const textWidth = context.measureText(token.name).width + 10 * geometry.zoom;
    const textY = screen.y + outerSize / 2 + 2 * geometry.zoom;
    context.fillStyle = "rgba(3,5,12,.86)"; context.fillRect(screen.x - textWidth / 2, textY, textWidth, fontSize + 5 * geometry.zoom);
    context.fillStyle = "#eee8d9"; context.fillText(token.name, screen.x, textY + 2 * geometry.zoom);
  }
  context.restore();
  const vignette = context.createRadialGradient(logicalWidth / 2, logicalHeight / 2, logicalHeight * 0.25, logicalWidth / 2, logicalHeight / 2, Math.max(logicalWidth, logicalHeight) * 0.72);
  vignette.addColorStop(0, "rgba(0,0,0,0)"); vignette.addColorStop(1, "rgba(0,0,0,.34)"); context.fillStyle = vignette; context.fillRect(0, 0, logicalWidth, logicalHeight);
  return canvas.toDataURL("image/webp", 0.92);
}

function mapDiscordContent() {
  const combatActive = state.initiative.active === true;
  const title = state.discordCapture.includeCurrentTurn
    ? `🗺️ **${combatActive ? "État du combat" : "État de la table"} — ${discordCaptureTurnSummary().replace(/([*_`~|\\])/g, "\\$1")}**`
    : `🗺️ **${combatActive ? "État du combat" : "État de la table"}**`;
  const message = String(state.discordCapture.message || "").trim();
  return message ? `${title}\n${message}` : title;
}

async function captureMapToDiscord() {
  if (!services.discordImages) return showToast("Le webhook Discord des illustrations n’est pas configuré.", "warning");
  try {
    const dataUrl = await renderMapCanvas({ includeHidden: false });
    const captureLabel = state.initiative.active === true ? `combat-round-${state.initiative.round}` : "table-mode-libre";
    await api("/api/discord/post", { method: "POST", body: { target: "images", content: mapDiscordContent(), imageDataUrl: dataUrl, filename: `${captureLabel}-${timestampForFilename()}.webp` } });
    showToast("Capture fidèle publiée sur Discord.", "success");
  } catch (error) { showToast(error.message, "error"); }
}

function openAssetDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains(DB_STORE)) request.result.createObjectStore(DB_STORE); };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function getLegacyAsset(id) {
  if (!id) return null;
  const db = await openAssetDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(DB_STORE, "readonly");
    const request = transaction.objectStore(DB_STORE).get(id);
    request.onsuccess = () => resolve(request.result ?? null);
    request.onerror = () => reject(request.error);
  });
}

async function deleteLegacyAsset(id) {
  if (!id) return;
  const db = await openAssetDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(DB_STORE, "readwrite");
    transaction.objectStore(DB_STORE).delete(id);
    transaction.oncomplete = resolve;
    transaction.onerror = () => reject(transaction.error);
  });
}

async function importAudioFiles(files, channel) {
  if (!files.length) return;
  let imported = 0;
  for (const file of files) {
    try {
      const result = await uploadRaw(`/api/media/upload?filename=${encodeURIComponent(file.name)}`, file);
      state.tracks.push({ id: uid("track"), mediaId: result.mediaId, url: result.url, name: file.name.replace(/\.[^.]+$/, ""), originalName: file.name, channel, type: file.type, size: result.size });
      imported += 1;
    } catch (error) { showToast(`${file.name} : ${error.message}`, "error", 5200); }
  }
  if (imported) { commit(); showToast(`${imported} piste${imported > 1 ? "s" : ""} importée${imported > 1 ? "s" : ""} et prête${imported > 1 ? "s" : ""} pour les joueurs.`, "success"); }
}

async function ensureTrackUrl(track) {
  if (track.url) return track.url;
  const legacyBlob = await getLegacyAsset(track.assetId);
  if (!legacyBlob) throw new Error(`Le fichier de « ${track.name} » est introuvable. Réimportez-le.`);
  const file = new File([legacyBlob], track.originalName || `${track.name}.mp3`, { type: track.type || legacyBlob.type || "audio/mpeg" });
  const result = await uploadRaw(`/api/media/upload?filename=${encodeURIComponent(file.name)}`, file);
  track.mediaId = result.mediaId; track.url = result.url; track.size = result.size;
  await deleteLegacyAsset(track.assetId).catch(() => {});
  delete track.assetId;
  commit();
  return track.url;
}

function channelState(channel) {
  return state.audio[channel];
}

function renderPlaylist() {
  const container = $("#playlist");
  $("#trackCount").textContent = `${state.tracks.length} piste${state.tracks.length === 1 ? "" : "s"}`;
  container.innerHTML = state.tracks.map((track) => {
    const playback = channelState(track.channel);
    const active = playback?.trackId === track.id;
    const playing = active && playback.playing;
    const sharedLabel = track.url ? "Disponible aux joueurs" : "Migration au prochain lancement";
    return `<div class="track-row ${playing ? "playing" : ""} ${active ? "active-track" : ""}" data-track-row="${escapeHtml(track.id)}">
      <button class="track-play" data-play-track="${escapeHtml(track.id)}" title="${playing ? "Mettre en pause" : "Lire et diffuser"}">${playing ? "Ⅱ" : "▶"}</button>
      <span class="track-copy"><strong>${escapeHtml(track.name)}</strong><small>${escapeHtml(track.originalName || "Fichier audio")} · ${sharedLabel}</small></span>
      <span class="track-channel">${track.channel === "ambience" ? "Ambiance" : "Musique"}</span>
      <button class="track-remove" data-remove-track="${escapeHtml(track.id)}" title="Supprimer">×</button>
    </div>`;
  }).join("") || `<div class="empty-state"><div class="empty-sigil">♫</div><strong>Aucune piste importée</strong><small>Ajoutez une musique ou une ambiance : elle sera stockée par la régie et diffusée aux joueurs connectés.</small></div>`;
  $$('[data-play-track]', container).forEach((button) => button.addEventListener("click", () => toggleTrack(button.dataset.playTrack)));
  $$('[data-remove-track]', container).forEach((button) => button.addEventListener("click", () => removeTrack(button.dataset.removeTrack)));
}

function renderAudioDock() {
  const musicTrack = state.tracks.find((track) => track.id === state.audio.music.trackId);
  const ambienceTrack = state.tracks.find((track) => track.id === state.audio.ambience.trackId);
  $("#musicNowPlaying").textContent = musicTrack?.name || "Aucune piste";
  $("#ambienceNowPlaying").textContent = ambienceTrack?.name || "Aucune ambiance";
  $("#mixerMusicTitle").textContent = musicTrack?.name || "Silence";
  $("#mixerAmbienceTitle").textContent = ambienceTrack?.name || "Silence";
  $("#musicPlayPause").textContent = state.audio.music.playing ? "Ⅱ" : "▶";
  $(".music-orb")?.classList.toggle("playing", Boolean(state.audio.music.playing));
  $(".ambience-orb")?.classList.toggle("playing", Boolean(state.audio.ambience.playing));
  $("#masterVolume").value = state.audio.masterVolume;
  $("#mixerMusicVolume").value = state.audio.musicVolume;
  $("#mixerAmbienceVolume").value = state.audio.ambienceVolume;
  $("#panicButton").textContent = state.audio.muted ? "Rétablir le son" : "Silence";
  $("#panicButton").classList.toggle("muted", Boolean(state.audio.muted));
  applyAudioVolumes();
  updateAudioProgress();
}

function updateAudioProgress() {
  const audio = audioElements.music;
  const ratio = audio.duration ? audio.currentTime / audio.duration : 0;
  $("#musicProgress").value = Math.round(clamp(ratio, 0, 1) * 1000);
  $("#musicElapsed").textContent = formatTime(audio.currentTime);
  $("#musicDuration").textContent = formatTime(audio.duration);
}

function updatePlaybackClock(channel, playing) {
  const audio = audioElements[channel];
  const playback = channelState(channel);
  playback.playing = playing;
  playback.position = Number(audio.currentTime || 0);
  playback.startedAt = playing ? Date.now() - playback.position * 1000 : null;
}

async function toggleTrack(trackId) {
  const track = state.tracks.find((entry) => entry.id === trackId);
  if (!track) return;
  const channel = track.channel;
  const audio = audioElements[channel];
  const playback = channelState(channel);
  if (playback.trackId === track.id && playback.playing) {
    audio.pause();
    updatePlaybackClock(channel, false);
    commit();
    return;
  }
  try {
    const url = await ensureTrackUrl(track);
    const isNewTrack = playback.trackId !== track.id || audio.dataset.trackId !== track.id;
    if (isNewTrack) {
      if (!audio.paused) await fadeAudio(audio, audio.volume, 0, 180);
      audio.pause();
      audio.src = url;
      audio.dataset.trackId = track.id;
      audio.currentTime = 0;
      playback.trackId = track.id;
      playback.position = 0;
    } else if (Number.isFinite(playback.position)) {
      audio.currentTime = playback.position;
    }
    applyAudioVolumes();
    await audio.play();
    updatePlaybackClock(channel, true);
    await fadeAudio(audio, 0, targetVolume(channel), 260);
    commit();
  } catch (error) {
    updatePlaybackClock(channel, false);
    commit();
    showToast(`Lecture impossible : ${error.message}`, "error", 5200);
  }
}

function targetVolume(channel) {
  if (state.audio.muted) return 0;
  const master = Number(state.audio.masterVolume) / 100;
  const channelValue = Number(channel === "music" ? state.audio.musicVolume : state.audio.ambienceVolume) / 100;
  return clamp(master * channelValue, 0, 1);
}

function applyAudioVolumes() {
  audioElements.music.volume = targetVolume("music");
  audioElements.ambience.volume = targetVolume("ambience");
}

function fadeAudio(audio, from, to, duration) {
  return new Promise((resolve) => {
    const started = performance.now();
    const step = (now) => {
      const progress = clamp((now - started) / Math.max(1, duration), 0, 1);
      audio.volume = clamp(from + (to - from) * progress, 0, 1);
      if (progress < 1) requestAnimationFrame(step); else resolve();
    };
    requestAnimationFrame(step);
  });
}

async function playAdjacentTrack(channel, offset) {
  const tracks = state.tracks.filter((track) => track.channel === channel);
  if (!tracks.length) return showToast(channel === "music" ? "Importez d’abord une musique." : "Importez d’abord une ambiance.", "warning");
  const currentId = channelState(channel).trackId;
  const currentIndex = tracks.findIndex((track) => track.id === currentId);
  const index = currentIndex < 0 ? 0 : (currentIndex + offset + tracks.length) % tracks.length;
  await toggleTrack(tracks[index].id);
}

async function removeTrack(id) {
  const track = state.tracks.find((entry) => entry.id === id);
  if (!track) return;
  if (!confirm(`Supprimer « ${track.name} » de la régie ?`)) return;
  const playback = channelState(track.channel);
  if (playback.trackId === id) {
    audioElements[track.channel].pause();
    audioElements[track.channel].removeAttribute("src");
    audioElements[track.channel].load();
    Object.assign(playback, { trackId: null, playing: false, position: 0, startedAt: null });
  }
  state.tracks = state.tracks.filter((entry) => entry.id !== id);
  if (track.mediaId) await api(`/api/media?mediaId=${encodeURIComponent(track.mediaId)}`, { method: "DELETE" }).catch((error) => showToast(error.message, "warning"));
  if (track.assetId) await deleteLegacyAsset(track.assetId).catch(() => {});
  commit();
}

function togglePanicMute() {
  state.audio.muted = !state.audio.muted;
  applyAudioVolumes();
  commit();
  showToast(state.audio.muted ? "Musique et ambiance coupées pour tout le monde." : "Niveaux de diffusion restaurés pour tout le monde.");
}

function renderSettings() {
  if (document.activeElement !== $("#settingsSessionName")) $("#settingsSessionName").value = state.session.name || "";
  if (document.activeElement !== $("#settingsGmName")) $("#settingsGmName").value = state.session.gmName || "";
  if (document.activeElement !== $("#settingsVoiceLabel")) $("#settingsVoiceLabel").value = state.session.voiceLabel || "";
}

function saveSettings() {
  state.session.name = $("#settingsSessionName").value.trim() || "Session de Xar Tsaroth";
  state.session.gmName = $("#settingsGmName").value.trim();
  state.session.voiceLabel = $("#settingsVoiceLabel").value.trim();
  commit();
  showToast("Réglages de session enregistrés.", "success");
}

function exportSession() {
  const exported = structuredClone(state);
  for (const player of exported.players) delete player.accessToken;
  exported.exportedAt = new Date().toISOString();
  exported.notice = "Les accès privés ont volontairement été régénérés lors de l’import.";
  const blob = new Blob([JSON.stringify(exported, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  downloadDataUrl(url, `xar-tsaroth-session-${timestampForFilename()}.json`);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function importSession(file) {
  if (!file) return;
  try {
    const imported = JSON.parse(await file.text());
    state = normalizeState(imported);
    for (const player of state.players) if (!player.accessToken) player.accessToken = newAccessToken();
    selectedPlayerId = state.players[0]?.id ?? null;
    selectedCharacterId = charactersForPlayer(selectedPlayerId)[0]?.id ?? state.characters[0]?.id ?? null;
    selectedTokenId = null;
    commit();
    showToast("Sauvegarde importée. Les liens privés manquants ont été régénérés.", "success");
  } catch (error) {
    showToast(`Sauvegarde invalide : ${error.message}`, "error");
  }
}

async function loadServiceStatus() {
  try {
    const response = await api("/api/health");
    services = { ...services, ...(response.services ?? {}) };
    applyOvhStorageStatus(response.ovhMediaCleanup);
    services.playerAccessProtected = Boolean(response.playerAccessProtected);
    lastServerRevision = Number(response.sessionRevision ?? lastServerRevision);
  } catch {
    showToast("Mode hors ligne : les fonctions locales restent disponibles.", "warning");
  }
  renderServices();
}

function playerAccessCode() {
  let code = new URLSearchParams(location.search).get("code") || sessionStorage.getItem("xar-player-access-code") || "";
  if (!code && services.playerAccessProtected) code = prompt("Code global de la vue joueurs à inclure dans le lien :")?.trim() || "";
  if (code) sessionStorage.setItem("xar-player-access-code", code);
  return code;
}

function buildPlayerViewUrl({ player = null } = {}) {
  const url = new URL("/player.html", location.origin);
  const code = playerAccessCode();
  if (code) url.searchParams.set("code", code);
  if (player) {
    url.searchParams.set("player", player.id);
    url.searchParams.set("token", player.accessToken);
  }
  return url;
}

function openGroupView() {
  window.open(buildPlayerViewUrl().href, "xar-tsaroth-group-view");
}

function updateChannelVolume(channel, value, { sync = false } = {}) {
  if (channel === "master") state.audio.masterVolume = Number(value);
  else state.audio[`${channel}Volume`] = Number(value);
  applyAudioVolumes();
  renderAudioDock();
  if (sync) commit({ render: false }); else persistLocalState();
}

function bindEvents() {
  bindTacticalMenus();
  $$('[data-tab-target]').forEach((button) => button.addEventListener("click", () => setActiveTab(button.dataset.tabTarget)));
  $("#closeDialog").addEventListener("click", closeDialog);
  $("#dialogBackdrop").addEventListener("click", (event) => { if (event.target === $("#dialogBackdrop")) closeDialog(); });
  $("#addSceneButton").addEventListener("click", addSceneDialog);
  $("#addPlayerButton").addEventListener("click", addPlayerDialog);
  $("#addCharacterButton").addEventListener("click", addCharacterDialog);
  $("#copyPlayerLink").addEventListener("click", copySelectedPlayerLink);
  $("#openGroupView").addEventListener("click", openGroupView);
  $("#openPlayerView").addEventListener("click", openGroupView);
  $("#toggleTacticalSyncButton").addEventListener("click", toggleTacticalSync);

  $("#playerPortraitInput").addEventListener("change", async (event) => {
    const character = selectedCharacter();
    if (character && event.target.files[0]) {
      try {
        character.portrait = await imageFileToDataUrl(event.target.files[0], 640, 640, 0.92);
        character._updatedAt = Date.now();
        syncTokensFromCharacter(character);
        commit();
      } catch (error) { showToast(error.message, "error"); }
    }
    event.target.value = "";
  });

  $("#importMapButton").addEventListener("click", () => $("#mapFileInput").click());
  $("#mapFileInput").addEventListener("change", (event) => { importMapFile(event.target.files[0]); event.target.value = ""; });
  $("#addTokenImageButton").addEventListener("click", () => $("#tokenFileInput").click());
  $("#tokenFileInput").addEventListener("change", (event) => { importTokenFile(event.target.files[0]); event.target.value = ""; });
  $("#tokenCustomImageInput").addEventListener("change", async (event) => {
    const token = state.map.tokens.find((entry) => entry.id === selectedTokenId);
    if (token && event.target.files[0]) {
      try { token.image = await imageFileToDataUrl(event.target.files[0], 640, 640, 0.92); token.followCharacter = false; token._updatedAt = Date.now(); commit(); }
      catch (error) { showToast(error.message, "error"); }
    }
    event.target.value = "";
  });
  $("#addBlankTokenButton").addEventListener("click", addBlankTokenDialog);
  $("#openTokenLibraryButton").addEventListener("click", openTokenLibraryDialog);
  $("#toggleGridButton").addEventListener("click", () => {
    state.map.grid = !state.map.grid;
    if (!state.map.grid) gridCalibrationMode = false;
    else snapAllTokensToGrid();
    commit();
  });
  $("#gridSize").addEventListener("input", (event) => { state.map.gridSize = Number(event.target.value); renderMap(); });
  $("#gridSize").addEventListener("change", () => { snapAllTokensToGrid(); commit(); });
  $("#gridOpacity").addEventListener("input", (event) => { state.map.gridOpacity = Number(event.target.value); renderMap(); });
  $("#gridOpacity").addEventListener("change", () => commit({ render: false }));
  [["#gridOffsetX", "gridOffsetX"], ["#gridOffsetY", "gridOffsetY"]].forEach(([selector, key]) => {
    $(selector).addEventListener("input", (event) => {
      state.map[key] = clamp(Number(event.target.value) || 0, -240, 240);
      applyMapViewport();
      renderGridCalibrationControls();
    });
    $(selector).addEventListener("change", () => { snapAllTokensToGrid(); commit(); });
  });
  $("#calibrateGridButton").addEventListener("click", () => setGridCalibrationMode(!gridCalibrationMode));
  $("#resetGridCalibration").addEventListener("click", () => {
    state.map.gridOffsetX = 0;
    state.map.gridOffsetY = 0;
    snapAllTokensToGrid();
    commit();
    showToast("Alignement de la grille remis à zéro.", "success");
  });
  $("#mapZoom").addEventListener("input", (event) => setMapZoom(Number(event.target.value) / 100));
  $("#mapZoom").addEventListener("change", () => commit({ render: false }));
  $("#zoomMapOut").addEventListener("click", () => { setMapZoom(state.map.zoom / 1.2); commit({ render: false }); });
  $("#zoomMapIn").addEventListener("click", () => { setMapZoom(state.map.zoom * 1.2); commit({ render: false }); });
  $("#resetMapView").addEventListener("click", resetMapView);
  $("#battlefield").addEventListener("wheel", (event) => {
    if (!event.ctrlKey && !event.metaKey) return;
    event.preventDefault();
    setMapZoom(state.map.zoom * (event.deltaY < 0 ? 1.08 : 0.92));
    clearTimeout($("#battlefield")._zoomCommitTimer);
    $("#battlefield")._zoomCommitTimer = setTimeout(() => commit({ render: false }), 220);
  }, { passive: false });
  $("#clearMapButton").addEventListener("click", () => {
    if (!confirm("Retirer la map et tous les tokens de ce combat ?")) return;
    Object.assign(state.map, { background: null, backgroundName: "", naturalWidth: 1600, naturalHeight: 900, zoom: 1, panX: 0, panY: 0, gridSize: DEFAULT_GRID_SIZE, gridOffsetX: 0, gridOffsetY: 0, tokens: [] });
    gridCalibrationMode = false;
    state.initiative = { ...createEmptyInitiativeState(), _updatedAt: Date.now() };
    selectedTokenId = null;
    commit();
  });
  $("#discordCaptureMessage").addEventListener("input", (event) => {
    state.discordCapture.message = event.target.value.slice(0, 1200);
    persistLocalState();
  });
  $("#discordCaptureMessage").addEventListener("change", () => commit({ render: false }));
  $("#discordIncludeCurrentTurn").addEventListener("change", (event) => {
    state.discordCapture.includeCurrentTurn = event.target.checked;
    commit();
  });
  $("#captureMapButton").addEventListener("click", captureMapToDiscord);
  bindMapPan();

  $("#calculatorExpression").addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    calculateExpressionFromInterface();
  });
  $$('[data-calculator-value]').forEach((button) => button.addEventListener("click", () => appendCalculatorValue(button.dataset.calculatorValue)));
  $("#calculatorClear").addEventListener("click", () => {
    $("#calculatorExpression").value = "";
    $("#calculatorResult").textContent = "0";
    $("#calculatorExact").textContent = "Entrez un calcul ou utilisez les touches.";
    $("#calculatorExpression").focus();
  });
  $("#calculatorBackspace").addEventListener("click", () => {
    const input = $("#calculatorExpression");
    input.value = input.value.slice(0, -1);
    input.focus();
  });
  $("#calculatorEquals").addEventListener("click", calculateExpressionFromInterface);
  $$('[data-percentage-mode]').forEach((button) => button.addEventListener("click", () => calculatePercentageFromInterface(button.dataset.percentageMode)));
  ["#percentageRate", "#percentageBase"].forEach((selector) => $(selector).addEventListener("input", () => calculatePercentageFromInterface("of")));
  calculatePercentageFromInterface("of");

  ["#rollAllInitiative", "#rollAllInitiativeCompact"].forEach((selector) => $(selector).addEventListener("click", rollAllInitiative));
  ["#nextTurnButton", "#nextTurnCompact"].forEach((selector) => $(selector).addEventListener("click", () => nextTurn(1)));
  ["#previousTurnButton", "#previousTurnCompact"].forEach((selector) => $(selector).addEventListener("click", () => nextTurn(-1)));
  $("#delayTurnButton").addEventListener("click", delayCurrentTurn);
  $("#newCombatButton").addEventListener("click", startCombat);
  $("#endCombatButton").addEventListener("click", endCombat);
  $("#rollDiceButton").addEventListener("click", () => performRoll($("#diceLabel").value.trim(), $("#diceFormula").value.trim(), $("#diceVisibility").value));
  $("#manageShortcuts").addEventListener("click", manageShortcutsDialog);
  $("#addCombatShortcut").addEventListener("click", manageShortcutsDialog);
  $("#addActionTimerButton").addEventListener("click", addActionTimerDialog);

  $("#imagePrompt").addEventListener("input", (event) => { state.forge.prompt = event.target.value; persistLocalState(); });
  $("#chatGptConversationSelect").addEventListener("change", (event) => { selectedBridgeConversationId = event.target.value; renderForge(); });
  $("#configureChatGptBridge").addEventListener("click", chatGptBridgeConfigDialog);
  $("#sendToChatGPTBridge").addEventListener("click", preparePromptInChatGpt);
  $("#openChatGPTButton").addEventListener("click", copyPromptAndOpenChatGPT);
  $("#pasteImageButton").addEventListener("click", pasteForgeImageFromClipboard);
  $("#importImageButton").addEventListener("click", () => $("#forgeFileInput").click());
  $("#forgeFileInput").addEventListener("change", (event) => { importForgeImage(event.target.files[0]); event.target.value = ""; });
  $("#referenceImageButton").addEventListener("click", () => $("#referenceFileInput").click());
  $("#referenceFileInput").addEventListener("change", (event) => { addReferenceImages([...event.target.files]); event.target.value = ""; });
  $("#sendImageDiscord").addEventListener("click", () => publishImage("discord"));
  $("#sendImageOvh").addEventListener("click", () => publishImage("ovh"));
  $("#sendImageBoth").addEventListener("click", () => publishImage("both"));
  $("#cleanupOvhMedia").addEventListener("click", () => {
    if (!confirm("Nettoyer les médias des anciens builds Xar Régie sur OVH ? Seuls les noms reconnus comme créés par la Régie seront supprimés ; le dossier www reste interdit.")) return;
    cleanupOvhMedia({ forceLegacy: true, manual: true });
  });
  $("#useImageAsMap").addEventListener("click", async () => { if (state.forge.imageDataUrl) await setMapBackground(state.forge.imageDataUrl, "Image de la forge"); setActiveTab("map"); });
  $("#downloadImage").addEventListener("click", () => downloadDataUrl(state.forge.imageDataUrl, currentImageFilename()));
  bindForgeDropZone();
  $$('[data-prompt-preset]').forEach((button) => button.addEventListener("click", () => {
    const presets = {
      cinematic: "Scène cinématique 16/9, cadrage large, action lisible et éclairage dramatique",
      portrait: "Portrait en pied d’un personnage de Xar Tsaroth, fond neutre atmosphérique, pose naturelle",
      battlemap: "Carte de combat vue strictement du dessus, chemins et obstacles lisibles, sans personnage, sans texte et sans grille visible"
    };
    const prefix = presets[button.dataset.promptPreset];
    $("#imagePrompt").value = `${prefix}${$("#imagePrompt").value ? `\n${$("#imagePrompt").value}` : ""}`;
    state.forge.prompt = $("#imagePrompt").value;
    persistLocalState();
  }));

  $("#importMusicButton").addEventListener("click", () => $("#musicFileInput").click());
  $("#importAmbienceButton").addEventListener("click", () => $("#ambienceFileInput").click());
  $("#musicFileInput").addEventListener("change", (event) => { importAudioFiles([...event.target.files], "music"); event.target.value = ""; });
  $("#ambienceFileInput").addEventListener("change", (event) => { importAudioFiles([...event.target.files], "ambience"); event.target.value = ""; });
  $("#musicPlayPause").addEventListener("click", async () => {
    const current = state.tracks.find((track) => track.id === state.audio.music.trackId) || state.tracks.find((track) => track.channel === "music");
    if (!current) return showToast("Importez d’abord une musique.", "warning");
    await toggleTrack(current.id);
  });
  $("#musicPrevious").addEventListener("click", () => playAdjacentTrack("music", -1));
  $("#musicNext").addEventListener("click", () => playAdjacentTrack("music", 1));
  $("#musicProgress").addEventListener("input", (event) => {
    const audio = audioElements.music;
    if (audio.duration) { audio.currentTime = (Number(event.target.value) / 1000) * audio.duration; updateAudioProgress(); }
  });
  $("#musicProgress").addEventListener("change", () => { updatePlaybackClock("music", state.audio.music.playing); commit({ render: false }); });
  $("#masterVolume").addEventListener("input", (event) => updateChannelVolume("master", event.target.value));
  $("#masterVolume").addEventListener("change", (event) => updateChannelVolume("master", event.target.value, { sync: true }));
  $("#mixerMusicVolume").addEventListener("input", (event) => updateChannelVolume("music", event.target.value));
  $("#mixerMusicVolume").addEventListener("change", (event) => updateChannelVolume("music", event.target.value, { sync: true }));
  $("#mixerAmbienceVolume").addEventListener("input", (event) => updateChannelVolume("ambience", event.target.value));
  $("#mixerAmbienceVolume").addEventListener("change", (event) => updateChannelVolume("ambience", event.target.value, { sync: true }));
  $("#panicButton").addEventListener("click", togglePanicMute);

  $("#saveSettingsButton").addEventListener("click", saveSettings);
  $("#exportSessionButton").addEventListener("click", exportSession);
  $("#importSessionButton").addEventListener("click", () => $("#sessionFileInput").click());
  $("#sessionFileInput").addEventListener("change", (event) => { importSession(event.target.files[0]); event.target.value = ""; });
  $("#resetSessionButton").addEventListener("click", () => {
    if (!confirm("Réinitialiser toute la session ? Cette action remplace les fiches, la carte et les liens joueurs.")) return;
    state = initialState();
    selectedPlayerId = state.players[0]?.id ?? null;
    selectedCharacterId = charactersForPlayer(selectedPlayerId)[0]?.id ?? null;
    selectedTokenId = null;
    commit();
  });
  $("#sceneRevealButton").addEventListener("click", async () => {
    const scene = activeScene();
    if (!scene) return showToast("Lancez d’abord une scène.", "warning");
    if (!services.discordJournal) return showToast("La scène est déjà visible en direct dans la vue joueurs. Le journal Discord n’est pas configuré.");
    try {
      await api("/api/discord/post", { method: "POST", body: { target: "journal", content: `✦ **${scene.name}**\n${scene.description}` } });
      showToast("Scène révélée dans le journal Discord.", "success");
    } catch (error) { showToast(error.message, "error"); }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      if (gridCalibrationMode) {
        setGridCalibrationMode(false);
        return;
      }
      if (closeTacticalMenus()) return;
      if (!$("#dialogBackdrop").classList.contains("hidden")) {
        closeDialog();
        return;
      }
    }
    if (event.target.matches("input, textarea, select") || !$("#dialogBackdrop").classList.contains("hidden")) return;
    if (event.key.toLowerCase() === "n") nextTurn(1);
    if (event.key.toLowerCase() === "p") nextTurn(-1);
    if (event.key.toLowerCase() === "i") rollAllInitiative();
    if (event.key.toLowerCase() === "m") togglePanicMute();
  });
  window.addEventListener("resize", () => requestAnimationFrame(applyMapViewport));
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") pollServerState({ force: true }); });
  window.addEventListener("beforeunload", () => { eventSource?.close(); for (const url of objectUrls.values()) URL.revokeObjectURL(url); });
}

async function restoreMjAudio() {
  let blocked = false;
  for (const channel of ["music", "ambience"]) {
    const playback = channelState(channel);
    const track = state.tracks.find((entry) => entry.id === playback.trackId);
    if (!track || !playback.playing) continue;
    try {
      const url = await ensureTrackUrl(track);
      const audio = audioElements[channel];
      audio.src = url;
      audio.dataset.trackId = track.id;
      const desired = playback.startedAt ? Math.max(0, (Date.now() - playback.startedAt) / 1000) : Number(playback.position || 0);
      audio.currentTime = desired;
      await audio.play();
    } catch {
      playback.position = playback.startedAt ? Math.max(0, (Date.now() - playback.startedAt) / 1000) : Number(playback.position || 0);
      playback.playing = false;
      playback.startedAt = null;
      blocked = true;
    }
  }
  applyAudioVolumes();
  if (blocked) {
    commit();
    showToast("Le navigateur a interrompu l’audio après le rechargement. Relancez la piste depuis le lecteur.", "warning", 5200);
  }
}

async function boot() {
  bindEvents();
  await Promise.all([loadServiceStatus(), refreshChatGptBridgeStatus({ rerender: false })]);
  try {
    const response = await api("/api/session/full");
    if (response.state) {
      state = normalizeState(response.state);
      lastServerRevision = Number(state.revision ?? 0);
      ensureSelections();
      persistLocalState();
    }
  } catch {
    // Au premier démarrage, l’état local initialise le serveur.
  }
  setActiveTab(currentTabName);
  renderAll();
  cleanupOvhMedia();
  scheduleServerSync();
  connectLiveSync();
  restoreMjAudio();
  setInterval(pollServerState, 8000);
  setInterval(() => refreshChatGptBridgeStatus(), 4000);
  setInterval(collectChatGptBridgeImports, 1600);
}

boot();
