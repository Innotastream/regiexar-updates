@echo off
setlocal
title Xar Tsaroth - Launcher de la Regie du Seuil
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Le socle applicatif 1.9 requiert encore Node.js 20 ou plus recent.
  echo Le futur installateur Tauri l'integrera sans installation manuelle.
  pause
  exit /b 1
)

for /f "delims=" %%v in ('node -p "process.versions.node.split('.')[0]"') do set "XAR_NODE_MAJOR=%%v"
if %XAR_NODE_MAJOR% LSS 20 (
  echo Votre version de Node.js est trop ancienne.
  echo Installez Node.js 20 LTS ou plus recent.
  pause
  exit /b 1
)

node installer.mjs
if errorlevel 1 pause
