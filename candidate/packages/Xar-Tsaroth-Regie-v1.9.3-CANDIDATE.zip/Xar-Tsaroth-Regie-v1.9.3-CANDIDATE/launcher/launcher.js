const token = document.documentElement.dataset.launcherToken;
const initialVersion = document.documentElement.dataset.appVersion;
const $ = (selector) => document.querySelector(selector);
const restartSessionKey = "xar-regie-expected-update";
let latestStatus = null;
let restartExpectedVersion = sessionStorage.getItem(restartSessionKey) || "";
let restartCompleted = false;

function setCard(cardId, tone, titleId, title, detailId, detail) {
  const card = $(cardId);
  card.classList.remove("good", "warning", "bad");
  if (tone) card.classList.add(tone);
  $(titleId).textContent = title;
  $(detailId).textContent = detail;
}

function setStage(selector, state) {
  const stage = $(selector);
  stage.classList.remove("complete", "current", "error");
  if (state) stage.classList.add(state);
}

function setProgress(value, detail) {
  const progress = Math.max(0, Math.min(100, Math.round(value)));
  $("#launchProgress").value = progress;
  $("#launchProgress").textContent = `${progress} %`;
  $("#progressValue").value = `${progress} %`;
  $("#progressValue").textContent = `${progress} %`;
  $("#progressDetail").textContent = detail;
}

function showRestartOverlay(message = "Le launcher installe le build contrôlé, conserve l’ancienne version puis revient automatiquement.") {
  $("#restartDetail").textContent = message;
  $("#restartOverlay").hidden = false;
  $("#launcherMain").setAttribute("aria-hidden", "true");
}

function hideRestartOverlay() {
  $("#restartOverlay").hidden = true;
  $("#launcherMain").removeAttribute("aria-hidden");
}

function render(status) {
  latestStatus = status;
  const application = status.application;
  const integrity = status.integrity;
  const update = status.update;
  const operation = status.operation;
  const operationBusy = ["downloading", "restarting"].includes(operation?.state);

  setCard(
    "#applicationCard",
    application.ready ? "good" : application.error ? "bad" : "warning",
    "#applicationStatus",
    application.ready ? "Régie prête" : application.error ? "Démarrage interrompu" : "Éveil en cours",
    "#applicationDetail",
    application.error || (application.ready ? "Le serveur local répond et la table peut être ouverte." : "Le launcher attend la réponse de l’application.")
  );

  const integrityIssueCount = (integrity.missing?.length || 0)
    + (integrity.modified?.length || 0)
    + (integrity.unexpected?.length || 0)
    + (integrity.invalidEntries?.length || 0);
  setCard(
    "#integrityCard",
    integrity.ok ? "good" : "bad",
    "#integrityStatus",
    integrity.ok ? "Sceau intact" : "Réparation requise",
    "#integrityDetail",
    integrity.ok
      ? `${integrity.checkedFiles} fichiers applicatifs correspondent au manifeste.`
      : integrity.reason === "manifest-missing"
        ? "Le manifeste d’intégrité est absent."
        : `${integrityIssueCount} fichier(s) absent(s), modifié(s), inattendu(s) ou invalide(s).`
  );

  const updateTone = update.state === "available" || update.state === "trust-missing" || update.state === "not-configured"
    ? "warning"
    : update.state === "error"
      ? "bad"
      : update.state === "current" || update.state === "ahead"
        ? "good"
        : "";
  const updateTitle = update.state === "available" ? `Version ${update.availableVersion} disponible`
    : update.state === "current" ? "Canal à jour"
      : update.state === "checking" ? "Vigie en cours"
        : update.state === "error" ? "Canal inaccessible"
          : update.state === "trust-missing" ? "Signature absente"
            : update.state === "ahead" ? "Version en avance"
              : "Canal à relier";
  setCard("#updateCard", updateTone, "#updateStatus", updateTitle, "#updateDetail", update.message);

  setStage("#stageApplication", application.ready ? "complete" : application.error ? "error" : "current");
  setStage("#stageIntegrity", integrity.ok ? "complete" : "error");
  setStage(
    "#stageUpdate",
    update.state === "checking" || update.state === "not-checked" ? "current"
      : update.state === "error" || update.state === "trust-missing" ? "error"
        : update.state === "available" || update.state === "not-configured" ? "current"
          : "complete"
  );

  if (operation?.state === "downloading") {
    setProgress(operation.progress, operation.message);
  } else if (operation?.state === "restarting") {
    setProgress(100, operation.message);
    showRestartOverlay();
  } else {
    const appProgress = application.ready ? 38 : application.error ? 18 : 24;
    const integrityProgress = integrity.ok || integrityIssueCount > 0 || integrity.reason ? 34 : 12;
    const updateResolved = !["not-checked", "checking"].includes(update.state);
    const updateProgress = updateResolved ? 28 : update.state === "checking" ? 15 : 4;
    const detail = application.error ? application.error
      : !integrity.ok ? "Le build doit être réparé avant utilisation."
        : update.state === "available" ? `La version ${update.availableVersion} attend votre accord.`
          : application.ready ? "Les sceaux locaux sont prêts. Vous pouvez entrer dans la Régie."
            : "Préparation de la table locale…";
    setProgress(appProgress + integrityProgress + updateProgress, detail);
  }

  const global = $("#globalStatus");
  global.classList.remove("good", "bad");
  let globalMessage = "Ouverture des sceaux…";
  if (application.error || !integrity.ok) {
    global.classList.add("bad");
    globalMessage = application.error ? "Le passage est interrompu" : "Le build demande une réparation";
  } else if (operationBusy) {
    globalMessage = operation?.message || "Mise à jour en cours…";
  } else if (update.state === "available") {
    globalMessage = `Mise à jour ${update.availableVersion} disponible`;
  } else if (application.ready) {
    global.classList.add("good");
    globalMessage = "Le passage est ouvert";
  }
  $("#globalStatusText").textContent = globalMessage;

  const repairAvailable = !integrity.ok && update.configured && ["available", "current"].includes(update.state);
  const updateAvailable = update.state === "available";
  const installButton = $("#installUpdate");
  installButton.hidden = !(repairAvailable || updateAvailable);
  installButton.disabled = operationBusy;
  if (repairAvailable) {
    $("#installUpdateLabel").textContent = "Réparer l’installation";
    $("#installUpdateDetail").textContent = "Retélécharger, contrôler et restaurer le build";
  } else if (updateAvailable) {
    $("#installUpdateLabel").textContent = `Installer la version ${update.availableVersion}`;
    $("#installUpdateDetail").textContent = "Mise à jour signée avec point de retour";
  }

  const canUseSignedPackage = update.configured && ["available", "current"].includes(update.state);
  $("#openApplication").disabled = !application.ready || !integrity.ok || operationBusy;
  $("#checkUpdate").disabled = operationBusy || update.state === "checking";
  $("#verifyIntegrity").disabled = operationBusy;
  $("#redownloadVersion").disabled = operationBusy || !canUseSignedPackage;
  $("#launcherMain").setAttribute("aria-busy", String(operationBusy));

  if (operation?.message && operationBusy) $("#operationMessage").textContent = operation.message;
  if (status.lastUpdate?.state === "installed" && status.lastUpdate.version === status.release.version) {
    $("#operationMessage").textContent = `Version ${status.lastUpdate.version} installée avec succès. Un point de retour a été conservé.`;
  } else if (status.lastUpdate?.state === "error") {
    $("#operationMessage").textContent = status.lastUpdate.message;
  }

  if (restartExpectedVersion && status.release.version === restartExpectedVersion && status.lastUpdate?.state === "installed") {
    showRestartOverlay(`Version ${restartExpectedVersion} installée. Réouverture du Seuil…`);
    if (!restartCompleted) {
      restartCompleted = true;
      sessionStorage.removeItem(restartSessionKey);
      setTimeout(() => location.reload(), 1_200);
    }
  } else if (restartExpectedVersion && status.lastUpdate?.state === "error") {
    restartExpectedVersion = "";
    sessionStorage.removeItem(restartSessionKey);
    hideRestartOverlay();
  }
}

async function request(path, { operation = "" } = {}) {
  $("#operationMessage").textContent = operation;
  const response = await fetch(path, {
    method: "POST",
    headers: { "X-Xar-Launcher-Token": token }
  });
  const payload = await response.json();
  if (!response.ok || !payload.ok) throw new Error(payload.error || "Commande impossible.");
  render(payload);
  return payload;
}

async function refresh() {
  try {
    const response = await fetch("/api/status", { cache: "no-store" });
    if (!response.ok) throw new Error(`statut ${response.status}`);
    render(await response.json());
  } catch (error) {
    if (restartExpectedVersion || latestStatus?.operation?.state === "restarting") {
      showRestartOverlay("Remplacement atomique en cours… Le launcher va revenir automatiquement.");
    } else {
      $("#operationMessage").textContent = `Launcher inaccessible : ${error.message}`;
    }
  }
}

$("#openApplication").addEventListener("click", async () => {
  try {
    await request("/api/open", { operation: "Ouverture de la table…" });
    $("#operationMessage").textContent = "La Régie a été ouverte dans votre navigateur.";
  } catch (error) { $("#operationMessage").textContent = error.message; }
});

$("#checkUpdate").addEventListener("click", async () => {
  try {
    await request("/api/check-update", { operation: "Lecture du canal de mise à jour signé…" });
    $("#operationMessage").textContent = "Vérification du canal terminée.";
  } catch (error) { $("#operationMessage").textContent = error.message; }
});

$("#verifyIntegrity").addEventListener("click", async () => {
  try {
    const payload = await request("/api/verify-integrity", { operation: "Contrôle de tous les fichiers applicatifs…" });
    $("#operationMessage").textContent = payload.integrity.ok
      ? "Intégrité confirmée : aucun fichier applicatif n’a été altéré."
      : payload.update.configured
        ? "Une anomalie a été trouvée. Utilisez « Réparer l’installation » pour restaurer un build signé."
        : "Une anomalie a été trouvée. Le futur canal signé devra être relié pour permettre la réparation automatique.";
  } catch (error) { $("#operationMessage").textContent = error.message; }
});

$("#redownloadVersion").addEventListener("click", async () => {
  try {
    const payload = await request("/api/redownload", { operation: "Téléchargement et contrôle cryptographique du ZIP…" });
    $("#operationMessage").textContent = `ZIP signé vérifié et conservé : ${payload.downloadedPackage.filename}`;
  } catch (error) { $("#operationMessage").textContent = error.message; }
});

$("#installUpdate").addEventListener("click", async () => {
  const expectedVersion = latestStatus?.update?.availableVersion || latestStatus?.release?.version || initialVersion;
  restartExpectedVersion = expectedVersion;
  sessionStorage.setItem(restartSessionKey, expectedVersion);
  try {
    await request("/api/install-update", { operation: "Préparation de la mise à jour signée…" });
    showRestartOverlay();
  } catch (error) {
    restartExpectedVersion = "";
    sessionStorage.removeItem(restartSessionKey);
    hideRestartOverlay();
    $("#operationMessage").textContent = error.message;
  }
});

if (restartExpectedVersion) showRestartOverlay("Reconnexion au launcher mis à jour…");
refresh();
setInterval(refresh, 1_500);
