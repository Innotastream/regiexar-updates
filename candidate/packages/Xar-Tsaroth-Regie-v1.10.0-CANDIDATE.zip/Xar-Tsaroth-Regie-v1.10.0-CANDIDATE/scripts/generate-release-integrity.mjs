import path from "node:path";
import { fileURLToPath } from "node:url";
import { writeIntegrityManifest } from "../launcher-core.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const manifest = writeIntegrityManifest(root);
console.log(`Manifeste d’intégrité ${manifest.applicationVersion} généré pour ${manifest.files.length} fichiers.`);
