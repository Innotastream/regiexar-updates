export function initiativeSortValue(token) {
  const value = Number(token?.initiative);
  return token?.initiative === null || token?.initiative === undefined || token?.initiative === "" || !Number.isFinite(value)
    ? Number.POSITIVE_INFINITY
    : value;
}

export function sanitizeInitiativeOrder(order, tokens = []) {
  const validIds = new Set(tokens.map((token) => token.id));
  return [...new Set(Array.isArray(order) ? order : [])].filter((id) => validIds.has(id));
}

export function sortInitiativeTokenIds(order, tokens = []) {
  const tokensById = new Map(tokens.map((token) => [token.id, token]));
  return sanitizeInitiativeOrder(order, tokens).sort((leftId, rightId) => {
    const left = tokensById.get(leftId);
    const right = tokensById.get(rightId);
    return initiativeSortValue(left) - initiativeSortValue(right)
      || String(left?.name || "").localeCompare(String(right?.name || ""), "fr");
  });
}

export function normalizeInitiativeState(rawInitiative, tokens = [], {
  inferLegacyActive = false,
  clearLegacyInactiveRoster = false
} = {}) {
  const rawOrder = sanitizeInitiativeOrder(rawInitiative?.order, tokens);
  const active = rawInitiative?.active === true
    || (inferLegacyActive && rawInitiative?.active === undefined && rawOrder.length > 0);
  const order = clearLegacyInactiveRoster && !active ? [] : rawOrder;
  const currentIndex = order.length
    ? Math.min(Math.max(0, Number(rawInitiative?.currentIndex) || 0), order.length - 1)
    : 0;
  const turnsStarted = active && (
    rawInitiative?.turnsStarted === true
    || Number(rawInitiative?.round) > 1
    || Number(rawInitiative?.currentIndex) > 0
  );
  return {
    order,
    currentIndex,
    round: Math.max(1, Number(rawInitiative?.round) || 1),
    active,
    turnsStarted,
    _updatedAt: Number(rawInitiative?._updatedAt ?? 0)
  };
}
