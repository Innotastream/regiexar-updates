export const DEFAULT_GRID_SIZE = 50;
export const DEFAULT_TOKEN_SIZE = 30;

export const TOKEN_SIZE_PRESETS = Object.freeze([
  Object.freeze({ id: "small", label: "Petite", size: 20 }),
  Object.freeze({ id: "normal", label: "Normale", size: 30 }),
  Object.freeze({ id: "large", label: "Grosse", size: 60 }),
  Object.freeze({ id: "huge", label: "Très grosse", size: 90 })
]);

export const DEFAULT_DISCORD_CAPTURE = Object.freeze({
  message: "Même cadrage, même zoom, même grille et mêmes tokens que la vue MJ publique.",
  includeCurrentTurn: true
});

export const BATTLEMAP_SCALE_GUIDE = [
  "Contraintes d’échelle pour la carte de combat : prévoir une grille virtuelle carrée de 50 px par case dans l’image finale.",
  "Une porte simple occupe 1 case (50 px) et une porte double exactement 2 cases (100 px) de largeur.",
  "Ne dessiner aucune grille, aucune ligne de case et aucun repère de quadrillage : la grille sera ajoutée et étalonnée dans l’application."
].join(" ");

export function isBattlemapPrompt(value = "") {
  return /(?:carte\s+(?:de\s+)?combat|battle\s*map|battlemap|vue\s+strictement\s+du\s+dessus)/i.test(String(value));
}

export function withBattlemapScaleGuide(value = "") {
  const prompt = String(value).trim();
  if (!isBattlemapPrompt(prompt) || prompt.includes(BATTLEMAP_SCALE_GUIDE)) return prompt;
  return `${prompt}\n\n${BATTLEMAP_SCALE_GUIDE}`;
}

export function closestTokenSizePreset(size) {
  const numericSize = Number(size);
  return TOKEN_SIZE_PRESETS.find((preset) => preset.size === numericSize) ?? null;
}
