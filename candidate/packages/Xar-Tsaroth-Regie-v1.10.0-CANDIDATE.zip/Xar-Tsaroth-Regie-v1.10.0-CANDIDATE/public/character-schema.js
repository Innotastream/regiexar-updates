export const CHARACTER_SCHEMA_ID = "xar-tsaroth.character-sheet";
export const CHARACTER_SCHEMA_VERSION = 1;

export class UnsupportedCharacterSchemaVersionError extends Error {
  constructor(version) {
    super(`Cette fiche provient d’une version plus récente de la Régie. Elle a été conservée intacte : mettez l’application à jour pour l’ouvrir (format ${version}, format pris en charge ${CHARACTER_SCHEMA_VERSION}).`);
    this.name = "UnsupportedCharacterSchemaVersionError";
    this.version = version;
  }
}

function plainObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function finiteNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function clone(value) {
  return value === undefined ? undefined : structuredClone(value);
}

function migrateVersion0To1(source, ownerPlayerId) {
  const resources = plainObject(source.resources);
  const fatigue = plainObject(source.fatigue);
  const secret = plainObject(source.secret);
  const next = {
    ...source,
    characterSchema: CHARACTER_SCHEMA_ID,
    characterSchemaVersion: 1,
    ownerPlayerId: source.ownerPlayerId ?? ownerPlayerId ?? null,
    resources: {
      hp: finiteNumber(resources.hp ?? source.hp),
      maxHp: finiteNumber(resources.maxHp ?? source.maxHp),
      mana: finiteNumber(resources.mana ?? source.mana),
      maxMana: finiteNumber(resources.maxMana ?? source.maxMana)
    },
    stats: { ...plainObject(source.stats) },
    fatigue: {
      current: finiteNumber(fatigue.current ?? source.fatigueCurrent),
      max: finiteNumber(fatigue.max ?? source.fatigueMax, 100)
    },
    secret: {
      mentalResistance: finiteNumber(secret.mentalResistance ?? source.mentalResistance),
      mentalResistanceMax: finiteNumber(secret.mentalResistanceMax ?? source.mentalResistanceMax, 100),
      notes: String(secret.notes ?? source.privateNotes ?? "")
    },
    conditions: Array.isArray(source.conditions) ? [...source.conditions] : [],
    shortcuts: Array.isArray(source.shortcuts) ? [...source.shortcuts] : []
  };

  for (const legacyKey of [
    "hp", "maxHp", "mana", "maxMana", "fatigueCurrent", "fatigueMax",
    "mentalResistance", "mentalResistanceMax", "privateNotes"
  ]) delete next[legacyKey];
  return next;
}

const migrations = new Map([
  [0, migrateVersion0To1]
]);

export function characterSchemaVersion(value) {
  const parsed = Number(value?.characterSchemaVersion ?? 0);
  return Number.isInteger(parsed) && parsed >= 0 ? parsed : 0;
}

export function migrateCharacterSheet(value, { ownerPlayerId = null } = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError("Une fiche de personnage doit être un objet JSON.");
  }

  const fromVersion = characterSchemaVersion(value);
  if (fromVersion > CHARACTER_SCHEMA_VERSION) {
    throw new UnsupportedCharacterSchemaVersionError(fromVersion);
  }

  let currentVersion = fromVersion;
  let character = clone(value);
  const appliedMigrations = [];
  while (currentVersion < CHARACTER_SCHEMA_VERSION) {
    const migration = migrations.get(currentVersion);
    if (!migration) throw new Error(`Migration de fiche manquante pour le schéma ${currentVersion}.`);
    character = migration(character, ownerPlayerId);
    appliedMigrations.push(`${currentVersion}->${currentVersion + 1}`);
    currentVersion += 1;
  }

  character.characterSchema = CHARACTER_SCHEMA_ID;
  character.characterSchemaVersion = CHARACTER_SCHEMA_VERSION;
  if (ownerPlayerId !== null) character.ownerPlayerId = ownerPlayerId;
  return {
    character,
    fromVersion,
    toVersion: CHARACTER_SCHEMA_VERSION,
    appliedMigrations,
    changed: appliedMigrations.length > 0 || value.characterSchema !== CHARACTER_SCHEMA_ID
  };
}
