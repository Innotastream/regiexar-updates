import { DEFAULT_GRID_SIZE } from "./combat-standards.js";

export function cloneStateValue(value) {
  if (typeof structuredClone === "function") return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

export function createEmptyMapState() {
  return {
    background: null,
    backgroundName: "",
    naturalWidth: 1600,
    naturalHeight: 900,
    zoom: 1,
    panX: 0,
    panY: 0,
    grid: true,
    gridSize: DEFAULT_GRID_SIZE,
    gridOffsetX: 0,
    gridOffsetY: 0,
    gridOpacity: 28,
    tokens: []
  };
}

export function createEmptyInitiativeState() {
  return { order: [], currentIndex: 0, round: 1, active: false, turnsStarted: false, _updatedAt: 0 };
}

export function createCombatSnapshot(map = createEmptyMapState(), initiative = createEmptyInitiativeState()) {
  return {
    map: cloneStateValue(map),
    initiative: cloneStateValue(initiative)
  };
}

export function prepareSceneCombats(scenes, {
  activeSceneId = null,
  currentMap = createEmptyMapState(),
  currentInitiative = createEmptyInitiativeState(),
  migrateLegacyCombat = false
} = {}) {
  const entries = Array.isArray(scenes) ? scenes : [];
  const legacyTargetId = activeSceneId || entries[0]?.id || null;
  return entries.map((scene) => {
    let combat;
    if (scene?.combat?.map && scene?.combat?.initiative) {
      combat = createCombatSnapshot(scene.combat.map, scene.combat.initiative);
    } else if (migrateLegacyCombat && scene?.id === legacyTargetId) {
      combat = createCombatSnapshot(currentMap, currentInitiative);
    } else {
      combat = createCombatSnapshot();
    }
    return { ...scene, combat };
  });
}

export function switchSceneCombat({ scenes, activeSceneId, nextSceneId, map, initiative }) {
  const nextScenes = cloneStateValue(Array.isArray(scenes) ? scenes : []);
  const current = nextScenes.find((scene) => scene.id === activeSceneId);
  if (current) current.combat = createCombatSnapshot(map, initiative);
  const next = nextScenes.find((scene) => scene.id === nextSceneId);
  if (!next) return null;
  next.combat = next.combat?.map && next.combat?.initiative
    ? createCombatSnapshot(next.combat.map, next.combat.initiative)
    : createCombatSnapshot();
  return {
    scenes: nextScenes,
    map: cloneStateValue(next.combat.map),
    initiative: cloneStateValue(next.combat.initiative)
  };
}
