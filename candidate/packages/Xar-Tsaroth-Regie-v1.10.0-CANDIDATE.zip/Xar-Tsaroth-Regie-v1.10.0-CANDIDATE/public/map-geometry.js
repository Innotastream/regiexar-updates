import { DEFAULT_GRID_SIZE, DEFAULT_TOKEN_SIZE } from "./combat-standards.js";

export const clamp = (value, minimum, maximum) => Math.min(maximum, Math.max(minimum, value));

export function normalizedMap(map = {}) {
  return {
    naturalWidth: Math.max(1, Number(map.naturalWidth) || 1600),
    naturalHeight: Math.max(1, Number(map.naturalHeight) || 900),
    zoom: clamp(Number(map.zoom) || 1, 0.25, 4.5),
    panX: clamp(Number(map.panX) || 0, -150, 150),
    panY: clamp(Number(map.panY) || 0, -150, 150),
    gridSize: clamp(Number(map.gridSize) || DEFAULT_GRID_SIZE, 12, 240),
    gridOffsetX: clamp(Number(map.gridOffsetX) || 0, -240, 240),
    gridOffsetY: clamp(Number(map.gridOffsetY) || 0, -240, 240)
  };
}

export function computeMapGeometry(viewportWidth, viewportHeight, map = {}) {
  const width = Math.max(1, Number(viewportWidth) || 1);
  const height = Math.max(1, Number(viewportHeight) || 1);
  const normalized = normalizedMap(map);
  const aspect = normalized.naturalWidth / normalized.naturalHeight;
  const viewportAspect = width / height;
  const fitWidth = viewportAspect > aspect ? height * aspect : width;
  const fitHeight = viewportAspect > aspect ? height : width / aspect;
  const centerX = width / 2 + (normalized.panX / 100) * fitWidth;
  const centerY = height / 2 + (normalized.panY / 100) * fitHeight;
  const worldWidth = fitWidth * normalized.zoom;
  const worldHeight = fitHeight * normalized.zoom;
  const gridBaseSize = (normalized.gridSize / normalized.naturalWidth) * fitWidth;
  const gridOffsetBaseX = (normalized.gridOffsetX / normalized.naturalWidth) * fitWidth;
  const gridOffsetBaseY = (normalized.gridOffsetY / normalized.naturalHeight) * fitHeight;
  return {
    ...normalized,
    viewportWidth: width,
    viewportHeight: height,
    fitWidth,
    fitHeight,
    centerX,
    centerY,
    worldWidth,
    worldHeight,
    gridBaseSize,
    gridScreenSize: gridBaseSize * normalized.zoom,
    gridOffsetBaseX,
    gridOffsetBaseY,
    gridOffsetScreenX: gridOffsetBaseX * normalized.zoom,
    gridOffsetScreenY: gridOffsetBaseY * normalized.zoom,
    left: centerX - worldWidth / 2,
    top: centerY - worldHeight / 2
  };
}

export function mapPointFromClient(clientX, clientY, worldRect, map = {}) {
  const normalized = normalizedMap(map);
  const width = Math.max(1, worldRect.width);
  const height = Math.max(1, worldRect.height);
  const x = clamp((clientX - worldRect.left) / width, 0, 1) * 100;
  const y = clamp((clientY - worldRect.top) / height, 0, 1) * 100;
  return snapMapPercentPoint(x, y, map);
}

function snapNaturalCoordinate(value, extent, gridSize, offset) {
  const candidateIndex = Math.floor((value - offset) / gridSize);
  const minimumIndex = Math.ceil((-offset - gridSize / 2) / gridSize);
  const maximumIndex = Math.floor((extent - offset - gridSize / 2) / gridSize);
  if (minimumIndex > maximumIndex) return extent / 2;
  const index = clamp(candidateIndex, minimumIndex, maximumIndex);
  return offset + index * gridSize + gridSize / 2;
}

export function snapMapPercentPoint(xPercent, yPercent, map = {}) {
  const normalized = normalizedMap(map);
  const safeX = Number.isFinite(Number(xPercent)) ? clamp(Number(xPercent), 0, 100) : 50;
  const safeY = Number.isFinite(Number(yPercent)) ? clamp(Number(yPercent), 0, 100) : 50;
  if (!map.grid) return { x: Number(safeX.toFixed(3)), y: Number(safeY.toFixed(3)) };
  const naturalX = snapNaturalCoordinate((safeX / 100) * normalized.naturalWidth, normalized.naturalWidth, normalized.gridSize, normalized.gridOffsetX);
  const naturalY = snapNaturalCoordinate((safeY / 100) * normalized.naturalHeight, normalized.naturalHeight, normalized.gridSize, normalized.gridOffsetY);
  return {
    x: Number(((naturalX / normalized.naturalWidth) * 100).toFixed(3)),
    y: Number(((naturalY / normalized.naturalHeight) * 100).toFixed(3))
  };
}

export function mapTokenScreenPosition(token, geometry) {
  return {
    x: geometry.left + (Number(token.x) / 100) * geometry.worldWidth,
    y: geometry.top + (Number(token.y) / 100) * geometry.worldHeight,
    size: (Number(token.size) || DEFAULT_TOKEN_SIZE) * geometry.zoom
  };
}

export function mapPanFromDrag(map, deltaX, deltaY, fitWidth, fitHeight) {
  const normalized = normalizedMap(map);
  const width = Math.max(1, Number(fitWidth) || 1);
  const height = Math.max(1, Number(fitHeight) || 1);
  return {
    panX: clamp(normalized.panX + (Number(deltaX) / width) * 100, -150, 150),
    panY: clamp(normalized.panY + (Number(deltaY) / height) * 100, -150, 150)
  };
}
