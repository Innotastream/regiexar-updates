const HALF_ROUNDING_EPSILON = Number.EPSILON * 16;

export function roundCombatResult(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) throw new Error("Le résultat n’est pas un nombre fini.");
  const tolerance = Math.max(1, Math.abs(number)) * HALF_ROUNDING_EPSILON;
  return Math.floor(number + 0.5 + tolerance);
}

export function percentageOf(percent, base) {
  const rate = Number(percent);
  const amount = Number(base);
  if (!Number.isFinite(rate) || !Number.isFinite(amount)) throw new Error("Indiquez un pourcentage et un nombre valides.");
  const exact = (rate / 100) * amount;
  return { exact, rounded: roundCombatResult(exact) };
}

export function applyPercentage(percent, base, mode = "add") {
  const rate = Number(percent);
  const amount = Number(base);
  if (!Number.isFinite(rate) || !Number.isFinite(amount)) throw new Error("Indiquez un pourcentage et un nombre valides.");
  if (!new Set(["add", "subtract"]).has(mode)) throw new Error("Opération de pourcentage inconnue.");
  const delta = (rate / 100) * amount;
  const exact = mode === "add" ? amount + delta : amount - delta;
  return { exact, rounded: roundCombatResult(exact), delta };
}

function normalizeExpression(value) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replaceAll(",", ".")
    .replaceAll("×", "*")
    .replaceAll("÷", "/")
    .replaceAll("−", "-")
    .replace(/\bde\b/g, "*")
    .replace(/(?<=\d|\))x(?=\d|\()/g, "*");
}

class ExpressionParser {
  constructor(source) {
    this.source = source;
    this.index = 0;
  }

  skipSpaces() {
    while (/\s/.test(this.source[this.index] ?? "")) this.index += 1;
  }

  consume(character) {
    this.skipSpaces();
    if (this.source[this.index] !== character) return false;
    this.index += 1;
    return true;
  }

  parse() {
    if (!this.source.trim()) throw new Error("Entrez un calcul.");
    const result = this.parseExpression();
    this.skipSpaces();
    if (this.index !== this.source.length) throw new Error(`Caractère inattendu : ${this.source[this.index]}`);
    if (!Number.isFinite(result)) throw new Error("Ce calcul ne produit pas un résultat fini.");
    return result;
  }

  parseExpression() {
    let result = this.parseTerm();
    while (true) {
      if (this.consume("+")) result += this.parseTerm();
      else if (this.consume("-")) result -= this.parseTerm();
      else return result;
    }
  }

  parseTerm() {
    let result = this.parseUnary();
    while (true) {
      if (this.consume("*")) result *= this.parseUnary();
      else if (this.consume("/")) {
        const divisor = this.parseUnary();
        if (Math.abs(divisor) < Number.EPSILON) throw new Error("Division par zéro impossible.");
        result /= divisor;
      } else return result;
    }
  }

  parseUnary() {
    if (this.consume("+")) return this.parseUnary();
    if (this.consume("-")) return -this.parseUnary();
    return this.parsePostfix();
  }

  parsePostfix() {
    let result = this.parsePrimary();
    while (this.consume("%")) result /= 100;
    return result;
  }

  parsePrimary() {
    if (this.consume("(")) {
      const result = this.parseExpression();
      if (!this.consume(")")) throw new Error("Il manque une parenthèse fermante.");
      return result;
    }
    this.skipSpaces();
    const match = /^(?:\d+(?:\.\d*)?|\.\d+)/.exec(this.source.slice(this.index));
    if (!match) throw new Error("Nombre ou parenthèse attendu.");
    this.index += match[0].length;
    return Number(match[0]);
  }
}

export function evaluateTacticalExpression(expression) {
  const exact = new ExpressionParser(normalizeExpression(expression)).parse();
  return { exact, rounded: roundCombatResult(exact) };
}
