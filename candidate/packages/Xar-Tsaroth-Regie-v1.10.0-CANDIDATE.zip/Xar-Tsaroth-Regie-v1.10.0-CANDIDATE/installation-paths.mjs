import os from "node:os";
import path from "node:path";

export function defaultPrivateRoot(environment = process.env, platform = process.platform, homeDirectory = os.homedir()) {
  if (environment.XAR_PRIVATE_ROOT) return path.resolve(environment.XAR_PRIVATE_ROOT);
  if (platform === "win32") {
    return path.join(environment.LOCALAPPDATA || environment.APPDATA || homeDirectory, "XarTsarothRegie");
  }
  if (platform === "darwin") return path.join(homeDirectory, "Library", "Application Support", "XarTsarothRegie");
  return path.join(environment.XDG_CONFIG_HOME || path.join(homeDirectory, ".config"), "xar-tsaroth-regie");
}

export function defaultInstallationRoot(environment = process.env, platform = process.platform, homeDirectory = os.homedir()) {
  if (environment.XAR_INSTALL_ROOT) return path.resolve(environment.XAR_INSTALL_ROOT);
  if (platform === "win32") {
    return path.join(environment.LOCALAPPDATA || homeDirectory, "Programs", "XarTsarothRegie");
  }
  if (platform === "darwin") return path.join(homeDirectory, "Applications", "Xar Tsaroth Regie");
  return path.join(environment.XDG_DATA_HOME || path.join(homeDirectory, ".local", "share"), "xar-tsaroth-regie", "app");
}

export function pathsReferToSameLocation(left, right, platform = process.platform) {
  const normalizedLeft = path.resolve(left);
  const normalizedRight = path.resolve(right);
  return platform === "win32"
    ? normalizedLeft.toLocaleLowerCase("fr") === normalizedRight.toLocaleLowerCase("fr")
    : normalizedLeft === normalizedRight;
}
