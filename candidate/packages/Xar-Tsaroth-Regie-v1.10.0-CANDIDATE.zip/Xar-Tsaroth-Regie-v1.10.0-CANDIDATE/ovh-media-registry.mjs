import path from "node:path";
import { randomUUID } from "node:crypto";

export const OVH_MANIFEST_FILENAME = "_xar-regie-media-v1.json";
export const OVH_MANIFEST_SCHEMA = 1;

const managedRemotePattern = /^xar-regie-v1-[a-f0-9]{32}\.(?:webp|png|jpe?g|gif)$/i;
const legacyRemotePattern = /^[a-z0-9](?:[a-z0-9-]{0,95})-\d{12}\.(?:webp|png|jpe?g)$/i;

function cleanText(value, maximum = 160) {
  return String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, "").slice(0, maximum);
}

export function isManagedRemoteName(value) {
  return managedRemotePattern.test(String(value ?? ""));
}

export function isLegacyRegieRemoteName(value) {
  const name = String(value ?? "");
  return !isManagedRemoteName(name) && legacyRemotePattern.test(name);
}

export function managedRemoteName(originalName, mimeType) {
  const requested = path.extname(String(originalName ?? "")).toLowerCase();
  const byMime = {
    "image/webp": ".webp",
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/gif": ".gif"
  };
  const extension = byMime[mimeType] ?? ([".webp", ".png", ".jpg", ".jpeg", ".gif"].includes(requested) ? requested : ".webp");
  return `xar-regie-v1-${randomUUID().replaceAll("-", "")}${extension}`;
}

export function emptyOvhManifest() {
  return {
    schemaVersion: OVH_MANIFEST_SCHEMA,
    files: [],
    legacySweepAt: null,
    legacySweepBuildVersion: null,
    lastCleanupAt: null,
    updatedAt: new Date(0).toISOString()
  };
}

export function normalizeOvhManifest(candidate) {
  if (!candidate || typeof candidate !== "object" || Number(candidate.schemaVersion) !== OVH_MANIFEST_SCHEMA) {
    throw new Error("Le registre distant Xar Régie est invalide ou incompatible.");
  }
  const byName = new Map();
  for (const raw of Array.isArray(candidate.files) ? candidate.files : []) {
    const remoteName = cleanText(raw?.remoteName, 120);
    if (!isManagedRemoteName(remoteName)) continue;
    byName.set(remoteName, {
      id: cleanText(raw?.id, 80) || remoteName,
      remoteName,
      originalName: cleanText(raw?.originalName, 160),
      contentType: cleanText(raw?.contentType, 80),
      size: Math.max(0, Number(raw?.size) || 0),
      buildVersion: cleanText(raw?.buildVersion, 40),
      createdAt: cleanText(raw?.createdAt, 40),
      keepAcrossBuilds: Boolean(raw?.keepAcrossBuilds)
    });
  }
  return {
    schemaVersion: OVH_MANIFEST_SCHEMA,
    files: [...byName.values()],
    legacySweepAt: cleanText(candidate.legacySweepAt, 40) || null,
    legacySweepBuildVersion: cleanText(candidate.legacySweepBuildVersion, 40) || null,
    lastCleanupAt: cleanText(candidate.lastCleanupAt, 40) || null,
    updatedAt: cleanText(candidate.updatedAt, 40) || new Date(0).toISOString()
  };
}

export function cleanupPlan(manifest, currentBuildVersion) {
  const normalized = normalizeOvhManifest(manifest);
  const obsolete = normalized.files.filter((entry) => entry.buildVersion !== currentBuildVersion && !entry.keepAcrossBuilds);
  const retained = normalized.files.filter((entry) => !obsolete.includes(entry));
  return { obsolete, retained };
}

export function appendManagedFile(manifest, entry) {
  const normalized = normalizeOvhManifest(manifest);
  if (!isManagedRemoteName(entry?.remoteName)) throw new Error("Nom de média distant non géré.");
  normalized.files = normalized.files.filter((item) => item.remoteName !== entry.remoteName);
  normalized.files.push({
    id: cleanText(entry.id, 80) || entry.remoteName,
    remoteName: entry.remoteName,
    originalName: cleanText(entry.originalName, 160),
    contentType: cleanText(entry.contentType, 80),
    size: Math.max(0, Number(entry.size) || 0),
    buildVersion: cleanText(entry.buildVersion, 40),
    createdAt: cleanText(entry.createdAt, 40),
    keepAcrossBuilds: Boolean(entry.keepAcrossBuilds)
  });
  normalized.updatedAt = new Date().toISOString();
  return normalized;
}
