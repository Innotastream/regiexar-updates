PONT NAVIGATEUR CHATGPT — XAR TSAROTH

1. Lancez d’abord la Régie du Seuil.
2. Dans la Forge d’images, cliquez sur « Configurer » et renseignez les deux conversations ChatGPT ciblées.
3. Ouvrez chrome://extensions (Chrome) ou edge://extensions (Edge).
4. Activez le mode développeur.
5. Cliquez sur « Charger l’extension non empaquetée » et choisissez ce dossier extension-chatgpt-xar.
6. Cliquez sur l’icône de l’extension, collez le code d’appairage affiché par la Régie puis cliquez sur « Appairer ».

UTILISATION

- Dans la Régie, choisissez une conversation, un prompt et les portraits de référence.
- Cliquez sur « Préparer dans ChatGPT ».
- Dans ChatGPT, le panneau Xar propose « Préparer » ou « Préparer + envoyer ».
- Une fois l’image créée, cliquez sur « Importer dans la Régie » sous l’image.

SÉCURITÉ

- L’extension ne demande ni mot de passe, ni cookie, ni clé API OpenAI.
- Le code d’appairage autorise uniquement les échanges avec votre serveur local.
- Le pont n’agit que dans les conversations exactes enregistrées dans la Régie.
- Chaque envoi et chaque import exige un clic visible.
