let activeJob = null;
let lastSentJobId = "";
let targetedConversation = false;
let previousConversationUrl = "";
let pollBusy = false;
let scanTimer = null;

function normalizedConversationUrl(value = location.href) {
  try {
    const parsed = new URL(value);
    if (parsed.hostname !== "chatgpt.com") return "";
    const match = parsed.pathname.match(/(?:^|\/)c\/[a-zA-Z0-9_-]+/);
    if (!match) return "";
    const end = (match.index || 0) + match[0].length;
    return `https://chatgpt.com${parsed.pathname.slice(0, end)}`;
  } catch {
    return "";
  }
}

async function extensionMessage(message) {
  const response = await chrome.runtime.sendMessage(message);
  if (!response?.ok) throw new Error(response?.error || "Le pont ne répond pas.");
  return response;
}

function ensurePanel() {
  let panel = document.getElementById("xar-bridge-panel");
  if (panel) return panel;
  panel = document.createElement("section");
  panel.id = "xar-bridge-panel";
  panel.className = "xar-bridge-hidden";
  panel.innerHTML = `
    <div class="xar-bridge-heading"><span class="xar-bridge-sigil">✦</span><div><strong>Régie du Seuil</strong><small>Demande ChatGPT préparée</small></div><button type="button" data-xar-close aria-label="Réduire">×</button></div>
    <p data-xar-summary></p>
    <div class="xar-bridge-meta" data-xar-meta></div>
    <div class="xar-bridge-actions">
      <button type="button" data-xar-prepare>Préparer</button>
      <button type="button" class="xar-bridge-primary" data-xar-send>Préparer + envoyer</button>
      <button type="button" class="xar-bridge-muted" data-xar-cancel>Ignorer</button>
    </div>
    <div class="xar-bridge-feedback" data-xar-feedback></div>`;
  document.documentElement.append(panel);
  panel.querySelector("[data-xar-close]").addEventListener("click", (event) => {
    panel.classList.toggle("xar-bridge-collapsed");
    event.currentTarget.textContent = panel.classList.contains("xar-bridge-collapsed") ? "⌃" : "×";
  });
  panel.querySelector("[data-xar-prepare]").addEventListener("click", () => prepareActiveJob(false));
  panel.querySelector("[data-xar-send]").addEventListener("click", () => prepareActiveJob(true));
  panel.querySelector("[data-xar-cancel]").addEventListener("click", cancelActiveJob);
  return panel;
}

function feedback(message, kind = "") {
  const target = ensurePanel().querySelector("[data-xar-feedback]");
  target.textContent = message;
  target.dataset.kind = kind;
}

function showJob(job) {
  activeJob = job;
  const panel = ensurePanel();
  panel.classList.remove("xar-bridge-hidden");
  panel.classList.remove("xar-bridge-collapsed");
  panel.querySelector("[data-xar-close]").textContent = "×";
  panel.querySelector("[data-xar-summary]").textContent = job.prompt.slice(0, 260) + (job.prompt.length > 260 ? "…" : "");
  panel.querySelector("[data-xar-meta]").textContent = `${job.attachments?.length || 0} pièce(s) jointe(s) · validation manuelle`;
  feedback("Choisissez comment remplir le composeur.");
}

function dataUrlToFile(entry, index) {
  const [header, base64 = ""] = String(entry.dataUrl || "").split(",", 2);
  const mimeType = header.match(/^data:([^;]+);base64$/)?.[1] || entry.mimeType || "image/webp";
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let position = 0; position < binary.length; position += 1) bytes[position] = binary.charCodeAt(position);
  return new File([bytes], entry.name || `reference-${index + 1}.webp`, { type: mimeType });
}

function composerElement() {
  return document.querySelector("#prompt-textarea")
    || document.querySelector('form textarea[placeholder]')
    || document.querySelector('form [contenteditable="true"][role="textbox"]')
    || document.querySelector('[contenteditable="true"][data-lexical-editor="true"]');
}

function fillComposer(prompt) {
  const composer = composerElement();
  if (!composer) throw new Error("Le composeur ChatGPT est introuvable. Rechargez la page puis réessayez.");
  composer.focus();
  if (composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement) {
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(composer), "value")?.set;
    if (setter) setter.call(composer, prompt);
    else composer.value = prompt;
    composer.dispatchEvent(new Event("input", { bubbles: true }));
    composer.dispatchEvent(new Event("change", { bubbles: true }));
    return;
  }
  const selection = getSelection();
  const range = document.createRange();
  range.selectNodeContents(composer);
  selection.removeAllRanges();
  selection.addRange(range);
  const inserted = document.execCommand("insertText", false, prompt);
  if (!inserted || !composer.textContent?.includes(prompt.slice(0, 30))) {
    composer.replaceChildren();
    const paragraph = document.createElement("p");
    paragraph.textContent = prompt;
    composer.append(paragraph);
    composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: prompt }));
  }
}

function attachFiles(attachments) {
  if (!attachments?.length) return;
  const candidates = [...document.querySelectorAll('input[type="file"]')];
  const fileInput = candidates.find((input) => String(input.accept || "").includes("image") || input.multiple) || candidates[0];
  if (!fileInput) throw new Error("Le bouton de pièces jointes ChatGPT est introuvable.");
  const transfer = new DataTransfer();
  attachments.forEach((entry, index) => transfer.items.add(dataUrlToFile(entry, index)));
  fileInput.files = transfer.files;
  fileInput.dispatchEvent(new Event("input", { bubbles: true }));
  fileInput.dispatchEvent(new Event("change", { bubbles: true }));
}

function sendButton() {
  return document.querySelector('[data-testid="send-button"]')
    || document.querySelector('button[aria-label*="Envoyer"]')
    || document.querySelector('button[aria-label*="Send"]')
    || composerElement()?.closest("form")?.querySelector('button[type="submit"]');
}

async function waitForSendButton(timeout = 18000) {
  const startedAt = Date.now();
  while (Date.now() - startedAt < timeout) {
    const button = sendButton();
    if (button && !button.disabled && button.getAttribute("aria-disabled") !== "true") return button;
    await new Promise((resolve) => setTimeout(resolve, 350));
  }
  return null;
}

async function prepareActiveJob(sendImmediately) {
  if (!activeJob) return;
  const job = activeJob;
  const panel = ensurePanel();
  panel.querySelectorAll("button").forEach((button) => { button.disabled = true; });
  feedback("Préparation du prompt et des références…");
  try {
    fillComposer(job.prompt);
    attachFiles(job.attachments || []);
    await extensionMessage({ type: "jobStatus", jobId: job.id, status: "prepared" });
    if (!sendImmediately) {
      feedback("Composeur prêt. Vérifiez puis utilisez le bouton d’envoi de ChatGPT.", "success");
      lastSentJobId = job.id;
      activeJob = null;
      setTimeout(() => panel.classList.add("xar-bridge-hidden"), 4200);
      return;
    }
    feedback("Attente de la fin du chargement des pièces jointes…");
    const button = await waitForSendButton();
    if (!button) throw new Error("Le bouton d’envoi n’est pas devenu disponible. Le composeur reste prêt pour un envoi manuel.");
    button.click();
    await extensionMessage({ type: "jobStatus", jobId: job.id, status: "sent" });
    lastSentJobId = job.id;
    activeJob = null;
    feedback("Demande envoyée. Un bouton d’import apparaîtra sur chaque grande image générée.", "success");
    setTimeout(() => panel.classList.add("xar-bridge-hidden"), 5200);
  } catch (error) {
    feedback(error.message, "error");
    await extensionMessage({ type: "jobStatus", jobId: job.id, status: "failed", message: error.message }).catch(() => {});
  } finally {
    panel.querySelectorAll("button").forEach((button) => { button.disabled = false; });
  }
}

async function cancelActiveJob() {
  if (!activeJob) return;
  await extensionMessage({ type: "jobStatus", jobId: activeJob.id, status: "cancelled" }).catch(() => {});
  activeJob = null;
  ensurePanel().classList.add("xar-bridge-hidden");
}

async function pollForJob() {
  if (pollBusy || activeJob) return;
  const currentUrl = normalizedConversationUrl();
  if (currentUrl !== previousConversationUrl) {
    previousConversationUrl = currentUrl;
    targetedConversation = false;
    activeJob = null;
    ensurePanel().classList.add("xar-bridge-hidden");
  }
  if (!currentUrl) return;
  pollBusy = true;
  try {
    const response = await extensionMessage({ type: "nextJob", conversationUrl: currentUrl });
    targetedConversation = Boolean(response.job) || (response.conversations || []).some((entry) => entry.url === currentUrl);
    if (response.job) showJob(response.job);
    scheduleImageScan();
  } catch {
    targetedConversation = false;
  } finally {
    pollBusy = false;
  }
}

function likelyGeneratedImage(image) {
  if (!image?.src || image.dataset.xarBridgeSeen) return false;
  if (image.src.startsWith("data:image/svg")) return false;
  const rect = image.getBoundingClientRect();
  return image.naturalWidth >= 256 || image.naturalHeight >= 256 || rect.width >= 220 || rect.height >= 220;
}

function imageFilename(image) {
  const alt = String(image.alt || "illustration-xar-tsaroth").trim().slice(0, 70).replace(/[^a-zA-Z0-9À-ÿ_-]+/g, "-");
  return `${alt || "illustration-xar-tsaroth"}-${Date.now()}.png`;
}

async function importImage(image, button) {
  button.disabled = true;
  button.textContent = "Import…";
  try {
    const common = { filename: imageFilename(image), jobId: lastSentJobId };
    try {
      await extensionMessage({ type: "importImage", src: image.currentSrc || image.src, ...common });
    } catch (directError) {
      const response = await fetch(image.currentSrc || image.src, { credentials: "include" });
      const blob = await response.blob();
      const dataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(blob);
      });
      await extensionMessage({ type: "importImageData", dataUrl, ...common });
    }
    button.textContent = "Importée dans la Régie ✓";
    button.classList.add("xar-bridge-imported");
  } catch (error) {
    button.disabled = false;
    button.textContent = `Réessayer · ${error.message}`;
  }
}

function scanGeneratedImages() {
  if (!targetedConversation) return;
  const images = [
    ...document.querySelectorAll(
      '[data-message-author-role="assistant"] img, article:has([data-message-author-role="assistant"]) img',
    ),
  ].filter(likelyGeneratedImage);
  for (const image of images) {
    image.dataset.xarBridgeSeen = "true";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "xar-bridge-import-button";
    button.textContent = "Importer dans la Régie";
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      importImage(image, button);
    });
    const anchor = image.closest("a, button");
    const host = anchor?.parentElement || image.parentElement;
    host?.append(button);
  }
}

function scheduleImageScan() {
  clearTimeout(scanTimer);
  scanTimer = setTimeout(scanGeneratedImages, 240);
}

ensurePanel();
setInterval(pollForJob, 1300);
const observer = new MutationObserver(scheduleImageScan);
observer.observe(document.documentElement, { childList: true, subtree: true });
pollForJob();
