const $ = (selector) => document.querySelector(selector);

function setStatus(message, type = "") {
  $("#status").textContent = message;
  $("#status").className = type;
}

async function send(message) {
  const response = await chrome.runtime.sendMessage(message);
  if (!response?.ok) throw new Error(response?.error || "Le pont ne répond pas.");
  return response;
}

async function load() {
  try {
    const response = await send({ type: "getSettings" });
    $("#baseUrl").value = response.baseUrl;
    $("#pairingToken").value = response.pairingToken;
    if (response.pairingToken) await test();
  } catch (error) { setStatus(error.message, "error"); }
}

async function pair() {
  setStatus("Appairage en cours…");
  try {
    const response = await send({ type: "saveSettings", baseUrl: $("#baseUrl").value, pairingToken: $("#pairingToken").value });
    const configured = response.status?.conversations?.filter((entry) => entry.url).length || 0;
    setStatus(`Pont connecté · ${configured}/2 conversation(s) configurée(s).`, "success");
  } catch (error) { setStatus(error.message, "error"); }
}

async function test() {
  setStatus("Test de la Régie locale…");
  try {
    const response = await send({ type: "testConnection" });
    const configured = response.status?.conversations?.filter((entry) => entry.url).length || 0;
    setStatus(`Régie joignable · ${configured}/2 conversation(s) configurée(s).`, "success");
  } catch (error) { setStatus(error.message, "error"); }
}

$("#pairButton").addEventListener("click", pair);
$("#testButton").addEventListener("click", test);
load();
