const DEFAULT_SETTINGS = {
  baseUrl: "http://127.0.0.1:4173",
  pairingToken: ""
};

function normalizedBaseUrl(value) {
  try {
    const parsed = new URL(String(value || DEFAULT_SETTINGS.baseUrl).trim());
    if (parsed.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(parsed.hostname)) return "";
    return parsed.origin;
  } catch {
    return "";
  }
}

async function settings() {
  const saved = await chrome.storage.local.get(DEFAULT_SETTINGS);
  return {
    baseUrl: normalizedBaseUrl(saved.baseUrl) || DEFAULT_SETTINGS.baseUrl,
    pairingToken: String(saved.pairingToken || "").trim()
  };
}

async function bridgeFetch(path, options = {}) {
  const config = await settings();
  if (!config.pairingToken) throw new Error("Extension non appairée.");
  const headers = new Headers(options.headers || {});
  headers.set("X-Xar-Bridge-Token", config.pairingToken);
  const response = await fetch(`${config.baseUrl}${path}`, { ...options, headers, cache: "no-store" });
  const contentType = response.headers.get("content-type") || "";
  const payload = contentType.includes("application/json") ? await response.json().catch(() => ({})) : null;
  if (!response.ok || payload?.ok === false) throw new Error(payload?.error || `Erreur ${response.status}`);
  return payload ?? response;
}

async function postJobStatus(jobId, status, message = "") {
  return bridgeFetch(`/api/chatgpt-bridge/jobs/${encodeURIComponent(jobId)}/status`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status, message })
  });
}

async function uploadImageBlob(blob, { filename, jobId }) {
  const type = blob.type?.startsWith("image/") ? blob.type : "image/png";
  const params = new URLSearchParams({ filename: filename || `chatgpt-${Date.now()}.png` });
  if (jobId) params.set("jobId", jobId);
  return bridgeFetch(`/api/chatgpt-bridge/import?${params}`, {
    method: "POST",
    headers: { "Content-Type": type },
    body: blob
  });
}

async function messageHandler(message) {
  if (!message || typeof message !== "object") throw new Error("Message invalide.");
  if (message.type === "getSettings") return { ok: true, ...(await settings()) };
  if (message.type === "saveSettings") {
    const baseUrl = normalizedBaseUrl(message.baseUrl);
    if (!baseUrl) throw new Error("La Régie doit utiliser http://127.0.0.1 ou http://localhost.");
    const pairingToken = String(message.pairingToken || "").trim();
    if (pairingToken.length < 32) throw new Error("Code d’appairage incomplet.");
    await chrome.storage.local.set({ baseUrl, pairingToken });
    const status = await bridgeFetch("/api/chatgpt-bridge/status");
    return { ok: true, status };
  }
  if (message.type === "testConnection") {
    return { ok: true, status: await bridgeFetch("/api/chatgpt-bridge/status") };
  }
  if (message.type === "nextJob") {
    const params = new URLSearchParams({ conversationUrl: String(message.conversationUrl || "") });
    return bridgeFetch(`/api/chatgpt-bridge/jobs/next?${params}`);
  }
  if (message.type === "jobStatus") {
    return postJobStatus(message.jobId, message.status, message.message);
  }
  if (message.type === "importImage") {
    const source = String(message.src || "");
    if (!source.startsWith("https://") && !source.startsWith("data:image/")) throw new Error("Adresse d’image non autorisée.");
    const response = await fetch(source, { credentials: "include", cache: "no-store" });
    if (!response.ok) throw new Error(`Téléchargement refusé (${response.status}).`);
    const blob = await response.blob();
    if (!blob.type.startsWith("image/")) throw new Error("Le résultat reçu n’est pas une image.");
    return uploadImageBlob(blob, message);
  }
  if (message.type === "importImageData") {
    const dataUrl = String(message.dataUrl || "");
    if (!dataUrl.startsWith("data:image/")) throw new Error("Image encodée invalide.");
    const blob = await fetch(dataUrl).then((response) => response.blob());
    return uploadImageBlob(blob, message);
  }
  throw new Error("Action inconnue.");
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  messageHandler(message)
    .then((result) => sendResponse(result))
    .catch((error) => sendResponse({ ok: false, error: error instanceof Error ? error.message : String(error) }));
  return true;
});
