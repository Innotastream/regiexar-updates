import { existsSync } from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";

const LOCAL_HOSTS = new Set(["127.0.0.1", "localhost", "::1", "[::1]"]);

function unique(values) {
  return [...new Set(values.filter(Boolean).map((value) => path.normalize(value)))];
}

export function normalizeLocalApplicationUrl(value) {
  const parsed = new URL(String(value ?? "").trim());
  if (parsed.protocol !== "http:" || !LOCAL_HOSTS.has(parsed.hostname)) {
    throw new Error("La fenêtre applicative accepte uniquement une adresse HTTP locale.");
  }
  parsed.username = "";
  parsed.password = "";
  parsed.hash = "";
  return parsed.href;
}

export function normalizeChatGptExternalUrl(value) {
  try {
    const parsed = new URL(String(value ?? "").trim());
    if (parsed.protocol !== "https:" || parsed.hostname !== "chatgpt.com") return "";
    if (parsed.pathname === "/" || parsed.pathname === "") return "https://chatgpt.com/";
    const conversation = parsed.pathname.match(/^\/c\/([a-zA-Z0-9_-]+)\/?$/);
    return conversation ? `https://chatgpt.com/c/${conversation[1]}` : "";
  } catch {
    return "";
  }
}

export function windowsApplicationBrowserCandidates(environment = process.env) {
  const programFiles = environment.ProgramFiles || environment.PROGRAMFILES;
  const programFilesX86 = environment["ProgramFiles(x86)"] || environment["PROGRAMFILES(X86)"];
  const localAppData = environment.LOCALAPPDATA;
  return [
    ...unique([
      programFilesX86 && path.join(programFilesX86, "Microsoft", "Edge", "Application", "msedge.exe"),
      programFiles && path.join(programFiles, "Microsoft", "Edge", "Application", "msedge.exe"),
      localAppData && path.join(localAppData, "Microsoft", "Edge", "Application", "msedge.exe")
    ]).map((executable) => ({ engine: "Microsoft Edge", executable })),
    ...unique([
      programFiles && path.join(programFiles, "Google", "Chrome", "Application", "chrome.exe"),
      programFilesX86 && path.join(programFilesX86, "Google", "Chrome", "Application", "chrome.exe"),
      localAppData && path.join(localAppData, "Google", "Chrome", "Application", "chrome.exe")
    ]).map((executable) => ({ engine: "Google Chrome", executable }))
  ];
}

export function resolveApplicationBrowser({
  platform = process.platform,
  environment = process.env,
  fileExists = existsSync
} = {}) {
  if (platform !== "win32") return null;
  return windowsApplicationBrowserCandidates(environment).find((candidate) => fileExists(candidate.executable)) ?? null;
}

export function dedicatedWindowCommand(url, {
  platform = process.platform,
  environment = process.env,
  fileExists = existsSync,
  width = 1480,
  height = 920
} = {}) {
  const browser = resolveApplicationBrowser({ platform, environment, fileExists });
  if (!browser) return null;
  const applicationUrl = normalizeLocalApplicationUrl(url);
  return {
    ...browser,
    args: [
      `--app=${applicationUrl}`,
      `--window-size=${Math.max(960, Math.trunc(width))},${Math.max(680, Math.trunc(height))}`,
      "--no-first-run",
      "--no-default-browser-check",
      "--disable-features=TranslateUI"
    ]
  };
}

export function systemBrowserCommand(url, platform = process.platform) {
  const parsed = new URL(String(url ?? "").trim());
  if (!new Set(["http:", "https:"]).has(parsed.protocol)) throw new Error("Adresse externe refusée.");
  const safeUrl = parsed.href;
  if (platform === "win32") {
    return { command: "rundll32.exe", args: ["url.dll,FileProtocolHandler", safeUrl] };
  }
  if (platform === "darwin") return { command: "open", args: [safeUrl] };
  return { command: "xdg-open", args: [safeUrl] };
}

function detach(command, args, { spawnProcess = spawn, onError = () => {} } = {}) {
  const child = spawnProcess(command, args, {
    detached: true,
    stdio: "ignore",
    windowsHide: true
  });
  child.once?.("error", onError);
  child.unref?.();
  return child;
}

export function openSystemBrowser(url, options = {}) {
  const descriptor = systemBrowserCommand(url, options.platform);
  detach(descriptor.command, descriptor.args, options);
  return { dedicated: false, mode: "system-browser", engine: "Navigateur par défaut" };
}

export function openDedicatedWindow(url, options = {}) {
  const descriptor = dedicatedWindowCommand(url, options);
  if (!descriptor) {
    openSystemBrowser(url, options);
    return {
      dedicated: false,
      mode: "browser-fallback",
      engine: "Navigateur par défaut",
      message: "Edge ou Chrome est introuvable : ouverture dans le navigateur par défaut."
    };
  }
  detach(descriptor.executable, descriptor.args, {
    ...options,
    onError: (error) => {
      try { openSystemBrowser(url, options); } catch {}
      options.onError?.(error);
    }
  });
  return {
    dedicated: true,
    mode: "dedicated",
    engine: descriptor.engine,
    message: `Fenêtre dédiée ouverte avec ${descriptor.engine}.`
  };
}
