const token = document.documentElement.dataset.launcherToken;
const initialVersion = document.documentElement.dataset.appVersion;
const $ = (selector) => document.querySelector(selector);
const restartSessionKey = "xar-regie-expected-update";
const soundPreferenceKey = "xar-regie-launcher-sfx";
const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)");
let latestStatus = null;
let restartExpectedVersion = sessionStorage.getItem(restartSessionKey) || "";
let restartCompleted = false;
let lastProgressValue = 0;
let readyAnnounced = false;
let announcedUpdateVersion = "";

function createSoundscape() {
  const AudioEngine = globalThis.AudioContext || globalThis.webkitAudioContext;
  let wanted = localStorage.getItem(soundPreferenceKey) === "on";
  let context = null;
  let master = null;
  let ambient = [];

  function renderPreference() {
    const button = $("#soundToggle");
    if (!AudioEngine) {
      button.disabled = true;
      button.setAttribute("aria-pressed", "false");
      button.setAttribute("aria-label", "Effets sonores indisponibles sur ce moteur");
      $("#soundToggleLabel").textContent = "SFX indisponibles";
      return;
    }
    button.setAttribute("aria-pressed", String(wanted));
    button.setAttribute("aria-label", wanted ? "Désactiver les effets sonores du launcher" : "Activer les effets sonores du launcher");
    $("#soundToggleLabel").textContent = wanted ? "SFX activés" : "SFX désactivés";
  }

  function audioContext() {
    if (!AudioEngine) return null;
    if (!context) {
      context = new AudioEngine();
      master = context.createGain();
      master.gain.value = .72;
      master.connect(context.destination);
    }
    return context;
  }

  function tone(frequency, {
    at = 0,
    duration = .12,
    volume = .025,
    type = "sine",
    endFrequency = frequency,
    attack = .008
  } = {}) {
    if (!wanted || !context || context.state !== "running") return;
    const start = context.currentTime + at;
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const filter = context.createBiquadFilter();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(Math.max(20, frequency), start);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(20, endFrequency), start + duration);
    filter.type = "lowpass";
    filter.frequency.value = 2600;
    gain.gain.setValueAtTime(.0001, start);
    gain.gain.exponentialRampToValueAtTime(volume, start + attack);
    gain.gain.exponentialRampToValueAtTime(.0001, start + duration);
    oscillator.connect(filter);
    filter.connect(gain);
    gain.connect(master);
    oscillator.start(start);
    oscillator.stop(start + duration + .03);
  }

  function startAmbience() {
    if (!wanted || ambient.length || !context || context.state !== "running") return;
    const ambienceGain = context.createGain();
    const filter = context.createBiquadFilter();
    const lfo = context.createOscillator();
    const lfoGain = context.createGain();
    ambienceGain.gain.setValueAtTime(.0001, context.currentTime);
    ambienceGain.gain.exponentialRampToValueAtTime(.022, context.currentTime + 1.4);
    filter.type = "lowpass";
    filter.frequency.value = 240;
    lfo.frequency.value = .095;
    lfoGain.gain.value = .006;
    lfo.connect(lfoGain);
    lfoGain.connect(ambienceGain.gain);
    const low = context.createOscillator();
    const fifth = context.createOscillator();
    low.type = "sine";
    fifth.type = "triangle";
    low.frequency.value = 46.25;
    fifth.frequency.value = 69.38;
    low.connect(filter);
    fifth.connect(filter);
    filter.connect(ambienceGain);
    ambienceGain.connect(master);
    low.start();
    fifth.start();
    lfo.start();
    ambient = [low, fifth, lfo, ambienceGain];
  }

  function stopAmbience() {
    if (!ambient.length || !context) return;
    const [low, fifth, lfo, ambienceGain] = ambient;
    ambienceGain.gain.cancelScheduledValues(context.currentTime);
    ambienceGain.gain.setTargetAtTime(.0001, context.currentTime, .08);
    setTimeout(() => {
      for (const node of [low, fifth, lfo]) {
        try { node.stop(); } catch {}
      }
    }, 450);
    ambient = [];
  }

  async function activate() {
    if (!wanted || !AudioEngine) return false;
    const engine = audioContext();
    if (engine.state !== "running") await engine.resume();
    startAmbience();
    return true;
  }

  function play(kind) {
    if (!wanted || !context || context.state !== "running") return;
    if (kind === "hover") {
      tone(690, { duration: .045, volume: .009, type: "triangle", endFrequency: 820 });
    } else if (kind === "click") {
      tone(128, { duration: .16, volume: .035, type: "triangle", endFrequency: 196 });
      tone(410, { at: .025, duration: .11, volume: .018, type: "sine", endFrequency: 620 });
    } else if (kind === "progress") {
      tone(520, { duration: .065, volume: .012, type: "sine", endFrequency: 790 });
    } else if (kind === "warning") {
      tone(205, { duration: .24, volume: .029, type: "triangle", endFrequency: 164 });
      tone(308, { at: .11, duration: .22, volume: .022, type: "triangle", endFrequency: 244 });
    } else if (kind === "ready") {
      [220, 329.63, 440, 659.25].forEach((frequency, index) => {
        tone(frequency, { at: index * .065, duration: .55, volume: .021 - index * .002, type: index % 2 ? "triangle" : "sine", endFrequency: frequency * 1.015 });
      });
      tone(92.5, { duration: .7, volume: .025, type: "sine", endFrequency: 110 });
    }
  }

  async function toggle() {
    wanted = !wanted;
    localStorage.setItem(soundPreferenceKey, wanted ? "on" : "off");
    renderPreference();
    if (wanted) {
      await activate();
      play("click");
      if (latestStatus?.application?.ready) setTimeout(() => play("ready"), 130);
    } else {
      stopAmbience();
      if (context?.state === "running") await context.suspend();
    }
  }

  renderPreference();
  return { activate, play, toggle, wanted: () => wanted };
}

const soundscape = createSoundscape();

function initializeCinematicEffects() {
  if (!reducedMotion.matches && matchMedia("(pointer: fine)").matches) {
    let framePending = false;
    let nextX = 0;
    let nextY = 0;
    window.addEventListener("pointermove", (event) => {
      nextX = ((event.clientX / innerWidth) - .5) * 18;
      nextY = ((event.clientY / innerHeight) - .5) * 14;
      if (framePending) return;
      framePending = true;
      requestAnimationFrame(() => {
        document.documentElement.style.setProperty("--parallax-x", `${nextX.toFixed(2)}px`);
        document.documentElement.style.setProperty("--parallax-y", `${nextY.toFixed(2)}px`);
        framePending = false;
      });
    }, { passive: true });
  }

  if (reducedMotion.matches) return;
  const canvas = $("#arcaneCanvas");
  const context = canvas.getContext("2d");
  if (!context) return;
  const particles = [];
  let width = innerWidth;
  let height = innerHeight;
  let pixelRatio = 1;

  function resetParticle(particle, initial = false) {
    particle.x = Math.random() * width;
    particle.y = initial ? Math.random() * height : height + Math.random() * 40;
    particle.radius = .35 + Math.random() * 1.25;
    particle.vx = (Math.random() - .5) * .18;
    particle.vy = -.12 - Math.random() * .48;
    particle.alpha = .16 + Math.random() * .53;
    particle.pulse = Math.random() * Math.PI * 2;
    particle.violet = Math.random() > .72;
  }

  function resize() {
    width = innerWidth;
    height = innerHeight;
    pixelRatio = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.round(width * pixelRatio);
    canvas.height = Math.round(height * pixelRatio);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
  }

  resize();
  for (let index = 0; index < Math.min(76, Math.max(38, Math.round(width / 21))); index += 1) {
    const particle = {};
    resetParticle(particle, true);
    particles.push(particle);
  }
  addEventListener("resize", resize, { passive: true });

  function paint(time) {
    context.clearRect(0, 0, width, height);
    context.globalCompositeOperation = "lighter";
    for (const particle of particles) {
      particle.x += particle.vx;
      particle.y += particle.vy;
      particle.pulse += .018;
      if (particle.y < -15 || particle.x < -20 || particle.x > width + 20) resetParticle(particle);
      const flicker = .62 + Math.sin(particle.pulse + time * .001) * .38;
      const color = particle.violet ? "193, 126, 222" : "255, 170, 72";
      context.beginPath();
      context.fillStyle = `rgba(${color}, ${particle.alpha * flicker})`;
      context.shadowColor = `rgba(${color}, .72)`;
      context.shadowBlur = particle.radius * 7;
      context.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
      context.fill();
    }
    context.shadowBlur = 0;
    context.globalCompositeOperation = "source-over";
    requestAnimationFrame(paint);
  }
  requestAnimationFrame(paint);
}

function setCard(cardId, tone, titleId, title, detailId, detail) {
  const card = $(cardId);
  card.classList.remove("good", "warning", "bad");
  if (tone) card.classList.add(tone);
  $(titleId).textContent = title;
  $(detailId).textContent = detail;
}

function setStage(selector, state) {
  const stage = $(selector);
  stage.classList.remove("complete", "current", "error");
  if (state) stage.classList.add(state);
}

function setProgress(value, detail) {
  const progress = Math.max(0, Math.min(100, Math.round(value)));
  const crossedMilestone = [25, 50, 75, 100].some((milestone) => lastProgressValue < milestone && progress >= milestone);
  $("#launchProgress").value = progress;
  $("#launchProgress").textContent = `${progress} %`;
  $("#progressValue").value = `${progress} %`;
  $("#progressValue").textContent = `${progress} %`;
  $("#progressDetail").textContent = detail;
  if (crossedMilestone) soundscape.play("progress");
  lastProgressValue = progress;
}

function showRestartOverlay(message = "Le launcher installe le build contrôlé, conserve l’ancienne version puis revient automatiquement.") {
  $("#restartDetail").textContent = message;
  $("#restartOverlay").hidden = false;
  $("#launcherMain").setAttribute("aria-hidden", "true");
}

function hideRestartOverlay() {
  $("#restartOverlay").hidden = true;
  $("#launcherMain").removeAttribute("aria-hidden");
}

function render(status) {
  latestStatus = status;
  const application = status.application;
  const shell = status.shell || { available: false, engine: null, application: { dedicated: false, mode: "browser-fallback" } };
  const integrity = status.integrity;
  const update = status.update;
  const operation = status.operation;
  const operationBusy = ["downloading", "restarting"].includes(operation?.state);

  setCard(
    "#applicationCard",
    application.ready ? "good" : application.error ? "bad" : "warning",
    "#applicationStatus",
    application.ready ? "Régie prête" : application.error ? "Démarrage interrompu" : "Éveil en cours",
    "#applicationDetail",
    application.error || (application.ready ? "Le serveur local répond et la table peut être ouverte." : "Le launcher attend la réponse de l’application.")
  );

  const shellDedicated = shell.application?.dedicated === true;
  setCard(
    "#shellCard",
    shellDedicated || shell.available ? "good" : "warning",
    "#shellStatus",
    shellDedicated ? "Fenêtre dédiée" : shell.available ? `${shell.engine} prêt` : "Mode navigateur",
    "#shellDetail",
    shellDedicated
      ? `${shell.application.engine} héberge la Régie sans onglet ni barre d’adresse.`
      : shell.available
        ? "Le prochain passage ouvrira la table dans sa propre fenêtre."
        : "Edge ou Chrome n’a pas été détecté : le navigateur par défaut prendra le relais."
  );

  const integrityIssueCount = (integrity.missing?.length || 0)
    + (integrity.modified?.length || 0)
    + (integrity.unexpected?.length || 0)
    + (integrity.invalidEntries?.length || 0);
  setCard(
    "#integrityCard",
    integrity.ok ? "good" : "bad",
    "#integrityStatus",
    integrity.ok ? "Sceau intact" : "Réparation requise",
    "#integrityDetail",
    integrity.ok
      ? `${integrity.checkedFiles} fichiers applicatifs correspondent au manifeste.`
      : integrity.reason === "manifest-missing"
        ? "Le manifeste d’intégrité est absent."
        : `${integrityIssueCount} fichier(s) absent(s), modifié(s), inattendu(s) ou invalide(s).`
  );

  const updateTone = update.state === "available" || update.state === "trust-missing" || update.state === "not-configured"
    ? "warning"
    : update.state === "error"
      ? "bad"
      : update.state === "current" || update.state === "ahead"
        ? "good"
        : "";
  const updateTitle = update.state === "available" ? `Version ${update.availableVersion} disponible`
    : update.state === "current" ? "Canal à jour"
      : update.state === "checking" ? "Vigie en cours"
        : update.state === "error" ? "Canal inaccessible"
          : update.state === "trust-missing" ? "Signature absente"
            : update.state === "ahead" ? "Version en avance"
              : "Canal à relier";
  setCard("#updateCard", updateTone, "#updateStatus", updateTitle, "#updateDetail", update.message);

  setStage("#stageApplication", application.ready ? "complete" : application.error ? "error" : "current");
  setStage("#stageIntegrity", integrity.ok ? "complete" : "error");
  setStage(
    "#stageUpdate",
    update.state === "checking" || update.state === "not-checked" ? "current"
      : update.state === "error" || update.state === "trust-missing" ? "error"
        : update.state === "available" || update.state === "not-configured" ? "current"
          : "complete"
  );

  if (operation?.state === "downloading") {
    setProgress(operation.progress, operation.message);
  } else if (operation?.state === "restarting") {
    setProgress(100, operation.message);
    showRestartOverlay();
  } else {
    const appProgress = application.ready ? 38 : application.error ? 18 : 24;
    const integrityProgress = integrity.ok || integrityIssueCount > 0 || integrity.reason ? 34 : 12;
    const updateResolved = !["not-checked", "checking"].includes(update.state);
    const updateProgress = updateResolved ? 28 : update.state === "checking" ? 15 : 4;
    const detail = application.error ? application.error
      : !integrity.ok ? "Le build doit être réparé avant utilisation."
        : update.state === "available" ? `La version ${update.availableVersion} attend votre accord.`
          : application.ready ? "Les sceaux locaux sont prêts. Vous pouvez entrer dans la Régie."
            : "Préparation de la table locale…";
    setProgress(appProgress + integrityProgress + updateProgress, detail);
  }

  const global = $("#globalStatus");
  global.classList.remove("good", "bad");
  let globalMessage = "Ouverture des sceaux…";
  if (application.error || !integrity.ok) {
    global.classList.add("bad");
    globalMessage = application.error ? "Le passage est interrompu" : "Le build demande une réparation";
  } else if (operationBusy) {
    globalMessage = operation?.message || "Mise à jour en cours…";
  } else if (update.state === "available") {
    globalMessage = `Mise à jour ${update.availableVersion} disponible`;
  } else if (application.ready) {
    global.classList.add("good");
    globalMessage = "Le passage vers la Régie est ouvert";
  }
  $("#globalStatusText").textContent = globalMessage;

  if (application.ready && integrity.ok && !readyAnnounced) {
    readyAnnounced = true;
    soundscape.play("ready");
  }
  if (update.state === "available" && announcedUpdateVersion !== update.availableVersion) {
    announcedUpdateVersion = update.availableVersion;
    soundscape.play("warning");
  }

  const repairAvailable = !integrity.ok && update.configured && ["available", "current"].includes(update.state);
  const updateAvailable = update.state === "available";
  const installButton = $("#installUpdate");
  installButton.hidden = !(repairAvailable || updateAvailable);
  installButton.disabled = operationBusy;
  if (repairAvailable) {
    $("#installUpdateLabel").textContent = "Réparer l’installation";
    $("#installUpdateDetail").textContent = "Retélécharger, contrôler et restaurer le build";
  } else if (updateAvailable) {
    $("#installUpdateLabel").textContent = `Installer la version ${update.availableVersion}`;
    $("#installUpdateDetail").textContent = "Mise à jour signée avec point de retour";
  }

  const canUseSignedPackage = update.configured && ["available", "current"].includes(update.state);
  $("#openApplication").disabled = !application.ready || !integrity.ok || operationBusy;
  $("#checkUpdate").disabled = operationBusy || update.state === "checking";
  $("#verifyIntegrity").disabled = operationBusy;
  $("#redownloadVersion").disabled = operationBusy || !canUseSignedPackage;
  $("#launcherMain").setAttribute("aria-busy", String(operationBusy));

  if (operation?.message && operationBusy) $("#operationMessage").textContent = operation.message;
  if (status.lastUpdate?.state === "installed" && status.lastUpdate.version === status.release.version) {
    $("#operationMessage").textContent = `Version ${status.lastUpdate.version} installée avec succès. Un point de retour a été conservé.`;
  } else if (status.lastUpdate?.state === "error") {
    $("#operationMessage").textContent = status.lastUpdate.message;
  }

  if (restartExpectedVersion && status.release.version === restartExpectedVersion && status.lastUpdate?.state === "installed") {
    showRestartOverlay(`Version ${restartExpectedVersion} installée. Réouverture du Seuil…`);
    if (!restartCompleted) {
      restartCompleted = true;
      sessionStorage.removeItem(restartSessionKey);
      setTimeout(() => location.reload(), 1_200);
    }
  } else if (restartExpectedVersion && status.lastUpdate?.state === "error") {
    restartExpectedVersion = "";
    sessionStorage.removeItem(restartSessionKey);
    hideRestartOverlay();
  }
}

async function request(path, { operation = "" } = {}) {
  $("#operationMessage").textContent = operation;
  const response = await fetch(path, {
    method: "POST",
    headers: { "X-Xar-Launcher-Token": token }
  });
  const payload = await response.json();
  if (!response.ok || !payload.ok) throw new Error(payload.error || "Commande impossible.");
  render(payload);
  return payload;
}

async function refresh() {
  try {
    const response = await fetch("/api/status", { cache: "no-store" });
    if (!response.ok) throw new Error(`statut ${response.status}`);
    render(await response.json());
  } catch (error) {
    if (restartExpectedVersion || latestStatus?.operation?.state === "restarting") {
      showRestartOverlay("Remplacement atomique en cours… Le launcher va revenir automatiquement.");
    } else {
      $("#operationMessage").textContent = `Launcher inaccessible : ${error.message}`;
    }
  }
}

$("#soundToggle").addEventListener("click", () => soundscape.toggle());
document.addEventListener("pointerdown", () => {
  if (soundscape.wanted()) soundscape.activate();
}, { once: true, capture: true });
document.querySelectorAll("button").forEach((button) => {
  button.addEventListener("pointerenter", () => {
    if (!button.disabled) soundscape.play("hover");
  });
  if (button.id !== "soundToggle") button.addEventListener("click", () => soundscape.play("click"));
});

$("#openApplication").addEventListener("click", async () => {
  try {
    const payload = await request("/api/open", { operation: "Ouverture de la fenêtre de Régie…" });
    $("#operationMessage").textContent = payload.shell?.application?.dedicated
      ? `La Régie est ouverte dans une fenêtre ${payload.shell.application.engine}.`
      : "La Régie est ouverte dans votre navigateur par défaut (moteur applicatif indisponible).";
  } catch (error) { $("#operationMessage").textContent = error.message; }
});

$("#checkUpdate").addEventListener("click", async () => {
  try {
    await request("/api/check-update", { operation: "Lecture du canal de mise à jour signé…" });
    $("#operationMessage").textContent = "Vérification du canal terminée.";
  } catch (error) { $("#operationMessage").textContent = error.message; }
});

$("#verifyIntegrity").addEventListener("click", async () => {
  try {
    const payload = await request("/api/verify-integrity", { operation: "Contrôle de tous les fichiers applicatifs…" });
    $("#operationMessage").textContent = payload.integrity.ok
      ? "Intégrité confirmée : aucun fichier applicatif n’a été altéré."
      : payload.update.configured
        ? "Une anomalie a été trouvée. Utilisez « Réparer l’installation » pour restaurer un build signé."
        : "Une anomalie a été trouvée. Le canal signé doit être relié pour permettre la réparation automatique.";
  } catch (error) { $("#operationMessage").textContent = error.message; }
});

$("#redownloadVersion").addEventListener("click", async () => {
  try {
    const payload = await request("/api/redownload", { operation: "Téléchargement et contrôle cryptographique du ZIP…" });
    $("#operationMessage").textContent = `ZIP signé vérifié et conservé : ${payload.downloadedPackage.filename}`;
  } catch (error) { $("#operationMessage").textContent = error.message; }
});

$("#installUpdate").addEventListener("click", async () => {
  const expectedVersion = latestStatus?.update?.availableVersion || latestStatus?.release?.version || initialVersion;
  restartExpectedVersion = expectedVersion;
  sessionStorage.setItem(restartSessionKey, expectedVersion);
  try {
    await request("/api/install-update", { operation: "Préparation de la mise à jour signée…" });
    showRestartOverlay();
  } catch (error) {
    restartExpectedVersion = "";
    sessionStorage.removeItem(restartSessionKey);
    hideRestartOverlay();
    $("#operationMessage").textContent = error.message;
  }
});

initializeCinematicEffects();
if (restartExpectedVersion) showRestartOverlay("Reconnexion au launcher mis à jour…");
refresh();
setInterval(refresh, 1_500);
