import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { installApplication } from "./installer-core.mjs";
import { defaultInstallationRoot, defaultPrivateRoot, pathsReferToSameLocation } from "./installation-paths.mjs";

const sourceRoot = path.dirname(fileURLToPath(import.meta.url));
const privateRoot = defaultPrivateRoot();
const installationRoot = defaultInstallationRoot();

function launchInstalledApplication(root) {
  const child = spawn(process.execPath, [path.join(root, "launcher.mjs")], {
    cwd: root,
    env: { ...process.env, XAR_PRIVATE_ROOT: privateRoot, XAR_INSTALL_ROOT: installationRoot },
    detached: true,
    stdio: "ignore",
    windowsHide: true
  });
  child.unref();
}

try {
  if (pathsReferToSameLocation(sourceRoot, installationRoot)) {
    launchInstalledApplication(installationRoot);
  } else {
    const result = installApplication({ sourceRoot, installationRoot, privateRoot });
    console.log(result.installed
      ? `Régie ${result.release.version} installée dans son dossier applicatif dédié.`
      : `Régie ${result.release.version} déjà installée et intacte.`);
    console.log("Les fiches, scènes et réglages restent dans le profil de données séparé.");
    launchInstalledApplication(installationRoot);
  }
} catch (error) {
  console.error(`Installation impossible : ${error.message}`);
  process.exitCode = 1;
}
