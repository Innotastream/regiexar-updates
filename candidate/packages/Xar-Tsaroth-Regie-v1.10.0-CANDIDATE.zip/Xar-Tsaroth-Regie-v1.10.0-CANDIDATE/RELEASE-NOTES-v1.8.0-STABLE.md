# Régie du Seuil 1.8.0 — Stable

## Base

- Construite depuis la **1.7.0 candidate** afin de conserver le mode libre par défaut, l’initiative volontaire et les contrôles tactiques séparés.
- La **1.8.0** est validée explicitement comme nouvelle base stable.
- Version produit lue dans `application.json` ; la version de Node.js reste une contrainte technique provisoire, pas le numéro du build applicatif.

## Nouveau socle applicatif

- Launcher local dédié sur `127.0.0.1:4169`, lancé par `start-windows.bat`, `start.sh` ou `npm start`.
- Démarrage contrôlé de la Régie, état de disponibilité, vérification des mises à jour et contrôle d’intégrité accessibles depuis une interface unique.
- Manifeste `release-integrity.json` couvrant tous les fichiers distribués par SHA-256.
- Lecteur de canal de mise à jour HTTPS avec manifeste Ed25519 ; toute signature, identité, taille ou empreinte incorrecte est refusée.
- Retéléchargement vérifié du ZIP dans le profil privé dès qu’un canal signé sera configuré.

## Fiches et migrations

- Un fichier `characters.json` distinct par joueur, stocké hors du build dans le profil système.
- Aucun jeton d’accès joueur n’est copié dans ces fichiers de fiches.
- Restauration de la version la plus récente de chaque fiche après changement de build.
- `characterSchemaVersion` sur chaque fiche et chaîne de migration explicite.
- Copie de sauvegarde automatique avant toute migration d’un ancien stockage.
- Refus d’écraser un stockage ou une fiche provenant d’un schéma futur.

## Limites connues de ce jalon

- Le launcher reste exécuté par Node.js 20+ ; l’exécutable autonome Tauri viendra dans un jalon ultérieur.
- Le canal distant est désactivé tant que l’hébergement HTTPS et la paire de signature de publication ne sont pas décidés.
- Le stockage actuel est durable sur la machine hôte. Les comptes et fiches multi-PC nécessitent encore Supabase Auth/PostgreSQL/RLS.
- Le build a été promu après validation explicite de l’utilisateur et répétition du contrôle complet depuis une extraction neuve.
