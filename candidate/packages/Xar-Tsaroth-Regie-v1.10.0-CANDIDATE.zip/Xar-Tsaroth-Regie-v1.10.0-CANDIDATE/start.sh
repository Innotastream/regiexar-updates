#!/usr/bin/env sh
set -eu
XAR_APP_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$XAR_APP_DIR"

if ! command -v node >/dev/null 2>&1; then
  echo "Le socle applicatif 1.9 requiert encore Node.js 20 ou plus récent."
  echo "Le futur installateur Tauri l’intégrera sans installation manuelle."
  exit 1
fi

XAR_NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]")"
if [ "$XAR_NODE_MAJOR" -lt 20 ]; then
  echo "Votre version de Node.js est trop ancienne. Installez Node.js 20 LTS ou plus récent."
  exit 1
fi

exec node installer.mjs
