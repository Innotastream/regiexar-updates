# Régie du Seuil 1.10.0 — Candidate

## Portail MMO et fenêtre applicative

- Le launcher devient un portail fantastique complet : sceau runique multicouche, vortex, brumes, rayons, braises sur canvas, parallaxe, panneaux métalliques et séquence de progression enrichie.
- Une ambiance sonore synthétisée localement ajoute survols, validation, alerte de mise à jour, montée de progression et nappe discrète. Elle reste contrôlable, mémorisée localement et compatible avec les restrictions d’autoplay.
- La préférence système de réduction des mouvements coupe les particules et réduit toutes les animations ; le clavier, les lecteurs d’écran, les contrastes forcés et les petits écrans restent pris en charge.
- Sous Windows, le launcher puis la table MJ s’ouvrent dans une fenêtre Edge en mode application, sans onglet ni barre d’adresse. Chrome est utilisé en second choix et le navigateur par défaut reste un repli sûr.

## Continuité ChatGPT et sécurité

- Les boutons de la Forge demandent au serveur local d’ouvrir ChatGPT dans le navigateur système habituel : la connexion Google et l’extension appairée ne dépendent pas du moteur de la fenêtre dédiée.
- La nouvelle route est limitée au poste MJ local, à l’origine de la Régie et à `https://chatgpt.com/` ou une conversation `/c/` canonique. Les paramètres, fragments et domaines ressemblants sont refusés.
- Aucun cookie, identifiant Google, jeton ChatGPT ou secret n’est lu, transféré ou ajouté au build.

## Données et mises à jour

- Le programme continue de vivre dans son dossier applicatif dédié et toutes les chroniques restent dans le profil privé séparé.
- L’auto-update signé, le contrôle d’intégrité, le retour de sécurité et l’interdiction du rollback silencieux sont inchangés.

## Statut

Cette version reste **candidate** jusqu’à validation explicite de l’utilisateur. La 1.8.0 reste la dernière version stable et sa référence de sécurité demeure intacte.
