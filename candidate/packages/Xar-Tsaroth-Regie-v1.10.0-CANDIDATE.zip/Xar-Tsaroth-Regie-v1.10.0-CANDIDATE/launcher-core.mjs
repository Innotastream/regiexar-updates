import {
  closeSync,
  createReadStream,
  createWriteStream,
  existsSync,
  mkdirSync,
  openSync,
  readSync,
  lstatSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync
} from "node:fs";
import { createHash, createPublicKey, verify as verifySignature } from "node:crypto";
import { Transform, Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { createInflateRaw } from "node:zlib";
import path from "node:path";

export const INTEGRITY_MANIFEST_FILENAME = "release-integrity.json";
export const INTEGRITY_SCHEMA_VERSION = 1;
export const UPDATE_MANIFEST_SCHEMA_VERSION = 1;
export const UPDATE_ARCHIVE_MAX_ENTRIES = 20_000;
export const UPDATE_ARCHIVE_MAX_EXPANDED_SIZE = 4 * 1024 * 1024 * 1024;

const excludedReleasePaths = [
  /^(?:data|node_modules|captures|test-results|playwright-report)(?:\/|$)/,
  /^(?:\.git|\.agents|\.codex)(?:\/|$)/,
  /^\.env(?:$|\.(?!example$))/, 
  /(?:^|\/)\.DS_Store$/,
  /(?:^|\/)desktop\.ini$/i,
  /(?:^|\/)Thumbs\.db$/i,
  /\.zip$/i,
  new RegExp(`^${INTEGRITY_MANIFEST_FILENAME.replace(".", "\\.")}$`)
];

export function sha256File(filePath) {
  const hash = createHash("sha256");
  const descriptor = readFileSync(filePath);
  hash.update(descriptor);
  return hash.digest("hex");
}

function normalizedRelativePath(value) {
  const relative = String(value ?? "").replaceAll("\\", "/");
  if (!relative || relative.startsWith("/") || /^[a-zA-Z]:/.test(relative)) return null;
  const normalized = path.posix.normalize(relative);
  if (normalized === ".." || normalized.startsWith("../") || normalized.includes("\0")) return null;
  return normalized;
}

export function releasePathIsIncluded(relativePath) {
  const normalized = normalizedRelativePath(relativePath);
  return Boolean(normalized && !excludedReleasePaths.some((pattern) => pattern.test(normalized)));
}

export function listReleaseFiles(rootDirectory) {
  const root = path.resolve(rootDirectory);
  const files = [];
  const visit = (directory, relativeDirectory = "") => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const relative = path.posix.join(relativeDirectory, entry.name);
      if (!releasePathIsIncluded(relative)) continue;
      const absolute = path.join(directory, entry.name);
      if (entry.isSymbolicLink() || lstatSync(absolute).isSymbolicLink()) {
        throw new Error(`Lien symbolique interdit dans une livraison : ${relative}`);
      }
      if (entry.isDirectory()) visit(absolute, relative);
      else if (entry.isFile()) files.push(relative);
    }
  };
  visit(root);
  return files.sort((left, right) => left.localeCompare(right, "fr"));
}

export function loadApplicationRelease(rootDirectory) {
  const filePath = path.join(path.resolve(rootDirectory), "application.json");
  const release = JSON.parse(readFileSync(filePath, "utf8"));
  if (!release.applicationId || !/^\d+\.\d+\.\d+$/.test(String(release.version ?? ""))) {
    throw new Error("application.json ne contient pas une identité et une version applicative valides.");
  }
  return release;
}

export function createIntegrityManifest(rootDirectory, applicationRelease = loadApplicationRelease(rootDirectory)) {
  const root = path.resolve(rootDirectory);
  return {
    schemaVersion: INTEGRITY_SCHEMA_VERSION,
    applicationId: applicationRelease.applicationId,
    applicationVersion: applicationRelease.version,
    generatedAt: new Date().toISOString(),
    files: listReleaseFiles(root).map((relativePath) => {
      const absolutePath = path.join(root, ...relativePath.split("/"));
      return {
        path: relativePath,
        size: statSync(absolutePath).size,
        sha256: sha256File(absolutePath)
      };
    })
  };
}

export function writeIntegrityManifest(rootDirectory) {
  const root = path.resolve(rootDirectory);
  const manifest = createIntegrityManifest(root);
  writeFileSync(path.join(root, INTEGRITY_MANIFEST_FILENAME), `${JSON.stringify(manifest, null, 2)}\n`, { mode: 0o644 });
  return manifest;
}

export function verifyInstallation(rootDirectory, manifest = null) {
  const root = path.resolve(rootDirectory);
  let resolvedManifest = manifest;
  try {
    resolvedManifest ??= JSON.parse(readFileSync(path.join(root, INTEGRITY_MANIFEST_FILENAME), "utf8"));
  } catch {
    return { ok: false, checkedFiles: 0, missing: [], modified: [], unexpected: [], invalidEntries: [], reason: "manifest-missing" };
  }
  if (Number(resolvedManifest?.schemaVersion) !== INTEGRITY_SCHEMA_VERSION || !Array.isArray(resolvedManifest?.files)) {
    return { ok: false, checkedFiles: 0, missing: [], modified: [], unexpected: [], invalidEntries: [], reason: "manifest-invalid" };
  }
  try {
    const applicationRelease = loadApplicationRelease(root);
    if (resolvedManifest.applicationId !== applicationRelease.applicationId
      || resolvedManifest.applicationVersion !== applicationRelease.version) {
      return { ok: false, checkedFiles: 0, missing: [], modified: [], unexpected: [], invalidEntries: [], reason: "manifest-release-mismatch" };
    }
  } catch {
    return { ok: false, checkedFiles: 0, missing: [], modified: [], unexpected: [], invalidEntries: [], reason: "application-release-invalid" };
  }

  const missing = [];
  const modified = [];
  const invalidEntries = [];
  const knownEntries = new Set();
  for (const entry of resolvedManifest.files) {
    const relative = normalizedRelativePath(entry?.path);
    if (!relative || knownEntries.has(relative) || !releasePathIsIncluded(relative) || !/^[a-f0-9]{64}$/i.test(String(entry?.sha256 ?? ""))) {
      invalidEntries.push(String(entry?.path ?? ""));
      continue;
    }
    knownEntries.add(relative);
    const absolute = path.join(root, ...relative.split("/"));
    if (!existsSync(absolute) || !lstatSync(absolute).isFile()) {
      missing.push(relative);
      continue;
    }
    const size = statSync(absolute).size;
    if (size !== Number(entry.size) || sha256File(absolute) !== String(entry.sha256).toLowerCase()) modified.push(relative);
  }
  let unexpected = [];
  try {
    unexpected = listReleaseFiles(root).filter((relative) => !knownEntries.has(relative));
  } catch {
    invalidEntries.push("symlink");
  }
  return {
    ok: missing.length === 0 && modified.length === 0 && unexpected.length === 0 && invalidEntries.length === 0,
    checkedFiles: resolvedManifest.files.length,
    missing,
    modified,
    unexpected,
    invalidEntries,
    reason: null
  };
}

const integrityReasonLabels = {
  "manifest-missing": `${INTEGRITY_MANIFEST_FILENAME} absent ou illisible`,
  "manifest-invalid": `${INTEGRITY_MANIFEST_FILENAME} invalide`,
  "manifest-release-mismatch": "le manifeste ne correspond pas à cette version applicative",
  "application-release-invalid": "application.json absent ou invalide"
};

function summarizeIntegrityEntries(label, entries, limit = 5) {
  if (!Array.isArray(entries) || entries.length === 0) return null;
  const visible = entries.slice(0, limit).join(", ");
  const remainder = entries.length - Math.min(entries.length, limit);
  return `${label} : ${visible}${remainder > 0 ? ` (+${remainder})` : ""}`;
}

export function describeIntegrityFailure(report) {
  if (report?.ok) return "aucun écart";
  const details = [
    report?.reason ? integrityReasonLabels[report.reason] ?? `cause ${report.reason}` : null,
    summarizeIntegrityEntries("fichiers manquants", report?.missing),
    summarizeIntegrityEntries("fichiers modifiés", report?.modified),
    summarizeIntegrityEntries("fichiers inattendus", report?.unexpected),
    summarizeIntegrityEntries("entrées de manifeste invalides", report?.invalidEntries)
  ].filter(Boolean);
  return details.join(" ; ") || "écart d’intégrité non identifié";
}

function parsedVersion(value) {
  const match = /^(\d+)\.(\d+)\.(\d+)$/.exec(String(value ?? ""));
  if (!match) throw new Error(`Version applicative invalide : ${value}`);
  return match.slice(1).map(Number);
}

export function compareApplicationVersions(left, right) {
  const leftParts = parsedVersion(left);
  const rightParts = parsedVersion(right);
  for (let index = 0; index < 3; index += 1) {
    if (leftParts[index] !== rightParts[index]) return leftParts[index] < rightParts[index] ? -1 : 1;
  }
  return 0;
}

function requireHttpsUrl(value, label) {
  let parsed;
  try { parsed = new URL(String(value ?? "")); }
  catch { throw new Error(`${label} invalide.`); }
  if (parsed.protocol !== "https:") throw new Error(`${label} doit utiliser HTTPS.`);
  return parsed.toString();
}

export function canonicalUpdatePayload(manifest) {
  return JSON.stringify({
    schemaVersion: Number(manifest.schemaVersion),
    applicationId: String(manifest.applicationId),
    channel: String(manifest.channel),
    version: String(manifest.version),
    publishedAt: String(manifest.publishedAt),
    package: {
      url: String(manifest.package?.url),
      sha256: String(manifest.package?.sha256).toLowerCase(),
      size: Number(manifest.package?.size)
    }
  });
}

export function verifySignedUpdateManifest(candidate, { applicationId, publicKey, channel = null }) {
  if (!publicKey) throw new Error("Aucune clé publique de mise à jour n’est intégrée à cette application.");
  if (Number(candidate?.schemaVersion) !== UPDATE_MANIFEST_SCHEMA_VERSION) throw new Error("Format de manifeste de mise à jour inconnu.");
  if (candidate.applicationId !== applicationId) throw new Error("Cette mise à jour appartient à une autre application.");
  if (!candidate.channel || (channel && candidate.channel !== channel)) throw new Error("Cette mise à jour appartient à un autre canal.");
  parsedVersion(candidate.version);
  requireHttpsUrl(candidate.package?.url, "L’adresse du paquet");
  if (!/^[a-f0-9]{64}$/i.test(String(candidate.package?.sha256 ?? ""))) throw new Error("Empreinte du paquet invalide.");
  if (!Number.isSafeInteger(Number(candidate.package?.size)) || Number(candidate.package?.size) < 1) throw new Error("Taille du paquet invalide.");
  const signature = Buffer.from(String(candidate.signature ?? ""), "base64");
  if (!signature.length) throw new Error("Signature de mise à jour absente.");
  const trustedKey = createPublicKey(publicKey);
  const valid = verifySignature(null, Buffer.from(canonicalUpdatePayload(candidate)), trustedKey, signature);
  if (!valid) throw new Error("Signature de mise à jour invalide.");
  return {
    ...candidate,
    package: {
      ...candidate.package,
      url: requireHttpsUrl(candidate.package.url, "L’adresse du paquet"),
      sha256: String(candidate.package.sha256).toLowerCase(),
      size: Number(candidate.package.size)
    }
  };
}

export async function fetchSignedUpdateManifest(manifestUrl, trust, fetchImplementation = fetch) {
  const url = requireHttpsUrl(manifestUrl, "L’adresse du canal de mise à jour");
  const response = await fetchImplementation(url, { headers: { Accept: "application/json" }, redirect: "error" });
  if (!response.ok) throw new Error(`Le canal de mise à jour répond avec le statut ${response.status}.`);
  const text = await response.text();
  if (Buffer.byteLength(text) > 256 * 1024) throw new Error("Le manifeste de mise à jour est trop volumineux.");
  return verifySignedUpdateManifest(JSON.parse(text), trust);
}

export async function downloadVerifiedPackage(packageInfo, destinationPath, fetchImplementation = fetch, { onProgress = null } = {}) {
  const url = requireHttpsUrl(packageInfo?.url, "L’adresse du paquet");
  const expectedSize = Number(packageInfo?.size);
  const expectedHash = String(packageInfo?.sha256 ?? "").toLowerCase();
  if (!Number.isSafeInteger(expectedSize) || expectedSize < 1 || expectedSize > 2 * 1024 * 1024 * 1024) {
    throw new Error("Taille de paquet refusée.");
  }
  if (!/^[a-f0-9]{64}$/.test(expectedHash)) throw new Error("Empreinte de paquet invalide.");
  const response = await fetchImplementation(url, { redirect: "error" });
  if (!response.ok || !response.body) throw new Error(`Téléchargement impossible (${response.status}).`);
  const announcedSize = Number(response.headers.get("content-length") || expectedSize);
  if (announcedSize !== expectedSize) throw new Error("La taille annoncée du paquet ne correspond pas au manifeste signé.");

  const destination = path.resolve(destinationPath);
  mkdirSync(path.dirname(destination), { recursive: true, mode: 0o700 });
  const temporary = `${destination}.${process.pid}.partial`;
  const hash = createHash("sha256");
  let received = 0;
  const meter = new Transform({
    transform(chunk, _encoding, callback) {
      received += chunk.length;
      if (received > expectedSize) return callback(new Error("Le paquet reçu dépasse la taille signée."));
      hash.update(chunk);
      if (typeof onProgress === "function") onProgress({ received, total: expectedSize, percent: Math.min(100, Math.round((received / expectedSize) * 100)) });
      callback(null, chunk);
    }
  });
  try {
    await pipeline(Readable.fromWeb(response.body), meter, createWriteStream(temporary, { mode: 0o600 }));
    if (received !== expectedSize || hash.digest("hex") !== expectedHash) throw new Error("Le paquet téléchargé ne correspond pas à son empreinte signée.");
    rmSync(destination, { force: true });
    renameSync(temporary, destination);
    return { path: destination, size: received, sha256: expectedHash };
  } catch (error) {
    rmSync(temporary, { force: true });
    throw error;
  }
}

function readExactly(descriptor, length, position) {
  const buffer = Buffer.alloc(length);
  let offset = 0;
  while (offset < length) {
    const received = readSync(descriptor, buffer, offset, length - offset, position + offset);
    if (!received) throw new Error("Archive ZIP tronquée.");
    offset += received;
  }
  return buffer;
}

function locateEndOfCentralDirectory(descriptor, archiveSize) {
  const tailLength = Math.min(archiveSize, 65_557);
  const tail = readExactly(descriptor, tailLength, archiveSize - tailLength);
  for (let offset = tail.length - 22; offset >= 0; offset -= 1) {
    if (tail.readUInt32LE(offset) === 0x06054b50) return tail.subarray(offset);
  }
  throw new Error("Répertoire central ZIP introuvable.");
}

function readZipEntries(archivePath) {
  const descriptor = openSync(archivePath, "r");
  try {
    const archiveSize = statSync(archivePath).size;
    const endRecord = locateEndOfCentralDirectory(descriptor, archiveSize);
    const disk = endRecord.readUInt16LE(4);
    const centralDisk = endRecord.readUInt16LE(6);
    const entriesOnDisk = endRecord.readUInt16LE(8);
    const entryCount = endRecord.readUInt16LE(10);
    const centralSize = endRecord.readUInt32LE(12);
    const centralOffset = endRecord.readUInt32LE(16);
    if (disk !== 0 || centralDisk !== 0 || entriesOnDisk !== entryCount) throw new Error("Les archives ZIP multi-volumes sont refusées.");
    if (entryCount > UPDATE_ARCHIVE_MAX_ENTRIES) throw new Error("L’archive contient trop de fichiers.");
    if (entryCount === 0xffff || centralSize === 0xffffffff || centralOffset === 0xffffffff) throw new Error("Le format ZIP64 n’est pas pris en charge par ce launcher.");
    if (centralOffset + centralSize > archiveSize) throw new Error("Répertoire central ZIP invalide.");

    const entries = [];
    const seen = new Set();
    let cursor = centralOffset;
    let expandedSize = 0;
    for (let index = 0; index < entryCount; index += 1) {
      const header = readExactly(descriptor, 46, cursor);
      if (header.readUInt32LE(0) !== 0x02014b50) throw new Error("Entrée ZIP centrale invalide.");
      const flags = header.readUInt16LE(8);
      const compressionMethod = header.readUInt16LE(10);
      const compressedSize = header.readUInt32LE(20);
      const uncompressedSize = header.readUInt32LE(24);
      const filenameLength = header.readUInt16LE(28);
      const extraLength = header.readUInt16LE(30);
      const commentLength = header.readUInt16LE(32);
      const externalAttributes = header.readUInt32LE(38);
      const localHeaderOffset = header.readUInt32LE(42);
      if (compressedSize === 0xffffffff || uncompressedSize === 0xffffffff || localHeaderOffset === 0xffffffff) {
        throw new Error("Une entrée ZIP64 est refusée.");
      }
      if (flags & 0x1) throw new Error("Les archives ZIP chiffrées sont refusées.");
      if (![0, 8].includes(compressionMethod)) throw new Error(`Compression ZIP non prise en charge (${compressionMethod}).`);
      const rawName = readExactly(descriptor, filenameLength, cursor + 46);
      const decodedName = rawName.toString(flags & 0x0800 ? "utf8" : "latin1");
      const normalized = normalizedRelativePath(decodedName);
      if (!normalized) throw new Error("Chemin dangereux dans l’archive ZIP.");
      const collisionKey = normalized.toLocaleLowerCase("fr");
      if (seen.has(collisionKey)) throw new Error(`Chemin dupliqué dans l’archive : ${normalized}`);
      seen.add(collisionKey);
      const unixMode = (externalAttributes >>> 16) & 0xffff;
      if ((unixMode & 0o170000) === 0o120000) throw new Error(`Lien symbolique interdit dans la mise à jour : ${normalized}`);
      const directory = decodedName.endsWith("/") || (unixMode & 0o170000) === 0o040000;
      expandedSize += directory ? 0 : uncompressedSize;
      if (expandedSize > UPDATE_ARCHIVE_MAX_EXPANDED_SIZE) throw new Error("La taille décompressée de la mise à jour est excessive.");
      entries.push({
        path: normalized,
        directory,
        flags,
        compressionMethod,
        compressedSize,
        uncompressedSize,
        localHeaderOffset,
        mode: unixMode & 0o111 ? 0o755 : 0o644
      });
      cursor += 46 + filenameLength + extraLength + commentLength;
    }
    return entries;
  } finally {
    closeSync(descriptor);
  }
}

export async function extractZipArchive(archivePath, destinationDirectory, { onProgress = null } = {}) {
  const archive = path.resolve(archivePath);
  const destination = path.resolve(destinationDirectory);
  const entries = readZipEntries(archive);
  rmSync(destination, { recursive: true, force: true });
  mkdirSync(destination, { recursive: true, mode: 0o700 });
  const descriptor = openSync(archive, "r");
  let extracted = 0;
  try {
    for (const entry of entries) {
      const absolute = path.resolve(destination, ...entry.path.split("/"));
      if (absolute !== destination && !absolute.startsWith(`${destination}${path.sep}`)) throw new Error("Chemin ZIP hors destination.");
      if (entry.directory) {
        mkdirSync(absolute, { recursive: true, mode: 0o755 });
        continue;
      }
      const localHeader = readExactly(descriptor, 30, entry.localHeaderOffset);
      if (localHeader.readUInt32LE(0) !== 0x04034b50) throw new Error(`En-tête ZIP local invalide : ${entry.path}`);
      const localFilenameLength = localHeader.readUInt16LE(26);
      const localExtraLength = localHeader.readUInt16LE(28);
      const dataStart = entry.localHeaderOffset + 30 + localFilenameLength + localExtraLength;
      const dataEnd = dataStart + entry.compressedSize - 1;
      mkdirSync(path.dirname(absolute), { recursive: true, mode: 0o755 });
      let written = 0;
      const sizeGuard = new Transform({
        transform(chunk, _encoding, callback) {
          written += chunk.length;
          if (written > entry.uncompressedSize) return callback(new Error(`Fichier ZIP trop volumineux : ${entry.path}`));
          callback(null, chunk);
        }
      });
      const source = entry.compressedSize === 0
        ? Readable.from([])
        : createReadStream(archive, { start: dataStart, end: dataEnd, fd: descriptor, autoClose: false });
      const streams = entry.compressionMethod === 8
        ? [source, createInflateRaw(), sizeGuard, createWriteStream(absolute, { mode: entry.mode })]
        : [source, sizeGuard, createWriteStream(absolute, { mode: entry.mode })];
      await pipeline(...streams);
      if (written !== entry.uncompressedSize) throw new Error(`Taille décompressée invalide : ${entry.path}`);
      extracted += 1;
      if (typeof onProgress === "function") onProgress({ extracted, total: entries.filter((item) => !item.directory).length, path: entry.path });
    }
    return { entries: entries.map((entry) => entry.path), extractedFiles: extracted };
  } catch (error) {
    rmSync(destination, { recursive: true, force: true });
    throw error;
  } finally {
    closeSync(descriptor);
  }
}

function allExtractedPaths(rootDirectory) {
  const paths = [];
  const visit = (directory, relativeDirectory = "") => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const relative = path.posix.join(relativeDirectory, entry.name);
      const absolute = path.join(directory, entry.name);
      if (entry.isSymbolicLink() || lstatSync(absolute).isSymbolicLink()) throw new Error(`Lien symbolique interdit : ${relative}`);
      paths.push({ relative, directory: entry.isDirectory() });
      if (entry.isDirectory()) visit(absolute, relative);
    }
  };
  visit(rootDirectory);
  return paths;
}

export function locateExtractedApplicationRoot(stagingDirectory) {
  const staging = path.resolve(stagingDirectory);
  if (existsSync(path.join(staging, "application.json"))) return staging;
  const children = readdirSync(staging, { withFileTypes: true }).filter((entry) => entry.name !== "__MACOSX");
  const candidates = children.filter((entry) => entry.isDirectory() && existsSync(path.join(staging, entry.name, "application.json")));
  if (candidates.length !== 1 || children.some((entry) => entry.name !== candidates[0]?.name)) {
    throw new Error("Le ZIP doit contenir une seule application complète.");
  }
  return path.join(staging, candidates[0].name);
}

export function validateExtractedUpdate(applicationRoot, signedManifest, currentRelease, { allowSameVersion = false } = {}) {
  const root = path.resolve(applicationRoot);
  const nextRelease = loadApplicationRelease(root);
  if (nextRelease.applicationId !== currentRelease.applicationId || nextRelease.applicationId !== signedManifest.applicationId) {
    throw new Error("L’application extraite ne correspond pas à la Régie installée.");
  }
  if (nextRelease.version !== signedManifest.version) throw new Error("La version extraite ne correspond pas au manifeste signé.");
  if (nextRelease.channel !== signedManifest.channel) throw new Error("Le canal du paquet ne correspond pas au manifeste signé.");
  const comparison = compareApplicationVersions(currentRelease.version, nextRelease.version);
  if (comparison > 0 || (comparison === 0 && !allowSameVersion)) throw new Error("Cette mise à jour n’est pas plus récente que l’installation active.");

  for (const entry of allExtractedPaths(root)) {
    if (entry.directory) continue;
    if (entry.relative !== INTEGRITY_MANIFEST_FILENAME && !releasePathIsIncluded(entry.relative)) {
      throw new Error(`Fichier privé ou interdit dans le paquet : ${entry.relative}`);
    }
  }
  const integrity = verifyInstallation(root);
  if (!integrity.ok) throw new Error("Le contenu extrait ne correspond pas à son manifeste d’intégrité.");
  return { release: nextRelease, integrity };
}
