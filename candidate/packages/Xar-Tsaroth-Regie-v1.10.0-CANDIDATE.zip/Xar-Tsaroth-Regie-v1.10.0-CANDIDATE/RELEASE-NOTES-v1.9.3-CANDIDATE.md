# Régie du Seuil 1.9.3 — Candidate

## Correctif d’installation Windows

- Les fichiers `desktop.ini` que l’Explorateur Windows peut créer dans un dossier extrait sont reconnus comme métadonnées système inoffensives et ne provoquent plus un faux refus d’intégrité.
- Les vrais écarts restent bloqués : manifeste absent ou invalide, fichier applicatif manquant, modifié ou injecté.
- En cas de refus, l’installateur indique désormais la cause et les chemins concernés, puis rappelle de décompresser entièrement le ZIP.
- Deux tests de régression couvrent les métadonnées Windows et le diagnostic nominatif d’un fichier manquant.

## Parcours de validation prévu

- Installer le bootstrap 1.9.2 corrigé depuis un dossier entièrement extrait.
- Vérifier la détection de la 1.9.3 sur le canal candidate public signé.
- Appliquer la mise à jour et confirmer la relance ainsi que la conservation des données privées.

## Statut

Cette version reste **candidate** jusqu’à validation explicite de l’utilisateur. La 1.8.0 reste la dernière version stable et sa référence de sécurité demeure intacte.
