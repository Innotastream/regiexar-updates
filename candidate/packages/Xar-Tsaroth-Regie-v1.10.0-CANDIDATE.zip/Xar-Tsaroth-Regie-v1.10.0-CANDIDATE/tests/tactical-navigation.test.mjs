import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("les contrôles tactiques sont séparés, rétractables et accessibles en haut de la carte", async () => {
  const [html, app, styles] = await Promise.all([
    readFile(path.join(ROOT, "public", "index.html"), "utf8"),
    readFile(path.join(ROOT, "public", "app.js"), "utf8"),
    readFile(path.join(ROOT, "public", "styles.css"), "utf8")
  ]);

  assert.match(html, /id="tacticalCommandCenter"/);
  assert.match(html, /id="mapSetupStepStatus"/);
  assert.match(html, /id="tokenSetupStepStatus"/);
  assert.match(html, /id="combatSetupStepStatus"/);
  assert.match(html, /<details id="addTokenMenu"/);
  assert.match(html, /<details id="mapControlsDrawer"/);
  assert.match(html, /<details id="tokenInspectorDrawer"/);
  assert.match(html, /<details id="shareControlsDrawer"/);
  assert.match(html, /id="selectedTokenMenuStatus"[^>]*aria-live="polite"/);
  assert.doesNotMatch(html, /class="panel map-sidebar"/);

  const mapDrawerStart = html.indexOf('id="mapControlsDrawer"');
  const tokenDrawerStart = html.indexOf('id="tokenInspectorDrawer"');
  const shareDrawerStart = html.indexOf('id="shareControlsDrawer"');
  const combatLayoutStart = html.indexOf('class="combat-layout"');
  assert.ok(mapDrawerStart > 0 && tokenDrawerStart > mapDrawerStart && shareDrawerStart > tokenDrawerStart);
  assert.ok(combatLayoutStart > shareDrawerStart);
  const mapDrawer = html.slice(mapDrawerStart, tokenDrawerStart);
  const tokenDrawer = html.slice(tokenDrawerStart, shareDrawerStart);
  const shareDrawer = html.slice(shareDrawerStart, combatLayoutStart);
  assert.match(mapDrawer, /id="toggleGridButton"/);
  assert.match(mapDrawer, /id="gridSize"/);
  assert.match(mapDrawer, /id="clearMapButton"/);
  assert.doesNotMatch(mapDrawer, /id="tokenInspector"/);
  assert.match(tokenDrawer, /id="tokenInspector"/);
  assert.doesNotMatch(tokenDrawer, /id="discordCaptureMessage"/);
  assert.match(shareDrawer, /id="discordCaptureMessage"/);

  assert.match(app, /function bindTacticalMenus\(\)/);
  assert.match(app, /function openTacticalDrawer\(id/);
  assert.match(app, /function renderTacticalCommandCenter\(\)/);
  assert.match(app, /closeTacticalMenus\(\{ except: drawer \}\)/);
  assert.match(app, /role="button" tabindex="0" aria-pressed=/);
  assert.match(app, /\["Enter", " "\]\.includes\(event\.key\)/);
  assert.match(app, /if \(closeTacticalMenus\(\)\) return/);

  const combatLayout = styles.match(/\.combat-layout\s*\{([^}]*)\}/s)?.[1] || "";
  assert.match(combatLayout, /grid-template-columns:\s*minmax\(480px, 1fr\) 300px/);
  assert.match(styles, /\.tactical-drawer-panel\s*\{[^}]*position:\s*absolute/s);
  assert.match(styles, /@media \(max-width: 980px\)[\s\S]*?\.tactical-drawer-panel,[\s\S]*?position:\s*static/);
  assert.match(styles, /summary:focus-visible/);
});
