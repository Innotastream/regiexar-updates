import test from "node:test";
import assert from "node:assert/strict";
import {
  applyPercentage,
  evaluateTacticalExpression,
  percentageOf,
  roundCombatResult
} from "../public/tactical-calculator.js";

test("l’arrondi tactique bascule à partir de la décimale 0,5", () => {
  assert.equal(roundCombatResult(52.4), 52);
  assert.equal(roundCombatResult(52.5), 53);
  assert.equal(roundCombatResult(52.6), 53);
  assert.equal(roundCombatResult(8.1), 8);
  assert.equal(roundCombatResult(8.5), 9);
});

test("les pourcentages rapides donnent la valeur exacte et la valeur arrondie", () => {
  assert.deepEqual(percentageOf(15, 54), { exact: 8.1, rounded: 8 });
  assert.deepEqual(applyPercentage(15, 54, "add"), { exact: 62.1, rounded: 62, delta: 8.1 });
  assert.deepEqual(applyPercentage(15, 54, "subtract"), { exact: 45.9, rounded: 46, delta: 8.1 });
});

test("le calcul libre accepte la notation française sans exécuter de code", () => {
  assert.deepEqual(evaluateTacticalExpression("15 % de 54"), { exact: 8.1, rounded: 8 });
  assert.deepEqual(evaluateTacticalExpression("(52,6 + 10) ÷ 2"), { exact: 31.3, rounded: 31 });
  assert.deepEqual(evaluateTacticalExpression("54 × 1,15"), { exact: 62.099999999999994, rounded: 62 });
  assert.throws(() => evaluateTacticalExpression("globalThis.process.exit()"));
  assert.throws(() => evaluateTacticalExpression("10 / 0"), /Division par zéro/);
});
