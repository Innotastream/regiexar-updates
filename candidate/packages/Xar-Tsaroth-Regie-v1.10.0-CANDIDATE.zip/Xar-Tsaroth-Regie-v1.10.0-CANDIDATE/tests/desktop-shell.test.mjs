import test from "node:test";
import assert from "node:assert/strict";
import {
  dedicatedWindowCommand,
  normalizeChatGptExternalUrl,
  normalizeLocalApplicationUrl,
  resolveApplicationBrowser,
  systemBrowserCommand,
  windowsApplicationBrowserCandidates
} from "../desktop-shell.mjs";

const WINDOWS_ENVIRONMENT = {
  ProgramFiles: "C:\\Program Files",
  "ProgramFiles(x86)": "C:\\Program Files (x86)",
  LOCALAPPDATA: "C:\\Users\\MJ\\AppData\\Local"
};

test("la fenêtre applicative refuse toute adresse non locale", () => {
  assert.equal(normalizeLocalApplicationUrl("http://127.0.0.1:4173/#secret"), "http://127.0.0.1:4173/");
  assert.throws(() => normalizeLocalApplicationUrl("https://example.org/"), /uniquement une adresse HTTP locale/);
  assert.throws(() => normalizeLocalApplicationUrl("file:///C:/secret.txt"), /uniquement une adresse HTTP locale/);
});

test("l’ouverture externe accepte uniquement ChatGPT sans paramètres parasites", () => {
  assert.equal(normalizeChatGptExternalUrl("https://chatgpt.com/"), "https://chatgpt.com/");
  assert.equal(normalizeChatGptExternalUrl("https://chatgpt.com/c/conversation_123?utm=secret#fragment"), "https://chatgpt.com/c/conversation_123");
  assert.equal(normalizeChatGptExternalUrl("https://chatgpt.com.evil.example/c/conversation_123"), "");
  assert.equal(normalizeChatGptExternalUrl("https://chatgpt.com/g/gpt-prive"), "");
});

test("Microsoft Edge est choisi en priorité pour la fenêtre Windows dédiée", () => {
  const candidates = windowsApplicationBrowserCandidates(WINDOWS_ENVIRONMENT);
  const expectedEdge = candidates.find((candidate) => candidate.engine === "Microsoft Edge");
  const browser = resolveApplicationBrowser({
    platform: "win32",
    environment: WINDOWS_ENVIRONMENT,
    fileExists: (filename) => filename === expectedEdge.executable
  });
  assert.deepEqual(browser, expectedEdge);
  const descriptor = dedicatedWindowCommand("http://127.0.0.1:4169", {
    platform: "win32",
    environment: WINDOWS_ENVIRONMENT,
    fileExists: (filename) => filename === expectedEdge.executable
  });
  assert.equal(descriptor.engine, "Microsoft Edge");
  assert.ok(descriptor.args.includes("--app=http://127.0.0.1:4169/"));
  assert.ok(descriptor.args.some((argument) => argument.startsWith("--window-size=")));
  assert.ok(descriptor.args.every((argument) => !argument.startsWith("--user-data-dir=")));
});

test("Chrome prend le relais si Edge est absent", () => {
  const candidates = windowsApplicationBrowserCandidates(WINDOWS_ENVIRONMENT);
  const expectedChrome = candidates.find((candidate) => candidate.engine === "Google Chrome");
  const browser = resolveApplicationBrowser({
    platform: "win32",
    environment: WINDOWS_ENVIRONMENT,
    fileExists: (filename) => filename === expectedChrome.executable
  });
  assert.deepEqual(browser, expectedChrome);
});

test("Windows ouvre le navigateur système sans passer par un shell cmd", () => {
  const descriptor = systemBrowserCommand("https://chatgpt.com/c/conversation_123", "win32");
  assert.equal(descriptor.command, "rundll32.exe");
  assert.deepEqual(descriptor.args, ["url.dll,FileProtocolHandler", "https://chatgpt.com/c/conversation_123"]);
});
