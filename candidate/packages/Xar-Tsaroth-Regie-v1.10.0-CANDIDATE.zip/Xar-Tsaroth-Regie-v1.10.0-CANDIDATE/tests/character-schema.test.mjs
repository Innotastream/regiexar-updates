import test from "node:test";
import assert from "node:assert/strict";
import {
  CHARACTER_SCHEMA_ID,
  CHARACTER_SCHEMA_VERSION,
  UnsupportedCharacterSchemaVersionError,
  migrateCharacterSheet
} from "../public/character-schema.js";

test("une fiche historique est convertie sans perdre ses champs métier", () => {
  const result = migrateCharacterSheet({
    id: "character-legacy",
    ownerPlayerId: "player-old",
    name: "Hira",
    hp: 12,
    maxHp: 20,
    mana: 4,
    maxMana: 9,
    fatigueCurrent: 3,
    privateNotes: "Secret préservé",
    customFutureField: { kept: true },
    _updatedAt: 42
  });

  assert.equal(result.fromVersion, 0);
  assert.equal(result.toVersion, CHARACTER_SCHEMA_VERSION);
  assert.deepEqual(result.appliedMigrations, ["0->1"]);
  assert.equal(result.character.characterSchema, CHARACTER_SCHEMA_ID);
  assert.deepEqual(result.character.resources, { hp: 12, maxHp: 20, mana: 4, maxMana: 9 });
  assert.equal(result.character.fatigue.current, 3);
  assert.equal(result.character.secret.notes, "Secret préservé");
  assert.deepEqual(result.character.customFutureField, { kept: true });
  assert.equal("privateNotes" in result.character, false);
});

test("une fiche au format courant reste idempotente", () => {
  const source = {
    characterSchema: CHARACTER_SCHEMA_ID,
    characterSchemaVersion: CHARACTER_SCHEMA_VERSION,
    id: "character-current",
    ownerPlayerId: "player-a",
    name: "Krael",
    resources: { hp: 19, maxHp: 24, mana: 0, maxMana: 0 },
    secret: { notes: "Conserver" }
  };
  const result = migrateCharacterSheet(source, { ownerPlayerId: "player-a" });
  assert.equal(result.changed, false);
  assert.deepEqual(result.character, source);
});

test("une ancienne application refuse d’écraser une fiche issue d’un schéma futur", () => {
  assert.throws(
    () => migrateCharacterSheet({ id: "future", characterSchemaVersion: CHARACTER_SCHEMA_VERSION + 1 }),
    UnsupportedCharacterSchemaVersionError
  );
});
