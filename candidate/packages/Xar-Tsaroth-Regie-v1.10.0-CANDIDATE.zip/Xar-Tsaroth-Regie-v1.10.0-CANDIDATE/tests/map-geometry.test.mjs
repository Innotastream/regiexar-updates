import test from "node:test";
import assert from "node:assert/strict";
import { computeMapGeometry, mapPanFromDrag, mapPointFromClient, mapTokenScreenPosition, normalizedMap, snapMapPercentPoint } from "../public/map-geometry.js";

test("la map, la grille et les tokens partagent une géométrie stable", () => {
  const map = { naturalWidth: 1600, naturalHeight: 900, zoom: 2, panX: 10, panY: -5, grid: true, gridSize: 80 };
  const geometry = computeMapGeometry(1000, 700, map);
  assert.equal(geometry.fitWidth, 1000);
  assert.equal(geometry.fitHeight, 562.5);
  assert.equal(geometry.worldWidth, 2000);
  assert.equal(geometry.worldHeight, 1125);
  assert.equal(geometry.centerX, 600);
  assert.equal(geometry.centerY, 321.875);
  assert.equal(geometry.gridBaseSize, 50);
  assert.equal(geometry.gridScreenSize, 100);
  assert.equal(geometry.gridOffsetScreenX, 0);
  assert.equal(geometry.gridOffsetScreenY, 0);

  const token = mapTokenScreenPosition({ x: 25, y: 60, size: 64 }, geometry);
  assert.deepEqual(token, { x: 100, y: 434.375, size: 128 });

  const worldRect = { left: -400, top: -240.625, width: 2000, height: 1125 };
  assert.deepEqual(mapPointFromClient(100, 434.375, worldRect, map), { x: 27.5, y: 57.778 });
});

test("les limites de zoom et de grille sont appliquées", () => {
  assert.deepEqual(normalizedMap({ zoom: 99, gridSize: 3, panX: 999, panY: -999 }), {
    naturalWidth: 1600,
    naturalHeight: 900,
    zoom: 4.5,
    panX: 150,
    panY: -150,
    gridSize: 12,
    gridOffsetX: 0,
    gridOffsetY: 0
  });
});

test("l’étalonnage décale la grille et l’aimantation vise le centre des cases", () => {
  const map = { naturalWidth: 1000, naturalHeight: 500, zoom: 2, grid: true, gridSize: 50, gridOffsetX: 10, gridOffsetY: -5 };
  const geometry = computeMapGeometry(1000, 500, map);
  assert.equal(geometry.gridBaseSize, 50);
  assert.equal(geometry.gridOffsetBaseX, 10);
  assert.equal(geometry.gridOffsetBaseY, -5);
  assert.equal(geometry.gridOffsetScreenX, 20);
  assert.equal(geometry.gridOffsetScreenY, -10);
  assert.deepEqual(mapPointFromClient(200, 200, { left: 0, top: 0, width: 2000, height: 1000 }, map), { x: 8.5, y: 24 });
  assert.deepEqual(snapMapPercentPoint(50, 50, map), { x: 48.5, y: 54 });
});

test("l’aimantation reste au centre d’une case même sur les bords de la map", () => {
  const map = { naturalWidth: 1000, naturalHeight: 500, grid: true, gridSize: 50, gridOffsetX: 10, gridOffsetY: -5 };
  assert.deepEqual(snapMapPercentPoint(0, 0, map), { x: 3.5, y: 4 });
  assert.deepEqual(snapMapPercentPoint(100, 100, map), { x: 98.5, y: 94 });
  assert.deepEqual(snapMapPercentPoint(23.41, 78.92, { ...map, grid: false }), { x: 23.41, y: 78.92 });
});

test("le glissement panoramique déplace la map dans son cadre", () => {
  assert.deepEqual(mapPanFromDrag({ panX: 10, panY: -5 }, 125, -56.25, 1000, 562.5), {
    panX: 22.5,
    panY: -15
  });
  assert.deepEqual(mapPanFromDrag({ panX: 149, panY: -149 }, 1000, -1000, 100, 100), {
    panX: 150,
    panY: -150
  });
});
