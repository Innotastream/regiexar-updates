import test from "node:test";
import assert from "node:assert/strict";
import {
  appendManagedFile,
  cleanupPlan,
  emptyOvhManifest,
  isLegacyRegieRemoteName,
  isManagedRemoteName,
  managedRemoteName,
  normalizeOvhManifest
} from "../ovh-media-registry.mjs";

function entry(remoteName, buildVersion, keepAcrossBuilds = false) {
  return {
    id: remoteName,
    remoteName,
    originalName: "vision.webp",
    contentType: "image/webp",
    size: 42,
    buildVersion,
    createdAt: "2026-08-16T12:00:00.000Z",
    keepAcrossBuilds
  };
}

test("le registre OVH ne reconnaît que les fichiers créés par la Régie", () => {
  const generated = managedRemoteName("Vision finale.webp", "image/webp");
  assert.equal(isManagedRemoteName(generated), true);
  assert.equal(isManagedRemoteName("../www/index.html"), false);
  assert.equal(isManagedRemoteName("portrait-manuel.webp"), false);
  assert.equal(isLegacyRegieRemoteName("vision-de-xar-202608161545.webp"), true);
  assert.equal(isLegacyRegieRemoteName("portrait-manuel.webp"), false);
  assert.equal(isLegacyRegieRemoteName("xar-regie-v1-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.webp"), false);
});

test("le changement de build ne supprime que les médias obsolètes non conservés", () => {
  const oldName = "xar-regie-v1-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.webp";
  const currentName = "xar-regie-v1-bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.png";
  const pinnedName = "xar-regie-v1-cccccccccccccccccccccccccccccccc.jpg";
  let manifest = emptyOvhManifest();
  manifest = appendManagedFile(manifest, entry(oldName, "1.2.0"));
  manifest = appendManagedFile(manifest, entry(currentName, "1.2.1"));
  manifest = appendManagedFile(manifest, entry(pinnedName, "1.1.1", true));
  const plan = cleanupPlan(manifest, "1.2.1");
  assert.deepEqual(plan.obsolete.map((item) => item.remoteName), [oldName]);
  assert.deepEqual(plan.retained.map((item) => item.remoteName), [currentName, pinnedName]);
});

test("un registre falsifié ne peut jamais viser www ou un fichier manuel", () => {
  const manifest = normalizeOvhManifest({
    schemaVersion: 1,
    files: [
      entry("xar-regie-v1-dddddddddddddddddddddddddddddddd.webp", "1.2.0"),
      entry("../www/index.html", "1.2.0"),
      entry("photo-famille.png", "1.2.0")
    ]
  });
  assert.deepEqual(manifest.files.map((item) => item.remoteName), ["xar-regie-v1-dddddddddddddddddddddddddddddddd.webp"]);
});
