import test from "node:test";
import assert from "node:assert/strict";
import {
  createCombatSnapshot,
  createEmptyMapState,
  prepareSceneCombats,
  switchSceneCombat
} from "../public/scene-state.js";

test("chaque scène possède un combat indépendant", () => {
  const first = createCombatSnapshot();
  const second = createCombatSnapshot();
  first.map.tokens.push({ id: "garde" });
  assert.equal(second.map.tokens.length, 0);
});

test("changer de scène sauvegarde le combat courant et charge celui de destination", () => {
  const scenes = [
    { id: "scene-a", name: "Cour" , combat: createCombatSnapshot() },
    { id: "scene-b", name: "Crypte", combat: createCombatSnapshot({ ...createEmptyMapState(), backgroundName: "crypte.webp", tokens: [{ id: "ombre" }] }, { order: ["ombre"], currentIndex: 0, round: 3 }) }
  ];
  const currentMap = { ...createEmptyMapState(), backgroundName: "cour.webp", tokens: [{ id: "garde" }] };
  const switched = switchSceneCombat({
    scenes,
    activeSceneId: "scene-a",
    nextSceneId: "scene-b",
    map: currentMap,
    initiative: { order: ["garde"], currentIndex: 0, round: 2 }
  });

  assert.equal(switched.scenes.find((scene) => scene.id === "scene-a").combat.map.backgroundName, "cour.webp");
  assert.deepEqual(switched.scenes.find((scene) => scene.id === "scene-a").combat.initiative.order, ["garde"]);
  assert.equal(switched.map.backgroundName, "crypte.webp");
  assert.deepEqual(switched.map.tokens.map((token) => token.id), ["ombre"]);
  assert.equal(switched.initiative.round, 3);

  switched.map.tokens.push({ id: "spectre" });
  assert.deepEqual(switched.scenes.find((scene) => scene.id === "scene-b").combat.map.tokens.map((token) => token.id), ["ombre"]);
});

test("la migration attribue l’ancien combat global à la scène active sans le recopier partout", () => {
  const map = { ...createEmptyMapState(), backgroundName: "ancienne-map.webp", tokens: [{ id: "ancien" }] };
  const scenes = prepareSceneCombats(
    [{ id: "scene-1" }, { id: "scene-2" }],
    { activeSceneId: "scene-2", currentMap: map, currentInitiative: { order: ["ancien"], currentIndex: 0, round: 4 }, migrateLegacyCombat: true }
  );
  assert.equal(scenes[0].combat.map.backgroundName, "");
  assert.equal(scenes[1].combat.map.backgroundName, "ancienne-map.webp");
  assert.equal(scenes[1].combat.initiative.round, 4);
});
