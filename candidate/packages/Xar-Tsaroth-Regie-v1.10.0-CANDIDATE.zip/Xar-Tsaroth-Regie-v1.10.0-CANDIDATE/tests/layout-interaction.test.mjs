import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("le viewport défile au centre et la map ne déclenche pas le drag natif", async () => {
  const [styles, app, html] = await Promise.all([
    readFile(path.join(ROOT, "public", "styles.css"), "utf8"),
    readFile(path.join(ROOT, "public", "app.js"), "utf8"),
    readFile(path.join(ROOT, "public", "index.html"), "utf8")
  ]);

  const appFrame = styles.match(/\.app-frame\s*\{([^}]*)\}/s)?.[1] || "";
  const workspace = styles.match(/\.workspace\s*\{([^}]*)\}/s)?.[1] || "";
  const mainContent = styles.match(/\.main-content\s*\{([^}]*)\}/s)?.[1] || "";
  assert.match(appFrame, /height:\s*100dvh/);
  assert.match(appFrame, /overflow:\s*hidden/);
  assert.match(workspace, /overflow:\s*hidden/);
  assert.match(mainContent, /overflow:\s*auto/);
  assert.match(styles, /@media \(max-width: 980px\)[\s\S]*?\.app-frame \{[^}]*height:\s*auto/);
  assert.match(styles, /\.battlefield \{[\s\S]*?-webkit-user-drag:\s*none/);
  assert.match(styles, /\.map-world-image \{[\s\S]*?-webkit-user-drag:\s*none/);
  assert.match(html, /id="mapWorldImage"[^>]*draggable="false"/);
  assert.match(app, /addEventListener\("dragstart", \(event\) => event\.preventDefault\(\)\)/);
  assert.match(app, /mapPanFromDrag/);
  assert.match(html, /id="referenceFileInput"[^>]*multiple/);
  assert.match(html, /id="sceneRail"/);
  assert.match(html, /id="openTokenLibraryButton"/);
  assert.match(styles, /\.workspace\.scene-rail-hidden/);
  assert.match(app, /tabName !== "regie"/);
  assert.match(app, /switchSceneCombat/);
  assert.match(app, /saveTokenToLibrary/);
  assert.match(app, /summonTokenTemplate/);
  assert.doesNotMatch(html, /id="addInitiativeEntry"/);
  assert.doesNotMatch(html, /id="fitMapButton"/);
  assert.match(app, /data-remove-reference-file/);
  assert.match(app, /revealDetailsToPlayers/);
  assert.match(app, /publicDetailsVisible && token\.maxHp > 0/);
  assert.match(app, /tokenEditMaxMana/);
  assert.match(app, /data-token-stat-row/);
  assert.match(html, /id="toggleTacticalSyncButton"/);
  assert.match(html, /id="gameModeStatus"/);
  assert.doesNotMatch(html, /id="togglePlayerMovementMode"/);
  assert.match(html, /id="calculatorExpression"/);
  assert.match(html, /id="percentageRate"/);
  assert.match(html, /id="newCombatButton"/);
  assert.match(html, /id="endCombatButton"/);
  assert.match(html, /id="addCombatShortcut"/);
  assert.match(html, /id="addActionTimerButton"/);
  assert.match(app, /sortInitiativeTokenIds/);
  assert.match(app, /state\.tacticalSync\.playerMovementMode = "free"/);
  assert.match(app, /removeTokenFromInitiative/);
  assert.match(app, /rollTokenInitiative/);
  assert.match(app, /state\.initiative\.active !== true/);
  assert.match(styles, /\.tactical-pause-banner/);
  assert.match(styles, /\.tactical-calculator/);
  assert.match(styles, /\.action-timer-card/);
});
