import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import {
  USER_CHARACTER_STORE_ID,
  USER_CHARACTER_STORE_SCHEMA_VERSION,
  UserCharacterStorage,
  userCharacterStorePath
} from "../character-storage.mjs";
import { CHARACTER_SCHEMA_VERSION } from "../public/character-schema.js";

function legacySession(hp = 7, updatedAt = 10) {
  return {
    schemaVersion: 7,
    players: [{ id: "player-a", name: "Alice", accessToken: "private-token" }],
    characters: [{
      id: "character-a",
      ownerPlayerId: "player-a",
      name: "Hira",
      hp,
      maxHp: 20,
      privateNotes: "Secret",
      _updatedAt: updatedAt
    }]
  };
}

test("chaque joueur reçoit un stockage de fiches distinct, hors du build", async (context) => {
  const dataDirectory = await mkdtemp(path.join(tmpdir(), "xar-user-storage-"));
  context.after(() => rm(dataDirectory, { recursive: true, force: true }));
  const storage = new UserCharacterStorage(dataDirectory, {
    applicationVersion: "1.8.0",
    now: () => new Date("2026-08-17T10:00:00.000Z")
  });
  const hydrated = storage.hydrateSession(legacySession());
  const filePath = userCharacterStorePath(dataDirectory, "player-a");
  const stored = JSON.parse(await readFile(filePath, "utf8"));

  assert.equal(hydrated.changed, true);
  assert.equal(stored.store, USER_CHARACTER_STORE_ID);
  assert.equal(stored.schemaVersion, USER_CHARACTER_STORE_SCHEMA_VERSION);
  assert.equal(stored.characterSchemaVersion, CHARACTER_SCHEMA_VERSION);
  assert.equal(stored.ownerPlayerId, "player-a");
  assert.equal(stored.characters[0].resources.hp, 7);
  assert.equal(stored.characters[0].secret.notes, "Secret");
  assert.equal(JSON.stringify(stored).includes("private-token"), false);
});

test("le stockage utilisateur restaure une fiche plus récente après changement de build", async (context) => {
  const dataDirectory = await mkdtemp(path.join(tmpdir(), "xar-user-restore-"));
  context.after(() => rm(dataDirectory, { recursive: true, force: true }));
  const firstStorage = new UserCharacterStorage(dataDirectory, { applicationVersion: "1.8.0" });
  const first = firstStorage.hydrateSession(legacySession(11, 50)).state;
  firstStorage.persistSession(first);

  const nextBuildState = legacySession(2, 20);
  const nextStorage = new UserCharacterStorage(dataDirectory, { applicationVersion: "1.9.0" });
  const restored = nextStorage.hydrateSession(nextBuildState);
  assert.equal(restored.state.characters[0].resources.hp, 11);
  assert.equal(restored.state.characters[0]._updatedAt, 50);

  restored.state.characters[0].resources.hp = 15;
  restored.state.characters[0]._updatedAt = 60;
  nextStorage.persistSession(restored.state);
  const saved = JSON.parse(await readFile(userCharacterStorePath(dataDirectory, "player-a"), "utf8"));
  assert.equal(saved.characters[0].resources.hp, 15);
  assert.equal(saved.applicationVersion, "1.9.0");
});

test("une migration de stockage crée une sauvegarde avant conversion", async (context) => {
  const dataDirectory = await mkdtemp(path.join(tmpdir(), "xar-user-migration-"));
  context.after(() => rm(dataDirectory, { recursive: true, force: true }));
  const storePath = userCharacterStorePath(dataDirectory, "player-a");
  await mkdir(path.dirname(storePath), { recursive: true });
  await writeFile(storePath, JSON.stringify([{ id: "character-a", name: "Ancienne", hp: 6, maxHp: 12, _updatedAt: 30 }]));
  const storage = new UserCharacterStorage(dataDirectory, {
    applicationVersion: "1.8.0",
    now: () => new Date("2026-08-17T11:00:00.000Z")
  });
  const result = storage.hydrateSession(legacySession(1, 1));
  const backups = await readdir(path.join(path.dirname(storePath), "backups"));

  assert.equal(result.state.characters[0].resources.hp, 6);
  assert.deepEqual(backups, ["characters-before-migration-2026-08-17T11-00-00-000Z.json"]);
  assert.equal(result.status.migrationsApplied >= 1, true);
});

test("un stockage futur ou illisible est conservé et jamais écrasé", async (context) => {
  const dataDirectory = await mkdtemp(path.join(tmpdir(), "xar-user-future-"));
  context.after(() => rm(dataDirectory, { recursive: true, force: true }));
  const storePath = userCharacterStorePath(dataDirectory, "player-a");
  await mkdir(path.dirname(storePath), { recursive: true });
  const futureStore = JSON.stringify({
    store: USER_CHARACTER_STORE_ID,
    schemaVersion: USER_CHARACTER_STORE_SCHEMA_VERSION + 1,
    ownerPlayerId: "player-a",
    characters: [{ id: "future" }]
  });
  await writeFile(storePath, futureStore);
  const storage = new UserCharacterStorage(dataDirectory, { applicationVersion: "1.8.0" });
  const hydrated = storage.hydrateSession(legacySession());
  storage.persistSession(hydrated.state);

  assert.equal(await readFile(storePath, "utf8"), futureStore);
  assert.equal(hydrated.status.warnings.length, 1);
});
