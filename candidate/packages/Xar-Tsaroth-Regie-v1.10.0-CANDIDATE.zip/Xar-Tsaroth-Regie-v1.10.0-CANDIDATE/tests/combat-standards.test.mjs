import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  BATTLEMAP_SCALE_GUIDE,
  DEFAULT_GRID_SIZE,
  DEFAULT_TOKEN_SIZE,
  TOKEN_SIZE_PRESETS,
  withBattlemapScaleGuide
} from "../public/combat-standards.js";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("les standards de grille, de portes et de créatures sont cohérents", () => {
  assert.equal(DEFAULT_GRID_SIZE, 50);
  assert.equal(DEFAULT_TOKEN_SIZE, 30);
  assert.deepEqual(TOKEN_SIZE_PRESETS.map(({ label, size }) => [label, size]), [
    ["Petite", 20],
    ["Normale", 30],
    ["Grosse", 60],
    ["Très grosse", 90]
  ]);
  assert.match(BATTLEMAP_SCALE_GUIDE, /50 px par case/);
  assert.match(BATTLEMAP_SCALE_GUIDE, /porte double exactement 2 cases \(100 px\)/);
  assert.match(BATTLEMAP_SCALE_GUIDE, /aucune grille/);

  const battlemapPrompt = withBattlemapScaleGuide("Carte de combat vue strictement du dessus");
  assert.match(battlemapPrompt, /50 px par case/);
  assert.equal((battlemapPrompt.match(/50 px par case/g) ?? []).length, 1);
  assert.equal(withBattlemapScaleGuide("Portrait cinématique"), "Portrait cinématique");
});

test("les contrôles Discord et l’étalonnage sont disponibles dans l’interface", async () => {
  const [html, app, styles] = await Promise.all([
    readFile(path.join(ROOT, "public", "index.html"), "utf8"),
    readFile(path.join(ROOT, "public", "app.js"), "utf8"),
    readFile(path.join(ROOT, "public", "styles.css"), "utf8")
  ]);

  assert.match(html, /id="gridSize"[^>]*value="50"/);
  assert.match(html, /id="gridOffsetX"/);
  assert.match(html, /id="gridOffsetY"/);
  assert.match(html, /id="calibrateGridButton"/);
  assert.match(html, /id="discordCaptureMessage"/);
  assert.match(html, /id="discordIncludeCurrentTurn"/);
  assert.match(app, /function mapDiscordContent\(\)/);
  assert.match(app, /state\.discordCapture\.message/);
  assert.match(app, /gridCalibrationMode/);
  assert.match(styles, /background-position:\s*var\(--grid-offset-x/);
  assert.match(styles, /\.battlefield\.calibrating-grid \.token-layer/);
});
