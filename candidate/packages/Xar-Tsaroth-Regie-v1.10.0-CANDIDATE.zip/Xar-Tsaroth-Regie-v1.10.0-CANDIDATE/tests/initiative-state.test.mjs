import test from "node:test";
import assert from "node:assert/strict";
import {
  normalizeInitiativeState,
  sanitizeInitiativeOrder,
  sortInitiativeTokenIds
} from "../public/initiative-state.js";

const tokens = [
  { id: "garde", name: "Garde", initiative: 42 },
  { id: "ombre", name: "Ombre", initiative: 12 },
  { id: "mage", name: "Mage", initiative: null }
];

test("la migration v1.6 retire l’ancien roster automatique quand le combat est inactif", () => {
  const migrated = normalizeInitiativeState({
    order: ["garde", "ombre", "mage"],
    currentIndex: 2,
    round: 4,
    active: false,
    turnsStarted: true
  }, tokens, { inferLegacyActive: true, clearLegacyInactiveRoster: true });

  assert.deepEqual(migrated.order, []);
  assert.equal(migrated.currentIndex, 0);
  assert.equal(migrated.active, false);
  assert.equal(migrated.turnsStarted, false);
});

test("une liste volontaire reste visible en mode libre dans le nouveau schéma", () => {
  const prepared = normalizeInitiativeState({
    order: ["ombre"],
    currentIndex: 0,
    round: 1,
    active: false
  }, tokens);

  assert.deepEqual(prepared.order, ["ombre"]);
  assert.equal(prepared.active, false);
  assert.equal(prepared.turnsStarted, false);
});

test("ajouter et trier une initiative n’inscrit pas les autres tokens du plateau", () => {
  const prepared = sanitizeInitiativeOrder(["garde", "inconnu", "garde"], tokens);
  prepared.push("ombre");
  assert.deepEqual(sortInitiativeTokenIds(prepared, tokens), ["ombre", "garde"]);
  assert.equal(prepared.includes("mage"), false);
});
