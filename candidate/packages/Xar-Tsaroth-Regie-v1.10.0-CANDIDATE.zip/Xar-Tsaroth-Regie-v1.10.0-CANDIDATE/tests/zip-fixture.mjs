import { readdir, readFile, stat, writeFile } from "node:fs/promises";
import path from "node:path";

const crcTable = Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit += 1) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  return value >>> 0;
});

function crc32(buffer) {
  let value = 0xffffffff;
  for (const byte of buffer) value = crcTable[(value ^ byte) & 0xff] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
}

export function createStoredZip(entries) {
  const localParts = [];
  const centralParts = [];
  let localOffset = 0;
  for (const entry of entries) {
    const name = Buffer.from(String(entry.path).replaceAll("\\", "/"), "utf8");
    const directory = entry.directory || String(entry.path).endsWith("/");
    const data = directory ? Buffer.alloc(0) : Buffer.from(entry.data || "");
    const checksum = crc32(data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt32LE(checksum, 14);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(name.length, 26);
    localParts.push(local, name, data);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(0x0314, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt32LE(checksum, 16);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(name.length, 28);
    const mode = directory ? 0o40755 : 0o100644;
    central.writeUInt32LE((mode << 16) >>> 0, 38);
    central.writeUInt32LE(localOffset, 42);
    centralParts.push(central, name);
    localOffset += local.length + name.length + data.length;
  }

  const centralDirectory = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralDirectory.length, 12);
  end.writeUInt32LE(localOffset, 16);
  return Buffer.concat([...localParts, centralDirectory, end]);
}

async function directoryEntries(root, relative = "") {
  const entries = [];
  for (const item of await readdir(path.join(root, relative), { withFileTypes: true })) {
    const itemRelative = path.posix.join(relative, item.name);
    if (item.isDirectory()) {
      entries.push({ path: `${itemRelative}/`, directory: true });
      entries.push(...await directoryEntries(root, itemRelative));
    } else if (item.isFile()) {
      entries.push({ path: itemRelative, data: await readFile(path.join(root, itemRelative)) });
    }
  }
  return entries;
}

export async function writeDirectoryZip(sourceDirectory, zipPath, topLevelDirectory = "") {
  const source = path.resolve(sourceDirectory);
  if (!(await stat(source)).isDirectory()) throw new Error("Source ZIP invalide.");
  const entries = await directoryEntries(source);
  const prefix = topLevelDirectory ? `${topLevelDirectory.replace(/\/+$/, "")}/` : "";
  const prefixed = prefix
    ? [{ path: prefix, directory: true }, ...entries.map((entry) => ({ ...entry, path: `${prefix}${entry.path}` }))]
    : entries;
  await writeFile(zipPath, createStoredZip(prefixed));
}
