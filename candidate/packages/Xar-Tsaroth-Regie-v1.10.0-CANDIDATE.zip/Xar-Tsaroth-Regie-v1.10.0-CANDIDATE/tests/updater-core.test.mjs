import test from "node:test";
import assert from "node:assert/strict";
import { generateKeyPairSync, sign } from "node:crypto";
import { mkdir, mkdtemp, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { canonicalUpdatePayload, sha256File, writeIntegrityManifest } from "../launcher-core.mjs";
import { applyPendingUpdate, readUpdateStatus } from "../updater-core.mjs";
import { writeDirectoryZip } from "./zip-fixture.mjs";

test("l’auto-update remplace atomiquement le build et conserve un point de retour", async (context) => {
  const sandbox = await mkdtemp(path.join(tmpdir(), "xar-self-update-"));
  context.after(() => rm(sandbox, { recursive: true, force: true }));
  const installation = path.join(sandbox, "Xar-Regie");
  const packageRoot = path.join(sandbox, "package-source");
  const privateRoot = path.join(sandbox, "private", "updates");
  await mkdir(installation, { recursive: true });
  await mkdir(packageRoot, { recursive: true });
  await mkdir(privateRoot, { recursive: true });

  const { publicKey, privateKey } = generateKeyPairSync("ed25519");
  const exportedPublicKey = publicKey.export({ type: "spki", format: "pem" });
  const currentRelease = {
    applicationId: "fr.xar.test",
    displayName: "Xar Test",
    version: "1.8.0",
    channel: "candidate",
    updatePublicKey: exportedPublicKey
  };
  const nextRelease = { ...currentRelease, version: "1.9.0" };
  await writeFile(path.join(installation, "application.json"), `${JSON.stringify(currentRelease, null, 2)}\n`);
  await writeFile(path.join(installation, "old-marker.txt"), "ancienne version\n");
  await writeFile(path.join(packageRoot, "application.json"), `${JSON.stringify(nextRelease, null, 2)}\n`);
  await writeFile(path.join(packageRoot, "launcher.mjs"), "export const version = '1.9.0';\n");
  await writeFile(path.join(packageRoot, "new-marker.txt"), "nouvelle version\n");
  writeIntegrityManifest(packageRoot);

  const archive = path.join(sandbox, "Xar-Tsaroth-Regie-v1.9.0-CANDIDATE.zip");
  await writeDirectoryZip(packageRoot, archive, "Xar-Tsaroth-Regie-v1.9.0-CANDIDATE");
  const packageInfo = {
    url: "https://updates.example.test/Xar-Tsaroth-Regie-v1.9.0-CANDIDATE.zip",
    sha256: sha256File(archive),
    size: (await stat(archive)).size
  };
  const manifest = {
    schemaVersion: 1,
    applicationId: currentRelease.applicationId,
    channel: "candidate",
    version: "1.9.0",
    publishedAt: "2026-08-17T12:00:00.000Z",
    package: packageInfo
  };
  manifest.signature = sign(null, Buffer.from(canonicalUpdatePayload(manifest)), privateKey).toString("base64");
  const pendingPath = path.join(privateRoot, "pending-update.json");
  await writeFile(pendingPath, `${JSON.stringify({
    schemaVersion: 1,
    packagePath: archive,
    manifest,
    allowSameVersion: false
  }, null, 2)}\n`);

  const result = await applyPendingUpdate({ pendingPath, installationRoot: installation, relaunch: false });
  assert.equal(result.version, "1.9.0");
  assert.equal(await readFile(path.join(installation, "new-marker.txt"), "utf8"), "nouvelle version\n");
  await assert.rejects(readFile(path.join(installation, "old-marker.txt")), /ENOENT/);
  assert.equal(await readFile(path.join(result.backupPath, "old-marker.txt"), "utf8"), "ancienne version\n");
  const status = readUpdateStatus(path.join(privateRoot, "update-status.json"));
  assert.equal(status.state, "installed");
  assert.equal(status.version, "1.9.0");
  assert.ok((await readdir(sandbox)).some((name) => name.includes("backup-v1.8.0")));
});

test("un paquet altéré est refusé avant tout remplacement", async (context) => {
  const sandbox = await mkdtemp(path.join(tmpdir(), "xar-self-update-tampered-"));
  context.after(() => rm(sandbox, { recursive: true, force: true }));
  const installation = path.join(sandbox, "Xar-Regie");
  const updates = path.join(sandbox, "private", "updates");
  await mkdir(installation, { recursive: true });
  await mkdir(updates, { recursive: true });
  const { publicKey, privateKey } = generateKeyPairSync("ed25519");
  const release = {
    applicationId: "fr.xar.test",
    version: "1.8.0",
    channel: "candidate",
    updatePublicKey: publicKey.export({ type: "spki", format: "pem" })
  };
  await writeFile(path.join(installation, "application.json"), JSON.stringify(release));
  await writeFile(path.join(installation, "old-marker.txt"), "intact\n");
  const archive = path.join(sandbox, "tampered.zip");
  await writeFile(archive, "contenu altéré");
  const manifest = {
    schemaVersion: 1,
    applicationId: release.applicationId,
    channel: "candidate",
    version: "1.9.0",
    publishedAt: "2026-08-17T12:00:00.000Z",
    package: { url: "https://updates.example.test/tampered.zip", sha256: "d".repeat(64), size: 15 }
  };
  manifest.signature = sign(null, Buffer.from(canonicalUpdatePayload(manifest)), privateKey).toString("base64");
  const pendingPath = path.join(updates, "pending-update.json");
  await writeFile(pendingPath, JSON.stringify({ schemaVersion: 1, packagePath: archive, manifest }));
  await assert.rejects(
    () => applyPendingUpdate({ pendingPath, installationRoot: installation, relaunch: false }),
    /taille|empreinte/i
  );
  assert.equal(await readFile(path.join(installation, "old-marker.txt"), "utf8"), "intact\n");
});
