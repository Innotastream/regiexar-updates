# Régie du Seuil 1.9.1 — Candidate

## Canal de mise à jour actif

- Connexion du launcher au canal public signé `Innotastream/regiexar-updates`.
- Publication publique limitée aux ZIP applicatifs complets et aux manifestes Ed25519.
- Conservation du code source dans le dépôt privé `Innotastream/regiexar`.
- Aucun jeton GitHub n’est demandé, enregistré ou intégré au launcher.

## Parcours de validation prévu

- Installation de l’archive bootstrap 1.9.0 dans son répertoire programme dédié.
- Détection de la 1.9.1 via `candidate/latest.json`.
- Téléchargement du ZIP public, validation de sa taille, de son SHA-256 et de sa signature.
- Extraction protégée, contrôle du manifeste interne, remplacement atomique et relance.
- Vérification que les fiches et données privées restent dans le profil utilisateur.

## Statut

Cette version reste **candidate** jusqu’à validation explicite de l’utilisateur. La 1.8.0 reste la dernière version stable et sa branche de sécurité demeure intacte.
