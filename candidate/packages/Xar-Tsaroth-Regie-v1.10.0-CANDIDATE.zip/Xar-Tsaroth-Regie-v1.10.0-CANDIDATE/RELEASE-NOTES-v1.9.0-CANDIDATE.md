# Régie du Seuil 1.9.0 — Candidate

## Base

- Construite exclusivement depuis la **1.8.0 stable** validée.
- Version produit `1.9.0` déclarée dans `application.json` et `package.json` ; canal `candidate`.
- La 1.8.0 stable, son ZIP et sa branche de sécurité restent inchangés.

## Nouveau launcher du Seuil

- Refonte visuelle complète dans l’identité Xar Tsaroth : chambre violette sombre, matières métalliques, sceau animé et effets dorés/orangés.
- Barre de progression SFX reliée à l’éveil du serveur, au contrôle d’intégrité et au canal signé.
- États techniques synthétiques, commande principale évidente et actions secondaires regroupées.
- Navigation clavier, focus visible, annonces accessibles, comportement responsive et respect de `prefers-reduced-motion`.
- Version applicative visible dans le badge supérieur et rappelée discrètement au bas du launcher.

## Installation et conservation du travail

- `start-windows.bat`, `start.sh` et `npm start` passent par un mini-installateur local.
- Programme copié dans un répertoire applicatif dédié au compte utilisateur ; données privées stockées dans un autre répertoire.
- Réinstallation et changement de build conservent fiches, scènes, médias et `.env.local` privé.
- Import initial de l’ancien dossier `data` sans l’intégrer au programme.
- Refus explicite d’un retour arrière vers un build plus ancien.
- Les anciennes fiches continuent d’être migrées avec sauvegarde préalable ; une fiche réellement issue d’un build futur reste intacte et demande une mise à jour en termes clairs.

## Auto-update complet

- Clé publique Ed25519 dédiée intégrée ; clé privée conservée hors projet, hors Git et hors ZIP.
- Validation de l’identité, du canal et de la signature du manifeste HTTPS.
- Téléchargement avec taille bornée, suivi de progression et contrôle SHA-256.
- Extracteur ZIP interne protégé contre traversée de chemin, liens symboliques, doublons, multi-volume, ZIP64 et expansion excessive.
- Refus des fichiers privés et contrôle de tous les fichiers applicatifs attendus ou inattendus.
- Installation atomique avec point de retour de l’ancien programme, vérification finale et relance automatique.
- Restauration et relance de l’ancienne version si l’installation finale échoue.
- Écran de reconnexion dédié pendant le remplacement, sans message trompeur sur le contexte des fiches.

## Limite volontaire de cette candidate

Le moteur de mise à jour est implémenté et testé de bout en bout avec des paquets signés locaux. L’URL HTTPS du canal reste vide jusqu’à la création du serveur de mises à jour séparé, qui constitue le prochain jalon. Aucun paquet non signé n’est accepté en attendant.
