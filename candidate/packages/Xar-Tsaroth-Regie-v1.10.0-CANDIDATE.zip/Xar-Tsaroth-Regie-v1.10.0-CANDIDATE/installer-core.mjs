import {
  chmodSync,
  copyFileSync,
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync
} from "node:fs";
import path from "node:path";
import {
  INTEGRITY_MANIFEST_FILENAME,
  compareApplicationVersions,
  describeIntegrityFailure,
  listReleaseFiles,
  loadApplicationRelease,
  verifyInstallation
} from "./launcher-core.mjs";

export const INSTALLATION_STATE_FILENAME = "installation-state.json";

function preparePersistentProfile(sourceRoot, privateRoot) {
  const dataDirectory = path.join(privateRoot, "data");
  mkdirSync(privateRoot, { recursive: true, mode: 0o700 });
  mkdirSync(dataDirectory, { recursive: true, mode: 0o700 });
  mkdirSync(path.join(privateRoot, "downloads"), { recursive: true, mode: 0o700 });
  mkdirSync(path.join(privateRoot, "updates"), { recursive: true, mode: 0o700 });

  const sourceEnvironment = path.join(sourceRoot, ".env.local");
  const privateEnvironment = path.join(privateRoot, ".env.local");
  if (existsSync(sourceEnvironment) && !existsSync(privateEnvironment)) copyFileSync(sourceEnvironment, privateEnvironment);
  try { if (existsSync(privateEnvironment)) chmodSync(privateEnvironment, 0o600); } catch {}

  const sourceData = path.join(sourceRoot, "data");
  if (!existsSync(path.join(dataDirectory, "session-state.json")) && existsSync(path.join(sourceData, "session-state.json"))) {
    cpSync(sourceData, dataDirectory, { recursive: true, force: false, errorOnExist: false });
  }
  return dataDirectory;
}

function copyVerifiedRelease(sourceRoot, destinationRoot) {
  rmSync(destinationRoot, { recursive: true, force: true });
  mkdirSync(destinationRoot, { recursive: true, mode: 0o755 });
  const files = [...listReleaseFiles(sourceRoot), INTEGRITY_MANIFEST_FILENAME];
  for (const relative of files) {
    const source = path.join(sourceRoot, ...relative.split("/"));
    const destination = path.join(destinationRoot, ...relative.split("/"));
    mkdirSync(path.dirname(destination), { recursive: true, mode: 0o755 });
    copyFileSync(source, destination);
    try { chmodSync(destination, statSync(source).mode & 0o111 ? 0o755 : 0o644); } catch {}
  }
}

function installedReleaseStatus(installationRoot) {
  if (!existsSync(path.join(installationRoot, "application.json"))) return null;
  try {
    return { release: loadApplicationRelease(installationRoot), integrity: verifyInstallation(installationRoot) };
  } catch {
    return null;
  }
}

function writeInstallationState(privateRoot, state) {
  const destination = path.join(privateRoot, INSTALLATION_STATE_FILENAME);
  const temporary = `${destination}.${process.pid}.partial`;
  writeFileSync(temporary, `${JSON.stringify({
    schemaVersion: 1,
    applicationId: state.applicationId,
    version: state.version,
    installationRoot: state.installationRoot,
    dataRoot: privateRoot,
    installedAt: new Date().toISOString()
  }, null, 2)}\n`, { mode: 0o600 });
  rmSync(destination, { force: true });
  renameSync(temporary, destination);
}

export function installApplication({ sourceRoot, installationRoot, privateRoot }) {
  const source = path.resolve(sourceRoot);
  const destination = path.resolve(installationRoot);
  const profile = path.resolve(privateRoot);
  if (destination === path.dirname(destination) || destination === source) throw new Error("Destination d’installation invalide.");

  const sourceIntegrity = verifyInstallation(source);
  if (!sourceIntegrity.ok) {
    throw new Error(`Le paquet source est incomplet ou altéré : installation refusée. Détail : ${describeIntegrityFailure(sourceIntegrity)}. Décompressez entièrement le ZIP dans un dossier normal avant de relancer start-windows.bat.`);
  }
  const sourceRelease = loadApplicationRelease(source);
  preparePersistentProfile(source, profile);
  const installed = installedReleaseStatus(destination);
  if (installed) {
    if (installed.release.applicationId !== sourceRelease.applicationId) throw new Error("Une autre application occupe déjà le dossier d’installation.");
    const comparison = compareApplicationVersions(installed.release.version, sourceRelease.version);
    if (comparison > 0) throw new Error("Une version applicative plus récente est déjà installée : retour arrière refusé.");
    if (comparison === 0 && installed.integrity.ok) {
      return { installed: false, reason: "already-current", release: installed.release, installationRoot: destination, privateRoot: profile };
    }
  }

  const parent = path.dirname(destination);
  const basename = path.basename(destination);
  mkdirSync(parent, { recursive: true, mode: 0o755 });
  const staging = path.join(parent, `.${basename}.install-stage-${Date.now()}-${process.pid}`);
  const backup = path.join(parent, `.${basename}.install-backup-${Date.now()}-${process.pid}`);
  let activeMoved = false;
  try {
    copyVerifiedRelease(source, staging);
    const stagedRelease = loadApplicationRelease(staging);
    const stagedIntegrity = verifyInstallation(staging);
    if (stagedRelease.applicationId !== sourceRelease.applicationId || stagedRelease.version !== sourceRelease.version || !stagedIntegrity.ok) {
      throw new Error("La copie d’installation n’a pas réussi son contrôle final.");
    }
    if (existsSync(destination)) {
      renameSync(destination, backup);
      activeMoved = true;
    }
    renameSync(staging, destination);
    writeInstallationState(profile, {
      applicationId: stagedRelease.applicationId,
      version: stagedRelease.version,
      installationRoot: destination
    });
    return {
      installed: true,
      reason: installed ? "updated-or-repaired" : "first-install",
      release: stagedRelease,
      installationRoot: destination,
      privateRoot: profile,
      backupPath: activeMoved ? backup : null
    };
  } catch (error) {
    rmSync(staging, { recursive: true, force: true });
    if (activeMoved && existsSync(backup) && !existsSync(destination)) renameSync(backup, destination);
    throw error;
  }
}
