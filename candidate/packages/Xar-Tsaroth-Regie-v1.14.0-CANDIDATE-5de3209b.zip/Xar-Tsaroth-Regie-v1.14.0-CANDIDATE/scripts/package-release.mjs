import { createHash } from "node:crypto";
import {
  mkdirSync,
  readFileSync,
  renameSync,
  rmSync,
  writeFileSync
} from "node:fs";
import path from "node:path";
import { deflateRawSync } from "node:zlib";
import { fileURLToPath } from "node:url";
import {
  INTEGRITY_MANIFEST_FILENAME,
  listReleaseFiles,
  loadApplicationRelease,
  verifyInstallation
} from "../launcher-core.mjs";

const crcTable = Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit += 1) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  return value >>> 0;
});

function crc32(buffer) {
  let value = 0xffffffff;
  for (const byte of buffer) value = crcTable[(value ^ byte) & 0xff] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
}

function archiveBuffer(entries) {
  if (entries.length > 0xffff) throw new Error("Le paquet contient trop de fichiers pour un ZIP standard.");
  const localParts = [];
  const centralParts = [];
  let localOffset = 0;

  for (const entry of entries) {
    const name = Buffer.from(entry.path.replaceAll("\\", "/"), "utf8");
    const plain = entry.data;
    const compressed = plain.length ? deflateRawSync(plain, { level: 9 }) : plain;
    const useCompression = compressed.length < plain.length;
    const payload = useCompression ? compressed : plain;
    for (const size of [plain.length, payload.length, localOffset]) {
      if (size > 0xffffffff) throw new Error("Le paquet dépasse les limites d’un ZIP standard.");
    }
    const checksum = crc32(plain);
    const flags = 0x0800;
    const method = useCompression ? 8 : 0;
    const dosDate = 0x0021;

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(flags, 6);
    local.writeUInt16LE(method, 8);
    local.writeUInt16LE(0, 10);
    local.writeUInt16LE(dosDate, 12);
    local.writeUInt32LE(checksum, 14);
    local.writeUInt32LE(payload.length, 18);
    local.writeUInt32LE(plain.length, 22);
    local.writeUInt16LE(name.length, 26);
    localParts.push(local, name, payload);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(0x0314, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(flags, 8);
    central.writeUInt16LE(method, 10);
    central.writeUInt16LE(0, 12);
    central.writeUInt16LE(dosDate, 14);
    central.writeUInt32LE(checksum, 16);
    central.writeUInt32LE(payload.length, 20);
    central.writeUInt32LE(plain.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt32LE((0o100644 << 16) >>> 0, 38);
    central.writeUInt32LE(localOffset, 42);
    centralParts.push(central, name);
    localOffset += local.length + name.length + payload.length;
  }

  const centralDirectory = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralDirectory.length, 12);
  end.writeUInt32LE(localOffset, 16);
  return Buffer.concat([...localParts, centralDirectory, end]);
}

export function packageRelease(projectRoot, outputPath, { topLevelDirectory } = {}) {
  const root = path.resolve(projectRoot);
  const output = path.resolve(outputPath);
  const release = loadApplicationRelease(root);
  const integrity = verifyInstallation(root);
  if (!integrity.ok) throw new Error("Le projet ne correspond pas à son manifeste d’intégrité.");

  const prefix = `${String(topLevelDirectory || `Xar-Tsaroth-Regie-v${release.version}-${release.channel.toUpperCase()}`).replaceAll("\\", "/").replace(/^\/+|\/+$/g, "")}/`;
  const files = [...listReleaseFiles(root), INTEGRITY_MANIFEST_FILENAME];
  const entries = files.map((relative) => ({
    path: `${prefix}${relative}`,
    data: readFileSync(path.join(root, relative))
  }));
  const archive = archiveBuffer(entries);
  const temporary = `${output}.part`;
  mkdirSync(path.dirname(output), { recursive: true });
  rmSync(temporary, { force: true });
  writeFileSync(temporary, archive, { mode: 0o644 });
  renameSync(temporary, output);
  return {
    output,
    files: files.length,
    size: archive.length,
    sha256: createHash("sha256").update(archive).digest("hex"),
    topLevelDirectory: prefix.slice(0, -1)
  };
}

function isCommandLineEntry() {
  return process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
}

if (isCommandLineEntry()) {
  const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
  const outputPath = process.argv[2];
  if (!outputPath) throw new Error("Usage : node scripts/package-release.mjs <paquet.zip> [dossier-racine]");
  const result = packageRelease(projectRoot, outputPath, { topLevelDirectory: process.argv[3] });
  console.log(JSON.stringify(result, null, 2));
}
