import test from "node:test";
import assert from "node:assert/strict";
import { access, mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  extractZipArchive,
  locateExtractedApplicationRoot,
  verifyInstallation
} from "../launcher-core.mjs";
import { packageRelease } from "../scripts/package-release.mjs";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("le paquet de mise à jour exclut les fichiers hors livraison et reste intègre", async (context) => {
  const temporary = await mkdtemp(path.join(tmpdir(), "xar-release-package-"));
  context.after(() => rm(temporary, { recursive: true, force: true }));
  const archive = path.join(temporary, "candidate.zip");
  const packaged = packageRelease(projectRoot, archive);
  assert.equal(packaged.files, verifyInstallation(projectRoot).checkedFiles + 1);

  const extraction = path.join(temporary, "extracted");
  await extractZipArchive(archive, extraction);
  const applicationRoot = locateExtractedApplicationRoot(extraction);
  assert.equal(verifyInstallation(applicationRoot).ok, true);
  await assert.rejects(access(path.join(applicationRoot, ".github")), /ENOENT/);
  await access(path.join(applicationRoot, "build", "installer.nsh"));
  await assert.rejects(access(path.join(applicationRoot, "release-publish-request.json")), /ENOENT/);
});
