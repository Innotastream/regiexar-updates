# Architecture — Application Windows actuelle et cible distante

## Décision retenue

La version locale distribuable utilise désormais une enveloppe **Electron** installable pour la Régie MJ. Elle embarque son moteur, conserve le serveur Node actuel dans un processus isolé et affiche le launcher puis la table dans une seule fenêtre sécurisée. Cette décision remplace le mini-installateur ZIP/Edge de la 1.10.1.

Le build applicatif 1.14.1 candidate reste volontairement une régie locale/LAN. La même enveloppe Windows offre une entrée MJ et une entrée Joueur, avec comptes et rôles gérés par l’administration locale, sans transformer le serveur local en service Internet ni remplacer le chantier futur des comptes distants.

## Sécurité locale livrée en 1.14.1

- Chaque personne possède un compte local avec identifiant unique, rôle `player` ou `gm` et vérificateur scrypt salé. Aucun mot de passe en clair n’est enregistré.
- Une connexion valide crée un jeton de session aléatoire éphémère, conservé uniquement en mémoire serveur et transmis à Electron dans un cookie `HttpOnly`, `SameSite=Strict`. La session enregistre séparément son mode effectif `player` ou `gm`; un compte MJ ouvert en mode Joueur ne satisfait donc aucune autorisation MJ.
- La révocation, le changement de rôle ou de mot de passe et la suppression d’un compte incrémentent ou retirent son autorisation, ferment ses flux en direct et invalident immédiatement ses anciennes sessions.
- La console d’administration locale possède un vérificateur scrypt distinct, limite les tentatives et permet de créer, révoquer, restaurer, supprimer, promouvoir ou rétrograder un compte, ainsi que remplacer son mot de passe.
- Chaque utilisateur peut changer son propre mot de passe après vérification du mot de passe actuel. Le nouveau vérificateur scrypt remplace l’ancien et une nouvelle session de même mode est émise.
- La présence en ligne est calculée à partir des flux de synchronisation réellement ouverts et porte le mode de session, jamais le niveau maximal du compte.
- Les secrets récupérables utilisent un coffre AES-256-GCM. La clé aléatoire de 256 bits est protégée par `safeStorage` d’Electron, donc par le coffre du système Windows pour l’application installée.
- `configuration.json` contient seulement les réglages non secrets. Les webhooks, le mot de passe OVH et la dernière adresse de table restent dans le coffre ; `.env.local` n’est plus requis et sert uniquement à une migration historique ponctuelle.
- Le stockage natif des fiches Joueur est écrit atomiquement hors du programme, conserve une copie précédente et vérifie que la fiche appartient bien au compte authentifié courant.
- Une fiche supprimée depuis la console est d’abord copiée dans `backups/characters-before-deletion-*.json`, puis retirée du stockage, de la session et de ses tokens liés avec un tombstone anti-résurrection.
- La passerelle Electron refuse qu’une page Joueur appelle la navigation MJ ; seul le launcher local peut changer de rôle.
- L’adresse Joueur est générique. Le launcher rejette tout identifiant, mot de passe, paramètre ou fragment dans cette adresse afin qu’aucun secret ne circule dans un lien, un historique ou un journal HTTP.
- Les sauvegardes transportables excluent le registre de comptes, les vérificateurs, le coffre, la configuration et le pont ChatGPT ; chaque import vérifie les chemins et empreintes, puis sauvegarde les fichiers remplacés.
- L’import `.docx` est borné avant et après décompression, refuse les chemins ZIP dangereux et produit uniquement une fiche appartenant au compte connecté.

## Garantie réaliste

Une donnée que l’utilisateur est autorisé à afficher peut toujours être observée sur sa propre machine. La garantie réalisable et obligatoire est donc : **aucune donnée que le joueur n’est pas autorisé à voir n’est envoyée à son application**. Cacher un champ avec du CSS ou du JavaScript ne constitue jamais une protection.

## Cible distante encore prévue

```text
Future application MJ ── HTTPS / WSS ────┐
                                         ├─ Supabase Auth + API/RPC autoritaire
Future application Joueur ─ HTTPS / WSS ─┘                │
                                                         ├─ PostgreSQL + RLS
                                                         ├─ Realtime filtré
                                                         ├─ Storage privé
                                                         └─ Fonctions serveur / secrets
```

- HTTPS et WSS uniquement, avec refus des transports non chiffrés.
- Chaque message temps réel est validé et autorisé ; une connexion ouverte ne donne aucun droit supplémentaire.
- Le serveur est l’unique autorité pour les déplacements, jets, tours, changements de scène, permissions et publications.
- Les mises à jour des launchers sont signées. La clé privée de signature reste hors du dépôt et hors des postes joueurs.

## Comptes et sessions de la cible distante

- Un compte par personne, avec e-mail ou identifiant et mot de passe gérés par Supabase Auth.
- Aucun mot de passe en clair n’est enregistré par la Régie, dans un fichier `.env`, dans le navigateur, dans les logs ou dans une sauvegarde de partie.
- MFA TOTP obligatoire pour les comptes MJ, proposé aux joueurs.
- Jetons courts et renouvellement rotatif ; révocation à la déconnexion, au changement de mot de passe et depuis l’écran d’administration MJ.
- Le refresh token est conservé dans le coffre de secrets du système d’exploitation via Tauri, jamais dans `localStorage`.
- Limitation des tentatives, délai progressif, récupération de compte et journal des connexions.

## Autorisations et séparation des données

PostgreSQL applique des politiques **Row Level Security** sur toutes les tables exposées. Le principe est « refus par défaut », puis autorisations explicites selon la campagne, le rôle et la relation au personnage.

Tables séparées prévues :

- `campaigns` et `campaign_members` : propriétaire MJ et membres invités ;
- `scenes`, `scene_combats`, `initiative_entries` : état de chaque scène ;
- `characters_public` : partie partageable de la fiche ;
- `characters_owner` : partie modifiable par le joueur propriétaire et le MJ ;
- `characters_gm_secret` : secrets visibles uniquement par le MJ ;
- `tokens_public` : apparence et position autorisées ;
- `tokens_private` : PV, mana, dégâts, statistiques et notes MJ non révélés ;
- `token_templates_private` : bestiaire du MJ ;
- `rolls` : portée `public`, `owner` ou `gm` appliquée côté serveur ;
- `media_objects` : métadonnées de fichiers privés et droits d’accès.

Les rôles ou permissions ne sont jamais déduits d’un champ modifiable par le joueur. Une action vérifie à chaque requête : identité, appartenance à la campagne, rôle, propriété du personnage/token et état de la session.

## Temps réel sans fuite

- Le joueur s’abonne uniquement aux lignes qu’il peut lire selon les politiques RLS.
- Les secrets MJ vivent dans des tables distinctes auxquelles le rôle joueur n’a aucun `SELECT`.
- Les captures Discord sont produites côté serveur à partir d’un DTO public, jamais à partir du DOM MJ.
- Le déplacement d’un token passe par une fonction `move_token` qui vérifie le contrôleur, borne les coordonnées et aimante le token à la grille avant écriture.
- Les jets passent par une fonction serveur utilisant un générateur cryptographique et enregistrant l’auteur réel (`MJ` ou nom du joueur).
- Reconnexion et conflits utilisent un numéro de révision par scène et des opérations idempotentes.

## Images, musique et pièces jointes

- Buckets privés ; aucun fichier de campagne sensible n’est public par défaut.
- Téléchargement par URL signée de courte durée ou requête authentifiée.
- Vérification du type réel du fichier, taille maximale, renommage serveur et analyse antivirus avant partage.
- Les clés Discord, OVH et autres secrets d’intégration restent dans les fonctions serveur ou un coffre de secrets. Aucune `service_role`, clé webhook, clé FTP/SFTP ou mot de passe ne doit être compilé dans un launcher.
- Les références ChatGPT restent un flux assisté sans capturer cookies, mot de passe ou session ChatGPT.

## Durcissement de l’application actuelle et des futurs launchers

- Electron actuel : `nodeIntegration` désactivé, isolation de contexte et bac à sable activés, permissions refusées par défaut, navigation limitée aux origines locales MJ ou à l’adresse Joueur générique validée.
- Aucune commande système générique n’est exposée au contenu Web. ChatGPT passe par une route locale à liste d’autorisation stricte puis le navigateur du système.
- Politique CSP stricte, navigation distante interdite dans la fenêtre principale, ouverture des liens externes via le navigateur du système.
- Installateurs et mises à jour signés ; refus d’une mise à jour sans signature valide.
- L’installeur Windows est toujours installé pour tous les comptes sous `C:\Program Files\Xar-Tsaroth` et sa publication échoue si la signature Authenticode ou l’identité de l’éditeur est absente.
- L’installeur Electron applique déjà ce découpage : enveloppe Windows, contenu applicatif actualisable et profil de données sont distincts ; les fiches ne sont jamais incluses dans le remplacement applicatif et le retour du code n’impose aucun retour des données.
- Cache local minimal, borné au compte et placé dans le profil privé ; aucun secret MJ ni bestiaire privé dans le cache Joueur.
- Session serveur supprimée à la déconnexion et invalidation immédiate de toutes les sessions d’un compte révoqué ou modifié.

## Tests obligatoires avant ouverture Internet

1. Tests RLS automatisés pour chaque action et chaque rôle, y compris accès horizontal à la fiche d’un autre joueur.
2. Tests prouvant que les réponses Joueur, événements Realtime et URLs médias ne contiennent aucun champ MJ.
3. Tests de falsification d’identifiants, rejeu, déplacement d’un token tiers et changement de rôle.
4. Tests de limites et validation sur chaque message WebSocket et chaque fichier.
5. Analyse de dépendances et de secrets à chaque build, puis audit externe avant la première version publique.
6. Sauvegardes chiffrées, restauration testée, rotation des clés et procédure de réponse à incident.

## Ordre de réalisation

1. Extraire le modèle de données actuel vers PostgreSQL et écrire toutes les politiques RLS.
2. Remplacer le registre de comptes local par Auth + invitations de campagne à durée limitée, sans réintroduire de secret dans les liens.
3. Déplacer les mutations sensibles vers des fonctions serveur autoritaires.
4. Brancher Realtime, puis vérifier les DTO publics avec des tests de non-divulgation.
5. Construire l’application Joueur et choisir son enveloppe après validation du modèle distant ; intégrer alors le coffre de secrets du système.
6. Signer les installateurs et le canal de mise à jour ; effectuer l’audit avant publication.

## Références de sécurité

- [OWASP — Authorization Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html)
- [OWASP — Authentication Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html)
- [OWASP — Password Storage Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html)
- [OWASP — WebSocket Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/WebSocket_Security_Cheat_Sheet.html)
- [Supabase — Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security)
- [Supabase — sécurisation des données et clés serveur](https://supabase.com/docs/guides/database/secure-data)
- [Supabase — fichiers privés et URLs signées](https://supabase.com/docs/guides/storage/serving/downloads)
- [Tauri 2 — signatures des mises à jour](https://v2.tauri.app/plugin/updater/)
